package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderCopy
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.AppSettingsSnapshot
import com.example.ui.navigation.RustatioRoutes
import com.example.ui.sessions.SessionDetailScreen
import com.example.ui.sessions.SessionDetailViewModel
import com.example.ui.sessions.SessionsScreen
import com.example.ui.sessions.SessionsViewModel
import com.example.ui.settings.AboutSettingsScreen
import com.example.ui.settings.AppearanceSettingsScreen
import com.example.ui.settings.ConnectionSettingsScreen
import com.example.ui.settings.DetectionTipsScreen
import com.example.ui.settings.GeneralSettingsScreen
import com.example.ui.settings.ImportExportSettingsScreen
import com.example.ui.settings.PresetsSettingsScreen
import com.example.ui.settings.ProxySettingsScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel
import com.example.ui.theme.RustatioTheme
import com.example.ui.theme.RustatioThemeTokens
import com.example.ui.watch.WatchScreen
import com.example.ui.watch.WatchViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val container = RustatioAppContainer.get(applicationContext)
    setContent {
      val settings by
        container.repository.settingsFlow.collectAsStateWithLifecycle(
          initialValue = AppSettingsSnapshot()
        )
      RustatioTheme(themeMode = settings.themeMode) {
        RustatioAppShell(container = container)
      }
    }
  }
}

private data class RootNavItem(
  val route: String,
  val label: String,
  val icon: ImageVector,
  val testTag: String,
)

@Composable
fun RustatioAppShell(container: RustatioAppContainer) {
  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route
  val showBottomOrRailNav = RustatioRoutes.isRootRoute(currentRoute)
  val colors = RustatioThemeTokens.colors

  val rootItems =
    remember {
      listOf(
        RootNavItem(RustatioRoutes.SESSIONS, "Phiên", Icons.Rounded.SwapVert, "nav_sessions"),
        RootNavItem(RustatioRoutes.WATCH, "Theo dõi", Icons.Rounded.FolderCopy, "nav_watch"),
        RootNavItem(RustatioRoutes.SETTINGS, "Cài đặt", Icons.Rounded.Settings, "nav_settings"),
      )
    }

  val sessionsViewModel: SessionsViewModel =
    viewModel(factory = SessionsViewModel.factory(container.repository))
  val watchViewModel: WatchViewModel =
    viewModel(factory = WatchViewModel.factory(container.repository))
  val settingsViewModel: SettingsViewModel =
    viewModel(factory = SettingsViewModel.factory(container.repository))

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useRail = maxWidth >= 840.dp

    Scaffold(
      modifier = Modifier.fillMaxSize(),
      containerColor = colors.background,
      contentWindowInsets = WindowInsets.safeDrawing,
      bottomBar = {
        if (showBottomOrRailNav && !useRail) {
          NavigationBar(
            containerColor = colors.surface,
            contentColor = colors.textPrimary,
          ) {
            rootItems.forEach { item ->
              val selected = currentRoute == item.route
              NavigationBarItem(
                selected = selected,
                onClick = {
                  navController.navigate(item.route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                      saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                  }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                colors =
                  NavigationBarItemDefaults.colors(
                    selectedIconColor = colors.primary,
                    selectedTextColor = colors.primary,
                    indicatorColor = colors.primaryContainer,
                    unselectedIconColor = colors.textSecondary,
                    unselectedTextColor = colors.textSecondary,
                  ),
                modifier = Modifier.testTag(item.testTag),
              )
            }
          }
        }
      },
    ) { innerPadding ->
      Row(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
        if (showBottomOrRailNav && useRail) {
          NavigationRail(containerColor = colors.surface) {
            rootItems.forEach { item ->
              NavigationRailItem(
                selected = currentRoute == item.route,
                onClick = {
                  navController.navigate(item.route) {
                    popUpTo(navController.graph.findStartDestination().id) {
                      saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                  }
                },
                icon = { Icon(item.icon, contentDescription = item.label) },
                label = { Text(item.label) },
                modifier = Modifier.testTag(item.testTag),
              )
            }
          }
        }

        NavHost(
          navController = navController,
          startDestination = RustatioRoutes.SESSIONS,
          modifier = Modifier.weight(1f).fillMaxSize(),
        ) {
          composable(RustatioRoutes.SESSIONS) {
            SessionsScreen(
              viewModel = sessionsViewModel,
              onOpenSessionDetail = { id ->
                navController.navigate(RustatioRoutes.sessionDetail(id))
              },
            )
          }

          composable(
            route = RustatioRoutes.SESSION_DETAIL,
            arguments = listOf(navArgument("instanceId") { type = NavType.StringType }),
          ) { entry ->
            val instanceId = entry.arguments?.getString("instanceId").orEmpty()
            val detailVm: SessionDetailViewModel =
              viewModel(
                key = "detail_$instanceId",
                factory = SessionDetailViewModel.factory(instanceId, container.repository),
              )
            SessionDetailScreen(
              viewModel = detailVm,
              onNavigateBack = { navController.popBackStack() },
            )
          }

          composable(RustatioRoutes.WATCH) {
            WatchScreen(viewModel = watchViewModel)
          }

          composable(RustatioRoutes.SETTINGS) {
            SettingsScreen(
              viewModel = settingsViewModel,
              onNavigateSubScreen = { route -> navController.navigate(route) },
            )
          }

          composable(RustatioRoutes.SETTINGS_GENERAL) {
            GeneralSettingsScreen(
              viewModel = settingsViewModel,
              onNavigateBack = { navController.popBackStack() },
            )
          }
          composable(RustatioRoutes.SETTINGS_APPEARANCE) {
            AppearanceSettingsScreen(
              viewModel = settingsViewModel,
              onNavigateBack = { navController.popBackStack() },
            )
          }
          composable(RustatioRoutes.SETTINGS_CONNECTION) {
            ConnectionSettingsScreen(
              viewModel = settingsViewModel,
              onNavigateBack = { navController.popBackStack() },
            )
          }
          composable(RustatioRoutes.SETTINGS_PROXY) {
            ProxySettingsScreen(
              viewModel = settingsViewModel,
              onNavigateBack = { navController.popBackStack() },
            )
          }
          composable(RustatioRoutes.SETTINGS_PRESETS) {
            PresetsSettingsScreen(
              viewModel = settingsViewModel,
              onNavigateBack = { navController.popBackStack() },
            )
          }
          composable(RustatioRoutes.SETTINGS_IMPORT_EXPORT) {
            ImportExportSettingsScreen(
              viewModel = settingsViewModel,
              onNavigateBack = { navController.popBackStack() },
            )
          }
          composable(RustatioRoutes.SETTINGS_TIPS) {
            DetectionTipsScreen(onNavigateBack = { navController.popBackStack() })
          }
          composable(RustatioRoutes.SETTINGS_ABOUT) {
            AboutSettingsScreen(onNavigateBack = { navController.popBackStack() })
          }
        }
      }
    }
  }
}
