package com.example.data.local

import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.PostStopAction
import com.example.domain.model.Preset
import com.example.domain.model.TorrentFile
import com.example.domain.model.TorrentInfo
import org.json.JSONArray
import org.json.JSONObject

object JsonCodecs {
  fun encodeTorrent(t: TorrentInfo): String {
    val obj = JSONObject()
    obj.put("info_hash_hex", t.infoHashHex)
    obj.put("announce", t.announce)
    val tiers = JSONArray()
    t.announceList.forEach { tier ->
      val arr = JSONArray()
      tier.forEach { arr.put(it) }
      tiers.put(arr)
    }
    obj.put("announce_list", tiers)
    obj.put("name", t.name)
    obj.put("total_size", t.totalSize)
    obj.put("piece_length", t.pieceLength)
    obj.put("num_pieces", t.numPieces)
    if (t.creationDate != null) obj.put("creation_date", t.creationDate)
    if (t.comment != null) obj.put("comment", t.comment)
    if (t.createdBy != null) obj.put("created_by", t.createdBy)
    obj.put("is_single_file", t.isSingleFile)
    obj.put("file_count", t.fileCount)
    val filesArr = JSONArray()
    t.files.forEach { f ->
      filesArr.put(JSONObject().put("path", f.path).put("size", f.size))
    }
    obj.put("files", filesArr)
    return obj.toString()
  }

  fun decodeTorrent(json: String?): TorrentInfo? {
    if (json.isNullOrBlank()) return null
    return runCatching {
      val obj = JSONObject(json)
      val tiers = mutableListOf<List<String>>()
      val tiersArr = obj.optJSONArray("announce_list")
      if (tiersArr != null) {
        for (i in 0 until tiersArr.length()) {
          val sub = tiersArr.optJSONArray(i) ?: continue
          val urls = mutableListOf<String>()
          for (j in 0 until sub.length()) {
            val u = sub.optString(j)
            if (u.isNotBlank()) urls.add(u)
          }
          if (urls.isNotEmpty()) tiers.add(urls)
        }
      }
      val files = mutableListOf<TorrentFile>()
      val filesArr = obj.optJSONArray("files")
      if (filesArr != null) {
        for (i in 0 until filesArr.length()) {
          val f = filesArr.optJSONObject(i) ?: continue
          files.add(TorrentFile(f.optString("path"), f.optLong("size", 0L)))
        }
      }
      TorrentInfo(
        infoHashHex = obj.optString("info_hash_hex"),
        announce = obj.optString("announce"),
        announceList = tiers,
        name = obj.optString("name"),
        totalSize = obj.optLong("total_size", 0L),
        pieceLength = obj.optLong("piece_length", 0L),
        numPieces = obj.optInt("num_pieces", 0),
        creationDate = if (obj.has("creation_date")) obj.optLong("creation_date") else null,
        comment = obj.optString("comment").takeIf { it.isNotBlank() },
        createdBy = obj.optString("created_by").takeIf { it.isNotBlank() },
        isSingleFile = obj.optBoolean("is_single_file", true),
        fileCount = obj.optInt("file_count", files.size),
        files = files,
      )
    }.getOrNull()
  }

  fun encodeConfig(c: FakerConfig): String {
    val obj = JSONObject()
    obj.put("uploadRate", c.uploadRateKBs)
    obj.put("downloadRate", c.downloadRateKBs)
    obj.put("port", c.port)
    obj.put("vpnPortSync", c.vpnPortSync)
    obj.put("selectedClient", c.clientType.id)
    obj.put("selectedClientVersion", c.clientVersion)
    obj.put("completionPercent", c.completionPercent)
    obj.put("initialUploaded", c.initialUploadedMB)
    obj.put("randomizeRates", c.randomizeRates)
    obj.put("randomRangePercent", c.randomRangePercent)
    obj.put("randomizeRatio", c.randomizeRatio)
    obj.put("randomRatioRangePercent", c.randomRatioRangePercent)
    obj.put("updateIntervalSeconds", c.updateIntervalSeconds)
    obj.put("scrapeInterval", c.scrapeIntervalSeconds)
    obj.put("stopAtRatioEnabled", c.stopAtRatioEnabled)
    obj.put("stopAtRatio", c.stopAtRatio)
    if (c.effectiveStopAtRatio != null) obj.put("effectiveStopAtRatio", c.effectiveStopAtRatio)
    obj.put("stopAtUploadedEnabled", c.stopAtUploadedEnabled)
    obj.put("stopAtUploadedGB", c.stopAtUploadedGB)
    obj.put("stopAtDownloadedEnabled", c.stopAtDownloadedEnabled)
    obj.put("stopAtDownloadedGB", c.stopAtDownloadedGB)
    obj.put("stopAtSeedTimeEnabled", c.stopAtSeedTimeEnabled)
    obj.put("stopAtSeedTimeHours", c.stopAtSeedTimeHours)
    obj.put("idleWhenNoLeechers", c.idleWhenNoLeechers)
    obj.put("idleWhenNoSeeders", c.idleWhenNoSeeders)
    obj.put("postStopAction", c.postStopAction.wireName)
    obj.put("progressiveRatesEnabled", c.progressiveRatesEnabled)
    obj.put("targetUploadRate", c.targetUploadRateKBs)
    obj.put("targetDownloadRate", c.targetDownloadRateKBs)
    obj.put("progressiveDurationHours", c.progressiveDurationHours)
    return obj.toString()
  }

  fun decodeConfig(json: String?): FakerConfig {
    if (json.isNullOrBlank()) return FakerConfig()
    return runCatching {
      val obj = JSONObject(json)
      val clientType = ClientType.fromId(obj.optString("selectedClient", "qbittorrent"))
      FakerConfig(
        uploadRateKBs = obj.optDouble("uploadRate", 50.0),
        downloadRateKBs = obj.optDouble("downloadRate", 0.0),
        port = obj.optInt("port", clientType.defaultPort),
        vpnPortSync = obj.optBoolean("vpnPortSync", false),
        clientType = clientType,
        clientVersion =
          obj.optString("selectedClientVersion").takeIf { it.isNotBlank() }
            ?: clientType.defaultVersion,
        completionPercent = obj.optDouble("completionPercent", 100.0),
        initialUploadedMB = obj.optLong("initialUploaded", 0L),
        randomizeRates = obj.optBoolean("randomizeRates", true),
        randomRangePercent = obj.optDouble("randomRangePercent", 20.0),
        randomizeRatio = obj.optBoolean("randomizeRatio", false),
        randomRatioRangePercent = obj.optDouble("randomRatioRangePercent", 10.0),
        updateIntervalSeconds = obj.optInt("updateIntervalSeconds", 5),
        scrapeIntervalSeconds = obj.optInt("scrapeInterval", 60),
        stopAtRatioEnabled = obj.optBoolean("stopAtRatioEnabled", false),
        stopAtRatio = obj.optDouble("stopAtRatio", 2.0),
        effectiveStopAtRatio =
          if (obj.has("effectiveStopAtRatio") && !obj.isNull("effectiveStopAtRatio")) {
            obj.optDouble("effectiveStopAtRatio")
          } else null,
        stopAtUploadedEnabled = obj.optBoolean("stopAtUploadedEnabled", false),
        stopAtUploadedGB = obj.optDouble("stopAtUploadedGB", 10.0),
        stopAtDownloadedEnabled = obj.optBoolean("stopAtDownloadedEnabled", false),
        stopAtDownloadedGB = obj.optDouble("stopAtDownloadedGB", 10.0),
        stopAtSeedTimeEnabled = obj.optBoolean("stopAtSeedTimeEnabled", false),
        stopAtSeedTimeHours = obj.optDouble("stopAtSeedTimeHours", 24.0),
        idleWhenNoLeechers = obj.optBoolean("idleWhenNoLeechers", false),
        idleWhenNoSeeders = obj.optBoolean("idleWhenNoSeeders", false),
        postStopAction = PostStopAction.fromWire(obj.optString("postStopAction")),
        progressiveRatesEnabled = obj.optBoolean("progressiveRatesEnabled", false),
        targetUploadRateKBs = obj.optDouble("targetUploadRate", 100.0),
        targetDownloadRateKBs = obj.optDouble("targetDownloadRate", 200.0),
        progressiveDurationHours = obj.optDouble("progressiveDurationHours", 1.0),
      )
    }.getOrDefault(FakerConfig())
  }

  /**
   * Compatible with Rustatio desktop/web export JSON format (`type: "rustatio-preset"`).
   */
  fun exportPresetJson(preset: Preset): String {
    val root = JSONObject()
    root.put("type", "rustatio-preset")
    root.put("version", 1)
    root.put("name", preset.name)
    root.put("description", preset.description)
    root.put("icon", preset.icon)
    root.put("created_at", preset.createdAt ?: "")
    root.put("settings", JSONObject(encodeConfig(preset.config)))
    return root.toString(2)
  }

  fun importPresetJson(rawJson: String): Result<Preset> =
    runCatching {
      val root = JSONObject(rawJson)
      val type = root.optString("type")
      require(type == "rustatio-preset" && root.has("settings")) {
        "Tệp cấu hình không đúng định dạng Rustatio preset (thiếu type='rustatio-preset' hoặc settings)."
      }
      val settingsObj = root.getJSONObject("settings")
      val config = decodeConfig(settingsObj.toString())
      val name = root.optString("name").ifBlank { "Preset đã nhập" }
      val desc = root.optString("description").ifBlank { "Preset nhập từ tệp JSON" }
      val icon = root.optString("icon").ifBlank { "folder" }
      val created = root.optString("created_at").takeIf { it.isNotBlank() }
      Preset(
        id = "custom-${System.currentTimeMillis()}",
        name = name,
        description = desc,
        icon = icon,
        recommended = false,
        custom = true,
        createdAt = created,
        config = config,
      )
    }

  fun encodeTags(tags: List<String>): String =
    JSONArray().apply { tags.forEach { put(it) } }.toString()

  fun decodeTags(json: String?): List<String> {
    if (json.isNullOrBlank()) return emptyList()
    return runCatching {
      val arr = JSONArray(json)
      buildList {
        for (i in 0 until arr.length()) {
          val s = arr.optString(i).trim()
          if (s.isNotEmpty()) add(s)
        }
      }
    }.getOrDefault(emptyList())
  }
}
