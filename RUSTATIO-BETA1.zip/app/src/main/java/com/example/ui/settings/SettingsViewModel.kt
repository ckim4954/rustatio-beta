package com.example.ui.settings

import android.content.ContentResolver
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppSettingsSnapshot
import com.example.data.local.JsonCodecs
import com.example.data.repository.RustatioRepository
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.FakerConfig
import com.example.domain.model.LogLevel
import com.example.domain.model.NetworkStatus
import com.example.domain.model.Preset
import com.example.domain.model.ProxySettings
import com.example.domain.model.ProxyType
import com.example.domain.model.RunMode
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface ConnectionTestState {
  data object Idle : ConnectionTestState
  data object Testing : ConnectionTestState
  data class Success(val message: String) : ConnectionTestState
  data class Error(val message: String) : ConnectionTestState
}

data class SettingsUiState(
  val settings: AppSettingsSnapshot = AppSettingsSnapshot(),
  val customPresets: List<Preset> = emptyList(),
  val builtInPresets: List<Preset> = BuiltInPresets.all,
  val proxyDraft: ProxySettings = ProxySettings(),
  val serverUrlDraft: String = "",
  val serverTokenDraft: String = "",
  val proxyTestState: ConnectionTestState = ConnectionTestState.Idle,
  val serverTestState: ConnectionTestState = ConnectionTestState.Idle,
  val networkStatus: NetworkStatus? = null,
  val isNetworkLoading: Boolean = false,
  val isSaving: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingDeletePreset: Preset? = null,
)

private data class SettingsDraftControls(
  val proxyDraft: ProxySettings? = null,
  val serverUrlDraft: String? = null,
  val serverTokenDraft: String? = null,
  val proxyTestState: ConnectionTestState = ConnectionTestState.Idle,
  val serverTestState: ConnectionTestState = ConnectionTestState.Idle,
  val networkStatus: NetworkStatus? = null,
  val isNetworkLoading: Boolean = false,
  val isSaving: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingDeletePreset: Preset? = null,
)

class SettingsViewModel(
  private val repository: RustatioRepository,
) : ViewModel() {

  private val controls = MutableStateFlow(SettingsDraftControls())

  val uiState: StateFlow<SettingsUiState> =
    combine(
      repository.settingsFlow,
      repository.customPresetsFlow,
      controls,
    ) { settings, customPresets, ctrl ->
      SettingsUiState(
        settings = settings,
        customPresets = customPresets,
        proxyDraft = ctrl.proxyDraft ?: settings.proxy,
        serverUrlDraft = ctrl.serverUrlDraft ?: settings.serverUrl,
        serverTokenDraft = ctrl.serverTokenDraft ?: settings.serverToken,
        proxyTestState = ctrl.proxyTestState,
        serverTestState = ctrl.serverTestState,
        networkStatus = ctrl.networkStatus,
        isNetworkLoading = ctrl.isNetworkLoading,
        isSaving = ctrl.isSaving,
        actionMessage = ctrl.actionMessage,
        errorMessage = ctrl.errorMessage,
        pendingDeletePreset = ctrl.pendingDeletePreset,
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000L),
      initialValue = SettingsUiState(),
    )

  fun setThemeMode(mode: ThemeMode) {
    viewModelScope.launch { repository.setThemeMode(mode) }
  }

  fun setRunMode(mode: RunMode) {
    viewModelScope.launch {
      repository.setRunMode(mode)
      if (mode == RunMode.SERVER && uiState.value.settings.serverUrl.isNotBlank()) {
        repository.refreshServerInstances()
      }
    }
  }

  fun setLogLevel(level: LogLevel) {
    viewModelScope.launch {
      repository.setLogLevel(level)
      controls.update { it.copy(actionMessage = "Đã cập nhật mức nhật ký: ${level.labelVi}") }
    }
  }

  fun updateServerDraft(url: String, token: String) {
    controls.update {
      it.copy(
        serverUrlDraft = url,
        serverTokenDraft = token,
        serverTestState = ConnectionTestState.Idle,
      )
    }
  }

  fun saveServerConnection() {
    val url = uiState.value.serverUrlDraft.trim()
    val token = uiState.value.serverTokenDraft.trim()
    if (url.isNotBlank() && !url.startsWith("http://") && !url.startsWith("https://")) {
      controls.update {
        it.copy(errorMessage = "Địa chỉ máy chủ phải bắt đầu bằng http:// hoặc https://")
      }
      return
    }
    viewModelScope.launch {
      controls.update { it.copy(isSaving = true, errorMessage = null, actionMessage = null) }
      repository.saveServerConnection(url, token)
      if (uiState.value.settings.runMode == RunMode.SERVER && url.isNotBlank()) {
        repository.refreshServerInstances()
      }
      controls.update {
        it.copy(
          isSaving = false,
          serverUrlDraft = null,
          serverTokenDraft = null,
          actionMessage = "Đã lưu thông tin kết nối máy chủ",
        )
      }
    }
  }

  fun testServerConnection() {
    val url = uiState.value.serverUrlDraft.trim()
    val token = uiState.value.serverTokenDraft.trim()
    viewModelScope.launch {
      controls.update { it.copy(serverTestState = ConnectionTestState.Testing) }
      repository
        .testServerConnection(url, token)
        .onSuccess {
          controls.update {
            it.copy(serverTestState = ConnectionTestState.Success("Kết nối máy chủ Rustatio thành công"))
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(
              serverTestState =
                ConnectionTestState.Error(err.message ?: "Không thể kết nối đến máy chủ"),
            )
          }
        }
    }
  }

  fun updateProxyDraft(transform: (ProxySettings) -> ProxySettings) {
    val current = uiState.value.proxyDraft
    controls.update {
      it.copy(
        proxyDraft = transform(current),
        proxyTestState = ConnectionTestState.Idle,
        errorMessage = null,
      )
    }
  }

  fun selectProxyType(type: ProxyType) {
    updateProxyDraft { p ->
      val nextPort = if (p.port == p.type.defaultPort) type.defaultPort else p.port
      p.copy(type = type, port = nextPort)
    }
  }

  fun saveProxySettings() {
    val draft = uiState.value.proxyDraft
    if (draft.enabled) {
      if (draft.host.isBlank()) {
        controls.update { it.copy(errorMessage = "Vui lòng nhập địa chỉ máy chủ Proxy (Host)") }
        return
      }
      if (draft.port !in 1..65535) {
        controls.update { it.copy(errorMessage = "Cổng Proxy phải nằm trong khoảng 1–65535") }
        return
      }
    }
    viewModelScope.launch {
      controls.update { it.copy(isSaving = true, errorMessage = null, actionMessage = null) }
      repository
        .saveProxySettings(draft)
        .onSuccess {
          controls.update {
            it.copy(
              isSaving = false,
              proxyDraft = null,
              actionMessage = "Đã lưu cấu hình Proxy",
            )
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isSaving = false, errorMessage = err.message ?: "Không thể lưu Proxy")
          }
        }
    }
  }

  fun testProxyConnection() {
    val draft = uiState.value.proxyDraft
    if (draft.host.isBlank() || draft.port !in 1..65535) {
      controls.update {
        it.copy(
          proxyTestState = ConnectionTestState.Error("Kiểm tra lại Host và Port Proxy trước khi thử"),
        )
      }
      return
    }
    viewModelScope.launch {
      controls.update { it.copy(proxyTestState = ConnectionTestState.Testing) }
      repository
        .testProxyConnection(draft)
        .onSuccess { msg ->
          controls.update { it.copy(proxyTestState = ConnectionTestState.Success(msg)) }
        }
        .onFailure { err ->
          controls.update {
            it.copy(
              proxyTestState = ConnectionTestState.Error(err.message ?: "Kiểm tra Proxy thất bại"),
            )
          }
        }
    }
  }

  fun refreshNetworkStatus() {
    viewModelScope.launch {
      controls.update { it.copy(isNetworkLoading = true) }
      repository
        .fetchNetworkStatus()
        .onSuccess { status ->
          controls.update { it.copy(isNetworkLoading = false, networkStatus = status) }
        }
        .onFailure { err ->
          controls.update {
            it.copy(
              isNetworkLoading = false,
              errorMessage = err.message ?: "Không thể lấy trạng thái mạng",
            )
          }
        }
    }
  }

  fun setDefaultPreset(presetId: String?) {
    viewModelScope.launch {
      val current = repository.settingsFlow.first().defaultPresetId
      val next = if (current == presetId) null else presetId
      repository.preferences.setDefaultPresetId(next)
      controls.update {
        it.copy(
          actionMessage =
            if (next == null) "Đã bỏ đặt preset mặc định"
            else "Đã đặt làm preset mặc định cho phiên mới",
        )
      }
    }
  }

  fun saveNewCustomPreset(name: String, description: String, baseConfig: FakerConfig) {
    viewModelScope.launch {
      controls.update { it.copy(isSaving = true, errorMessage = null) }
      repository
        .saveCustomPreset(name, description, baseConfig)
        .onSuccess { preset ->
          controls.update {
            it.copy(isSaving = false, actionMessage = "Đã lưu preset '${preset.name}'")
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isSaving = false, errorMessage = err.message) }
        }
    }
  }

  fun requestDeletePreset(preset: Preset) {
    controls.update { it.copy(pendingDeletePreset = preset) }
  }

  fun dismissDeletePreset() {
    controls.update { it.copy(pendingDeletePreset = null) }
  }

  fun confirmDeletePreset() {
    val target = controls.value.pendingDeletePreset ?: return
    controls.update { it.copy(pendingDeletePreset = null) }
    viewModelScope.launch {
      repository.deleteCustomPreset(target.id)
      controls.update { it.copy(actionMessage = "Đã xóa preset '${target.name}'") }
    }
  }

  fun importPresetFromUri(resolver: ContentResolver, uri: Uri) {
    viewModelScope.launch {
      controls.update { it.copy(isSaving = true, errorMessage = null) }
      val jsonResult =
        withContext(Dispatchers.IO) {
          runCatching {
            resolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
              ?: error("Không thể đọc nội dung tệp JSON")
          }
        }
      jsonResult
        .onFailure { err -> controls.update { it.copy(isSaving = false, errorMessage = err.message) } }
        .onSuccess { raw ->
          repository
            .importCustomPreset(raw)
            .onSuccess { preset ->
              controls.update {
                it.copy(isSaving = false, actionMessage = "Đã nhập preset '${preset.name}'")
              }
            }
            .onFailure { err ->
              controls.update { it.copy(isSaving = false, errorMessage = err.message) }
            }
        }
    }
  }

  fun exportPresetToUri(resolver: ContentResolver, uri: Uri, preset: Preset) {
    viewModelScope.launch {
      controls.update { it.copy(isSaving = true, errorMessage = null) }
      val res =
        withContext(Dispatchers.IO) {
          runCatching {
            val content = JsonCodecs.exportPresetJson(preset)
            resolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(content) }
              ?: error("Không thể ghi ra tệp đích")
          }
        }
      res
        .onSuccess {
          controls.update {
            it.copy(isSaving = false, actionMessage = "Đã xuất tệp cấu hình '${preset.name}.json'")
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isSaving = false, errorMessage = err.message) }
        }
    }
  }

  fun dismissMessages() {
    controls.update { it.copy(actionMessage = null, errorMessage = null) }
  }

  companion object {
    fun factory(repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          SettingsViewModel(repository) as T
      }
  }
}
