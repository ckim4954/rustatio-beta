package com.example.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.FakerConfig
import com.example.domain.model.Formatters
import com.example.domain.model.Preset
import com.example.domain.model.TipImportance
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.RustatioSectionHeader
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@Composable
fun PresetsSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  var showCreateDialog by remember { mutableStateOf(false) }

  SettingsSubScreenScaffold(title = "Presets", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      state.actionMessage?.let { msg ->
        item {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      item {
        Button(
          onClick = { showCreateDialog = true },
          modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("presets_create_btn"),
        ) {
          Icon(Icons.Rounded.Add, contentDescription = null)
          Spacer(Modifier.width(6.dp))
          Text("Tạo Preset tùy chỉnh mới")
        }
      }

      item { RustatioSectionHeader("PRESETS TÍCH HỢP (${state.builtInPresets.size})") }
      items(state.builtInPresets, key = { it.id }) { preset ->
        PresetCard(
          preset = preset,
          isDefault = state.settings.defaultPresetId == preset.id,
          onToggleDefault = { viewModel.setDefaultPreset(preset.id) },
          onDelete = null,
        )
      }

      item { RustatioSectionHeader("PRESETS TÙY CHỈNH (${state.customPresets.size})") }
      if (state.customPresets.isEmpty()) {
        item {
          RustatioEmptyState(
            icon = Icons.Rounded.StarOutline,
            title = "Chưa có preset tùy chỉnh",
            description = "Bạn có thể tạo mới hoặc nhập tệp .json từ mục Nhập / Xuất cấu hình.",
          )
        }
      } else {
        items(state.customPresets, key = { it.id }) { preset ->
          PresetCard(
            preset = preset,
            isDefault = state.settings.defaultPresetId == preset.id,
            onToggleDefault = { viewModel.setDefaultPreset(preset.id) },
            onDelete = { viewModel.requestDeletePreset(preset) },
          )
        }
      }
    }
  }

  if (showCreateDialog) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showCreateDialog = false },
      title = { Text("Tạo Preset tùy chỉnh") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Tên Preset") },
            placeholder = { Text("Ví dụ: Seed Đêm An Toàn") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = desc,
            onValueChange = { desc = it },
            label = { Text("Mô tả ngắn") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.saveNewCustomPreset(name, desc, FakerConfig())
            showCreateDialog = false
          },
          enabled = name.isNotBlank(),
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Lưu Preset")
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showCreateDialog = false },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Hủy")
        }
      },
    )
  }

  RustatioConfirmDialog(
    visible = state.pendingDeletePreset != null,
    title = "Xác nhận xóa Preset",
    message = "Xóa preset \"${state.pendingDeletePreset?.name.orEmpty()}\"? Hành động này không thể hoàn tác.",
    confirmLabel = "Xóa",
    isDestructive = true,
    onConfirm = { viewModel.confirmDeletePreset() },
    onDismiss = { viewModel.dismissDeletePreset() },
  )
}

@Composable
private fun PresetCard(
  preset: Preset,
  isDefault: Boolean,
  onToggleDefault: () -> Unit,
  onDelete: (() -> Unit)?,
) {
  val colors = RustatioThemeTokens.colors
  var expandedTips by remember { mutableStateOf(false) }

  RustatioSectionCard(highlighted = isDefault) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(preset.name, style = MaterialTheme.typography.titleMedium)
          if (preset.recommended) {
            Surface(shape = RoundedCornerShape(8.dp), color = colors.upload.copy(alpha = 0.16f)) {
              Text(
                text = "Khuyên dùng",
                style = MaterialTheme.typography.labelSmall,
                color = colors.upload,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
          if (isDefault) {
            Surface(shape = RoundedCornerShape(8.dp), color = colors.primaryContainer) {
              Text(
                text = "★ Mặc định",
                style = MaterialTheme.typography.labelSmall,
                color = colors.primary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
        }
        Spacer(Modifier.height(4.dp))
        Text(preset.description, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
      }
      if (onDelete != null) {
        IconButton(
          onClick = onDelete,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp),
        ) {
          Icon(Icons.Rounded.Delete, contentDescription = "Xóa preset", tint = colors.error)
        }
      }
    }

    Spacer(Modifier.height(8.dp))
    Text(
      text =
        "↑ ${Formatters.formatSpeedKBs(preset.config.uploadRateKBs)} · ↓ ${Formatters.formatSpeedKBs(preset.config.downloadRateKBs)} · ${preset.config.clientType.displayName} ${preset.config.clientVersion}",
      style = MonoMetricSmall,
      color = colors.textPrimary,
    )

    if (preset.tips.isNotEmpty()) {
      TextButton(
        onClick = { expandedTips = !expandedTips },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp),
      ) {
        Text(if (expandedTips) "Ẩn chi tiết" else "Tại sao dùng cấu hình này?")
      }
      if (expandedTips) {
        preset.tips.forEach { tip ->
          Text(
            text = "• $tip",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            modifier = Modifier.padding(vertical = 2.dp),
          )
        }
      }
    }

    Spacer(Modifier.height(6.dp))
    OutlinedButton(
      onClick = onToggleDefault,
      modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
    ) {
      Icon(
        imageVector = if (isDefault) Icons.Rounded.Star else Icons.Rounded.StarOutline,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
      )
      Spacer(Modifier.width(6.dp))
      Text(if (isDefault) "Đang là mặc định (nhấn để bỏ)" else "Đặt làm mặc định cho phiên mới")
    }
  }
}

@Composable
fun ImportExportSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val colors = RustatioThemeTokens.colors
  var exportTarget by remember { mutableStateOf<Preset?>(null) }

  val importLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) viewModel.importPresetFromUri(context.contentResolver, uri)
    }

  val exportLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
      val preset = exportTarget
      if (uri != null && preset != null) {
        viewModel.exportPresetToUri(context.contentResolver, uri, preset)
      }
      exportTarget = null
    }

  SettingsSubScreenScaffold(title = "Nhập / Xuất cấu hình", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      state.actionMessage?.let { msg ->
        item {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }
      state.errorMessage?.let { err ->
        item {
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      item {
        RustatioSectionCard {
          Text("Nhập Preset từ tệp JSON", style = MaterialTheme.typography.titleMedium)
          Spacer(Modifier.height(4.dp))
          Text(
            "Tương thích hoàn toàn với tệp cấu hình chuẩn Rustatio Desktop/Web (type: \"rustatio-preset\").",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
          )
          Spacer(Modifier.height(10.dp))
          Button(
            onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("import_json_btn"),
          ) {
            Icon(Icons.Rounded.FileUpload, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Chọn tệp .json để nhập")
          }
        }
      }

      item { RustatioSectionHeader("XUẤT PRESET RA TỆP JSON") }
      val allPresets = state.builtInPresets + state.customPresets
      items(allPresets, key = { "exp_${it.id}" }) { preset ->
        RustatioSectionCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(preset.name, style = MaterialTheme.typography.titleSmall)
              Text(preset.description, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
            }
            OutlinedButton(
              onClick = {
                exportTarget = preset
                val safeName = preset.name.lowercase().replace(Regex("[^a-z0-9]+"), "-")
                exportLauncher.launch("rustatio-$safeName.json")
              },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            ) {
              Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(4.dp))
              Text("Xuất")
            }
          }
        }
      }
    }
  }
}

@Composable
fun DetectionTipsScreen(onNavigateBack: () -> Unit) {
  val colors = RustatioThemeTokens.colors
  SettingsSubScreenScaffold(title = "Mẹo tránh bị phát hiện", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      items(BuiltInPresets.detectionTips) { tip ->
        val badgeColor =
          when (tip.importance) {
            TipImportance.CRITICAL -> colors.error
            TipImportance.HIGH -> colors.warning
            TipImportance.MEDIUM -> colors.download
          }
        RustatioSectionCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(tip.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = badgeColor.copy(alpha = 0.14f),
              border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f)),
            ) {
              Text(
                text = tip.importance.labelVi,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
          Spacer(Modifier.height(6.dp))
          Text(tip.description, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
        }
      }
    }
  }
}

@Composable
fun AboutSettingsScreen(onNavigateBack: () -> Unit) {
  val colors = RustatioThemeTokens.colors
  SettingsSubScreenScaffold(title = "Thông tin ứng dụng", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      item {
        RustatioSectionCard {
          Text("Rustatio Android", style = MaterialTheme.typography.titleLarge, color = colors.primary)
          Spacer(Modifier.height(4.dp))
          Text("Phiên bản tham chiếu: 2.14.1", style = MaterialTheme.typography.bodyMedium)
          Spacer(Modifier.height(8.dp))
          Text(
            "Ứng dụng quản lý và giả lập tỷ lệ BitTorrent đa phiên trên Android, hỗ trợ chạy trực tiếp trên thiết bị và kết nối đồng bộ với Rustatio Server.",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
          )
        }
      }
      item {
        RustatioSectionHeader("KHẢ NĂNG TÍCH HỢP")
        RustatioSectionCard {
          val capabilities =
            listOf(
              "6 trình khách giả lập: qBittorrent, µTorrent, Transmission, Deluge, BitTorrent, rTorrent.",
              "Đọc tệp .torrent chuẩn Bencode & tính SHA-1 info_hash cục bộ.",
              "6 điều kiện dừng tự động, dao động tốc độ ngẫu nhiên và tăng tốc lũy tiến.",
              "Theo dõi thư mục Android SAF và thư mục trên Rustatio Server.",
              "Hỗ trợ Proxy SOCKS4/4a/5/5h và sao lưu JSON tương thích Desktop/Web.",
            )
          capabilities.forEach { line ->
            Text(
              text = "• $line",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
              modifier = Modifier.padding(vertical = 3.dp),
            )
          }
        }
      }
    }
  }
}
