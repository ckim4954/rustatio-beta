package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.JsonCodecs
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.ClientType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `app_name matches Rustatio`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rustatio", appName)
  }

  @Test
  fun `preset json export and import stays compatible with rustatio-preset format`() {
    val balanced = BuiltInPresets.all.first { it.id == "balanced" }
    val exported = JsonCodecs.exportPresetJson(balanced)
    assertTrue(exported.contains("\"type\": \"rustatio-preset\""))

    val imported = JsonCodecs.importPresetJson(exported)
    assertTrue(imported.isSuccess)
    val preset = imported.getOrThrow()
    assertEquals(balanced.name, preset.name)
    assertEquals(balanced.config.uploadRateKBs, preset.config.uploadRateKBs, 0.01)
    assertEquals(ClientType.QBITTORRENT, preset.config.clientType)

    val invalid = JsonCodecs.importPresetJson("{\"type\":\"other\"}")
    assertFalse(invalid.isSuccess)
  }

  @Test
  fun `root navigation and settings subscreen CUJ works in Vietnamese`() {
    composeRule.waitForIdle()

    // Bottom navigation shows 3 Vietnamese destinations on root screen
    composeRule.onNodeWithTag("nav_sessions").assertIsDisplayed()
    composeRule.onNodeWithTag("nav_watch").assertIsDisplayed()
    composeRule.onNodeWithTag("nav_settings").assertIsDisplayed()

    // Navigate to Watch ("Theo dõi")
    composeRule.onNodeWithTag("nav_watch").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("watch_mode_saf").assertIsDisplayed()
    composeRule.onNodeWithTag("watch_mode_server").assertIsDisplayed()

    // Navigate to Settings ("Cài đặt") and open Appearance ("Giao diện")
    composeRule.onNodeWithTag("nav_settings").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("settings_row_appearance").performClick()
    composeRule.waitForIdle()

    // Subscreen should hide bottom nav and show theme options
    composeRule.onNodeWithTag("nav_sessions").assertDoesNotExist()
    composeRule.onNodeWithTag("theme_option_light").assertIsDisplayed()
    composeRule.onNodeWithTag("theme_option_dark").performClick()
    composeRule.waitForIdle()

    // Back returns to Settings root with bottom nav visible again
    composeRule.onNodeWithTag("settings_sub_back").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("nav_sessions").assertIsDisplayed()
  }

  @Test
  fun `sessions empty state and create empty session navigates to detail`() {
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("sessions_add_fab").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("add_create_empty").performClick()
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithText("Chi tiết phiên").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.waitForIdle()

    // SessionDetailScreen displays Vietnamese tabs & hides bottom bar
    composeRule.onNodeWithText("Chi tiết phiên").assertIsDisplayed()
    composeRule.onNodeWithTag("detail_tab_1").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithText("Loại Client").assertIsDisplayed()
    composeRule.onNodeWithTag("config_port_input").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("config_tab_list").performScrollToNode(hasTestTag("config_save_button"))
    composeRule.onNodeWithTag("config_save_button").assertIsDisplayed()

    // Navigate back to Sessions
    composeRule.onNodeWithTag("detail_back_button").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("nav_sessions").assertIsDisplayed()
  }
}
