package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.JsonCodecs
import com.example.data.local.LocalInstanceEntity
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.PostStopAction
import com.example.domain.model.Preset
import com.example.ui.settings.CustomPresetEditorUiState
import com.example.ui.settings.CustomPresetEditorViewModel
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CustomPresetPersistenceTest {

  private lateinit var context: Context

  private val expected28Keys =
    setOf(
      "selectedClient",
      "selectedClientVersion",
      "port",
      "vpnPortSync",
      "uploadRate",
      "downloadRate",
      "completionPercent",
      "randomizeRates",
      "randomRangePercent",
      "updateIntervalSeconds",
      "scrapeInterval",
      "progressiveRatesEnabled",
      "targetUploadRate",
      "targetDownloadRate",
      "progressiveDurationHours",
      "stopAtRatioEnabled",
      "stopAtRatio",
      "randomizeRatio",
      "randomRatioRangePercent",
      "stopAtUploadedEnabled",
      "stopAtUploadedGB",
      "stopAtDownloadedEnabled",
      "stopAtDownloadedGB",
      "stopAtSeedTimeEnabled",
      "stopAtSeedTimeHours",
      "idleWhenNoLeechers",
      "idleWhenNoSeeders",
      "postStopAction",
    )

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    RustatioAppContainer.resetForTests()
    context.deleteDatabase("rustatio_db")
  }

  @After
  fun tearDown() {
    RustatioAppContainer.resetForTests()
    context.deleteDatabase("rustatio_db")
  }

  private fun awaitCondition(timeoutMs: Long = 5_000L, predicate: () -> Boolean) {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (!predicate() && System.currentTimeMillis() < deadline) {
      ShadowLooper.idleMainLooper()
      Thread.sleep(20)
    }
    ShadowLooper.idleMainLooper()
    assertTrue("Timed out after ${timeoutMs}ms waiting for condition", predicate())
  }

  @Test
  fun `custom preset JSON uses exact 28 keys without initialUploaded and normalizes legacy fields`() {
    val cfg =
      FakerConfig(
        uploadRateKBs = 750.5,
        downloadRateKBs = 125.25,
        port = 51413,
        vpnPortSync = true,
        clientType = ClientType.TRANSMISSION,
        clientVersion = "4.1.4",
        completionPercent = 90.0,
        initialUploadedMB = 999L, // Must NOT appear in preset settings
        randomizeRates = true,
        randomRangePercent = 30.0,
        randomizeRatio = true,
        randomRatioRangePercent = 12.0,
        updateIntervalSeconds = 15,
        scrapeIntervalSeconds = 240,
        stopAtRatioEnabled = true,
        stopAtRatio = 2.75,
        stopAtUploadedEnabled = true,
        stopAtUploadedGB = 45.5,
        stopAtDownloadedEnabled = true,
        stopAtDownloadedGB = 12.25,
        stopAtSeedTimeEnabled = true,
        stopAtSeedTimeHours = 36.5,
        idleWhenNoLeechers = true,
        idleWhenNoSeeders = true,
        postStopAction = PostStopAction.STOP_SEEDING,
        progressiveRatesEnabled = true,
        targetUploadRateKBs = 1800.0,
        targetDownloadRateKBs = 250.0,
        progressiveDurationHours = 4.5,
      )

    val settingsObj = JsonCodecs.encodePresetSettings(cfg)
    val keys = settingsObj.keys().asSequence().toSet()
    assertEquals(28, expected28Keys.size)
    assertEquals(expected28Keys, keys)
    assertFalse(settingsObj.has("initialUploaded"))
    assertFalse(settingsObj.has("initialDownloaded"))
    assertFalse(settingsObj.has("effectiveStopAtRatio"))

    // Verify metadata structure matches customPreset.js
    val preset =
      Preset(
        id = "custom-1234",
        name = "Test 28",
        description = "Mo ta 28 truong",
        icon = "star",
        custom = true,
        createdAt = "2026-11-14T12:00:00.000Z",
        config = cfg,
      )
    val builtObj = JsonCodecs.buildCustomPresetObject(preset)
    assertEquals("custom-1234", builtObj.getString("id"))
    assertEquals("Test 28", builtObj.getString("name"))
    assertEquals("Mo ta 28 truong", builtObj.getString("description"))
    assertEquals("star", builtObj.getString("icon"))
    assertTrue(builtObj.getBoolean("custom"))
    assertEquals("2026-11-14T12:00:00.000Z", builtObj.getString("created_at"))
    assertEquals(28, builtObj.getJSONObject("settings").length())

    // Verify legacy normalizePresetSettings alias compatibility
    val legacyJson =
      """
      {
        "type": "rustatio-preset",
        "version": 1,
        "name": "Legacy",
        "description": "Legacy idle aliases",
        "settings": {
          "client": "deluge",
          "clientVersion": "2.2.0",
          "stopWhenNoLeechers": true,
          "stopWhenNoSeeders": true,
          "scrapeIntervalSeconds": 300,
          "progressiveRates": true,
          "postStopAction": "delete_instance"
        }
      }
      """.trimIndent()
    val imported = JsonCodecs.importPresetJson(legacyJson).getOrThrow()
    assertEquals(ClientType.DELUGE, imported.config.clientType)
    assertEquals("2.2.0", imported.config.clientVersion)
    assertTrue(imported.config.idleWhenNoLeechers)
    assertTrue(imported.config.idleWhenNoSeeders)
    assertEquals(300, imported.config.scrapeIntervalSeconds)
    assertTrue(imported.config.progressiveRatesEnabled)
    assertEquals(PostStopAction.DELETE_INSTANCE, imported.config.postStopAction)

    // Verify canonical key takes precedence over legacy key
    val mixed =
      JSONObject()
        .put("stopWhenNoLeechers", false)
        .put("idleWhenNoLeechers", true)
    val decodedMixed = JsonCodecs.decodePresetConfig(mixed.toString())
    assertTrue(decodedMixed.idleWhenNoLeechers)
  }

  @Test
  fun `editor validation handles required name, bounds, zero speeds, and preserves disabled toggle values`() {
    val blank = CustomPresetEditorUiState.newBlank()
    assertNotNull(blank.validationErrors.nameError)
    assertNull(blank.toFakerConfig())

    val zeroSpeeds =
      blank.copy(
        name = "Zero Seed",
        uploadRateText = "0",
        downloadRateText = "0",
        completionPercentText = "0",
        randomRangePercentText = "0",
        progressiveRatesEnabled = true,
        targetUploadRateText = "0",
        targetDownloadRateText = "0",
        progressiveDurationHoursText = "1",
        stopAtRatioEnabled = false,
        stopAtRatioText = "3.5",
        stopAtUploadedEnabled = false,
        stopAtUploadedGBText = "25",
      )
    assertFalse(zeroSpeeds.validationErrors.hasErrors)
    val cfg = zeroSpeeds.toFakerConfig()!!
    assertEquals(0.0, cfg.uploadRateKBs, 0.001)
    assertEquals(0.0, cfg.downloadRateKBs, 0.001)
    assertEquals(0.0, cfg.completionPercent, 0.001)
    // Underlying disabled values preserved
    assertEquals(3.5, cfg.stopAtRatio, 0.001)
    assertEquals(25.0, cfg.stopAtUploadedGB, 0.001)
    assertFalse(zeroSpeeds.hasThresholdStopCondition)

    // Enabling a threshold condition toggles hasThresholdStopCondition cleanly
    val withThreshold = zeroSpeeds.copy(stopAtSeedTimeEnabled = true, stopAtSeedTimeHoursText = "12")
    assertTrue(withThreshold.hasThresholdStopCondition)

    // Invalid bounds while enabled fail cleanly
    val badBounds =
      zeroSpeeds.copy(
        portText = "70000",
        updateIntervalSecondsText = "0",
        scrapeIntervalText = "5",
        stopAtRatioEnabled = true,
        stopAtRatioText = "0",
      )
    assertNotNull(badBounds.validationErrors.portError)
    assertNotNull(badBounds.validationErrors.updateIntervalError)
    assertNotNull(badBounds.validationErrors.scrapeIntervalError)
    assertNotNull(badBounds.validationErrors.stopAtRatioError)
  }

  @Test
  fun `end to end create restart reopen edit and apply custom preset persists all 28 settings`() {
    val container = RustatioAppContainer.get(context)
    val repo = container.repository

    // Save a comprehensive custom preset through CustomPresetEditorViewModel
    val createVm = CustomPresetEditorViewModel(presetId = null, repository = repo)
    createVm.selectClient(ClientType.DELUGE)
    createVm.update {
      it.copy(
        name = "Seed Đêm Nâng Cao",
        description = "Kiểm tra toàn bộ 28 trường cấu hình",
        selectedClientVersion = "2.1.1",
        portText = "52444",
        vpnPortSync = true,
        uploadRateText = "888.5",
        downloadRateText = "12.5",
        completionPercentText = "75",
        randomizeRates = true,
        randomRangePercentText = "28",
        updateIntervalSecondsText = "12",
        scrapeIntervalText = "300",
        progressiveRatesEnabled = true,
        targetUploadRateText = "2400",
        targetDownloadRateText = "0",
        progressiveDurationHoursText = "5.5",
        stopAtRatioEnabled = true,
        stopAtRatioText = "3.45",
        randomizeRatio = true,
        randomRatioRangePercentText = "14",
        stopAtUploadedEnabled = true,
        stopAtUploadedGBText = "65.5",
        stopAtDownloadedEnabled = true,
        stopAtDownloadedGBText = "9.25",
        stopAtSeedTimeEnabled = true,
        stopAtSeedTimeHoursText = "48",
        idleWhenNoLeechers = true,
        idleWhenNoSeeders = true,
        postStopAction = PostStopAction.STOP_SEEDING,
      )
    }

    var savedId: String? = null
    val saveLatch = CountDownLatch(1)
    createVm.save { saved ->
      savedId = saved.id
      saveLatch.countDown()
    }
    awaitCondition { saveLatch.count == 0L }
    assertTrue(saveLatch.await(1, TimeUnit.SECONDS))
    assertNotNull("Custom preset should save and return an ID", savedId)

    // Verify exact 28-key JSON inside Room entity
    val entity = runBlocking { container.database.customPresetDao().getById(savedId!!) }
    assertNotNull(entity)
    val persistedSettings = JSONObject(entity!!.settingsJson)
    assertEquals(expected28Keys, persistedSettings.keys().asSequence().toSet())

    // Simulate genuine app process restart: checkpoint WAL, close DB, reset container, then re-open
    RustatioAppContainer.resetForTests()
    val restartedContainer = RustatioAppContainer.get(context)
    val restartedRepo = restartedContainer.repository

    // Reopen in Edit mode & verify all 28 fields match saved values
    val editVm = CustomPresetEditorViewModel(presetId = savedId, repository = restartedRepo)
    awaitCondition { !editVm.uiState.value.isLoading }

    val loaded = editVm.uiState.value
    assertNull("Expected no loadError but got: ${loaded.loadError}", loaded.loadError)
    assertEquals("Seed Đêm Nâng Cao", loaded.name)
    assertEquals("Kiểm tra toàn bộ 28 trường cấu hình", loaded.description)
    assertEquals(ClientType.DELUGE, loaded.selectedClient)
    assertEquals("2.1.1", loaded.selectedClientVersion)
    assertEquals("52444", loaded.portText)
    assertTrue(loaded.vpnPortSync)
    assertEquals("888.5", loaded.uploadRateText)
    assertEquals("12.5", loaded.downloadRateText)
    assertEquals("75", loaded.completionPercentText)
    assertTrue(loaded.randomizeRates)
    assertEquals("28", loaded.randomRangePercentText)
    assertEquals("12", loaded.updateIntervalSecondsText)
    assertEquals("300", loaded.scrapeIntervalText)
    assertTrue(loaded.progressiveRatesEnabled)
    assertEquals("2400", loaded.targetUploadRateText)
    assertEquals("0", loaded.targetDownloadRateText)
    assertEquals("5.5", loaded.progressiveDurationHoursText)
    assertTrue(loaded.stopAtRatioEnabled)
    assertEquals("3.45", loaded.stopAtRatioText)
    assertTrue(loaded.randomizeRatio)
    assertEquals("14", loaded.randomRatioRangePercentText)
    assertTrue(loaded.stopAtUploadedEnabled)
    assertEquals("65.5", loaded.stopAtUploadedGBText)
    assertTrue(loaded.stopAtDownloadedEnabled)
    assertEquals("9.25", loaded.stopAtDownloadedGBText)
    assertTrue(loaded.stopAtSeedTimeEnabled)
    assertEquals("48", loaded.stopAtSeedTimeHoursText)
    assertTrue(loaded.idleWhenNoLeechers)
    assertTrue(loaded.idleWhenNoSeeders)
    assertEquals(PostStopAction.STOP_SEEDING, loaded.postStopAction)

    // Edit preset, turn OFF some toggles & confirm underlying numeric values remain intact
    editVm.update {
      it.copy(
        name = "Seed Đêm v2",
        progressiveRatesEnabled = false,
        stopAtUploadedEnabled = false,
        uploadRateText = "0",
        downloadRateText = "0",
        postStopAction = PostStopAction.DELETE_INSTANCE,
      )
    }
    var editedPreset: Preset? = null
    editVm.save { saved -> editedPreset = saved }
    awaitCondition { editedPreset != null }
    assertNotNull(editedPreset)

    // Reset container again to confirm edits survived another DB reopen
    RustatioAppContainer.resetForTests()
    val thirdContainer = RustatioAppContainer.get(context)
    val thirdRepo = thirdContainer.repository

    val reloadedPreset = runBlocking { thirdRepo.getCustomPresetById(savedId!!)!! }
    assertEquals("Seed Đêm v2", reloadedPreset.name)
    assertFalse(reloadedPreset.config.progressiveRatesEnabled)
    assertEquals(2400.0, reloadedPreset.config.targetUploadRateKBs, 0.01) // Preserved!
    assertFalse(reloadedPreset.config.stopAtUploadedEnabled)
    assertEquals(65.5, reloadedPreset.config.stopAtUploadedGB, 0.01) // Preserved!
    assertEquals(0.0, reloadedPreset.config.uploadRateKBs, 0.01)
    assertEquals(0.0, reloadedPreset.config.downloadRateKBs, 0.01)
    assertEquals(PostStopAction.DELETE_INSTANCE, reloadedPreset.config.postStopAction)

    // Create an instance (with initialUploadedMB = 512) and apply preset -> read-back verify
    val instanceId = "inst-verify-01"
    runBlocking {
      thirdContainer.database.localInstanceDao().upsert(
        LocalInstanceEntity(
          id = instanceId,
          torrentJson = null,
          configJson = JsonCodecs.encodeConfig(FakerConfig(initialUploadedMB = 512L)),
          tagsJson = "[]",
          source = "manual",
          cumulativeUploadedBytes = 0L,
          cumulativeDownloadedBytes = 0L,
          createdAtMs = 1_700_000_000_000L,
        )
      )
      val applyResult = thirdRepo.applyPresetToInstance(instanceId, reloadedPreset)
      assertTrue(applyResult.isSuccess)
      val verified = thirdRepo.instancesFlow.first().first { it.id == instanceId }
      assertEquals(ClientType.DELUGE, verified.config.clientType)
      assertEquals("2.1.1", verified.config.clientVersion)
      assertEquals(52444, verified.config.port)
      assertTrue(verified.config.vpnPortSync)
      assertEquals(0.0, verified.config.uploadRateKBs, 0.01)
      assertEquals(75.0, verified.config.completionPercent, 0.01)
      assertEquals(512L, verified.config.initialUploadedMB) // Instance's initialUploadedMB preserved!
      assertEquals(PostStopAction.DELETE_INSTANCE, verified.config.postStopAction)
    }
  }
}
