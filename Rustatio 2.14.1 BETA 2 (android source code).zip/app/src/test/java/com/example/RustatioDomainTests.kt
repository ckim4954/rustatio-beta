package com.example

import com.example.data.torrent.BencodeParser
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.domain.model.ProxySettings
import com.example.domain.model.ProxyType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RustatioDomainTests {

  @Test
  fun `bencode parser parses single file torrent and computes 40-char sha1 info_hash`() {
    val torrentBytes =
      ("d8:announce27:https://tracker.example/ann" +
        "4:infod6:lengthi1048576e4:name12:ubuntu.iso.z" +
        "12:piece lengthi262144e6:pieces20:12345678901234567890ee")
        .toByteArray(Charsets.ISO_8859_1)

    val result = BencodeParser.parseTorrent(torrentBytes, "fallback.torrent")
    assertTrue(result.isSuccess)
    val info = result.getOrThrow()
    assertEquals("ubuntu.iso.z", info.name)
    assertEquals(1048576L, info.totalSize)
    assertEquals(262144L, info.pieceLength)
    assertEquals(1, info.numPieces)
    assertTrue(info.isSingleFile)
    assertEquals("https://tracker.example/ann", info.announce)
    assertEquals(40, info.infoHashHex.length)
  }

  @Test
  fun `bencode parser rejects empty or malformed input`() {
    assertTrue(BencodeParser.parseTorrent(ByteArray(0)).isFailure)
    assertTrue(BencodeParser.parseTorrent("invalid".toByteArray()).isFailure)
  }

  @Test
  fun `built-in presets and detection tips are complete`() {
    assertEquals(5, BuiltInPresets.all.size)
    assertEquals(8, BuiltInPresets.detectionTips.size)
    assertTrue(BuiltInPresets.all.any { it.recommended })
  }

  @Test
  fun `proxy url resolves hostname schemes accurately`() {
    val socks5h =
      ProxySettings(
        enabled = true,
        type = ProxyType.SOCKS5,
        host = "10.0.0.2",
        port = 1080,
        resolveHostnameViaProxy = true,
      )
    assertEquals("socks5h://10.0.0.2:1080", socks5h.toUrl())

    val socks5 = socks5h.copy(resolveHostnameViaProxy = false)
    assertEquals("socks5://10.0.0.2:1080", socks5.toUrl())
  }

  @Test
  fun `formatters produce accurate units and Vietnamese status labels`() {
    assertEquals("1.00 MB", Formatters.formatBytes(1024L * 1024L))
    assertEquals("500 KB/s", Formatters.formatSpeedKBs(500.0))
    assertEquals("2.00 MB/s", Formatters.formatSpeedKBs(2048.0))
    assertEquals("Đang chạy", Formatters.stateLabelVi(FakerState.RUNNING))
    assertEquals("Tạm dừng", Formatters.stateLabelVi(FakerState.PAUSED))
    assertEquals("Đã dừng", Formatters.stateLabelVi(FakerState.STOPPED))
  }
}
