package com.example.data.remote

import com.example.data.torrent.BencodeParser
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.FakerStats
import com.example.domain.model.InstanceItem
import com.example.domain.model.InstanceSource
import com.example.domain.model.NetworkStatus
import com.example.domain.model.PostStopAction
import com.example.domain.model.Preset
import com.example.domain.model.ProxySettings
import com.example.domain.model.ProxyType
import com.example.domain.model.TorrentFile
import com.example.domain.model.TorrentInfo
import com.example.domain.model.WatchConfig
import com.example.domain.model.WatchFileEntry
import com.example.domain.model.WatchFileStatus
import com.example.domain.model.WatchStatus
import java.io.IOException
import java.net.Authenticator
import java.net.InetSocketAddress
import java.net.PasswordAuthentication
import java.net.Proxy
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

data class TrackerAnnounceResult(
  val seeders: Int,
  val leechers: Int,
  val intervalSeconds: Int,
  val trackerId: String? = null,
)

class RustatioServerClient {

  private val baseClient: OkHttpClient =
    OkHttpClient.Builder()
      .connectTimeout(10, TimeUnit.SECONDS)
      .readTimeout(20, TimeUnit.SECONDS)
      .writeTimeout(20, TimeUnit.SECONDS)
      .build()

  private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

  suspend fun checkServerConnection(baseUrl: String, token: String): Result<Boolean> =
    withContext(Dispatchers.IO) {
      runCatching {
        val normalized = baseUrl.trim().trimEnd('/')
        require(normalized.startsWith("http://") || normalized.startsWith("https://")) {
          "Địa chỉ máy chủ phải bắt đầu bằng http:// hoặc https://"
        }
        val statusRes = executeGet("$normalized/api/auth/status", null)
        val authEnabled = statusRes.optJSONObject("data")?.optBoolean("auth_enabled") ?: false
        if (authEnabled) {
          require(token.isNotBlank()) { "Máy chủ yêu cầu Bearer Token để xác thực." }
          val verifyReq =
            Request.Builder()
              .url("$normalized/api/auth/verify")
              .header("Authorization", "Bearer ${token.trim()}")
              .get()
              .build()
          baseClient.newCall(verifyReq).execute().use { resp ->
            if (!resp.isSuccessful) {
              error("Xác thực thất bại (HTTP ${resp.code}). Kiểm tra lại Bearer Token.")
            }
          }
        }
        true
      }
    }

  suspend fun listInstances(baseUrl: String, token: String): Result<List<InstanceItem>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val data = executeApi("$baseUrl/api/instances", "GET", null, token)
        val arr = data.optJSONArray("data") ?: JSONArray()
        buildList {
          for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            add(parseServerInstance(obj))
          }
        }
      }
    }

  suspend fun createInstance(baseUrl: String, token: String): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val data = executeApi("$baseUrl/api/instances", "POST", JSONObject(), token)
        data.getJSONObject("data").getString("id")
      }
    }

  suspend fun uploadInstanceTorrent(
    baseUrl: String,
    token: String,
    instanceId: String,
    fileName: String,
    bytes: ByteArray,
  ): Result<TorrentInfo> =
    withContext(Dispatchers.IO) {
      runCatching {
        val body =
          MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart(
              "file",
              fileName,
              bytes.toRequestBody("application/x-bittorrent".toMediaType()),
            )
            .build()
        val reqBuilder = Request.Builder().url("${baseUrl.trimEnd('/')}/api/instances/$instanceId/torrent").post(body)
        if (token.isNotBlank()) reqBuilder.header("Authorization", "Bearer ${token.trim()}")
        baseClient.newCall(reqBuilder.build()).execute().use { resp ->
          val text = resp.body?.string().orEmpty()
          val json = JSONObject(text)
          if (!resp.isSuccessful || !json.optBoolean("success", false)) {
            error(json.optString("error").ifBlank { "Không thể nạp torrent (HTTP ${resp.code})" })
          }
          parseTorrentInfo(json.getJSONObject("data").getJSONObject("torrent"))
        }
      }
    }

  suspend fun startFaker(
    baseUrl: String,
    token: String,
    id: String,
    torrent: TorrentInfo,
    config: FakerConfig,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val payload =
          JSONObject().apply {
            put("torrent", serializeTorrentInfoForServer(torrent))
            put("config", serializeFakerConfigForServer(config, torrent.totalSize))
          }
        executeApi("$baseUrl/api/faker/$id/start", "POST", payload, token)
        Unit
      }
    }

  suspend fun pauseFaker(baseUrl: String, token: String, id: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi("$baseUrl/api/faker/$id/pause", "POST", JSONObject(), token)
        Unit
      }
    }

  suspend fun resumeFaker(baseUrl: String, token: String, id: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi("$baseUrl/api/faker/$id/resume", "POST", JSONObject(), token)
        Unit
      }
    }

  suspend fun stopFaker(baseUrl: String, token: String, id: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi("$baseUrl/api/faker/$id/stop", "POST", JSONObject(), token)
        Unit
      }
    }

  suspend fun updateInstanceConfig(
    baseUrl: String,
    token: String,
    id: String,
    config: FakerConfig,
    torrentSize: Long,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi(
          "$baseUrl/api/instances/$id/config",
          "PATCH",
          serializeFakerConfigForServer(config, torrentSize),
          token,
        )
        Unit
      }
    }

  suspend fun setInstanceTags(
    baseUrl: String,
    token: String,
    id: String,
    tags: List<String>,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi(
          "$baseUrl/api/instances/$id/tags",
          "PUT",
          JSONObject().put("tags", JSONArray(tags)),
          token,
        )
        Unit
      }
    }

  suspend fun deleteInstance(
    baseUrl: String,
    token: String,
    id: String,
    force: Boolean = true,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val query = if (force) "?force=true" else ""
        executeApi("$baseUrl/api/instances/$id$query", "DELETE", null, token)
        Unit
      }
    }

  suspend fun gridAction(
    baseUrl: String,
    token: String,
    action: String,
    ids: List<String>,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi(
          "$baseUrl/api/grid/$action",
          "POST",
          JSONObject().put("ids", JSONArray(ids)),
          token,
        )
        Unit
      }
    }

  suspend fun getProxySettings(baseUrl: String, token: String): Result<ProxySettings> =
    withContext(Dispatchers.IO) {
      runCatching {
        val data = executeApi("$baseUrl/api/network/proxy", "GET", null, token)
        val obj = data.optJSONObject("data") ?: return@runCatching ProxySettings()
        parseProxyUrlToSettings(
          enabled = obj.optBoolean("enabled", false),
          url = obj.optString("url"),
          username = obj.optString("username"),
          password = obj.optString("password"),
        )
      }
    }

  suspend fun setProxySettings(
    baseUrl: String,
    token: String,
    settings: ProxySettings,
  ): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val payload =
          JSONObject().apply {
            put("enabled", settings.enabled)
            put("url", settings.toUrl())
            if (settings.authentication) {
              put("username", settings.username)
              put("password", settings.password)
            }
          }
        executeApi("$baseUrl/api/network/proxy", "PUT", payload, token)
        Unit
      }
    }

  suspend fun testProxyOnServer(
    baseUrl: String,
    token: String,
    settings: ProxySettings,
  ): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val payload =
          JSONObject().apply {
            put("enabled", settings.enabled)
            put("url", settings.toUrl())
            if (settings.authentication) {
              put("username", settings.username)
              put("password", settings.password)
            }
          }
        val data = executeApi("$baseUrl/api/network/proxy/test", "POST", payload, token)
        val ip = data.optJSONObject("data")?.optString("ip").orEmpty()
        if (ip.isNotBlank()) "Proxy kết nối thành công — IP đầu ra: $ip"
        else "Proxy kết nối thành công"
      }
    }

  suspend fun testProxyDirect(settings: ProxySettings): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val client = buildClientWithProxy(settings, 8)
        val req = Request.Builder().url("https://api.ipify.org?format=json").get().build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) error("Kiểm tra proxy thất bại (HTTP ${resp.code})")
          val json = JSONObject(resp.body?.string().orEmpty())
          val ip = json.optString("ip")
          if (ip.isNotBlank()) "Kết nối Proxy thành công — IP đầu ra: $ip"
          else "Kết nối Proxy thành công"
        }
      }
    }

  suspend fun fetchNetworkStatus(
    baseUrl: String?,
    token: String,
    proxy: ProxySettings,
  ): Result<NetworkStatus> =
    withContext(Dispatchers.IO) {
      runCatching {
        if (!baseUrl.isNullOrBlank()) {
          val res = executeApi("$baseUrl/api/network/status", "GET", null, token)
          val obj = res.optJSONObject("data")
          if (obj != null) {
            return@runCatching NetworkStatus(
              ip = obj.optString("ip").takeIf { it.isNotBlank() },
              country = obj.optString("country").takeIf { it.isNotBlank() },
              city = obj.optString("city").takeIf { it.isNotBlank() },
              org = obj.optString("org").takeIf { it.isNotBlank() },
              isVpn = obj.optBoolean("is_vpn", false),
              vpnProvider = obj.optString("vpn_provider").takeIf { it.isNotBlank() },
              forwardedPort =
                if (obj.has("forwarded_port") && !obj.isNull("forwarded_port")) {
                  obj.optInt("forwarded_port")
                } else null,
              proxyEnabled = obj.optBoolean("proxy_enabled", proxy.enabled),
            )
          }
        }
        val client = buildClientWithProxy(proxy, 6)
        val req = Request.Builder().url("https://api.ipify.org?format=json").get().build()
        client.newCall(req).execute().use { resp ->
          val ip =
            if (resp.isSuccessful) JSONObject(resp.body?.string().orEmpty()).optString("ip")
            else ""
          NetworkStatus(
            ip = ip.takeIf { it.isNotBlank() },
            proxyEnabled = proxy.enabled,
          )
        }
      }
    }

  suspend fun fetchWatchData(
    baseUrl: String,
    token: String,
  ): Result<Triple<WatchStatus, WatchConfig, List<WatchFileEntry>>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val statusObj =
          executeApi("$baseUrl/api/watch/status", "GET", null, token).optJSONObject("data")
            ?: JSONObject()
        val cfgObj =
          executeApi("$baseUrl/api/watch/config", "GET", null, token).optJSONObject("data")
            ?: JSONObject()
        val filesArr =
          executeApi("$baseUrl/api/watch/files", "GET", null, token).optJSONArray("data")
            ?: JSONArray()
        val entries = buildList {
          for (i in 0 until filesArr.length()) {
            val f = filesArr.optJSONObject(i) ?: continue
            val filename = f.optString("filename")
            add(
              WatchFileEntry(
                filename = filename,
                displayName = f.optString("name").ifBlank { filename.substringAfterLast('/') },
                sizeBytes = f.optLong("size", 0L),
                status = WatchFileStatus.fromWire(f.optString("status")),
                errorMessage = f.optString("error").takeIf { it.isNotBlank() },
              )
            )
          }
        }
        val status =
          WatchStatus(
            watchDir = statusObj.optString("watch_dir"),
            loadedCount = statusObj.optInt("loaded_count", entries.count { it.status == WatchFileStatus.LOADED }),
            totalFiles = entries.size,
            pendingCount = entries.count { it.status == WatchFileStatus.PENDING },
            invalidCount = entries.count { it.status == WatchFileStatus.INVALID },
            isWatching = true,
          )
        val config =
          WatchConfig(
            watchDir = cfgObj.optString("watch_dir", status.watchDir),
            maxDepth = cfgObj.optInt("max_depth", 1),
            autoStart = cfgObj.optBoolean("auto_start", false),
          )
        Triple(status, config, entries)
      }
    }

  suspend fun setWatchConfig(baseUrl: String, token: String, config: WatchConfig): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val body =
          JSONObject().apply {
            put("max_depth", config.maxDepth)
            put("auto_start", config.autoStart)
          }
        executeApi("$baseUrl/api/watch/config", "PUT", body, token)
        Unit
      }
    }

  suspend fun reloadWatchFile(baseUrl: String, token: String, path: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val enc = URLEncoder.encode(path, "UTF-8")
        executeApi("$baseUrl/api/watch/files/reload?path=$enc", "POST", JSONObject(), token)
        Unit
      }
    }

  suspend fun reloadAllWatchFiles(baseUrl: String, token: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        executeApi("$baseUrl/api/watch/reload", "POST", JSONObject(), token)
        Unit
      }
    }

  suspend fun deleteWatchFile(baseUrl: String, token: String, path: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val enc = URLEncoder.encode(path, "UTF-8")
        executeApi("$baseUrl/api/watch/files?path=$enc", "DELETE", null, token)
        Unit
      }
    }

  /**
   * Sends a real BitTorrent HTTP/HTTPS tracker announce request using the emulated client's
   * User-Agent and peer_id format (matching `rustatio-core/src/protocol/`).
   */
  suspend fun announceTracker(
    torrent: TorrentInfo,
    config: FakerConfig,
    peerId: String,
    key: String,
    uploaded: Long,
    downloaded: Long,
    left: Long,
    event: String?,
    proxy: ProxySettings,
  ): Result<TrackerAnnounceResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        val announceUrl = torrent.announce.trim()
        require(announceUrl.startsWith("http://", true) || announceUrl.startsWith("https://", true)) {
          if (announceUrl.startsWith("udp://", true)) {
            "Tracker UDP hiện cần chạy qua Rustatio Server; phiên cục bộ vẫn tính tiến trình ngoại tuyến."
          } else {
            "URL tracker không hợp lệ: $announceUrl"
          }
        }
        val infoHashEncoded = percentEncodeHex(torrent.infoHashHex)
        val peerIdEncoded = URLEncoder.encode(peerId, "US-ASCII")
        val sep = if (announceUrl.contains('?')) "&" else "?"
        val sb = StringBuilder(announceUrl).append(sep)
        sb.append("info_hash=").append(infoHashEncoded)
        sb.append("&peer_id=").append(peerIdEncoded)
        sb.append("&port=").append(config.port)
        sb.append("&uploaded=").append(uploaded.coerceAtLeast(0L))
        sb.append("&downloaded=").append(downloaded.coerceAtLeast(0L))
        sb.append("&left=").append(left.coerceAtLeast(0L))
        sb.append("&compact=1&numwant=50")
        if (!key.isNullOrBlank()) sb.append("&key=").append(key)
        if (!event.isNullOrBlank()) sb.append("&event=").append(event)

        val client = buildClientWithProxy(proxy, 12)
        val ua = "${config.clientType.userAgentPrefix}${config.clientVersion}"
        val req = Request.Builder().url(sb.toString()).header("User-Agent", ua).get().build()
        client.newCall(req).execute().use { resp ->
          if (!resp.isSuccessful) {
            error("Tracker phản hồi mã lỗi HTTP ${resp.code}")
          }
          val bytes = resp.body?.bytes() ?: error("Tracker trả về dữ liệu trống")
          // Parse bencode tracker response if valid
          parseTrackerResponse(bytes)
        }
      }
    }

  private fun parseTrackerResponse(bytes: ByteArray): TrackerAnnounceResult {
    // Simple bencode inspection for interval, complete, incomplete, failure reason
    val seedersRegex = "8:completei(\\d+)e".toRegex()
    val leechersRegex = "10:incompletei(\\d+)e".toRegex()
    val intervalRegex = "8:intervali(\\d+)e".toRegex()
    val raw = bytes.toString(Charsets.ISO_8859_1)
    if (raw.contains("14:failure reason")) {
      val after = raw.substringAfter("14:failure reason")
      val colonIdx = after.indexOf(':')
      if (colonIdx > 0) {
        val len = after.substring(0, colonIdx).toIntOrNull()
        if (len != null && colonIdx + 1 + len <= after.length) {
          error("Tracker từ chối: ${after.substring(colonIdx + 1, colonIdx + 1 + len)}")
        }
      }
    }
    val seeders = seedersRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    val leechers = leechersRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    val interval = intervalRegex.find(raw)?.groupValues?.get(1)?.toIntOrNull() ?: 1800
    return TrackerAnnounceResult(seeders = seeders, leechers = leechers, intervalSeconds = interval)
  }

  private fun percentEncodeHex(hex: String): String {
    val sb = StringBuilder()
    var i = 0
    while (i + 1 < hex.length) {
      sb.append('%').append(hex.substring(i, i + 2).uppercase())
      i += 2
    }
    return sb.toString()
  }

  private fun buildClientWithProxy(proxySettings: ProxySettings, timeoutSec: Long): OkHttpClient {
    val builder =
      baseClient
        .newBuilder()
        .connectTimeout(timeoutSec, TimeUnit.SECONDS)
        .readTimeout(timeoutSec, TimeUnit.SECONDS)
    if (proxySettings.enabled && proxySettings.host.isNotBlank()) {
      val javaProxyType =
        if (proxySettings.type == ProxyType.HTTP) Proxy.Type.HTTP else Proxy.Type.SOCKS
      builder.proxy(Proxy(javaProxyType, InetSocketAddress(proxySettings.host.trim(), proxySettings.port)))
      if (proxySettings.authentication && proxySettings.username.isNotBlank()) {
        Authenticator.setDefault(
          object : Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
              return PasswordAuthentication(
                proxySettings.username,
                proxySettings.password.toCharArray(),
              )
            }
          }
        )
      }
    }
    return builder.build()
  }

  private fun executeGet(url: String, token: String?): JSONObject {
    val reqBuilder = Request.Builder().url(url).get()
    if (!token.isNullOrBlank()) reqBuilder.header("Authorization", "Bearer ${token.trim()}")
    baseClient.newCall(reqBuilder.build()).execute().use { resp ->
      val text = resp.body?.string().orEmpty()
      if (!resp.isSuccessful) {
        val msg = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
        error(msg.ifBlank { "Lỗi HTTP ${resp.code}" })
      }
      return JSONObject(text)
    }
  }

  private fun executeApi(
    rawUrl: String,
    method: String,
    body: JSONObject?,
    token: String,
  ): JSONObject {
    val cleanUrl =
      if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl
      else "http://${rawUrl.trimStart('/')}"
    val reqBuilder = Request.Builder().url(cleanUrl)
    if (token.isNotBlank()) {
      reqBuilder.header("Authorization", "Bearer ${token.trim()}")
    }
    val reqBody = body?.toString()?.toRequestBody(jsonMediaType)
    when (method) {
      "GET" -> reqBuilder.get()
      "POST" -> reqBuilder.post(reqBody ?: "{}".toRequestBody(jsonMediaType))
      "PUT" -> reqBuilder.put(reqBody ?: "{}".toRequestBody(jsonMediaType))
      "PATCH" -> reqBuilder.patch(reqBody ?: "{}".toRequestBody(jsonMediaType))
      "DELETE" -> reqBuilder.delete(reqBody)
      else -> reqBuilder.method(method, reqBody)
    }
    baseClient.newCall(reqBuilder.build()).execute().use { resp ->
      val text = resp.body?.string().orEmpty()
      val json = runCatching { JSONObject(text) }.getOrNull()
      if (resp.code == 401 || resp.code == 403) {
        error("Yêu cầu xác thực máy chủ (HTTP ${resp.code}). Vui lòng kiểm tra Bearer Token.")
      }
      if (!resp.isSuccessful || (json != null && !json.optBoolean("success", true))) {
        val err = json?.optString("error").orEmpty()
        error(err.ifBlank { "Yêu cầu thất bại (HTTP ${resp.code})" })
      }
      return json ?: JSONObject()
    }
  }

  private fun parseServerInstance(obj: JSONObject): InstanceItem {
    val id = obj.optString("id")
    val torrentObj = obj.optJSONObject("torrent")
    val configObj = obj.optJSONObject("config")
    val statsObj = obj.optJSONObject("stats")
    val tagsArr = obj.optJSONArray("tags")
    val tags =
      buildList {
        if (tagsArr != null) {
          for (i in 0 until tagsArr.length()) {
            val s = tagsArr.optString(i)
            if (s.isNotBlank()) add(s)
          }
        }
      }
    val torrent = torrentObj?.let { parseTorrentInfo(it) }
    val config = configObj?.let { parseServerConfig(it) } ?: FakerConfig()
    val stats = statsObj?.let { parseServerStats(it) } ?: FakerStats()
    val source = InstanceSource.fromWire(obj.optString("source"))
    return InstanceItem(
      id = id,
      torrent = torrent,
      config = config,
      stats = stats,
      tags = tags,
      source = source,
      isRemote = true,
      statusMessage = "Đồng bộ từ Rustatio Server",
    )
  }

  private fun parseTorrentInfo(obj: JSONObject): TorrentInfo {
    val hashArr = obj.optJSONArray("info_hash")
    val hex =
      if (hashArr != null) {
        buildString {
          for (i in 0 until hashArr.length()) {
            append("%02x".format(hashArr.optInt(i) and 0xFF))
          }
        }
      } else obj.optString("info_hash_hex")
    val tiers = mutableListOf<List<String>>()
    val tiersArr = obj.optJSONArray("announce_list")
    if (tiersArr != null) {
      for (i in 0 until tiersArr.length()) {
        val sub = tiersArr.optJSONArray(i) ?: continue
        val list = mutableListOf<String>()
        for (j in 0 until sub.length()) {
          val u = sub.optString(j)
          if (u.isNotBlank()) list.add(u)
        }
        if (list.isNotEmpty()) tiers.add(list)
      }
    }
    val files = mutableListOf<TorrentFile>()
    val filesArr = obj.optJSONArray("files")
    if (filesArr != null) {
      for (i in 0 until filesArr.length()) {
        val f = filesArr.optJSONObject(i) ?: continue
        files.add(TorrentFile(f.optString("path"), f.optLong("size", 0L)))
      }
    }
    return TorrentInfo(
      infoHashHex = hex,
      announce = obj.optString("announce"),
      announceList = tiers,
      name = obj.optString("name"),
      totalSize = obj.optLong("total_size", 0L),
      pieceLength = obj.optLong("piece_length", 0L),
      numPieces = obj.optInt("num_pieces", 0),
      creationDate = if (obj.has("creation_date") && !obj.isNull("creation_date")) obj.optLong("creation_date") else null,
      comment = obj.optString("comment").takeIf { it.isNotBlank() },
      createdBy = obj.optString("created_by").takeIf { it.isNotBlank() },
      isSingleFile = obj.optBoolean("is_single_file", files.size <= 1),
      fileCount = obj.optInt("file_count", files.size.coerceAtLeast(1)),
      files = files,
    )
  }

  private fun parseServerConfig(obj: JSONObject): FakerConfig {
    val client = ClientType.fromId(obj.optString("client_type", "qbittorrent"))
    return FakerConfig(
      uploadRateKBs = obj.optDouble("upload_rate", 50.0),
      downloadRateKBs = obj.optDouble("download_rate", 0.0),
      port = obj.optInt("port", client.defaultPort),
      vpnPortSync = obj.optBoolean("vpn_port_sync", false),
      clientType = client,
      clientVersion = obj.optString("client_version").ifBlank { client.defaultVersion },
      completionPercent = obj.optDouble("completion_percent", 100.0),
      initialUploadedMB = obj.optLong("initial_uploaded", 0L) / (1024L * 1024L),
      randomizeRates = obj.optBoolean("randomize_rates", true),
      randomRangePercent = obj.optDouble("random_range_percent", 20.0),
      randomizeRatio = obj.optBoolean("randomize_ratio", false),
      randomRatioRangePercent = obj.optDouble("random_ratio_range_percent", 10.0),
      updateIntervalSeconds = obj.optInt("update_interval_seconds", 5),
      scrapeIntervalSeconds = obj.optInt("scrape_interval", 60),
      stopAtRatioEnabled = obj.has("stop_at_ratio") && !obj.isNull("stop_at_ratio"),
      stopAtRatio = obj.optDouble("stop_at_ratio", 2.0),
      stopAtUploadedEnabled = obj.has("stop_at_uploaded") && !obj.isNull("stop_at_uploaded"),
      stopAtUploadedGB = obj.optLong("stop_at_uploaded", 0L) / (1024.0 * 1024.0 * 1024.0),
      stopAtDownloadedEnabled = obj.has("stop_at_downloaded") && !obj.isNull("stop_at_downloaded"),
      stopAtDownloadedGB = obj.optLong("stop_at_downloaded", 0L) / (1024.0 * 1024.0 * 1024.0),
      stopAtSeedTimeEnabled = obj.has("stop_at_seed_time") && !obj.isNull("stop_at_seed_time"),
      stopAtSeedTimeHours = obj.optLong("stop_at_seed_time", 0L) / 3600.0,
      idleWhenNoLeechers = obj.optBoolean("idle_when_no_leechers", false),
      idleWhenNoSeeders = obj.optBoolean("idle_when_no_seeders", false),
      postStopAction = PostStopAction.fromWire(obj.optString("post_stop_action")),
      progressiveRatesEnabled = obj.optBoolean("progressive_rates", false),
      targetUploadRateKBs = obj.optDouble("target_upload_rate", 100.0),
      targetDownloadRateKBs = obj.optDouble("target_download_rate", 200.0),
      progressiveDurationHours = obj.optLong("progressive_duration", 3600L) / 3600.0,
    )
  }

  private fun parseServerStats(obj: JSONObject): FakerStats {
    val elapsed = obj.optJSONObject("elapsed_time")?.optLong("secs", 0L) ?: 0L
    val upHist = parseDoubleArray(obj.optJSONArray("upload_rate_history"))
    val dlHist = parseDoubleArray(obj.optJSONArray("download_rate_history"))
    val ratioHist = parseDoubleArray(obj.optJSONArray("ratio_history"))
    return FakerStats(
      state = FakerState.fromWire(obj.optString("state")),
      uploadedBytes = obj.optLong("uploaded", 0L),
      downloadedBytes = obj.optLong("downloaded", 0L),
      ratio = obj.optDouble("ratio", 0.0),
      leftBytes = obj.optLong("left", 0L),
      torrentCompletion = obj.optDouble("torrent_completion", 100.0),
      seeders = obj.optInt("seeders", 0),
      leechers = obj.optInt("leechers", 0),
      isIdling = obj.optBoolean("is_idling", false),
      idlingReason = obj.optString("idling_reason").takeIf { it.isNotBlank() },
      trackerError = obj.optString("tracker_error").takeIf { it.isNotBlank() },
      sessionUploadedBytes = obj.optLong("session_uploaded", 0L),
      sessionDownloadedBytes = obj.optLong("session_downloaded", 0L),
      sessionRatio = obj.optDouble("session_ratio", 0.0),
      elapsedSeconds = elapsed,
      currentUploadRateKBs = obj.optDouble("current_upload_rate", 0.0),
      currentDownloadRateKBs = obj.optDouble("current_download_rate", 0.0),
      averageUploadRateKBs = obj.optDouble("average_upload_rate", 0.0),
      averageDownloadRateKBs = obj.optDouble("average_download_rate", 0.0),
      uploadProgress = obj.optDouble("upload_progress", 0.0),
      downloadProgress = obj.optDouble("download_progress", 0.0),
      ratioProgress = obj.optDouble("ratio_progress", 0.0),
      seedTimeProgress = obj.optDouble("seed_time_progress", 0.0),
      announceCount = obj.optInt("announce_count", 0),
      uploadRateHistory = upHist,
      downloadRateHistory = dlHist,
      ratioHistory = ratioHist,
      stopConditionMet = obj.optBoolean("stop_condition_met", false),
    )
  }

  private fun parseDoubleArray(arr: JSONArray?): List<Double> {
    if (arr == null) return emptyList()
    return buildList {
      for (i in 0 until arr.length()) add(arr.optDouble(i, 0.0))
    }
  }

  private fun serializeTorrentInfoForServer(t: TorrentInfo): JSONObject {
    val hashBytes = JSONArray()
    var i = 0
    while (i + 1 < t.infoHashHex.length) {
      hashBytes.put(t.infoHashHex.substring(i, i + 2).toInt(16))
      i += 2
    }
    return JSONObject().apply {
      put("info_hash", hashBytes)
      put("announce", t.announce)
      put("name", t.name)
      put("total_size", t.totalSize)
      put("piece_length", t.pieceLength)
      put("num_pieces", t.numPieces)
      put("is_single_file", t.isSingleFile)
      put("file_count", t.fileCount)
    }
  }

  private fun serializeFakerConfigForServer(c: FakerConfig, torrentSize: Long): JSONObject {
    val initialDl = ((torrentSize * c.completionPercent) / 100.0).toLong().coerceAtLeast(0L)
    return JSONObject().apply {
      put("upload_rate", c.uploadRateKBs)
      put("download_rate", c.downloadRateKBs)
      put("port", c.port)
      put("vpn_port_sync", c.vpnPortSync)
      put("client_type", c.clientType.id)
      put("client_version", c.clientVersion)
      put("initial_uploaded", c.initialUploadedMB * 1024L * 1024L)
      put("initial_downloaded", initialDl)
      put("completion_percent", c.completionPercent)
      put("num_want", 50)
      put("randomize_rates", c.randomizeRates)
      put("random_range_percent", c.randomRangePercent)
      put("randomize_ratio", c.randomizeRatio)
      put("random_ratio_range_percent", c.randomRatioRangePercent)
      put("stop_at_ratio", if (c.stopAtRatioEnabled) c.stopAtRatio else JSONObject.NULL)
      put(
        "stop_at_uploaded",
        if (c.stopAtUploadedEnabled) (c.stopAtUploadedGB * 1024.0 * 1024.0 * 1024.0).toLong()
        else JSONObject.NULL,
      )
      put(
        "stop_at_downloaded",
        if (c.stopAtDownloadedEnabled) (c.stopAtDownloadedGB * 1024.0 * 1024.0 * 1024.0).toLong()
        else JSONObject.NULL,
      )
      put(
        "stop_at_seed_time",
        if (c.stopAtSeedTimeEnabled) (c.stopAtSeedTimeHours * 3600.0).toLong()
        else JSONObject.NULL,
      )
      put("idle_when_no_leechers", c.idleWhenNoLeechers)
      put("idle_when_no_seeders", c.idleWhenNoSeeders)
      put("scrape_interval", c.scrapeIntervalSeconds)
      put("update_interval_seconds", c.updateIntervalSeconds)
      put("progressive_rates", c.progressiveRatesEnabled)
      put("target_upload_rate", c.targetUploadRateKBs)
      put("target_download_rate", c.targetDownloadRateKBs)
      put("progressive_duration", (c.progressiveDurationHours * 3600.0).toLong())
      put("post_stop_action", c.postStopAction.wireName)
    }
  }

  private fun parseProxyUrlToSettings(
    enabled: Boolean,
    url: String,
    username: String,
    password: String,
  ): ProxySettings {
    val lower = url.lowercase()
    val type =
      when {
        lower.startsWith("socks5h://") -> ProxyType.SOCKS5H
        lower.startsWith("socks5://") -> ProxyType.SOCKS5
        lower.startsWith("socks4a://") -> ProxyType.SOCKS4A
        lower.startsWith("socks4://") -> ProxyType.SOCKS4
        lower.startsWith("http://") -> ProxyType.HTTP
        else -> ProxyType.SOCKS5
      }
    val hostPort = url.substringAfter("://", "127.0.0.1:1080")
    val host = hostPort.substringBefore(':').ifBlank { "127.0.0.1" }
    val port = hostPort.substringAfter(':', "1080").toIntOrNull() ?: type.defaultPort
    return ProxySettings(
      enabled = enabled,
      type = type,
      host = host,
      port = port,
      resolveHostnameViaProxy = type == ProxyType.SOCKS5H || type == ProxyType.SOCKS4A,
      authentication = username.isNotBlank(),
      username = username,
      password = password,
    )
  }
}
