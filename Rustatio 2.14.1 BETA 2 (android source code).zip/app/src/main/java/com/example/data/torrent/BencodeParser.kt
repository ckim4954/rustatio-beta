package com.example.data.torrent

import com.example.domain.model.TorrentFile
import com.example.domain.model.TorrentInfo
import java.io.ByteArrayInputStream
import java.security.MessageDigest

/**
 * Pure Kotlin Bencode parser matching `rustatio-core/src/torrent/info.rs`
 * and computing the exact SHA-1 `info_hash` over the raw `info` dictionary bytes.
 */
object BencodeParser {

  sealed class BValue {
    data class BInt(val value: Long) : BValue()

    data class BBytes(val value: ByteArray) : BValue() {
      fun asUtf8(): String = value.toString(Charsets.UTF_8)
    }

    data class BList(val items: List<BValue>) : BValue()

    data class BDict(val entries: LinkedHashMap<String, BValue>, val rawStart: Int, val rawEnd: Int) :
      BValue()
  }

  fun parseTorrent(bytes: ByteArray, fallbackName: String = "torrent.torrent"): Result<TorrentInfo> =
    runCatching {
      require(bytes.isNotEmpty()) { "Tệp .torrent trống." }
      val reader = Reader(bytes)
      val root =
        reader.readValue() as? BValue.BDict
          ?: error("Cấu trúc Bencode gốc không phải từ điển hợp lệ.")

      val infoDict =
        root.entries["info"] as? BValue.BDict ?: error("Thiếu khóa bắt buộc 'info' trong tệp .torrent.")

      val rawInfoBytes = bytes.copyOfRange(infoDict.rawStart, infoDict.rawEnd)
      val infoHashBytes = MessageDigest.getInstance("SHA-1").digest(rawInfoBytes)
      val infoHashHex = infoHashBytes.joinToString("") { "%02x".format(it) }

      val announceList =
        (root.entries["announce-list"] as? BValue.BList)?.items?.mapNotNull { tierVal ->
          (tierVal as? BValue.BList)?.items?.mapNotNull { urlVal ->
            (urlVal as? BValue.BBytes)?.asUtf8()?.trim()?.takeIf { it.isNotEmpty() }
          }?.takeIf { it.isNotEmpty() }
        } ?: emptyList()

      val announce =
        (root.entries["announce"] as? BValue.BBytes)?.asUtf8()?.trim()?.takeIf { it.isNotEmpty() }
          ?: announceList.flatten().firstOrNull()
          ?: ""

      val name =
        (infoDict.entries["name.utf-8"] as? BValue.BBytes)?.asUtf8()?.takeIf { it.isNotBlank() }
          ?: (infoDict.entries["name"] as? BValue.BBytes)?.asUtf8()?.takeIf { it.isNotBlank() }
          ?: fallbackName.removeSuffix(".torrent")

      val pieceLength = (infoDict.entries["piece length"] as? BValue.BInt)?.value ?: 0L
      val piecesLen = (infoDict.entries["pieces"] as? BValue.BBytes)?.value?.size ?: 0
      val numPieces = piecesLen / 20

      val singleLength = (infoDict.entries["length"] as? BValue.BInt)?.value
      val filesList = infoDict.entries["files"] as? BValue.BList

      val parsedFiles: List<TorrentFile>
      val totalSize: Long
      val isSingleFile: Boolean

      if (filesList != null) {
        isSingleFile = false
        parsedFiles =
          filesList.items.mapNotNull { entry ->
            val dict = entry as? BValue.BDict ?: return@mapNotNull null
            val len = (dict.entries["length"] as? BValue.BInt)?.value ?: 0L
            val pathParts =
              (dict.entries["path.utf-8"] as? BValue.BList ?: dict.entries["path"] as? BValue.BList)
                ?.items
                ?.mapNotNull { (it as? BValue.BBytes)?.asUtf8() }
                ?: emptyList()
            TorrentFile(path = pathParts.joinToString("/").ifBlank { "file" }, size = len)
          }
        totalSize = parsedFiles.sumOf { it.size }
      } else {
        isSingleFile = true
        totalSize = (singleLength ?: 0L).coerceAtLeast(0L)
        parsedFiles = listOf(TorrentFile(path = name, size = totalSize))
      }

      val creationDate = (root.entries["creation date"] as? BValue.BInt)?.value
      val comment =
        (root.entries["comment.utf-8"] as? BValue.BBytes)?.asUtf8()
          ?: (root.entries["comment"] as? BValue.BBytes)?.asUtf8()
      val createdBy = (root.entries["created by"] as? BValue.BBytes)?.asUtf8()

      TorrentInfo(
        infoHashHex = infoHashHex,
        announce = announce,
        announceList = announceList,
        name = name,
        totalSize = totalSize,
        pieceLength = pieceLength,
        numPieces = numPieces,
        creationDate = creationDate,
        comment = comment?.takeIf { it.isNotBlank() },
        createdBy = createdBy?.takeIf { it.isNotBlank() },
        isSingleFile = isSingleFile,
        fileCount = parsedFiles.size,
        files = parsedFiles,
      )
    }

  private class Reader(private val data: ByteArray) {
    private var pos = 0

    fun readValue(): BValue {
      if (pos >= data.size) error("Kết thúc dữ liệu Bencode bất ngờ tại vị trí $pos.")
      return when (val ch = data[pos].toInt().toChar()) {
        'i' -> readInt()
        'l' -> readList()
        'd' -> readDict()
        in '0'..'9' -> readBytes()
        else -> error("Ký tự Bencode không hợp lệ '$ch' tại vị trí $pos.")
      }
    }

    private fun readInt(): BValue.BInt {
      pos++ // skip 'i'
      val end = indexOf('e'.code.toByte())
      val str = String(data, pos, end - pos, Charsets.US_ASCII)
      pos = end + 1
      return BValue.BInt(str.toLongOrNull() ?: error("Số nguyên Bencode không hợp lệ: $str"))
    }

    private fun readBytes(): BValue.BBytes {
      val colon = indexOf(':'.code.toByte())
      val lenStr = String(data, pos, colon - pos, Charsets.US_ASCII)
      val len = lenStr.toIntOrNull() ?: error("Độ dài chuỗi Bencode không hợp lệ: $lenStr")
      require(len >= 0 && colon + 1 + len <= data.size) { "Độ dài Bencode vượt kích thước tệp." }
      val slice = data.copyOfRange(colon + 1, colon + 1 + len)
      pos = colon + 1 + len
      return BValue.BBytes(slice)
    }

    private fun readList(): BValue.BList {
      pos++ // skip 'l'
      val items = mutableListOf<BValue>()
      while (pos < data.size && data[pos] != 'e'.code.toByte()) {
        items.add(readValue())
      }
      if (pos >= data.size) error("Danh sách Bencode thiếu ký tự kết thúc 'e'.")
      pos++ // skip 'e'
      return BValue.BList(items)
    }

    private fun readDict(): BValue.BDict {
      val start = pos
      pos++ // skip 'd'
      val map = LinkedHashMap<String, BValue>()
      while (pos < data.size && data[pos] != 'e'.code.toByte()) {
        val key = readBytes().asUtf8()
        val value = readValue()
        map[key] = value
      }
      if (pos >= data.size) error("Từ điển Bencode thiếu ký tự kết thúc 'e'.")
      pos++ // skip 'e'
      return BValue.BDict(map, start, pos)
    }

    private fun indexOf(target: Byte): Int {
      var i = pos
      while (i < data.size) {
        if (data[i] == target) return i
        i++
      }
      error("Thiếu ký tự phân tách Bencode tại vị trí $pos.")
    }
  }
}
