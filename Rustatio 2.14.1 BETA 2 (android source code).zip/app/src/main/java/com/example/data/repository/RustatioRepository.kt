package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.engine.LocalFakerEngine
import com.example.data.local.AppPreferences
import com.example.data.local.AppSettingsSnapshot
import com.example.data.local.CustomPresetEntity
import com.example.data.local.JsonCodecs
import com.example.data.local.LocalInstanceEntity
import com.example.data.local.RustatioDatabase
import com.example.data.remote.RustatioServerClient
import com.example.data.torrent.BencodeParser
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.FakerStats
import com.example.domain.model.InstanceItem
import com.example.domain.model.InstanceSource
import com.example.domain.model.LogEntry
import com.example.domain.model.LogLevel
import com.example.domain.model.NetworkStatus
import com.example.domain.model.Preset
import com.example.domain.model.ProxySettings
import com.example.domain.model.RunMode
import com.example.domain.model.TorrentInfo
import com.example.domain.model.WatchConfig
import com.example.domain.model.WatchFileEntry
import com.example.domain.model.WatchFileStatus
import com.example.domain.model.WatchStatus
import com.example.ui.theme.ThemeMode
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class RustatioRepository(
  private val context: Context,
  val preferences: AppPreferences,
  private val database: RustatioDatabase,
  private val serverClient: RustatioServerClient,
  val localEngine: LocalFakerEngine,
) {
  private val instanceDao = database.localInstanceDao()
  private val presetDao = database.customPresetDao()

  private val _remoteInstances = MutableStateFlow<List<InstanceItem>>(emptyList())
  private val _serverOnline = MutableStateFlow(false)
  val serverOnline: StateFlow<Boolean> = _serverOnline.asStateFlow()

  private val _serverError = MutableStateFlow<String?>(null)
  val serverError: StateFlow<String?> = _serverError.asStateFlow()

  val settingsFlow: Flow<AppSettingsSnapshot> = preferences.settingsFlow

  val logsFlow: StateFlow<List<LogEntry>> = localEngine.logs

  val customPresetsFlow: Flow<List<Preset>> =
    presetDao.observeAll().map { entities ->
      entities.map { entity ->
        Preset(
          id = entity.id,
          name = entity.name,
          description = entity.description,
          icon = entity.icon,
          recommended = false,
          custom = true,
          createdAt = entity.createdAt,
          config = JsonCodecs.decodePresetConfig(entity.settingsJson),
        )
      }
    }

  val instancesFlow: Flow<List<InstanceItem>> =
    combine(
      instanceDao.observeAll(),
      localEngine.statsMap,
      _remoteInstances,
      settingsFlow,
    ) { localEntities, statsMap, remoteList, settings ->
      if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
        remoteList
      } else {
        localEntities.map { entity ->
          val torrent = JsonCodecs.decodeTorrent(entity.torrentJson)
          val config = JsonCodecs.decodeConfig(entity.configJson)
          val tags = JsonCodecs.decodeTags(entity.tagsJson)
          val liveStats = statsMap[entity.id]
          val stats =
            liveStats
              ?: FakerStats(
                state = FakerState.STOPPED,
                uploadedBytes = entity.cumulativeUploadedBytes,
                downloadedBytes = entity.cumulativeDownloadedBytes,
                ratio =
                  if (torrent != null && torrent.totalSize > 0L) {
                    entity.cumulativeUploadedBytes.toDouble() / torrent.totalSize
                  } else 0.0,
                torrentCompletion = config.completionPercent,
              )
          InstanceItem(
            id = entity.id,
            torrent = torrent,
            config = config,
            stats = stats,
            tags = tags,
            source = InstanceSource.fromWire(entity.source),
            isRemote = false,
            statusMessage =
              if (torrent == null) "Chưa chọn tệp .torrent"
              else when (stats.state) {
                FakerState.RUNNING -> "Đang giả lập tỷ lệ"
                FakerState.PAUSED -> "Đang tạm dừng"
                FakerState.STARTING -> "Đang kết nối tracker"
                else -> "Sẵn sàng giả lập"
              },
            createdAtMs = entity.createdAtMs,
          )
        }
      }
    }

  init {
    localEngine.attachCallbacks(
      persistTotals = { id, up, dl ->
        val current = instanceDao.getAll().firstOrNull { it.id == id }
        if (current != null) {
          instanceDao.upsert(
            current.copy(cumulativeUploadedBytes = up, cumulativeDownloadedBytes = dl)
          )
        }
      },
      deleteInstance = { id -> instanceDao.deleteById(id) },
    )
  }

  suspend fun refreshServerInstances(): Result<Unit> {
    val settings = settingsFlow.first()
    if (settings.runMode != RunMode.SERVER || settings.serverUrl.isBlank()) {
      _serverOnline.value = false
      return Result.failure(IllegalStateException("Chưa cấu hình địa chỉ Rustatio Server."))
    }
    return serverClient.listInstances(settings.serverUrl, settings.serverToken).map { list ->
      _remoteInstances.value = list
      _serverOnline.value = true
      _serverError.value = null
    }.onFailure { err ->
      _serverOnline.value = false
      _serverError.value = err.message
      localEngine.appendLog(LogLevel.ERROR, null, "Lỗi đồng bộ server: ${err.message}")
    }
  }

  suspend fun importTorrentUris(
    uris: List<Uri>,
    source: InstanceSource = InstanceSource.MANUAL,
  ): Result<Int> =
    withContext(Dispatchers.IO) {
      runCatching {
        val settings = settingsFlow.first()
        val defaultConfig = resolveDefaultConfig(settings.defaultPresetId)
        var imported = 0
        for (uri in uris) {
          val bytes =
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
              ?: error("Không thể đọc dữ liệu tệp từ URI: $uri")
          val fileName = queryDisplayName(uri) ?: "torrent.torrent"
          if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
            val id = serverClient.createInstance(settings.serverUrl, settings.serverToken).getOrThrow()
            serverClient
              .uploadInstanceTorrent(settings.serverUrl, settings.serverToken, id, fileName, bytes)
              .getOrThrow()
            imported++
          } else {
            val torrent = BencodeParser.parseTorrent(bytes, fileName).getOrThrow()
            val existing = instanceDao.getAll()
            val dup =
              existing.firstOrNull {
                JsonCodecs.decodeTorrent(it.torrentJson)?.infoHashHex == torrent.infoHashHex
              }
            if (dup == null) {
              val id = UUID.randomUUID().toString().take(8)
              instanceDao.upsert(
                LocalInstanceEntity(
                  id = id,
                  torrentJson = JsonCodecs.encodeTorrent(torrent),
                  configJson = JsonCodecs.encodeConfig(defaultConfig),
                  tagsJson = "[]",
                  source = source.wireName,
                  cumulativeUploadedBytes = 0L,
                  cumulativeDownloadedBytes = 0L,
                  createdAtMs = System.currentTimeMillis(),
                )
              )
              localEngine.appendLog(
                LogLevel.INFO,
                id,
                "[Phiên $id] Đã nhập torrent '${torrent.name}'",
              )
              imported++
            }
          }
        }
        if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
          refreshServerInstances()
        }
        imported
      }
    }

  suspend fun createEmptySession(): Result<String> {
    val settings = settingsFlow.first()
    val defaultConfig = resolveDefaultConfig(settings.defaultPresetId)
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      serverClient.createInstance(settings.serverUrl, settings.serverToken).also {
        refreshServerInstances()
      }
    } else {
      val id = UUID.randomUUID().toString().take(8)
      instanceDao.upsert(
        LocalInstanceEntity(
          id = id,
          torrentJson = null,
          configJson = JsonCodecs.encodeConfig(defaultConfig),
          tagsJson = "[]",
          source = InstanceSource.MANUAL.wireName,
          cumulativeUploadedBytes = 0L,
          cumulativeDownloadedBytes = 0L,
          createdAtMs = System.currentTimeMillis(),
        )
      )
      localEngine.appendLog(LogLevel.INFO, id, "Đã tạo phiên mới #$id")
      Result.success(id)
    }
  }

  suspend fun replaceSessionTorrent(instanceId: String, uri: Uri): Result<TorrentInfo> =
    withContext(Dispatchers.IO) {
      runCatching {
        val bytes =
          context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Không thể đọc tệp .torrent.")
        val name = queryDisplayName(uri) ?: "torrent.torrent"
        val settings = settingsFlow.first()
        if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
          val info =
            serverClient
              .uploadInstanceTorrent(settings.serverUrl, settings.serverToken, instanceId, name, bytes)
              .getOrThrow()
          refreshServerInstances()
          info
        } else {
          val info = BencodeParser.parseTorrent(bytes, name).getOrThrow()
          val existing = instanceDao.getAll().firstOrNull { it.id == instanceId }
            ?: error("Không tìm thấy phiên.")
          instanceDao.upsert(existing.copy(torrentJson = JsonCodecs.encodeTorrent(info)))
          info
        }
      }
    }

  suspend fun updateSessionConfig(instanceId: String, config: FakerConfig): Result<Unit> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      val item = _remoteInstances.value.firstOrNull { it.id == instanceId }
      serverClient
        .updateInstanceConfig(
          settings.serverUrl,
          settings.serverToken,
          instanceId,
          config,
          item?.torrent?.totalSize ?: 0L,
        )
        .also { refreshServerInstances() }
    } else {
      val existing = instanceDao.getAll().firstOrNull { it.id == instanceId }
        ?: return Result.failure(IllegalArgumentException("Không tìm thấy phiên"))
      instanceDao.upsert(existing.copy(configJson = JsonCodecs.encodeConfig(config)))
      localEngine.appendLog(LogLevel.DEBUG, instanceId, "[Phiên $instanceId] Đã lưu cấu hình mới")
      Result.success(Unit)
    }
  }

  suspend fun updateSessionTags(instanceId: String, tags: List<String>): Result<Unit> {
    val clean = tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      serverClient.setInstanceTags(settings.serverUrl, settings.serverToken, instanceId, clean)
        .also { refreshServerInstances() }
    } else {
      val existing = instanceDao.getAll().firstOrNull { it.id == instanceId }
        ?: return Result.failure(IllegalArgumentException("Không tìm thấy phiên"))
      instanceDao.upsert(existing.copy(tagsJson = JsonCodecs.encodeTags(clean)))
      Result.success(Unit)
    }
  }

  suspend fun startSession(item: InstanceItem): Result<Unit> {
    val torrent =
      item.torrent
        ?: return Result.failure(IllegalStateException("Vui lòng chọn tệp .torrent trước khi bắt đầu."))
    val settings = settingsFlow.first()
    localEngine.updateProxy(settings.proxy)
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.startFaker(settings.serverUrl, settings.serverToken, item.id, torrent, item.config)
        .also { refreshServerInstances() }
    } else {
      localEngine.start(
        instanceId = item.id,
        torrent = torrent,
        config = item.config,
        baseUploadedBytes = item.stats.uploadedBytes,
        baseDownloadedBytes = item.stats.downloadedBytes,
      )
      Result.success(Unit)
    }
  }

  suspend fun pauseSession(item: InstanceItem): Result<Unit> {
    val settings = settingsFlow.first()
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.pauseFaker(settings.serverUrl, settings.serverToken, item.id)
        .also { refreshServerInstances() }
    } else {
      localEngine.pause(item.id)
      Result.success(Unit)
    }
  }

  suspend fun resumeSession(item: InstanceItem): Result<Unit> {
    val settings = settingsFlow.first()
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.resumeFaker(settings.serverUrl, settings.serverToken, item.id)
        .also { refreshServerInstances() }
    } else {
      localEngine.resume(item.id)
      Result.success(Unit)
    }
  }

  suspend fun stopSession(item: InstanceItem): Result<Unit> {
    val settings = settingsFlow.first()
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.stopFaker(settings.serverUrl, settings.serverToken, item.id)
        .also { refreshServerInstances() }
    } else {
      localEngine.stop(item.id)
      Result.success(Unit)
    }
  }

  suspend fun deleteSessions(ids: List<String>): Result<Unit> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      serverClient.gridAction(settings.serverUrl, settings.serverToken, "delete", ids)
        .also { refreshServerInstances() }
    } else {
      ids.forEach { localEngine.stop(it) }
      instanceDao.deleteByIds(ids)
      Result.success(Unit)
    }
  }

  suspend fun bulkAction(action: String, items: List<InstanceItem>): Result<Unit> {
    val settings = settingsFlow.first()
    val ids = items.map { it.id }
    if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      return serverClient.gridAction(settings.serverUrl, settings.serverToken, action, ids)
        .also { refreshServerInstances() }
    }
    items.forEach { item ->
      when (action) {
        "start" -> if (item.torrent != null) startSession(item)
        "pause" -> pauseSession(item)
        "resume" -> resumeSession(item)
        "stop" -> stopSession(item)
      }
    }
    return Result.success(Unit)
  }

  // Watch folder SAF + Server
  suspend fun scanLocalWatchTree(treeUriStr: String, maxDepth: Int): Result<Pair<WatchStatus, List<WatchFileEntry>>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val treeUri = Uri.parse(treeUriStr)
        val existingHashes =
          instanceDao.getAll()
            .mapNotNull { JsonCodecs.decodeTorrent(it.torrentJson)?.infoHashHex }
            .toSet()

        val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val entries = mutableListOf<WatchFileEntry>()
        val folders = mutableSetOf<String>()

        fun walk(docId: String, relPrefix: String, depth: Int) {
          val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
          val projection =
            arrayOf(
              DocumentsContract.Document.COLUMN_DOCUMENT_ID,
              DocumentsContract.Document.COLUMN_DISPLAY_NAME,
              DocumentsContract.Document.COLUMN_MIME_TYPE,
              DocumentsContract.Document.COLUMN_SIZE,
            )
          context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val sizeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            while (cursor.moveToNext()) {
              val childId = cursor.getString(idIdx)
              val childName = cursor.getString(nameIdx) ?: continue
              val mime = cursor.getString(mimeIdx).orEmpty()
              val size = if (sizeIdx >= 0) cursor.getLong(sizeIdx) else 0L
              val relPath = if (relPrefix.isBlank()) childName else "$relPrefix/$childName"
              if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                folders.add(relPath)
                if (maxDepth == 0 || depth < maxDepth) {
                  walk(childId, relPath, depth + 1)
                }
              } else if (childName.endsWith(".torrent", ignoreCase = true)) {
                val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                val parsed =
                  context.contentResolver.openInputStream(docUri)?.use { input ->
                    BencodeParser.parseTorrent(input.readBytes(), childName)
                  }
                val infoHash = parsed?.getOrNull()?.infoHashHex
                val status =
                  when {
                    parsed == null || parsed.isFailure -> WatchFileStatus.INVALID
                    infoHash != null && existingHashes.contains(infoHash) -> WatchFileStatus.LOADED
                    else -> WatchFileStatus.PENDING
                  }
                entries.add(
                  WatchFileEntry(
                    filename = relPath,
                    displayName = childName,
                    sizeBytes = size,
                    status = status,
                    uriString = docUri.toString(),
                    errorMessage = parsed?.exceptionOrNull()?.message,
                    infoHashHex = infoHash,
                  )
                )
              }
            }
          }
        }

        walk(rootDocId, "", 1)

        val displayPath =
          treeUri.lastPathSegment?.substringAfter(':', treeUri.lastPathSegment.orEmpty())
            ?.ifBlank { treeUriStr } ?: treeUriStr
        val status =
          WatchStatus(
            watchDir = displayPath,
            loadedCount = entries.count { it.status == WatchFileStatus.LOADED },
            totalFiles = entries.size,
            pendingCount = entries.count { it.status == WatchFileStatus.PENDING },
            invalidCount = entries.count { it.status == WatchFileStatus.INVALID },
            folderCount = folders.size,
            isWatching = true,
          )
        status to entries.sortedBy { it.filename.lowercase() }
      }
    }

  suspend fun deleteLocalSafWatchFile(uriString: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val deleted = DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(uriString))
        if (!deleted) error("Hệ thống từ chối xóa tệp khỏi thư mục SAF.")
      }
    }

  suspend fun fetchServerWatch() =
    settingsFlow.first().let { s ->
      if (s.serverUrl.isBlank()) Result.failure(IllegalStateException("Chưa cấu hình địa chỉ máy chủ."))
      else serverClient.fetchWatchData(s.serverUrl, s.serverToken)
    }

  suspend fun setServerWatchConfig(config: WatchConfig) =
    settingsFlow.first().let { s ->
      serverClient.setWatchConfig(s.serverUrl, s.serverToken, config)
    }

  suspend fun reloadServerWatchFile(path: String) =
    settingsFlow.first().let { s ->
      serverClient.reloadWatchFile(s.serverUrl, s.serverToken, path)
    }

  suspend fun reloadAllServerWatch() =
    settingsFlow.first().let { s ->
      serverClient.reloadAllWatchFiles(s.serverUrl, s.serverToken)
    }

  suspend fun deleteServerWatchFile(path: String) =
    settingsFlow.first().let { s ->
      serverClient.deleteWatchFile(s.serverUrl, s.serverToken, path)
    }

  // Presets & Settings
  suspend fun getCustomPresetById(id: String): Preset? =
    withContext(Dispatchers.IO) {
      presetDao.getById(id)?.let { entity ->
        Preset(
          id = entity.id,
          name = entity.name,
          description = entity.description,
          icon = entity.icon,
          recommended = false,
          custom = true,
          createdAt = entity.createdAt,
          config = JsonCodecs.decodePresetConfig(entity.settingsJson),
        )
      }
    }

  suspend fun saveCustomPreset(
    name: String,
    description: String,
    config: FakerConfig,
    icon: String = "star",
  ): Result<Preset> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Vui lòng nhập tên Preset." }
        val cleanDesc = description.trim()
        require(cleanDesc.length <= 200) { "Mô tả Preset không được vượt quá 200 ký tự." }
        val id = "custom-${System.currentTimeMillis()}"
        val nowIso =
          java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            .format(java.util.Date())
        val finalDesc = cleanDesc.ifBlank { "Preset tùy chỉnh" }
        val entity =
          CustomPresetEntity(
            id = id,
            name = cleanName,
            description = finalDesc,
            icon = icon.ifBlank { "star" },
            createdAt = nowIso,
            settingsJson = JsonCodecs.encodePresetSettings(config).toString(),
          )
        presetDao.upsert(entity)
        getCustomPresetById(id) ?: error("Không thể đọc lại Preset vừa lưu từ cơ sở dữ liệu.")
      }
    }

  suspend fun updateCustomPreset(
    id: String,
    name: String,
    description: String,
    config: FakerConfig,
    icon: String = "star",
  ): Result<Preset> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Vui lòng nhập tên Preset." }
        val cleanDesc = description.trim()
        require(cleanDesc.length <= 200) { "Mô tả Preset không được vượt quá 200 ký tự." }
        val existing = presetDao.getById(id) ?: error("Không tìm thấy Preset tùy chỉnh để cập nhật.")
        val entity =
          existing.copy(
            name = cleanName,
            description = cleanDesc.ifBlank { "Preset tùy chỉnh" },
            icon = icon.ifBlank { existing.icon.ifBlank { "star" } },
            settingsJson = JsonCodecs.encodePresetSettings(config).toString(),
          )
        presetDao.upsert(entity)
        getCustomPresetById(id) ?: error("Không thể đọc lại Preset sau khi cập nhật.")
      }
    }

  suspend fun applyPresetToInstance(instanceId: String, preset: Preset): Result<InstanceItem> =
    withContext(Dispatchers.IO) {
      runCatching {
        val settings = settingsFlow.first()
        if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
          val current =
            _remoteInstances.value.firstOrNull { it.id == instanceId }
              ?: error("Không tìm thấy phiên trên Server.")
          val merged = preset.config.copy(initialUploadedMB = current.config.initialUploadedMB)
          updateSessionConfig(instanceId, merged).getOrThrow()
          val refreshedList =
            serverClient.listInstances(settings.serverUrl, settings.serverToken).getOrThrow()
          _remoteInstances.value = refreshedList
          refreshedList.firstOrNull { it.id == instanceId }
            ?: error("Không thể xác minh phiên sau khi áp dụng Preset trên Server.")
        } else {
          val existing =
            instanceDao.getAll().firstOrNull { it.id == instanceId }
              ?: error("Không tìm thấy phiên #$instanceId trong cơ sở dữ liệu.")
          val existingConfig = JsonCodecs.decodeConfig(existing.configJson)
          val merged = preset.config.copy(initialUploadedMB = existingConfig.initialUploadedMB)
          updateSessionConfig(instanceId, merged).getOrThrow()
          val reloaded =
            instanceDao.getAll().firstOrNull { it.id == instanceId }
              ?: error("Không thể đọc lại phiên #$instanceId sau khi áp dụng Preset.")
          val torrent = JsonCodecs.decodeTorrent(reloaded.torrentJson)
          val reloadedConfig = JsonCodecs.decodeConfig(reloaded.configJson)
          val tags = JsonCodecs.decodeTags(reloaded.tagsJson)
          InstanceItem(
            id = reloaded.id,
            torrent = torrent,
            config = reloadedConfig,
            tags = tags,
            source = InstanceSource.fromWire(reloaded.source),
            isRemote = false,
            createdAtMs = reloaded.createdAtMs,
          )
        }
      }
    }

  suspend fun importCustomPreset(jsonText: String): Result<Preset> =
    JsonCodecs.importPresetJson(jsonText).onSuccess { preset ->
      presetDao.upsert(
        CustomPresetEntity(
          id = preset.id,
          name = preset.name,
          description = preset.description,
          icon = preset.icon,
          createdAt = preset.createdAt,
          settingsJson = JsonCodecs.encodePresetSettings(preset.config).toString(),
        )
      )
    }

  suspend fun deleteCustomPreset(id: String) {
    presetDao.deleteById(id)
    val defaultId = settingsFlow.first().defaultPresetId
    if (defaultId == id) preferences.setDefaultPresetId(null)
  }

  suspend fun setThemeMode(mode: ThemeMode) = preferences.setThemeMode(mode)

  suspend fun setRunMode(mode: RunMode) = preferences.setRunMode(mode)

  suspend fun saveServerConnection(url: String, token: String) =
    preferences.setServerConnection(url, token)

  suspend fun testServerConnection(url: String, token: String): Result<Boolean> =
    serverClient.checkServerConnection(url, token)

  suspend fun setLogLevel(level: LogLevel) = preferences.setLogLevel(level)

  suspend fun saveProxySettings(proxy: ProxySettings): Result<Unit> {
    preferences.setProxySettings(proxy)
    localEngine.updateProxy(proxy)
    val settings = settingsFlow.first()
    if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank() && _serverOnline.value) {
      return serverClient.setProxySettings(settings.serverUrl, settings.serverToken, proxy)
    }
    return Result.success(Unit)
  }

  suspend fun testProxyConnection(proxy: ProxySettings): Result<String> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank() && _serverOnline.value) {
      serverClient.testProxyOnServer(settings.serverUrl, settings.serverToken, proxy)
    } else {
      serverClient.testProxyDirect(proxy)
    }
  }

  suspend fun fetchNetworkStatus(): Result<NetworkStatus> {
    val settings = settingsFlow.first()
    val url = if (settings.runMode == RunMode.SERVER) settings.serverUrl else null
    return serverClient.fetchNetworkStatus(url, settings.serverToken, settings.proxy)
  }

  private suspend fun resolveDefaultConfig(defaultPresetId: String?): FakerConfig {
    if (defaultPresetId.isNullOrBlank()) return FakerConfig()
    BuiltInPresets.all.firstOrNull { it.id == defaultPresetId }?.let { return it.config }
    return customPresetsFlow.first().firstOrNull { it.id == defaultPresetId }?.config ?: FakerConfig()
  }

  private fun queryDisplayName(uri: Uri): String? {
    context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
      ?.use { c ->
        if (c.moveToFirst()) {
          val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
          if (idx >= 0) return c.getString(idx)
        }
      }
    return uri.lastPathSegment?.substringAfterLast('/')
  }
}
