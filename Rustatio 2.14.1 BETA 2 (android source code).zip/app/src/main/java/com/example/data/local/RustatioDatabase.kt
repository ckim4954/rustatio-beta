package com.example.data.local

import android.content.Context
import androidx.annotation.VisibleForTesting
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [LocalInstanceEntity::class, CustomPresetEntity::class],
  version = 1,
  exportSchema = false,
)
abstract class RustatioDatabase : RoomDatabase() {
  abstract fun localInstanceDao(): LocalInstanceDao

  abstract fun customPresetDao(): CustomPresetDao

  companion object {
    @Volatile private var instance: RustatioDatabase? = null

    fun getInstance(context: Context): RustatioDatabase =
      instance
        ?: synchronized(this) {
          instance
            ?: Room.databaseBuilder(
                context.applicationContext,
                RustatioDatabase::class.java,
                "rustatio_db",
              )
              .build()
              .also { instance = it }
        }

    @VisibleForTesting
    fun closeAndResetForTests() {
      synchronized(this) {
        instance?.let { db ->
          runCatching { db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close() }
          runCatching { db.close() }
        }
        instance = null
      }
    }
  }
}
