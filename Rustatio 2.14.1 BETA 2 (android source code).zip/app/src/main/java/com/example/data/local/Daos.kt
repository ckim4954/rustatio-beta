package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LocalInstanceDao {
  @Query("SELECT * FROM local_instances ORDER BY createdAtMs DESC")
  fun observeAll(): Flow<List<LocalInstanceEntity>>

  @Query("SELECT * FROM local_instances ORDER BY createdAtMs DESC")
  suspend fun getAll(): List<LocalInstanceEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(entity: LocalInstanceEntity)

  @Query("DELETE FROM local_instances WHERE id = :id")
  suspend fun deleteById(id: String)

  @Query("DELETE FROM local_instances WHERE id IN (:ids)")
  suspend fun deleteByIds(ids: List<String>)
}

@Dao
interface CustomPresetDao {
  @Query("SELECT * FROM custom_presets ORDER BY name ASC")
  fun observeAll(): Flow<List<CustomPresetEntity>>

  @Query("SELECT * FROM custom_presets WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): CustomPresetEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(entity: CustomPresetEntity)

  @Query("DELETE FROM custom_presets WHERE id = :id")
  suspend fun deleteById(id: String)
}
