package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.LogLevel
import com.example.domain.model.ProxySettings
import com.example.domain.model.ProxyType
import com.example.domain.model.RunMode
import com.example.domain.model.WatchConfig
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.rustatioDataStore: DataStore<Preferences> by
  preferencesDataStore(name = "rustatio_preferences")

data class AppSettingsSnapshot(
  val themeMode: ThemeMode = ThemeMode.DARK,
  val runMode: RunMode = RunMode.LOCAL,
  val serverUrl: String = "",
  val serverToken: String = "",
  val logLevel: LogLevel = LogLevel.INFO,
  val proxy: ProxySettings = ProxySettings(),
  val watchTreeUri: String = "",
  val watchMaxDepth: Int = 1,
  val watchAutoStart: Boolean = false,
  val defaultPresetId: String? = null,
)

class AppPreferences(private val context: Context) {

  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val RUN_MODE = stringPreferencesKey("run_mode")
    val SERVER_URL = stringPreferencesKey("server_url")
    val SERVER_TOKEN = stringPreferencesKey("server_token")
    val LOG_LEVEL = stringPreferencesKey("log_level")
    val PROXY_ENABLED = booleanPreferencesKey("proxy_enabled")
    val PROXY_TYPE = stringPreferencesKey("proxy_type")
    val PROXY_HOST = stringPreferencesKey("proxy_host")
    val PROXY_PORT = intPreferencesKey("proxy_port")
    val PROXY_RESOLVE_HOST = booleanPreferencesKey("proxy_resolve_host")
    val PROXY_AUTH = booleanPreferencesKey("proxy_auth")
    val PROXY_USER = stringPreferencesKey("proxy_user")
    val PROXY_PASS = stringPreferencesKey("proxy_pass")
    val WATCH_TREE_URI = stringPreferencesKey("watch_tree_uri")
    val WATCH_MAX_DEPTH = intPreferencesKey("watch_max_depth")
    val WATCH_AUTO_START = booleanPreferencesKey("watch_auto_start")
    val DEFAULT_PRESET_ID = stringPreferencesKey("default_preset_id")
  }

  val settingsFlow: Flow<AppSettingsSnapshot> =
    context.rustatioDataStore.data.map { prefs ->
      AppSettingsSnapshot(
        themeMode = ThemeMode.fromId(prefs[Keys.THEME_MODE]),
        runMode = RunMode.fromId(prefs[Keys.RUN_MODE]),
        serverUrl = prefs[Keys.SERVER_URL].orEmpty(),
        serverToken = prefs[Keys.SERVER_TOKEN].orEmpty(),
        logLevel = LogLevel.fromWire(prefs[Keys.LOG_LEVEL]),
        proxy =
          ProxySettings(
            enabled = prefs[Keys.PROXY_ENABLED] ?: false,
            type = ProxyType.fromId(prefs[Keys.PROXY_TYPE]),
            host = prefs[Keys.PROXY_HOST] ?: "127.0.0.1",
            port = prefs[Keys.PROXY_PORT] ?: 1080,
            resolveHostnameViaProxy = prefs[Keys.PROXY_RESOLVE_HOST] ?: true,
            authentication = prefs[Keys.PROXY_AUTH] ?: false,
            username = prefs[Keys.PROXY_USER].orEmpty(),
            password = prefs[Keys.PROXY_PASS].orEmpty(),
          ),
        watchTreeUri = prefs[Keys.WATCH_TREE_URI].orEmpty(),
        watchMaxDepth = prefs[Keys.WATCH_MAX_DEPTH] ?: 1,
        watchAutoStart = prefs[Keys.WATCH_AUTO_START] ?: false,
        defaultPresetId = prefs[Keys.DEFAULT_PRESET_ID],
      )
    }

  suspend fun setThemeMode(mode: ThemeMode) {
    context.rustatioDataStore.edit { it[Keys.THEME_MODE] = mode.id }
  }

  suspend fun setRunMode(mode: RunMode) {
    context.rustatioDataStore.edit { it[Keys.RUN_MODE] = mode.id }
  }

  suspend fun setServerConnection(url: String, token: String) {
    context.rustatioDataStore.edit {
      it[Keys.SERVER_URL] = url.trim().trimEnd('/')
      it[Keys.SERVER_TOKEN] = token.trim()
    }
  }

  suspend fun setLogLevel(level: LogLevel) {
    context.rustatioDataStore.edit { it[Keys.LOG_LEVEL] = level.wireName }
  }

  suspend fun setProxySettings(proxy: ProxySettings) {
    context.rustatioDataStore.edit {
      it[Keys.PROXY_ENABLED] = proxy.enabled
      it[Keys.PROXY_TYPE] = proxy.type.id
      it[Keys.PROXY_HOST] = proxy.host.trim()
      it[Keys.PROXY_PORT] = proxy.port
      it[Keys.PROXY_RESOLVE_HOST] = proxy.resolveHostnameViaProxy
      it[Keys.PROXY_AUTH] = proxy.authentication
      it[Keys.PROXY_USER] = proxy.username.trim()
      it[Keys.PROXY_PASS] = proxy.password
    }
  }

  suspend fun setWatchTreeUri(uri: String) {
    context.rustatioDataStore.edit { it[Keys.WATCH_TREE_URI] = uri }
  }

  suspend fun setWatchConfig(config: WatchConfig) {
    context.rustatioDataStore.edit {
      it[Keys.WATCH_MAX_DEPTH] = config.maxDepth.coerceAtLeast(0)
      it[Keys.WATCH_AUTO_START] = config.autoStart
    }
  }

  suspend fun setDefaultPresetId(presetId: String?) {
    context.rustatioDataStore.edit {
      if (presetId.isNullOrBlank()) it.remove(Keys.DEFAULT_PRESET_ID)
      else it[Keys.DEFAULT_PRESET_ID] = presetId
    }
  }
}
