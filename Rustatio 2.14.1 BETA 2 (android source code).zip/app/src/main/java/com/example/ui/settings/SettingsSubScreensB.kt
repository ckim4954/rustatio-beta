package com.example.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.Formatters
import com.example.domain.model.InstanceItem
import com.example.domain.model.Preset
import com.example.domain.model.TipImportance
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.RustatioSectionHeader
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@Composable
fun PresetsSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
  onCreateCustomPreset: () -> Unit,
  onEditCustomPreset: (String) -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  var applyTargetPreset by remember { mutableStateOf<Preset?>(null) }

  SettingsSubScreenScaffold(title = "Presets", onNavigateBack = onNavigateBack) { padding ->
    Column(
      modifier = Modifier.fillMaxSize().padding(padding),
    ) {
      state.actionMessage?.let { msg ->
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }
      state.errorMessage?.let { err ->
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      LazyColumn(
        modifier =
          Modifier.weight(1f)
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("presets_list"),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp),
      ) {

      item {
        Button(
          onClick = onCreateCustomPreset,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = colors.presetAccent,
              contentColor = colors.onPresetAccent,
            ),
          modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("presets_create_btn"),
        ) {
          Icon(Icons.Rounded.Add, contentDescription = null)
          Spacer(Modifier.width(6.dp))
          Text("Tạo Preset tùy chỉnh mới")
        }
      }

      item { RustatioSectionHeader("PRESETS TÍCH HỢP (${state.builtInPresets.size})") }
      items(state.builtInPresets, key = { it.id }) { preset ->
        PresetCard(
          preset = preset,
          isDefault = state.settings.defaultPresetId == preset.id,
          onToggleDefault = { viewModel.setDefaultPreset(preset.id) },
          onApply = { applyTargetPreset = preset },
          onEdit = null,
          onDelete = null,
        )
      }

      item { RustatioSectionHeader("PRESETS TÙY CHỈNH (${state.customPresets.size})") }
      if (state.customPresets.isEmpty()) {
        item {
          RustatioEmptyState(
            icon = Icons.Rounded.StarOutline,
            title = "Chưa có preset tùy chỉnh",
            description = "Bạn có thể tạo mới hoặc nhập tệp .json từ mục Nhập / Xuất cấu hình.",
          )
        }
      } else {
        items(state.customPresets, key = { it.id }) { preset ->
          PresetCard(
            preset = preset,
            isDefault = state.settings.defaultPresetId == preset.id,
            onToggleDefault = { viewModel.setDefaultPreset(preset.id) },
            onApply = { applyTargetPreset = preset },
            onEdit = { onEditCustomPreset(preset.id) },
            onDelete = { viewModel.requestDeletePreset(preset) },
          )
        }
      }
    }
    }
  }

  val presetToApply = applyTargetPreset
  if (presetToApply != null) {
    ApplyPresetToInstanceDialog(
      preset = presetToApply,
      instances = state.instances,
      onSelectInstance = { instance ->
        applyTargetPreset = null
        viewModel.applyPresetToInstance(instance.id, presetToApply)
      },
      onDismiss = { applyTargetPreset = null },
    )
  }

  RustatioConfirmDialog(
    visible = state.pendingDeletePreset != null,
    title = "Xác nhận xóa Preset",
    message = "Xóa preset \"${state.pendingDeletePreset?.name.orEmpty()}\"? Hành động này không thể hoàn tác.",
    confirmLabel = "Xóa",
    isDestructive = true,
    onConfirm = { viewModel.confirmDeletePreset() },
    onDismiss = { viewModel.dismissDeletePreset() },
  )
}

@Composable
private fun ApplyPresetToInstanceDialog(
  preset: Preset,
  instances: List<InstanceItem>,
  onSelectInstance: (InstanceItem) -> Unit,
  onDismiss: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Áp dụng '${preset.name}'") },
    text = {
      if (instances.isEmpty()) {
        Text(
          text = "Hiện chưa có Instance nào. Hãy tạo một Instance ở tab Phiên trước rồi áp dụng Preset.",
          style = MaterialTheme.typography.bodyMedium,
          color = colors.textSecondary,
        )
      } else {
        Column(
          modifier = Modifier.verticalScroll(rememberScrollState()),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = "Chọn Instance muốn áp dụng cấu hình từ Preset này:",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
          )
          instances.forEach { inst ->
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = colors.surfaceSubtle,
              border = BorderStroke(1.dp, colors.border),
              modifier =
                Modifier.fillMaxWidth()
                  .clickable { onSelectInstance(inst) }
                  .testTag("apply_preset_instance_${inst.id}"),
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(
                  text = inst.displayName,
                  style = MaterialTheme.typography.titleSmall,
                  color = colors.textPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(2.dp))
                Text(
                  text =
                    "${Formatters.stateLabelVi(inst.effectiveState)} · ↑ ${Formatters.formatSpeedKBs(inst.config.uploadRateKBs)} · ${inst.config.clientType.displayName}",
                  style = MaterialTheme.typography.bodySmall,
                  color = colors.textSecondary,
                )
              }
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.defaultMinSize(minHeight = 48.dp)) {
        Text("Đóng")
      }
    },
  )
}

@Composable
private fun PresetCard(
  preset: Preset,
  isDefault: Boolean,
  onToggleDefault: () -> Unit,
  onApply: () -> Unit,
  onEdit: (() -> Unit)?,
  onDelete: (() -> Unit)?,
) {
  val colors = RustatioThemeTokens.colors
  var expandedTips by remember { mutableStateOf(false) }

  RustatioSectionCard(highlighted = isDefault) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.Top,
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(preset.name, style = MaterialTheme.typography.titleMedium)
          if (preset.recommended) {
            Surface(shape = RoundedCornerShape(8.dp), color = colors.upload.copy(alpha = 0.16f)) {
              Text(
                text = "Khuyên dùng",
                style = MaterialTheme.typography.labelSmall,
                color = colors.upload,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
          if (isDefault) {
            Surface(shape = RoundedCornerShape(8.dp), color = colors.primaryContainer) {
              Text(
                text = "★ Mặc định",
                style = MaterialTheme.typography.labelSmall,
                color = colors.primary,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
              )
            }
          }
        }
        Spacer(Modifier.height(4.dp))
        Text(preset.description, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        if (onEdit != null) {
          IconButton(
            onClick = onEdit,
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("preset_edit_${preset.id}"),
          ) {
            Icon(Icons.Rounded.Edit, contentDescription = "Chỉnh sửa preset", tint = colors.presetAccent)
          }
        }
        if (onDelete != null) {
          IconButton(
            onClick = onDelete,
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("preset_delete_${preset.id}"),
          ) {
            Icon(Icons.Rounded.Delete, contentDescription = "Xóa preset", tint = colors.error)
          }
        }
      }
    }

    Spacer(Modifier.height(8.dp))
    Text(
      text =
        "↑ ${Formatters.formatSpeedKBs(preset.config.uploadRateKBs)} · ↓ ${Formatters.formatSpeedKBs(preset.config.downloadRateKBs)} · ${preset.config.clientType.displayName} ${preset.config.clientVersion}",
      style = MonoMetricSmall,
      color = colors.textPrimary,
    )

    if (preset.tips.isNotEmpty()) {
      TextButton(
        onClick = { expandedTips = !expandedTips },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp),
      ) {
        Text(if (expandedTips) "Ẩn chi tiết" else "Tại sao dùng cấu hình này?")
      }
      if (expandedTips) {
        preset.tips.forEach { tip ->
          Text(
            text = "• $tip",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            modifier = Modifier.padding(vertical = 2.dp),
          )
        }
      }
    }

    Spacer(Modifier.height(8.dp))
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      OutlinedButton(
        onClick = onApply,
        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("preset_apply_${preset.id}"),
      ) {
        Icon(
          imageVector = Icons.Rounded.PlayArrow,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(4.dp))
        Text("Áp dụng", maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
      OutlinedButton(
        onClick = onToggleDefault,
        modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp),
      ) {
        Icon(
          imageVector = if (isDefault) Icons.Rounded.Star else Icons.Rounded.StarOutline,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(Modifier.width(4.dp))
        Text(
          text = if (isDefault) "Bỏ mặc định" else "Đặt mặc định",
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun ImportExportSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current
  val colors = RustatioThemeTokens.colors
  var exportTarget by remember { mutableStateOf<Preset?>(null) }

  val importLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
      if (uri != null) viewModel.importPresetFromUri(context.contentResolver, uri)
    }

  val exportLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
      val preset = exportTarget
      if (uri != null && preset != null) {
        viewModel.exportPresetToUri(context.contentResolver, uri, preset)
      }
      exportTarget = null
    }

  SettingsSubScreenScaffold(title = "Nhập / Xuất cấu hình", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      state.actionMessage?.let { msg ->
        item {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }
      state.errorMessage?.let { err ->
        item {
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      item {
        RustatioSectionCard {
          Text("Nhập Preset từ tệp JSON", style = MaterialTheme.typography.titleMedium)
          Spacer(Modifier.height(4.dp))
          Text(
            "Tương thích hoàn toàn với tệp cấu hình chuẩn Rustatio Desktop/Web (type: \"rustatio-preset\").",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
          )
          Spacer(Modifier.height(10.dp))
          Button(
            onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) },
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("import_json_btn"),
          ) {
            Icon(Icons.Rounded.FileUpload, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Chọn tệp .json để nhập")
          }
        }
      }

      item { RustatioSectionHeader("XUẤT PRESET RA TỆP JSON") }
      val allPresets = state.builtInPresets + state.customPresets
      items(allPresets, key = { "exp_${it.id}" }) { preset ->
        RustatioSectionCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text(preset.name, style = MaterialTheme.typography.titleSmall)
              Text(preset.description, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
            }
            OutlinedButton(
              onClick = {
                exportTarget = preset
                val safeName = preset.name.lowercase().replace(Regex("[^a-z0-9]+"), "-")
                exportLauncher.launch("rustatio-$safeName.json")
              },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            ) {
              Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(4.dp))
              Text("Xuất")
            }
          }
        }
      }
    }
  }
}

@Composable
fun DetectionTipsScreen(onNavigateBack: () -> Unit) {
  val colors = RustatioThemeTokens.colors
  SettingsSubScreenScaffold(title = "Mẹo tránh bị phát hiện", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      items(BuiltInPresets.detectionTips) { tip ->
        val badgeColor =
          when (tip.importance) {
            TipImportance.CRITICAL -> colors.error
            TipImportance.HIGH -> colors.warning
            TipImportance.MEDIUM -> colors.download
          }
        RustatioSectionCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(tip.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = badgeColor.copy(alpha = 0.14f),
              border = BorderStroke(1.dp, badgeColor.copy(alpha = 0.4f)),
            ) {
              Text(
                text = tip.importance.labelVi,
                style = MaterialTheme.typography.labelSmall,
                color = badgeColor,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
          Spacer(Modifier.height(6.dp))
          Text(tip.description, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
        }
      }
    }
  }
}

@Composable
fun AboutSettingsScreen(onNavigateBack: () -> Unit) {
  val colors = RustatioThemeTokens.colors
  SettingsSubScreenScaffold(title = "Thông tin ứng dụng", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 28.dp),
    ) {
      item {
        RustatioSectionCard {
          Text("Rustatio Android", style = MaterialTheme.typography.titleLarge, color = colors.primary)
          Spacer(Modifier.height(4.dp))
          Text("Phiên bản tham chiếu: 2.14.1", style = MaterialTheme.typography.bodyMedium)
          Spacer(Modifier.height(8.dp))
          Text(
            "Ứng dụng quản lý và giả lập tỷ lệ BitTorrent đa phiên trên Android, hỗ trợ chạy trực tiếp trên thiết bị và kết nối đồng bộ với Rustatio Server.",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
          )
        }
      }
      item {
        RustatioSectionHeader("KHẢ NĂNG TÍCH HỢP")
        RustatioSectionCard {
          val capabilities =
            listOf(
              "6 trình khách giả lập: qBittorrent, µTorrent, Transmission, Deluge, BitTorrent, rTorrent.",
              "Đọc tệp .torrent chuẩn Bencode & tính SHA-1 info_hash cục bộ.",
              "6 điều kiện dừng tự động, dao động tốc độ ngẫu nhiên và tăng tốc lũy tiến.",
              "Theo dõi thư mục Android SAF và thư mục trên Rustatio Server.",
              "Hỗ trợ Proxy SOCKS4/4a/5/5h và sao lưu JSON tương thích Desktop/Web.",
            )
          capabilities.forEach { line ->
            Text(
              text = "• $line",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
              modifier = Modifier.padding(vertical = 3.dp),
            )
          }
        }
      }
    }
  }
}
