package com.example.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.HelpOutline
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.DonutLarge
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.Hub
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.LocalCafe
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.ClientType
import com.example.domain.model.PostStopAction
import com.example.domain.model.Preset
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomPresetEditorScreen(
  viewModel: CustomPresetEditorViewModel,
  onNavigateBack: () -> Unit,
  onSaved: (Preset) -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val errors = state.validationErrors

  BackHandler {
    viewModel.requestCancel(onNavigateBack)
  }

  Scaffold(
    modifier = Modifier.fillMaxSize().imePadding(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
        navigationIcon = {
          IconButton(
            onClick = { viewModel.requestCancel(onNavigateBack) },
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("preset_editor_back"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
              contentDescription = "Quay lại",
              tint = colors.textPrimary,
            )
          }
        },
        title = {
          Column {
            Text(
              text =
                if (state.isEditMode) "Chỉnh sửa Preset tùy chỉnh"
                else "Tạo Preset tùy chỉnh",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
              color = colors.textPrimary,
            )
            Text(
              text = "Thiết lập cấu hình và lưu thành một Preset",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
        },
        actions = {
          IconButton(
            onClick = { viewModel.setShowHelp(true) },
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("preset_editor_help"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.HelpOutline,
              contentDescription = "Hướng dẫn cấu hình",
              tint = colors.textSecondary,
            )
          }
        },
      )
    },
    bottomBar = {
      Surface(
        color = colors.background,
        border = BorderStroke(1.dp, colors.border),
        modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          OutlinedButton(
            onClick = { viewModel.requestCancel(onNavigateBack) },
            enabled = !state.isSaving,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, colors.border),
            modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("preset_cancel_btn"),
          ) {
            Text("Hủy", color = colors.textPrimary, fontWeight = FontWeight.Medium)
          }
          Button(
            onClick = { viewModel.save(onSaved) },
            enabled = !state.isSaving && !state.isLoading && state.loadError == null,
            shape = RoundedCornerShape(12.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = colors.presetAccent,
                contentColor = colors.onPresetAccent,
              ),
            modifier = Modifier.weight(1.35f).defaultMinSize(minHeight = 48.dp).testTag("preset_save_btn"),
          ) {
            if (state.isSaving) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = colors.onPresetAccent,
              )
              Spacer(Modifier.width(8.dp))
              Text("Đang lưu…", fontWeight = FontWeight.SemiBold)
            } else {
              Icon(
                imageVector = Icons.Rounded.Save,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(Modifier.width(8.dp))
              Text("Lưu Preset", fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    },
  ) { innerPadding ->
    if (state.isLoading) {
      Box(
        modifier = Modifier.fillMaxSize().padding(innerPadding),
        contentAlignment = Alignment.Center,
      ) {
        CircularProgressIndicator(color = colors.presetAccent)
      }
      return@Scaffold
    }

    if (state.loadError != null) {
      Column(
        modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        RustatioBanner(type = BannerType.ERROR, message = state.loadError.orEmpty())
        OutlinedButton(onClick = onNavigateBack, modifier = Modifier.defaultMinSize(minHeight = 48.dp)) {
          Text("Quay lại")
        }
      }
      return@Scaffold
    }

    val fieldColors =
      OutlinedTextFieldDefaults.colors(
        focusedBorderColor = colors.presetAccent,
        unfocusedBorderColor = colors.border,
        focusedContainerColor = colors.surfaceSubtle,
        unfocusedContainerColor = colors.surfaceSubtle,
        focusedTextColor = colors.textPrimary,
        unfocusedTextColor = colors.textPrimary,
        focusedLabelColor = colors.presetAccent,
        unfocusedLabelColor = colors.textSecondary,
        cursorColor = colors.presetAccent,
      )

    BoxWithConstraints(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyColumn(
        modifier =
          Modifier.fillMaxSize()
            .widthIn(max = 680.dp)
            .padding(horizontal = 16.dp)
            .testTag("preset_editor_list"),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        state.errorMessage?.let { err ->
          item {
            RustatioBanner(
              type = BannerType.ERROR,
              message = err,
              actionLabel = "Đóng",
              onAction = { viewModel.update { it } },
            )
          }
        }

        // 1. Preset metadata
        item {
          PresetSectionCard(icon = Icons.Rounded.Layers, title = "Thông tin Preset") {
            Text(
              text = "Tên Preset *",
              style = MaterialTheme.typography.labelMedium,
              color = colors.textSecondary,
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
              value = state.name,
              onValueChange = { raw -> viewModel.update { it.copy(name = raw) } },
              placeholder = { Text("Ví dụ: Seed ổn định", color = colors.textSecondary) },
              trailingIcon =
                if (state.name.isNotEmpty()) {
                  {
                    IconButton(
                      onClick = { viewModel.update { it.copy(name = "") } },
                      modifier = Modifier.defaultMinSize(48.dp, 48.dp),
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Xóa tên",
                        tint = colors.textSecondary,
                      )
                    }
                  }
                } else null,
              isError = (state.hasAttemptedSave || state.name.isNotEmpty()) && errors.nameError != null,
              supportingText =
                if (state.hasAttemptedSave && errors.nameError != null) {
                  { Text(errors.nameError) }
                } else null,
              singleLine = true,
              shape = RoundedCornerShape(10.dp),
              colors = fieldColors,
              modifier = Modifier.fillMaxWidth().testTag("preset_name_input"),
            )

            Spacer(Modifier.height(10.dp))
            Text(
              text = "Mô tả",
              style = MaterialTheme.typography.labelMedium,
              color = colors.textSecondary,
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
              value = state.description,
              onValueChange = { raw ->
                if (raw.length <= 200) viewModel.update { it.copy(description = raw) }
              },
              placeholder = {
                Text("Giữ tốc độ ổn định, dừng khi đạt Ratio 2.0", color = colors.textSecondary)
              },
              minLines = 2,
              maxLines = 4,
              isError = errors.descriptionError != null,
              shape = RoundedCornerShape(10.dp),
              colors = fieldColors,
              modifier = Modifier.fillMaxWidth().testTag("preset_desc_input"),
            )
            Row(
              modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
              horizontalArrangement = Arrangement.End,
            ) {
              Text(
                text = "${state.description.length}/200",
                style = MaterialTheme.typography.labelSmall,
                color = if (state.description.length > 200) colors.error else colors.textSecondary,
              )
            }
          }
        }

        // 2. Client & Version
        item {
          PresetSectionCard(icon = Icons.Rounded.Dns, title = "Client & Phiên bản") {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = "Client",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                modifier = Modifier.weight(0.9f),
              )
              PresetDropdownSelector(
                selectedLabel = state.selectedClient.displayName,
                items = ClientType.entries.map { it to it.displayName },
                onSelect = { client -> viewModel.selectClient(client) },
                testTag = "preset_client_dropdown",
                modifier = Modifier.weight(1.3f),
              )
            }
            Spacer(Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(
                text = "Phiên bản",
                style = MaterialTheme.typography.bodyMedium,
                color = colors.textSecondary,
                modifier = Modifier.weight(0.9f),
              )
              PresetDropdownSelector(
                selectedLabel = state.selectedClientVersion,
                items = state.selectedClient.versions.map { it to it },
                onSelect = { ver -> viewModel.update { it.copy(selectedClientVersion = ver) } },
                testTag = "preset_version_dropdown",
                modifier = Modifier.weight(1.3f),
              )
            }
          }
        }

        // 3. Connection
        item {
          PresetSectionCard(icon = Icons.Rounded.Hub, title = "Kết nối") {
            PresetInlineNumericRow(
              label = "Port",
              value = state.portText,
              onValueChange = { v -> viewModel.update { it.copy(portText = v) } },
              onIncrement = {
                viewModel.stepInt(state.portText, 1, 1, 65535) { s, v -> s.copy(portText = v) }
              },
              onDecrement = {
                viewModel.stepInt(state.portText, -1, 1, 65535) { s, v -> s.copy(portText = v) }
              },
              inputTag = "preset_port_input",
              leadingIcon = Icons.Rounded.Hub,
              isError = state.hasAttemptedSave && errors.portError != null,
              errorText = errors.portError,
              isDecimal = false,
            )
            Spacer(Modifier.height(10.dp))
            PresetSwitchRow(
              title = "Đồng bộ Port với VPN",
              leadingIcon = Icons.Rounded.Shield,
              checked = state.vpnPortSync,
              onCheckedChange = { checked -> viewModel.update { it.copy(vpnPortSync = checked) } },
              switchTag = "preset_vpn_port_sync_switch",
            )
          }
        }

        // 4. Speeds
        item {
          PresetSectionCard(icon = Icons.Rounded.Speed, title = "Tốc độ") {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Tải lên (KB/s)",
                  style = MaterialTheme.typography.labelMedium,
                  color = colors.textSecondary,
                )
                Spacer(Modifier.height(6.dp))
                PresetStepperBox(
                  value = state.uploadRateText,
                  onValueChange = { v -> viewModel.update { it.copy(uploadRateText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.uploadRateText, 50.0, 0.0, 1_000_000.0) { s, v ->
                      s.copy(uploadRateText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.uploadRateText, -50.0, 0.0, 1_000_000.0) { s, v ->
                      s.copy(uploadRateText = v)
                    }
                  },
                  inputTag = "preset_upload_rate_input",
                  isError = state.hasAttemptedSave && errors.uploadRateError != null,
                  errorText = errors.uploadRateError,
                  modifier = Modifier.fillMaxWidth(),
                )
              }
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Tải xuống (KB/s)",
                  style = MaterialTheme.typography.labelMedium,
                  color = colors.textSecondary,
                )
                Spacer(Modifier.height(6.dp))
                PresetStepperBox(
                  value = state.downloadRateText,
                  onValueChange = { v -> viewModel.update { it.copy(downloadRateText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.downloadRateText, 50.0, 0.0, 1_000_000.0) { s, v ->
                      s.copy(downloadRateText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.downloadRateText, -50.0, 0.0, 1_000_000.0) { s, v ->
                      s.copy(downloadRateText = v)
                    }
                  },
                  inputTag = "preset_download_rate_input",
                  isError = state.hasAttemptedSave && errors.downloadRateError != null,
                  errorText = errors.downloadRateError,
                  modifier = Modifier.fillMaxWidth(),
                )
              }
            }
          }
        }

        // 5. Initial State
        item {
          PresetSectionCard(icon = Icons.Rounded.DonutLarge, title = "Trạng thái ban đầu") {
            PresetInlineNumericRow(
              label = "Tỷ lệ hoàn tất (%)",
              value = state.completionPercentText,
              onValueChange = { v -> viewModel.update { it.copy(completionPercentText = v) } },
              onIncrement = {
                viewModel.stepDouble(state.completionPercentText, 5.0, 0.0, 100.0) { s, v ->
                  s.copy(completionPercentText = v)
                }
              },
              onDecrement = {
                viewModel.stepDouble(state.completionPercentText, -5.0, 0.0, 100.0) { s, v ->
                  s.copy(completionPercentText = v)
                }
              },
              inputTag = "preset_completion_input",
              isError = state.hasAttemptedSave && errors.completionError != null,
              errorText = errors.completionError,
            )
          }
        }

        // 6. Rate Randomization
        item {
          PresetSectionCard(
            icon = Icons.AutoMirrored.Rounded.ShowChart,
            title = "Biến thiên tốc độ",
          ) {
            PresetSwitchRow(
              title = "Biến thiên tốc độ ngẫu nhiên",
              checked = state.randomizeRates,
              onCheckedChange = { checked -> viewModel.update { it.copy(randomizeRates = checked) } },
              switchTag = "preset_randomize_rates_switch",
            )
            AnimatedVisibility(visible = state.randomizeRates) {
              Column {
                Spacer(Modifier.height(10.dp))
                PresetInlineNumericRow(
                  label = "Biên độ dao động (±%)",
                  value = state.randomRangePercentText,
                  onValueChange = { v -> viewModel.update { it.copy(randomRangePercentText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.randomRangePercentText, 5.0, 0.0, 100.0) { s, v ->
                      s.copy(randomRangePercentText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.randomRangePercentText, -5.0, 0.0, 100.0) { s, v ->
                      s.copy(randomRangePercentText = v)
                    }
                  },
                  inputTag = "preset_random_range_input",
                  trailingLabelBadge = {
                    IconButton(
                      onClick = { viewModel.toggleRandomRangeInfo() },
                      modifier = Modifier.size(28.dp),
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.Info,
                        contentDescription = "Thông tin biên độ dao động",
                        tint = colors.textSecondary,
                        modifier = Modifier.size(16.dp),
                      )
                    }
                  },
                  isError = state.hasAttemptedSave && errors.randomRangeError != null,
                  errorText = errors.randomRangeError,
                )
                if (state.showRandomRangeInfo) {
                  Text(
                    text = "Ví dụ: với 500 KB/s và ±20%, tốc độ thực tế sẽ dao động trong khoảng 400–600 KB/s.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    modifier = Modifier.padding(top = 6.dp),
                  )
                }
              }
            }
          }
        }

        // 7. Intervals
        item {
          PresetSectionCard(icon = Icons.Rounded.Schedule, title = "Chu kỳ") {
            PresetInlineNumericRow(
              label = "Chu kỳ cập nhật (giây)",
              value = state.updateIntervalSecondsText,
              onValueChange = { v -> viewModel.update { it.copy(updateIntervalSecondsText = v) } },
              onIncrement = {
                viewModel.stepInt(state.updateIntervalSecondsText, 5, 1, 86400) { s, v ->
                  s.copy(updateIntervalSecondsText = v)
                }
              },
              onDecrement = {
                viewModel.stepInt(state.updateIntervalSecondsText, -5, 1, 86400) { s, v ->
                  s.copy(updateIntervalSecondsText = v)
                }
              },
              inputTag = "preset_update_interval_input",
              isError = state.hasAttemptedSave && errors.updateIntervalError != null,
              errorText = errors.updateIntervalError,
              isDecimal = false,
            )
            Spacer(Modifier.height(10.dp))
            PresetInlineNumericRow(
              label = "Chu kỳ scrape (giây)",
              value = state.scrapeIntervalText,
              onValueChange = { v -> viewModel.update { it.copy(scrapeIntervalText = v) } },
              onIncrement = {
                viewModel.stepInt(state.scrapeIntervalText, 30, 10, 86400) { s, v ->
                  s.copy(scrapeIntervalText = v)
                }
              },
              onDecrement = {
                viewModel.stepInt(state.scrapeIntervalText, -30, 10, 86400) { s, v ->
                  s.copy(scrapeIntervalText = v)
                }
              },
              inputTag = "preset_scrape_interval_input",
              isError = state.hasAttemptedSave && errors.scrapeIntervalError != null,
              errorText = errors.scrapeIntervalError,
              isDecimal = false,
            )
          }
        }

        // 8. Progressive Rates
        item {
          PresetSectionCard(
            icon = Icons.AutoMirrored.Rounded.TrendingUp,
            title = "Tăng tốc lũy tiến (Progressive Rates)",
            headerTrailing = {
              EmeraldSwitch(
                checked = state.progressiveRatesEnabled,
                onCheckedChange = { checked ->
                  viewModel.update { it.copy(progressiveRatesEnabled = checked) }
                },
                modifier = Modifier.testTag("preset_progressive_switch"),
              )
            },
          ) {
            if (!state.progressiveRatesEnabled) {
              Text(
                text = "Bật công tắc để thiết lập tốc độ mục tiêu và thời gian tăng tốc.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
              )
            }
            AnimatedVisibility(visible = state.progressiveRatesEnabled) {
              Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "Tải lên mục tiêu (KB/s)",
                      style = MaterialTheme.typography.labelMedium,
                      color = colors.textSecondary,
                    )
                    Spacer(Modifier.height(6.dp))
                    PresetStepperBox(
                      value = state.targetUploadRateText,
                      onValueChange = { v -> viewModel.update { it.copy(targetUploadRateText = v) } },
                      onIncrement = {
                        viewModel.stepDouble(state.targetUploadRateText, 100.0, 0.0, 1_000_000.0) { s, v ->
                          s.copy(targetUploadRateText = v)
                        }
                      },
                      onDecrement = {
                        viewModel.stepDouble(state.targetUploadRateText, -100.0, 0.0, 1_000_000.0) { s, v ->
                          s.copy(targetUploadRateText = v)
                        }
                      },
                      inputTag = "preset_target_upload_input",
                      isError = state.hasAttemptedSave && errors.targetUploadRateError != null,
                      errorText = errors.targetUploadRateError,
                      modifier = Modifier.fillMaxWidth(),
                    )
                  }
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "Tải xuống mục tiêu (KB/s)",
                      style = MaterialTheme.typography.labelMedium,
                      color = colors.textSecondary,
                    )
                    Spacer(Modifier.height(6.dp))
                    PresetStepperBox(
                      value = state.targetDownloadRateText,
                      onValueChange = { v -> viewModel.update { it.copy(targetDownloadRateText = v) } },
                      onIncrement = {
                        viewModel.stepDouble(state.targetDownloadRateText, 100.0, 0.0, 1_000_000.0) { s, v ->
                          s.copy(targetDownloadRateText = v)
                        }
                      },
                      onDecrement = {
                        viewModel.stepDouble(state.targetDownloadRateText, -100.0, 0.0, 1_000_000.0) { s, v ->
                          s.copy(targetDownloadRateText = v)
                        }
                      },
                      inputTag = "preset_target_download_input",
                      isError = state.hasAttemptedSave && errors.targetDownloadRateError != null,
                      errorText = errors.targetDownloadRateError,
                      modifier = Modifier.fillMaxWidth(),
                    )
                  }
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                  Text(
                    text = "Thời gian tăng tốc (giờ)",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary,
                  )
                  Spacer(Modifier.height(6.dp))
                  PresetStepperBox(
                    value = state.progressiveDurationHoursText,
                    onValueChange = { v -> viewModel.update { it.copy(progressiveDurationHoursText = v) } },
                    onIncrement = {
                      viewModel.stepDouble(state.progressiveDurationHoursText, 1.0, 0.25, 720.0) { s, v ->
                        s.copy(progressiveDurationHoursText = v)
                      }
                    },
                    onDecrement = {
                      viewModel.stepDouble(state.progressiveDurationHoursText, -1.0, 0.25, 720.0) { s, v ->
                        s.copy(progressiveDurationHoursText = v)
                      }
                    },
                    inputTag = "preset_progressive_duration_input",
                    isError = state.hasAttemptedSave && errors.progressiveDurationError != null,
                    errorText = errors.progressiveDurationError,
                    modifier = Modifier.fillMaxWidth(),
                  )
                }
              }
            }
          }
        }

        // 9. Stop Conditions
        item {
          PresetSectionCard(icon = Icons.Rounded.Flag, title = "Điều kiện dừng") {
            // Stop at ratio
            PresetSwitchRow(
              title = "Dừng khi đạt Ratio mục tiêu",
              checked = state.stopAtRatioEnabled,
              onCheckedChange = { checked -> viewModel.update { it.copy(stopAtRatioEnabled = checked) } },
              switchTag = "preset_stop_ratio_switch",
            )
            AnimatedVisibility(visible = state.stopAtRatioEnabled) {
              Column(
                modifier = Modifier.padding(top = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                PresetInlineNumericRow(
                  label = "Ratio mục tiêu",
                  value = state.stopAtRatioText,
                  onValueChange = { v -> viewModel.update { it.copy(stopAtRatioText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.stopAtRatioText, 0.25, 0.05, 1000.0, fixedDecimals = 2) { s, v ->
                      s.copy(stopAtRatioText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.stopAtRatioText, -0.25, 0.05, 1000.0, fixedDecimals = 2) { s, v ->
                      s.copy(stopAtRatioText = v)
                    }
                  },
                  inputTag = "preset_stop_ratio_input",
                  isError = state.hasAttemptedSave && errors.stopAtRatioError != null,
                  errorText = errors.stopAtRatioError,
                )
                PresetSwitchRow(
                  title = "Biến thiên Ratio ngẫu nhiên",
                  checked = state.randomizeRatio,
                  onCheckedChange = { checked -> viewModel.update { it.copy(randomizeRatio = checked) } },
                  switchTag = "preset_randomize_ratio_switch",
                  leadingIcon = Icons.Rounded.Schedule,
                )
                AnimatedVisibility(visible = state.randomizeRatio) {
                  PresetInlineNumericRow(
                    label = "Biên độ Ratio (±%)",
                    value = state.randomRatioRangePercentText,
                    onValueChange = { v ->
                      viewModel.update { it.copy(randomRatioRangePercentText = v) }
                    },
                    onIncrement = {
                      viewModel.stepDouble(state.randomRatioRangePercentText, 1.0, 0.0, 100.0) { s, v ->
                        s.copy(randomRatioRangePercentText = v)
                      }
                    },
                    onDecrement = {
                      viewModel.stepDouble(state.randomRatioRangePercentText, -1.0, 0.0, 100.0) { s, v ->
                        s.copy(randomRatioRangePercentText = v)
                      }
                    },
                    inputTag = "preset_random_ratio_range_input",
                    isError = state.hasAttemptedSave && errors.randomRatioRangeError != null,
                    errorText = errors.randomRatioRangeError,
                  )
                }
              }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = colors.border)

            // Stop at uploaded GB
            PresetSwitchRow(
              title = "Dừng khi tải lên đủ dung lượng",
              checked = state.stopAtUploadedEnabled,
              onCheckedChange = { checked ->
                viewModel.update { it.copy(stopAtUploadedEnabled = checked) }
              },
              switchTag = "preset_stop_uploaded_switch",
            )
            AnimatedVisibility(visible = state.stopAtUploadedEnabled) {
              Box(modifier = Modifier.padding(top = 8.dp)) {
                PresetInlineNumericRow(
                  label = "Dung lượng tải lên (GB)",
                  value = state.stopAtUploadedGBText,
                  onValueChange = { v -> viewModel.update { it.copy(stopAtUploadedGBText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.stopAtUploadedGBText, 1.0, 0.1, 1_000_000.0) { s, v ->
                      s.copy(stopAtUploadedGBText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.stopAtUploadedGBText, -1.0, 0.1, 1_000_000.0) { s, v ->
                      s.copy(stopAtUploadedGBText = v)
                    }
                  },
                  inputTag = "preset_stop_uploaded_gb_input",
                  isError = state.hasAttemptedSave && errors.stopAtUploadedGBError != null,
                  errorText = errors.stopAtUploadedGBError,
                )
              }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = colors.border)

            // Stop at downloaded GB
            PresetSwitchRow(
              title = "Dừng khi tải xuống đủ dung lượng",
              checked = state.stopAtDownloadedEnabled,
              onCheckedChange = { checked ->
                viewModel.update { it.copy(stopAtDownloadedEnabled = checked) }
              },
              switchTag = "preset_stop_downloaded_switch",
            )
            AnimatedVisibility(visible = state.stopAtDownloadedEnabled) {
              Box(modifier = Modifier.padding(top = 8.dp)) {
                PresetInlineNumericRow(
                  label = "Dung lượng tải xuống (GB)",
                  value = state.stopAtDownloadedGBText,
                  onValueChange = { v -> viewModel.update { it.copy(stopAtDownloadedGBText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.stopAtDownloadedGBText, 1.0, 0.1, 1_000_000.0) { s, v ->
                      s.copy(stopAtDownloadedGBText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.stopAtDownloadedGBText, -1.0, 0.1, 1_000_000.0) { s, v ->
                      s.copy(stopAtDownloadedGBText = v)
                    }
                  },
                  inputTag = "preset_stop_downloaded_gb_input",
                  isError = state.hasAttemptedSave && errors.stopAtDownloadedGBError != null,
                  errorText = errors.stopAtDownloadedGBError,
                )
              }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = colors.border)

            // Stop at seed time
            PresetSwitchRow(
              title = "Dừng theo thời gian seeding",
              checked = state.stopAtSeedTimeEnabled,
              onCheckedChange = { checked ->
                viewModel.update { it.copy(stopAtSeedTimeEnabled = checked) }
              },
              switchTag = "preset_stop_seed_time_switch",
            )
            AnimatedVisibility(visible = state.stopAtSeedTimeEnabled) {
              Box(modifier = Modifier.padding(top = 8.dp)) {
                PresetInlineNumericRow(
                  label = "Thời gian seeding (giờ)",
                  value = state.stopAtSeedTimeHoursText,
                  onValueChange = { v -> viewModel.update { it.copy(stopAtSeedTimeHoursText = v) } },
                  onIncrement = {
                    viewModel.stepDouble(state.stopAtSeedTimeHoursText, 1.0, 0.1, 100_000.0) { s, v ->
                      s.copy(stopAtSeedTimeHoursText = v)
                    }
                  },
                  onDecrement = {
                    viewModel.stepDouble(state.stopAtSeedTimeHoursText, -1.0, 0.1, 100_000.0) { s, v ->
                      s.copy(stopAtSeedTimeHoursText = v)
                    }
                  },
                  inputTag = "preset_stop_seed_time_hours_input",
                  isError = state.hasAttemptedSave && errors.stopAtSeedTimeHoursError != null,
                  errorText = errors.stopAtSeedTimeHoursError,
                )
              }
            }
          }
        }

        // 10. Idle Conditions
        item {
          PresetSectionCard(icon = Icons.Rounded.LocalCafe, title = "Điều kiện tạm nghỉ (Idle)") {
            PresetSwitchRow(
              title = "Tạm nghỉ (0 KB/s) khi không có Leecher",
              checked = state.idleWhenNoLeechers,
              onCheckedChange = { checked ->
                viewModel.update { it.copy(idleWhenNoLeechers = checked) }
              },
              switchTag = "preset_idle_no_leechers_switch",
            )
            Spacer(Modifier.height(6.dp))
            PresetSwitchRow(
              title = "Tạm nghỉ (0 KB/s) khi không có Seeder",
              checked = state.idleWhenNoSeeders,
              onCheckedChange = { checked ->
                viewModel.update { it.copy(idleWhenNoSeeders = checked) }
              },
              switchTag = "preset_idle_no_seeders_switch",
            )
          }
        }

        // 11. Post-Stop Action (Only shown when >= 1 threshold stop condition is enabled)
        if (state.hasThresholdStopCondition) {
          item {
            PresetSectionCard(
              icon = Icons.Rounded.PowerSettingsNew,
              title = "Hành động sau khi đạt điều kiện",
            ) {
              Text(
                text = "Hành động",
                style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary,
              )
              Spacer(Modifier.height(6.dp))
              val actionItems =
                listOf(
                  PostStopAction.IDLE to "Tiếp tục (tạm nghỉ)",
                  PostStopAction.STOP_SEEDING to "Dừng",
                  PostStopAction.DELETE_INSTANCE to "Xóa Instance",
                )
              val selectedLabel =
                actionItems.firstOrNull { it.first == state.postStopAction }?.second
                  ?: "Tiếp tục (tạm nghỉ)"
              PresetDropdownSelector(
                selectedLabel = selectedLabel,
                items = actionItems,
                onSelect = { action -> viewModel.update { it.copy(postStopAction = action) } },
                testTag = "preset_post_stop_action_dropdown",
                modifier = Modifier.fillMaxWidth(),
              )
              Spacer(Modifier.height(8.dp))
              val explanation =
                when (state.postStopAction) {
                  PostStopAction.IDLE ->
                    "Khi đạt điều kiện dừng, chuyển về trạng thái tạm nghỉ (0 KB/s), giữ lại Instance."
                  PostStopAction.STOP_SEEDING ->
                    "Khi đạt điều kiện dừng, gửi sự kiện stopped tới tracker và dừng hẳn Instance."
                  PostStopAction.DELETE_INSTANCE ->
                    "Khi đạt điều kiện dừng, dừng faker và tự động xóa Instance khỏi danh sách."
                }
              Text(
                text = explanation,
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
              )
            }
          }
        }
      }
    }
  }

  if (state.showHelpDialog) {
    PresetEditorHelpDialog(onDismiss = { viewModel.setShowHelp(false) })
  }

  RustatioConfirmDialog(
    visible = state.showDiscardDialog,
    title = "Hủy thay đổi Preset?",
    message = "Các thông số bạn vừa chỉnh sửa chưa được lưu. Bạn có chắc muốn quay lại?",
    confirmLabel = "Hủy bỏ",
    isDestructive = true,
    onConfirm = {
      viewModel.setShowDiscardDialog(false)
      onNavigateBack()
    },
    onDismiss = { viewModel.setShowDiscardDialog(false) },
  )
}
