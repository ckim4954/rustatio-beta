package com.example.ui.watch

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RustatioRepository
import com.example.domain.model.InstanceSource
import com.example.domain.model.WatchConfig
import com.example.domain.model.WatchFileEntry
import com.example.domain.model.WatchFileStatus
import com.example.domain.model.WatchSourceMode
import com.example.domain.model.WatchStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class WatchFilterTab(val labelVi: String) {
  ALL("Tất cả"),
  PENDING("Đang chờ"),
  LOADED("Đã nạp"),
  INVALID("Không hợp lệ"),
}

sealed interface WatchTreeRow {
  val key: String
  val depth: Int

  data class FolderRow(
    override val key: String,
    val folderPath: String,
    val folderName: String,
    override val depth: Int,
    val fileCount: Int,
    val expanded: Boolean,
  ) : WatchTreeRow

  data class FileRow(
    override val key: String,
    override val depth: Int,
    val entry: WatchFileEntry,
  ) : WatchTreeRow
}

data class WatchUiState(
  val sourceMode: WatchSourceMode = WatchSourceMode.LOCAL_SAF,
  val isLoading: Boolean = false,
  val watchTreeUri: String = "",
  val status: WatchStatus = WatchStatus(),
  val config: WatchConfig = WatchConfig(),
  val entries: List<WatchFileEntry> = emptyList(),
  val visibleRows: List<WatchTreeRow> = emptyList(),
  val expandedFolders: Set<String> = emptySet(),
  val allFolderPaths: Set<String> = emptySet(),
  val searchQuery: String = "",
  val statusFilter: WatchFilterTab = WatchFilterTab.ALL,
  val selectedFiles: Set<String> = emptySet(),
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val showDeleteConfirm: Boolean = false,
  val pendingDeleteTargets: List<WatchFileEntry> = emptyList(),
)

class WatchViewModel(
  private val repository: RustatioRepository,
) : ViewModel() {

  private val _uiState = MutableStateFlow(WatchUiState())
  val uiState: StateFlow<WatchUiState> = _uiState.asStateFlow()

  init {
    viewModelScope.launch {
      val settings = repository.settingsFlow.first()
      _uiState.update {
        it.copy(
          watchTreeUri = settings.watchTreeUri,
          config = WatchConfig(watchDir = "", maxDepth = settings.watchMaxDepth, autoStart = settings.watchAutoStart),
        )
      }
      if (settings.watchTreeUri.isNotBlank()) {
        refresh()
      }
    }
  }

  fun setSourceMode(mode: WatchSourceMode) {
    _uiState.update {
      it.copy(
        sourceMode = mode,
        selectedFiles = emptySet(),
        errorMessage = null,
        actionMessage = null,
      )
    }
    refresh()
  }

  fun onSafFolderPicked(uriString: String) {
    viewModelScope.launch {
      repository.preferences.setWatchTreeUri(uriString)
      _uiState.update { it.copy(watchTreeUri = uriString, selectedFiles = emptySet()) }
      refresh()
    }
  }

  fun updateWatchConfig(maxDepth: Int, autoStart: Boolean) {
    viewModelScope.launch {
      val cfg = _uiState.value.config.copy(maxDepth = maxDepth.coerceAtLeast(0), autoStart = autoStart)
      if (_uiState.value.sourceMode == WatchSourceMode.SERVER) {
        repository
          .setServerWatchConfig(cfg)
          .onSuccess {
            _uiState.update { it.copy(config = cfg, actionMessage = "Đã cập nhật cấu hình Theo dõi trên Server") }
            refresh()
          }
          .onFailure { err -> _uiState.update { it.copy(errorMessage = err.message) } }
      } else {
        repository.preferences.setWatchConfig(cfg)
        _uiState.update { it.copy(config = cfg, actionMessage = "Đã cập nhật cấu hình quét thư mục") }
        refresh()
      }
    }
  }

  fun refresh() {
    val current = _uiState.value
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, errorMessage = null) }
      if (current.sourceMode == WatchSourceMode.LOCAL_SAF) {
        if (current.watchTreeUri.isBlank()) {
          _uiState.update {
            it.copy(
              isLoading = false,
              status = WatchStatus(),
              entries = emptyList(),
              visibleRows = emptyList(),
              allFolderPaths = emptySet(),
            )
          }
          return@launch
        }
        repository
          .scanLocalWatchTree(current.watchTreeUri, current.config.maxDepth)
          .onSuccess { (status, entries) ->
            val folders = collectAllFolders(entries)
            val expanded =
              if (current.expandedFolders.isEmpty() && folders.isNotEmpty()) folders
              else current.expandedFolders.intersect(folders)
            _uiState.update { state ->
              state.copy(
                isLoading = false,
                status = status,
                entries = entries,
                allFolderPaths = folders,
                expandedFolders = expanded,
              ).recomputeRows()
            }
          }
          .onFailure { err ->
            _uiState.update {
              it.copy(
                isLoading = false,
                errorMessage =
                  err.message ?: "Không thể truy cập thư mục đã chọn. Vui lòng cấp lại quyền SAF.",
              )
            }
          }
      } else {
        repository
          .fetchServerWatch()
          .onSuccess { (status, cfg, entries) ->
            val folders = collectAllFolders(entries)
            val expanded =
              if (current.expandedFolders.isEmpty() && folders.isNotEmpty()) folders
              else current.expandedFolders.intersect(folders)
            _uiState.update { state ->
              state.copy(
                isLoading = false,
                status = status,
                config = cfg,
                entries = entries,
                allFolderPaths = folders,
                expandedFolders = expanded,
              ).recomputeRows()
            }
          }
          .onFailure { err ->
            _uiState.update {
              it.copy(
                isLoading = false,
                errorMessage = err.message ?: "Không thể tải danh sách theo dõi từ máy chủ",
              )
            }
          }
      }
    }
  }

  fun setSearchQuery(q: String) {
    _uiState.update { it.copy(searchQuery = q).recomputeRows() }
  }

  fun setStatusFilter(tab: WatchFilterTab) {
    _uiState.update { it.copy(statusFilter = tab).recomputeRows() }
  }

  fun toggleFolder(folderPath: String) {
    _uiState.update { state ->
      val next =
        if (state.expandedFolders.contains(folderPath)) state.expandedFolders - folderPath
        else state.expandedFolders + folderPath
      state.copy(expandedFolders = next).recomputeRows()
    }
  }

  fun expandAllFolders() {
    _uiState.update { state ->
      state.copy(expandedFolders = state.allFolderPaths).recomputeRows()
    }
  }

  fun collapseAllFolders() {
    _uiState.update { state ->
      state.copy(expandedFolders = emptySet()).recomputeRows()
    }
  }

  fun toggleFileSelected(filename: String) {
    _uiState.update { state ->
      val next =
        if (state.selectedFiles.contains(filename)) state.selectedFiles - filename
        else state.selectedFiles + filename
      state.copy(selectedFiles = next)
    }
  }

  fun clearSelection() {
    _uiState.update { it.copy(selectedFiles = emptySet()) }
  }

  fun loadEntriesToSessions(targets: List<WatchFileEntry>) {
    if (targets.isEmpty()) return
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, errorMessage = null, actionMessage = null) }
      if (_uiState.value.sourceMode == WatchSourceMode.LOCAL_SAF) {
        val uris = targets.mapNotNull { entry -> entry.uriString?.let { Uri.parse(it) } }
        repository
          .importTorrentUris(uris, InstanceSource.WATCH_FOLDER)
          .onSuccess { count ->
            _uiState.update {
              it.copy(
                isLoading = false,
                selectedFiles = emptySet(),
                actionMessage =
                  if (count > 0) "Đã nạp $count tệp .torrent vào danh sách Phiên"
                  else "Các tệp đã chọn đều đã có trong danh sách Phiên",
              )
            }
            refresh()
          }
          .onFailure { err ->
            _uiState.update { it.copy(isLoading = false, errorMessage = err.message) }
          }
      } else {
        var success = 0
        var lastErr: Throwable? = null
        targets.forEach { entry ->
          repository
            .reloadServerWatchFile(entry.filename)
            .onSuccess { success++ }
            .onFailure { lastErr = it }
        }
        if (lastErr != null) {
          _uiState.update { it.copy(isLoading = false, errorMessage = lastErr?.message) }
        } else {
          _uiState.update {
            it.copy(
              isLoading = false,
              selectedFiles = emptySet(),
              actionMessage = "Đã gửi yêu cầu nạp lại $success tệp trên Server",
            )
          }
          refresh()
        }
      }
    }
  }

  fun reloadAllPending() {
    val state = _uiState.value
    if (state.sourceMode == WatchSourceMode.SERVER) {
      viewModelScope.launch {
        _uiState.update { it.copy(isLoading = true) }
        repository
          .reloadAllServerWatch()
          .onSuccess {
            _uiState.update { it.copy(isLoading = false, actionMessage = "Đã nạp lại toàn bộ thư mục trên Server") }
            refresh()
          }
          .onFailure { err -> _uiState.update { it.copy(isLoading = false, errorMessage = err.message) } }
      }
    } else {
      val pending = state.entries.filter { it.status == WatchFileStatus.PENDING }
      loadEntriesToSessions(pending)
    }
  }

  fun requestDeleteSelected() {
    val state = _uiState.value
    val targets = state.entries.filter { state.selectedFiles.contains(it.filename) }
    if (targets.isNotEmpty()) {
      _uiState.update { it.copy(showDeleteConfirm = true, pendingDeleteTargets = targets) }
    }
  }

  fun dismissDeleteDialog() {
    _uiState.update { it.copy(showDeleteConfirm = false, pendingDeleteTargets = emptyList()) }
  }

  fun confirmDelete() {
    val targets = _uiState.value.pendingDeleteTargets
    _uiState.update { it.copy(showDeleteConfirm = false, pendingDeleteTargets = emptyList()) }
    if (targets.isEmpty()) return
    viewModelScope.launch {
      _uiState.update { it.copy(isLoading = true, errorMessage = null) }
      var count = 0
      var lastErr: Throwable? = null
      if (_uiState.value.sourceMode == WatchSourceMode.LOCAL_SAF) {
        targets.forEach { entry ->
          val uri = entry.uriString
          if (uri != null) {
            repository
              .deleteLocalSafWatchFile(uri)
              .onSuccess { count++ }
              .onFailure { lastErr = it }
          }
        }
      } else {
        targets.forEach { entry ->
          repository
            .deleteServerWatchFile(entry.filename)
            .onSuccess { count++ }
            .onFailure { lastErr = it }
        }
      }
      _uiState.update {
        it.copy(
          isLoading = false,
          selectedFiles = emptySet(),
          actionMessage = if (count > 0) "Đã xóa $count tệp .torrent" else null,
          errorMessage = lastErr?.message,
        )
      }
      refresh()
    }
  }

  fun dismissMessages() {
    _uiState.update { it.copy(actionMessage = null, errorMessage = null) }
  }

  private fun collectAllFolders(entries: List<WatchFileEntry>): Set<String> {
    val folders = mutableSetOf<String>()
    entries.forEach { e ->
      val parts = e.filename.split('/')
      for (i in 1 until parts.size) {
        folders.add(parts.take(i).joinToString("/"))
      }
    }
    return folders
  }

  private fun WatchUiState.recomputeRows(): WatchUiState {
    val query = searchQuery.trim().lowercase()
    val filtered =
      entries.filter { e ->
        val matchStatus =
          when (statusFilter) {
            WatchFilterTab.ALL -> true
            WatchFilterTab.PENDING -> e.status == WatchFileStatus.PENDING
            WatchFilterTab.LOADED -> e.status == WatchFileStatus.LOADED
            WatchFilterTab.INVALID -> e.status == WatchFileStatus.INVALID
          }
        val matchQuery =
          query.isEmpty() ||
            e.filename.lowercase().contains(query) ||
            e.displayName.lowercase().contains(query)
        matchStatus && matchQuery
      }

    // Build flat hierarchical rows preserving expand/collapse state
    val rows = mutableListOf<WatchTreeRow>()
    val folderCounts = mutableMapOf<String, Int>()
    filtered.forEach { e ->
      val parts = e.filename.split('/')
      for (i in 1 until parts.size) {
        val fp = parts.take(i).joinToString("/")
        folderCounts[fp] = (folderCounts[fp] ?: 0) + 1
      }
    }

    val emittedFolders = mutableSetOf<String>()
    filtered.sortedBy { it.filename.lowercase() }.forEach { e ->
      val parts = e.filename.split('/')
      var ancestorsExpanded = true
      for (i in 1 until parts.size) {
        val fp = parts.take(i).joinToString("/")
        if (ancestorsExpanded && emittedFolders.add(fp)) {
          val isExpanded = if (query.isNotEmpty()) true else expandedFolders.contains(fp)
          rows.add(
            WatchTreeRow.FolderRow(
              key = "folder:$fp",
              folderPath = fp,
              folderName = parts[i - 1],
              depth = i - 1,
              fileCount = folderCounts[fp] ?: 0,
              expanded = isExpanded,
            )
          )
        }
        val folderOpen = if (query.isNotEmpty()) true else expandedFolders.contains(fp)
        if (!folderOpen) {
          ancestorsExpanded = false
          break
        }
      }
      if (ancestorsExpanded) {
        rows.add(
          WatchTreeRow.FileRow(
            key = "file:${e.filename}",
            depth = (parts.size - 1).coerceAtLeast(0),
            entry = e,
          )
        )
      }
    }

    return copy(visibleRows = rows)
  }

  companion object {
    fun factory(repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          WatchViewModel(repository) as T
      }
  }
}
