package com.example.ui.sessions

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ShowChart
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.domain.model.Formatters
import com.example.domain.model.InstanceItem
import com.example.domain.model.LogEntry
import com.example.domain.model.LogLevel
import com.example.ui.components.BannerType
import com.example.ui.components.MetricTile
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.RustatioSectionHeader
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens
import kotlin.math.max

@Composable
fun SessionStatsTab(item: InstanceItem) {
  val colors = RustatioThemeTokens.colors
  val stats = item.stats
  val cfg = item.config

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    if (!stats.trackerError.isNullOrBlank()) {
      item {
        RustatioBanner(
          type = BannerType.WARNING,
          message = "Thông báo Tracker: ${stats.trackerError}",
        )
      }
    }

    if (stats.isIdling) {
      item {
        RustatioBanner(
          type = BannerType.INFO,
          message =
            when (stats.idlingReason) {
              "no_leechers" -> "Đang tạm nghỉ truyền tải do không có Leecher nào."
              "no_seeders" -> "Đang tạm nghỉ tải xuống do không có Seeder nào."
              else -> "Phiên đang ở trạng thái tạm nghỉ tự động."
            },
        )
      }
    }

    item {
      RustatioSectionHeader("Thống kê phiên hiện tại")
      RustatioSectionCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Đã tải lên",
            value = Formatters.formatBytes(stats.sessionUploadedBytes),
            accentColor = colors.upload,
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Đã tải xuống",
            value = Formatters.formatBytes(stats.sessionDownloadedBytes),
            accentColor = colors.download,
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Tỷ lệ phiên",
            value = Formatters.formatRatio(stats.sessionRatio),
            accentColor = colors.ratio,
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Thời gian chạy",
            value = Formatters.formatDuration(stats.elapsedSeconds),
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Tốc độ lên / TB",
            value = "${Formatters.formatSpeedKBs(stats.currentUploadRateKBs)} · ${Formatters.formatSpeedKBs(stats.averageUploadRateKBs)}",
            accentColor = colors.upload,
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Tốc độ xuống / TB",
            value = "${Formatters.formatSpeedKBs(stats.currentDownloadRateKBs)} · ${Formatters.formatSpeedKBs(stats.averageDownloadRateKBs)}",
            accentColor = colors.download,
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    item {
      RustatioSectionHeader("Thống kê tổng tích lũy")
      RustatioSectionCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Tổng tải lên",
            value = Formatters.formatBytes(stats.uploadedBytes),
            accentColor = colors.upload,
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Tổng tải xuống",
            value = Formatters.formatBytes(stats.downloadedBytes),
            accentColor = colors.download,
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Tỷ lệ tích lũy",
            value = Formatters.formatRatio(stats.ratio),
            accentColor = colors.ratio,
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Còn lại",
            value = Formatters.formatBytes(stats.leftBytes),
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Seeders / Leechers",
            value = "${stats.seeders} S · ${stats.leechers} L",
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Số lần Announce",
            value = stats.announceCount.toString(),
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    if (cfg.activeStopConditionsCount > 0) {
      item {
        RustatioSectionHeader("Tiến độ điều kiện dừng")
        RustatioSectionCard {
          if (cfg.stopAtRatioEnabled) {
            StopProgressItem(
              label = "Tỷ lệ mục tiêu (${Formatters.formatRatio(stats.effectiveStopAtRatio ?: cfg.stopAtRatio)})",
              progressPct = stats.ratioProgress,
              etaText = Formatters.formatDuration(stats.etaRatioSeconds),
              barColor = colors.ratio,
            )
          }
          if (cfg.stopAtUploadedEnabled) {
            StopProgressItem(
              label = "Giới hạn tải lên (${cfg.stopAtUploadedGB} GB)",
              progressPct = stats.uploadProgress,
              etaText = Formatters.formatDuration(stats.etaUploadedSeconds),
              barColor = colors.upload,
            )
          }
          if (cfg.stopAtDownloadedEnabled) {
            StopProgressItem(
              label = "Giới hạn tải xuống (${cfg.stopAtDownloadedGB} GB)",
              progressPct = stats.downloadProgress,
              etaText = "—",
              barColor = colors.download,
            )
          }
          if (cfg.stopAtSeedTimeEnabled) {
            StopProgressItem(
              label = "Thời gian seed (${cfg.stopAtSeedTimeHours} giờ)",
              progressPct = stats.seedTimeProgress,
              etaText = Formatters.formatDuration(stats.etaSeedTimeSeconds),
              barColor = colors.primary,
            )
          }
        }
      }
    }

    item { Spacer(Modifier.height(72.dp)) }
  }
}

@Composable
private fun StopProgressItem(
  label: String,
  progressPct: Double,
  etaText: String,
  barColor: Color,
) {
  val colors = RustatioThemeTokens.colors
  Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.textPrimary)
      Text(
        text = "${"%.1f".format(progressPct)}% · Còn $etaText",
        style = MonoMetricSmall,
        color = colors.textSecondary,
      )
    }
    Spacer(Modifier.height(4.dp))
    LinearProgressIndicator(
      progress = { (progressPct / 100.0).toFloat().coerceIn(0f, 1f) },
      modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp)),
      color = barColor,
      trackColor = colors.surfaceElevated,
    )
  }
}

@Composable
fun SessionPerformanceTab(item: InstanceItem) {
  val colors = RustatioThemeTokens.colors
  val up = item.stats.uploadRateHistory
  val dl = item.stats.downloadRateHistory
  val ratio = item.stats.ratioHistory

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    if (up.size < 2 && dl.size < 2) {
      item {
        RustatioEmptyState(
          icon = Icons.AutoMirrored.Rounded.ShowChart,
          title = "Chưa đủ dữ liệu biểu đồ",
          description =
            "Bắt đầu phiên và đợi vài chu kỳ cập nhật để xem biểu đồ tốc độ tải lên, tải xuống và tỷ lệ theo thời gian thực.",
        )
      }
    } else {
      item {
        RustatioSectionHeader("Biểu đồ tốc độ (KB/s)")
        RustatioSectionCard {
          Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            LegendDot("Tải lên", colors.upload)
            LegendDot("Tải xuống", colors.download)
          }
          Spacer(Modifier.height(10.dp))
          val maxSpeed = max(10.0, max(up.maxOrNull() ?: 0.0, dl.maxOrNull() ?: 0.0) * 1.15)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("0 KB/s", style = MonoMetricSmall, color = colors.textSecondary)
            Text(
              "Đỉnh: ${Formatters.formatSpeedKBs(maxSpeed)}",
              style = MonoMetricSmall,
              color = colors.textSecondary,
            )
          }
          Spacer(Modifier.height(6.dp))
          MultiLineChartCanvas(
            seriesList = listOf(up to colors.upload, dl to colors.download),
            maxY = maxSpeed,
            gridColor = colors.border,
            modifier = Modifier.fillMaxWidth().height(190.dp),
          )
        }
      }

      if (ratio.size >= 2) {
        item {
          RustatioSectionHeader("Biểu đồ tỷ lệ (Ratio)")
          RustatioSectionCard {
            LegendDot("Tỷ lệ tích lũy", colors.ratio)
            Spacer(Modifier.height(8.dp))
            val maxRatio = max(0.5, (ratio.maxOrNull() ?: 0.0) * 1.2)
            Text(
              "Đỉnh tỷ lệ: ${Formatters.formatRatio(maxRatio)}",
              style = MonoMetricSmall,
              color = colors.textSecondary,
            )
            Spacer(Modifier.height(6.dp))
            MultiLineChartCanvas(
              seriesList = listOf(ratio to colors.ratio),
              maxY = maxRatio,
              gridColor = colors.border,
              modifier = Modifier.fillMaxWidth().height(150.dp),
            )
          }
        }
      }
    }
    item { Spacer(Modifier.height(72.dp)) }
  }
}

@Composable
private fun LegendDot(label: String, color: Color) {
  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
    Text(label, style = MaterialTheme.typography.labelMedium)
  }
}

@Composable
private fun MultiLineChartCanvas(
  seriesList: List<Pair<List<Double>, Color>>,
  maxY: Double,
  gridColor: Color,
  modifier: Modifier = Modifier,
) {
  Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    val gridLines = 4
    for (i in 0..gridLines) {
      val y = h * (i.toFloat() / gridLines)
      drawLine(
        color = gridColor.copy(alpha = 0.55f),
        start = Offset(0f, y),
        end = Offset(w, y),
        strokeWidth = 1.dp.toPx(),
      )
    }

    seriesList.forEach { (points, color) ->
      if (points.size >= 2) {
        val path = Path()
        points.forEachIndexed { index, value ->
          val x = (index.toFloat() / (points.size - 1)) * w
          val normalizedY = (value / maxY).coerceIn(0.0, 1.0).toFloat()
          val y = h - (normalizedY * h)
          if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
          path = path,
          color = color,
          style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
      }
    }
  }
}

@Composable
fun SessionLogsTab(
  state: SessionDetailUiState,
  viewModel: SessionDetailViewModel,
) {
  val colors = RustatioThemeTokens.colors
  Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text("Nhật ký hoạt động", style = MaterialTheme.typography.titleSmall)
      TextButton(
        onClick = { viewModel.clearLogs() },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("logs_clear_btn"),
      ) {
        Icon(Icons.Rounded.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(4.dp))
        Text("Xóa nhật ký")
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      LogLevel.entries.forEach { level ->
        FilterChip(
          selected = state.selectedLogLevel == level,
          onClick = { viewModel.setLogLevel(level) },
          label = { Text(level.labelVi) },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        )
      }
    }

    Spacer(Modifier.height(8.dp))

    if (state.logs.isEmpty()) {
      RustatioEmptyState(
        icon = Icons.Rounded.Terminal,
        title = "Chưa có bản ghi nhật ký",
        description = "Các sự kiện announce tracker, thay đổi cấu hình và lỗi sẽ hiển thị tại đây.",
      )
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
      ) {
        items(state.logs, key = { it.id }) { entry ->
          LogRow(entry = entry)
        }
      }
    }
  }
}

@Composable
private fun LogRow(entry: LogEntry) {
  val colors = RustatioThemeTokens.colors
  val levelColor =
    when (entry.level) {
      LogLevel.ERROR -> colors.error
      LogLevel.WARN -> colors.warning
      LogLevel.INFO -> colors.download
      LogLevel.DEBUG -> colors.primary
      LogLevel.TRACE -> colors.textSecondary
    }
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = colors.surface,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalAlignment = Alignment.Top,
    ) {
      Text(
        text = Formatters.formatTimestamp(entry.timestampMs),
        style = MonoMetricSmall,
        color = colors.textSecondary,
      )
      Surface(
        shape = RoundedCornerShape(6.dp),
        color = levelColor.copy(alpha = 0.16f),
      ) {
        Text(
          text = entry.level.labelVi,
          style = MaterialTheme.typography.labelSmall,
          color = levelColor,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
      }
      Text(
        text = entry.message,
        style = MonoMetricSmall,
        color = colors.textPrimary,
        modifier = Modifier.weight(1f),
      )
    }
  }
}
