package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color

enum class ThemeMode(val id: String) {
  DARK("dark"),
  LIGHT("light"),
  SYSTEM("system");

  companion object {
    fun fromId(id: String?): ThemeMode = entries.firstOrNull { it.id == id } ?: DARK
  }
}

private val RustatioDarkColorScheme =
  darkColorScheme(
    primary = BrandViolet,
    onPrimary = Color.White,
    primaryContainer = BrandVioletContainerDark,
    onPrimaryContainer = Color(0xFFDCDCFF),
    secondary = UploadGreen,
    onSecondary = Color(0xFF04210F),
    tertiary = DownloadBlue,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = DarkTextSecondary,
    outline = DarkBorder,
    outlineVariant = Color(0xFF212A26),
    error = ErrorRed,
    onError = Color.White,
  )

private val RustatioLightColorScheme =
  lightColorScheme(
    primary = BrandVioletLightTheme,
    onPrimary = Color.White,
    primaryContainer = BrandVioletContainerLight,
    onPrimaryContainer = Color(0xFF1F1F6B),
    secondary = UploadGreenDark,
    onSecondary = Color.White,
    tertiary = DownloadBlueDark,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = LightTextSecondary,
    outline = LightBorder,
    outlineVariant = Color(0xFFE1E8E5),
    error = ErrorRedDark,
    onError = Color.White,
  )

object RustatioThemeTokens {
  val colors: RustatioExtendedColors
    @Composable get() = LocalRustatioColors.current
}

@Composable
fun RustatioTheme(
  themeMode: ThemeMode = ThemeMode.DARK,
  content: @Composable () -> Unit,
) {
  val useDark =
    when (themeMode) {
      ThemeMode.DARK -> true
      ThemeMode.LIGHT -> false
      ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

  val colorScheme = if (useDark) RustatioDarkColorScheme else RustatioLightColorScheme
  val extendedColors = if (useDark) DarkExtendedColors else LightExtendedColors

  CompositionLocalProvider(LocalRustatioColors provides extendedColors) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = RustatioTypography,
      shapes = RustatioShapes,
      content = content,
    )
  }
}
