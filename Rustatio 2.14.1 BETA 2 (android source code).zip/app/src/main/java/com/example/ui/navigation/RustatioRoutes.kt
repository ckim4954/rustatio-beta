package com.example.ui.navigation

object RustatioRoutes {
  const val SESSIONS = "sessions"
  const val WATCH = "watch"
  const val SETTINGS = "settings"

  const val SESSION_DETAIL = "session_detail/{instanceId}"
  fun sessionDetail(instanceId: String): String = "session_detail/$instanceId"

  const val SETTINGS_GENERAL = "settings/general"
  const val SETTINGS_APPEARANCE = "settings/appearance"
  const val SETTINGS_CONNECTION = "settings/connection"
  const val SETTINGS_PROXY = "settings/proxy"
  const val SETTINGS_PRESETS = "settings/presets"
  const val SETTINGS_PRESETS_CREATE = "settings/presets/create"
  const val SETTINGS_PRESETS_EDIT = "settings/presets/edit/{presetId}"
  fun editCustomPreset(presetId: String): String = "settings/presets/edit/$presetId"

  const val SETTINGS_IMPORT_EXPORT = "settings/import_export"
  const val SETTINGS_TIPS = "settings/tips"
  const val SETTINGS_ABOUT = "settings/about"

  val rootRoutes = setOf(SESSIONS, WATCH, SETTINGS)

  fun isRootRoute(route: String?): Boolean = route in rootRoutes
}
