package com.example.ui.sessions

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppSettingsSnapshot
import com.example.data.repository.RustatioRepository
import com.example.domain.model.FakerState
import com.example.domain.model.InstanceItem
import com.example.domain.model.RunMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SessionStatusFilter(val id: String, val labelVi: String) {
  ALL("all", "Tất cả"),
  RUNNING("running", "Đang chạy"),
  PAUSED("paused", "Tạm dừng"),
  STOPPED("stopped", "Đã dừng"),
}

data class SessionsUiState(
  val isLoading: Boolean = true,
  val runMode: RunMode = RunMode.LOCAL,
  val serverOnline: Boolean = false,
  val serverError: String? = null,
  val allInstances: List<InstanceItem> = emptyList(),
  val filteredInstances: List<InstanceItem> = emptyList(),
  val totalCount: Int = 0,
  val runningCount: Int = 0,
  val pausedCount: Int = 0,
  val stoppedCount: Int = 0,
  val searchQuery: String = "",
  val statusFilter: SessionStatusFilter = SessionStatusFilter.ALL,
  val tagFilter: String? = null, // "__untagged__" for untagged
  val trackerFilter: String? = null,
  val availableTags: List<String> = emptyList(),
  val availableTrackers: List<String> = emptyList(),
  val selectedIds: Set<String> = emptySet(),
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingDeleteIds: List<String> = emptyList(),
) {
  val isMultiSelectActive: Boolean get() = selectedIds.isNotEmpty()
  val activeFilterCount: Int
    get() =
      (if (statusFilter != SessionStatusFilter.ALL) 1 else 0) +
        (if (tagFilter != null) 1 else 0) +
        (if (trackerFilter != null) 1 else 0)
}

private data class SessionsLocalControls(
  val searchQuery: String = "",
  val statusFilter: SessionStatusFilter = SessionStatusFilter.ALL,
  val tagFilter: String? = null,
  val trackerFilter: String? = null,
  val selectedIds: Set<String> = emptySet(),
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingDeleteIds: List<String> = emptyList(),
  val hasLoadedOnce: Boolean = false,
)

class SessionsViewModel(
  private val repository: RustatioRepository,
) : ViewModel() {

  private val controls = MutableStateFlow(SessionsLocalControls())

  val uiState: StateFlow<SessionsUiState> =
    combine(
      repository.instancesFlow,
      repository.settingsFlow,
      repository.serverOnline,
      repository.serverError,
      controls,
    ) { instances, settings, online, serverErr, ctrl ->
      val query = ctrl.searchQuery.trim().lowercase()
      val availableTags = instances.flatMap { it.tags }.distinct().sorted()
      val availableTrackers =
        instances.mapNotNull { it.torrent?.primaryTrackerHost }.distinct().sorted()

      val filtered =
        instances.filter { item ->
          val matchesQuery =
            query.isEmpty() ||
              item.displayName.lowercase().contains(query) ||
              item.tags.any { it.lowercase().contains(query) } ||
              (item.torrent?.primaryTrackerHost?.lowercase()?.contains(query) == true) ||
              item.config.clientType.displayName.lowercase().contains(query)

          val matchesStatus =
            when (ctrl.statusFilter) {
              SessionStatusFilter.ALL -> true
              SessionStatusFilter.RUNNING -> item.effectiveState.isActive
              SessionStatusFilter.PAUSED -> item.effectiveState == FakerState.PAUSED
              SessionStatusFilter.STOPPED ->
                item.effectiveState == FakerState.STOPPED || item.effectiveState == FakerState.IDLE
            }

          val matchesTag =
            when (ctrl.tagFilter) {
              null -> true
              TAG_UNTAGGED -> item.tags.isEmpty()
              else -> item.tags.contains(ctrl.tagFilter)
            }

          val matchesTracker =
            ctrl.trackerFilter == null || item.torrent?.primaryTrackerHost == ctrl.trackerFilter

          matchesQuery && matchesStatus && matchesTag && matchesTracker
        }

      val validSelected = ctrl.selectedIds.intersect(instances.map { it.id }.toSet())

      SessionsUiState(
        isLoading = false,
        runMode = settings.runMode,
        serverOnline = online,
        serverError = serverErr,
        allInstances = instances,
        filteredInstances = filtered,
        totalCount = instances.size,
        runningCount = instances.count { it.effectiveState.isActive },
        pausedCount = instances.count { it.effectiveState == FakerState.PAUSED },
        stoppedCount =
          instances.count {
            it.effectiveState == FakerState.STOPPED || it.effectiveState == FakerState.IDLE
          },
        searchQuery = ctrl.searchQuery,
        statusFilter = ctrl.statusFilter,
        tagFilter = ctrl.tagFilter,
        trackerFilter = ctrl.trackerFilter,
        availableTags = availableTags,
        availableTrackers = availableTrackers,
        selectedIds = validSelected,
        isBusy = ctrl.isBusy,
        actionMessage = ctrl.actionMessage,
        errorMessage = ctrl.errorMessage,
        pendingDeleteIds = ctrl.pendingDeleteIds,
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000L),
      initialValue = SessionsUiState(isLoading = true),
    )

  init {
    viewModelScope.launch {
      repository.settingsFlow.collect { settings: AppSettingsSnapshot ->
        if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank()) {
          repository.refreshServerInstances()
        }
      }
    }
  }

  fun setSearchQuery(q: String) {
    controls.update { it.copy(searchQuery = q) }
  }

  fun setStatusFilter(filter: SessionStatusFilter) {
    controls.update { it.copy(statusFilter = filter) }
  }

  fun setTagFilter(tag: String?) {
    controls.update { it.copy(tagFilter = tag) }
  }

  fun setTrackerFilter(tracker: String?) {
    controls.update { it.copy(trackerFilter = tracker) }
  }

  fun clearAllFilters() {
    controls.update {
      it.copy(
        searchQuery = "",
        statusFilter = SessionStatusFilter.ALL,
        tagFilter = null,
        trackerFilter = null,
      )
    }
  }

  fun toggleSelection(id: String) {
    controls.update { ctrl ->
      val next =
        if (ctrl.selectedIds.contains(id)) ctrl.selectedIds - id else ctrl.selectedIds + id
      ctrl.copy(selectedIds = next)
    }
  }

  fun selectAllVisible() {
    val visibleIds = uiState.value.filteredInstances.map { it.id }.toSet()
    controls.update { it.copy(selectedIds = visibleIds) }
  }

  fun clearSelection() {
    controls.update { it.copy(selectedIds = emptySet()) }
  }

  fun refreshServer() {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .refreshServerInstances()
        .onSuccess {
          controls.update {
            it.copy(isBusy = false, actionMessage = "Đã đồng bộ danh sách phiên từ máy chủ")
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể kết nối máy chủ")
          }
        }
    }
  }

  fun importTorrents(uris: List<Uri>) {
    if (uris.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .importTorrentUris(uris)
        .onSuccess { count ->
          val msg =
            if (count > 0) "Đã nhập thành công $count tệp .torrent"
            else "Tệp .torrent đã tồn tại trong danh sách"
          controls.update { it.copy(isBusy = false, actionMessage = msg) }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Lỗi khi đọc tệp .torrent")
          }
        }
    }
  }

  fun createEmptySession(onCreated: (String) -> Unit) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      repository
        .createEmptySession()
        .onSuccess { id ->
          controls.update { it.copy(isBusy = false) }
          onCreated(id)
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể tạo phiên mới")
          }
        }
    }
  }

  fun startSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .startSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể bắt đầu phiên") }
        }
    }
  }

  fun pauseSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .pauseSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể tạm dừng phiên") }
        }
    }
  }

  fun resumeSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .resumeSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể tiếp tục phiên") }
        }
    }
  }

  fun stopSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .stopSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể dừng phiên") }
        }
    }
  }

  fun bulkAction(action: String) {
    val selected = uiState.value.allInstances.filter { uiState.value.selectedIds.contains(it.id) }
    if (selected.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      repository
        .bulkAction(action, selected)
        .onSuccess {
          val label =
            when (action) {
              "start" -> "bắt đầu"
              "pause" -> "tạm dừng"
              "stop" -> "dừng"
              else -> "cập nhật"
            }
          controls.update {
            it.copy(
              isBusy = false,
              selectedIds = emptySet(),
              actionMessage = "Đã $label ${selected.size} phiên đã chọn",
            )
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isBusy = false, errorMessage = err.message) }
        }
    }
  }

  fun requestDeleteSelected() {
    val ids = uiState.value.selectedIds.toList()
    if (ids.isNotEmpty()) controls.update { it.copy(pendingDeleteIds = ids) }
  }

  fun dismissDeleteDialog() {
    controls.update { it.copy(pendingDeleteIds = emptyList()) }
  }

  fun confirmDelete() {
    val ids = controls.value.pendingDeleteIds
    if (ids.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, pendingDeleteIds = emptyList()) }
      repository
        .deleteSessions(ids)
        .onSuccess {
          controls.update {
            it.copy(
              isBusy = false,
              selectedIds = emptySet(),
              actionMessage = "Đã xóa ${ids.size} phiên",
            )
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isBusy = false, errorMessage = err.message) }
        }
    }
  }

  fun saveTagsForSelected(rawTagsCommaSeparated: String) {
    val tags =
      rawTagsCommaSeparated
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
    val ids = uiState.value.selectedIds.toList()
    if (ids.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      var lastError: Throwable? = null
      ids.forEach { id ->
        repository.updateSessionTags(id, tags).onFailure { lastError = it }
      }
      if (lastError != null) {
        controls.update { it.copy(isBusy = false, errorMessage = lastError?.message) }
      } else {
        controls.update {
          it.copy(
            isBusy = false,
            selectedIds = emptySet(),
            actionMessage = "Đã cập nhật thẻ cho ${ids.size} phiên",
          )
        }
      }
    }
  }

  fun dismissMessages() {
    controls.update { it.copy(actionMessage = null, errorMessage = null) }
  }

  companion object {
    const val TAG_UNTAGGED = "__untagged__"

    fun factory(repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          SessionsViewModel(repository) as T
      }
  }
}
