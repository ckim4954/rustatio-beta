package com.example.ui.watch

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Formatters
import com.example.domain.model.WatchFileEntry
import com.example.domain.model.WatchFileStatus
import com.example.domain.model.WatchSourceMode
import com.example.ui.components.BannerType
import com.example.ui.components.ExpandableTorrentTitle
import com.example.ui.components.MetricTile
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioLoadingSkeleton
import com.example.ui.components.RustatioSectionCard
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WatchScreen(
  viewModel: WatchViewModel,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val context = LocalContext.current
  val listState = rememberLazyListState()
  var showConfigSheet by remember { mutableStateOf(false) }

  val folderPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
      if (uri != null) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
          .onFailure {
            runCatching {
              context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION,
              )
            }
          }
        viewModel.onSafFolderPicked(uri.toString())
      }
    }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
        title = {
          Column {
            Text(
              text = "Theo dõi",
              style = MaterialTheme.typography.headlineMedium,
              color = colors.textPrimary,
            )
            Text(
              text = "Trình duyệt thư mục .torrent",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
        },
        actions = {
          IconButton(
            onClick = { showConfigSheet = true },
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("watch_config_btn"),
          ) {
            Icon(Icons.Rounded.Tune, contentDescription = "Tùy chọn theo dõi")
          }
          IconButton(
            onClick = { viewModel.refresh() },
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("watch_refresh_btn"),
          ) {
            Icon(Icons.Rounded.Refresh, contentDescription = "Làm mới thư mục")
          }
        },
      )
    },
  ) { innerPadding ->
    Column(
      modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Source Mode Switch: SAF vs Server
      SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
        SegmentedButton(
          selected = state.sourceMode == WatchSourceMode.LOCAL_SAF,
          onClick = { viewModel.setSourceMode(WatchSourceMode.LOCAL_SAF) },
          shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("watch_mode_saf"),
        ) {
          Text("Thư mục Android (SAF)", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        SegmentedButton(
          selected = state.sourceMode == WatchSourceMode.SERVER,
          onClick = { viewModel.setSourceMode(WatchSourceMode.SERVER) },
          shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("watch_mode_server"),
        ) {
          Text("Thư mục trên Server", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
      }

      state.actionMessage?.let { msg ->
        RustatioBanner(
          type = BannerType.SUCCESS,
          message = msg,
          actionLabel = "Đóng",
          onAction = { viewModel.dismissMessages() },
        )
      }

      state.errorMessage?.let { err ->
        RustatioBanner(
          type = BannerType.ERROR,
          message = err,
          actionLabel = "Thử lại",
          onAction = { viewModel.refresh() },
        )
      }

      // Overview card
      if (state.status.watchDir.isNotBlank() || state.sourceMode == WatchSourceMode.SERVER) {
        RustatioSectionCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            ExpandableTorrentTitle(
              title = state.status.watchDir.ifBlank { "Chưa có đường dẫn Server" },
              subtitle =
                if (state.sourceMode == WatchSourceMode.LOCAL_SAF) "Nguồn: Android Storage Access Framework"
                else "Nguồn: Rustatio Server Watch API",
              modifier = Modifier.weight(1f).padding(end = 8.dp),
            )
            if (state.sourceMode == WatchSourceMode.LOCAL_SAF) {
              OutlinedButton(
                onClick = { folderPicker.launch(null) },
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("watch_change_folder_btn"),
              ) {
                Text("Đổi thư mục")
              }
            }
          }

          Spacer(Modifier.height(10.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricTile("Thư mục", state.status.folderCount.toString(), modifier = Modifier.weight(1f))
            MetricTile("Tổng tệp", state.status.totalFiles.toString(), modifier = Modifier.weight(1f))
            MetricTile(
              "Đã nạp",
              state.status.loadedCount.toString(),
              accentColor = colors.upload,
              modifier = Modifier.weight(1f),
            )
            MetricTile(
              "Đang chờ",
              state.status.pendingCount.toString(),
              accentColor = colors.warning,
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Multi-select action bar or quick toolbar
      if (state.selectedFiles.isNotEmpty()) {
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = colors.primaryContainer,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "Đã chọn ${state.selectedFiles.size} tệp",
              style = MaterialTheme.typography.titleSmall,
              color = colors.primary,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              TextButton(
                onClick = {
                  val targets = state.entries.filter { state.selectedFiles.contains(it.filename) }
                  viewModel.loadEntriesToSessions(targets)
                },
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("watch_load_selected_btn"),
              ) {
                Text("Nạp (${state.selectedFiles.size})")
              }
              TextButton(
                onClick = { viewModel.requestDeleteSelected() },
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("watch_delete_selected_btn"),
              ) {
                Text("Xóa", color = colors.error)
              }
              IconButton(
                onClick = { viewModel.clearSelection() },
                modifier = Modifier.defaultMinSize(48.dp, 48.dp),
              ) {
                Icon(Icons.Rounded.Close, contentDescription = "Bỏ chọn")
              }
            }
          }
        }
      }

      // Search + filter + expand/collapse
      if (state.entries.isNotEmpty()) {
        OutlinedTextField(
          value = state.searchQuery,
          onValueChange = viewModel::setSearchQuery,
          placeholder = { Text("Tìm tệp hoặc đường dẫn…") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (state.searchQuery.isNotEmpty()) {
              IconButton(onClick = { viewModel.setSearchQuery("") }) {
                Icon(Icons.Rounded.Close, contentDescription = "Xóa tìm kiếm")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.fillMaxWidth().testTag("watch_search_input"),
        )

        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          WatchFilterTab.entries.forEach { tab ->
            FilterChip(
              selected = state.statusFilter == tab,
              onClick = { viewModel.setStatusFilter(tab) },
              label = { Text(tab.labelVi) },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            )
          }
          if (state.allFolderPaths.isNotEmpty()) {
            TextButton(
              onClick = { viewModel.expandAllFolders() },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            ) {
              Text("Mở tất cả")
            }
            TextButton(
              onClick = { viewModel.collapseAllFolders() },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            ) {
              Text("Thu gọn")
            }
          }
          if (state.status.pendingCount > 0) {
            TextButton(
              onClick = { viewModel.reloadAllPending() },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("watch_reload_all_btn"),
            ) {
              Text("Nạp tất cả chờ")
            }
          }
        }
      }

      // Body list / states
      when {
        state.isLoading -> {
          RustatioLoadingSkeleton(cardCount = 3)
        }
        state.sourceMode == WatchSourceMode.LOCAL_SAF && state.watchTreeUri.isBlank() -> {
          RustatioEmptyState(
            icon = Icons.Rounded.CreateNewFolder,
            title = "Chưa chọn thư mục theo dõi",
            description =
              "Chọn một thư mục trên thiết bị bằng Storage Access Framework để quét tệp .torrent và nạp nhanh vào danh sách Phiên.",
            primaryActionLabel = "Chọn thư mục .torrent",
            onPrimaryAction = { folderPicker.launch(null) },
            actionTestTag = "watch_pick_folder_btn",
          )
        }
        state.entries.isEmpty() -> {
          RustatioEmptyState(
            icon = Icons.Rounded.FolderOpen,
            title = "Không tìm thấy tệp .torrent",
            description =
              if (state.sourceMode == WatchSourceMode.LOCAL_SAF)
                "Thư mục hiện tại chưa có tệp .torrent nào trong độ sâu đã cấu hình."
              else "Thư mục theo dõi trên máy chủ hiện đang trống hoặc chưa kết nối.",
            primaryActionLabel =
              if (state.sourceMode == WatchSourceMode.LOCAL_SAF) "Chọn thư mục khác" else "Thử lại",
            onPrimaryAction = {
              if (state.sourceMode == WatchSourceMode.LOCAL_SAF) folderPicker.launch(null)
              else viewModel.refresh()
            },
          )
        }
        state.visibleRows.isEmpty() -> {
          RustatioEmptyState(
            icon = Icons.Rounded.Search,
            title = "Không có tệp khớp bộ lọc",
            description = "Hãy thay đổi từ khóa tìm kiếm hoặc chọn bộ lọc Tất cả.",
            primaryActionLabel = "Hiển thị tất cả",
            onPrimaryAction = {
              viewModel.setSearchQuery("")
              viewModel.setStatusFilter(WatchFilterTab.ALL)
            },
          )
        }
        else -> {
          LazyColumn(
            state = listState,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            modifier = Modifier.fillMaxSize(),
          ) {
            items(state.visibleRows, key = { it.key }) { row ->
              when (row) {
                is WatchTreeRow.FolderRow -> {
                  WatchFolderItem(
                    row = row,
                    onClick = { viewModel.toggleFolder(row.folderPath) },
                  )
                }
                is WatchTreeRow.FileRow -> {
                  WatchFileItem(
                    row = row,
                    selected = state.selectedFiles.contains(row.entry.filename),
                    onToggleSelect = { viewModel.toggleFileSelected(row.entry.filename) },
                    onLoadOne = { viewModel.loadEntriesToSessions(listOf(row.entry)) },
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  // Watch Config Sheet
  if (showConfigSheet) {
    var depth by remember(state.config.maxDepth) { mutableIntStateOf(state.config.maxDepth) }
    var autoStart by remember(state.config.autoStart) { mutableStateOf(state.config.autoStart) }
    ModalBottomSheet(onDismissRequest = { showConfigSheet = false }) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text("Tùy chọn theo dõi thư mục", style = MaterialTheme.typography.titleLarge)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("Độ sâu quét thư mục con", style = MaterialTheme.typography.bodyLarge)
            Text(
              if (depth == 0) "Không giới hạn (quét toàn bộ thư mục con)"
              else "Tối đa $depth cấp thư mục",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedButton(
              onClick = { depth = (depth - 1).coerceAtLeast(0) },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp),
            ) {
              Text("−")
            }
            OutlinedButton(
              onClick = { depth += 1 },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp),
            ) {
              Text("+")
            }
          }
        }
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text("Tự động chạy khi nạp torrent", style = MaterialTheme.typography.bodyLarge)
            Text(
              "Áp dụng cho Watch Service khi có tệp mới",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Switch(checked = autoStart, onCheckedChange = { autoStart = it })
        }
        Button(
          onClick = {
            viewModel.updateWatchConfig(depth, autoStart)
            showConfigSheet = false
          },
          modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Áp dụng")
        }
        Spacer(Modifier.height(16.dp))
      }
    }
  }

  RustatioConfirmDialog(
    visible = state.showDeleteConfirm,
    title = "Xác nhận xóa tệp .torrent",
    message =
      "Bạn có chắc muốn xóa ${state.pendingDeleteTargets.size} tệp .torrent đã chọn khỏi thư mục theo dõi?",
    confirmLabel = "Xóa tệp",
    isDestructive = true,
    onConfirm = { viewModel.confirmDelete() },
    onDismiss = { viewModel.dismissDeleteDialog() },
  )
}

@Composable
private fun WatchFolderItem(
  row: WatchTreeRow.FolderRow,
  onClick: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = colors.surfaceElevated,
    border = BorderStroke(1.dp, colors.border),
    modifier =
      Modifier.fillMaxWidth()
        .padding(start = (row.depth * 14).dp)
        .clickable(onClick = onClick)
        .defaultMinSize(minHeight = 48.dp),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = if (row.expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
        contentDescription = if (row.expanded) "Thu gọn" else "Mở rộng",
        tint = colors.textSecondary,
      )
      Icon(
        imageVector = Icons.Rounded.Folder,
        contentDescription = null,
        tint = colors.primary,
      )
      Text(
        text = row.folderName,
        style = MaterialTheme.typography.titleSmall,
        color = colors.textPrimary,
        maxLines = 2,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.weight(1f),
      )
      Text(
        text = "${row.fileCount} tệp",
        style = MonoMetricSmall,
        color = colors.textSecondary,
      )
    }
  }
}

@Composable
private fun WatchFileItem(
  row: WatchTreeRow.FileRow,
  selected: Boolean,
  onToggleSelect: () -> Unit,
  onLoadOne: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  val entry = row.entry
  val (statusColor, statusLabel) =
    when (entry.status) {
      WatchFileStatus.LOADED -> colors.upload to "Đã nạp"
      WatchFileStatus.PENDING -> colors.warning to "Đang chờ"
      WatchFileStatus.INVALID -> colors.error to "Không hợp lệ"
    }

  Surface(
    shape = RoundedCornerShape(12.dp),
    color = if (selected) colors.primaryContainer.copy(alpha = 0.5f) else colors.surface,
    border = BorderStroke(1.dp, if (selected) colors.primary else colors.border),
    modifier =
      Modifier.fillMaxWidth()
        .padding(start = (row.depth * 14).dp)
        .clickable(onClick = onToggleSelect),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = if (selected) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
        contentDescription = if (selected) "Đã chọn" else "Chưa chọn",
        tint = if (selected) colors.primary else colors.textSecondary,
      )
      Icon(
        imageVector = Icons.Rounded.Description,
        contentDescription = null,
        tint = statusColor,
        modifier = Modifier.size(20.dp),
      )
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = entry.displayName,
          style = MaterialTheme.typography.bodyLarge,
          color = colors.textPrimary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text =
            buildString {
              append(statusLabel)
              if (entry.sizeBytes > 0L) append(" · ${Formatters.formatBytes(entry.sizeBytes)}")
              if (!entry.errorMessage.isNullOrBlank()) append(" · ${entry.errorMessage}")
            },
          style = MaterialTheme.typography.bodySmall,
          color = if (entry.status == WatchFileStatus.INVALID) colors.error else colors.textSecondary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
      if (entry.status != WatchFileStatus.INVALID) {
        IconButton(
          onClick = onLoadOne,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp),
        ) {
          Icon(
            imageVector = Icons.Rounded.UploadFile,
            contentDescription = "Nạp vào Phiên",
            tint = colors.primary,
          )
        }
      }
    }
  }
}
