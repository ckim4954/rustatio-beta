package com.example.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.JsonCodecs
import com.example.data.repository.RustatioRepository
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.PostStopAction
import com.example.domain.model.Preset
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PresetFormValidationErrors(
  val nameError: String? = null,
  val descriptionError: String? = null,
  val portError: String? = null,
  val uploadRateError: String? = null,
  val downloadRateError: String? = null,
  val completionError: String? = null,
  val randomRangeError: String? = null,
  val updateIntervalError: String? = null,
  val scrapeIntervalError: String? = null,
  val targetUploadRateError: String? = null,
  val targetDownloadRateError: String? = null,
  val progressiveDurationError: String? = null,
  val stopAtRatioError: String? = null,
  val randomRatioRangeError: String? = null,
  val stopAtUploadedGBError: String? = null,
  val stopAtDownloadedGBError: String? = null,
  val stopAtSeedTimeHoursError: String? = null,
) {
  val hasErrors: Boolean
    get() =
      listOf(
        nameError,
        descriptionError,
        portError,
        uploadRateError,
        downloadRateError,
        completionError,
        randomRangeError,
        updateIntervalError,
        scrapeIntervalError,
        targetUploadRateError,
        targetDownloadRateError,
        progressiveDurationError,
        stopAtRatioError,
        randomRatioRangeError,
        stopAtUploadedGBError,
        stopAtDownloadedGBError,
        stopAtSeedTimeHoursError,
      ).any { it != null }
}

data class CustomPresetEditorUiState(
  val editingPresetId: String? = null,
  val isLoading: Boolean = false,
  val isSaving: Boolean = false,
  val loadError: String? = null,
  val errorMessage: String? = null,
  val showHelpDialog: Boolean = false,
  val showDiscardDialog: Boolean = false,
  val hasAttemptedSave: Boolean = false,
  val showRandomRangeInfo: Boolean = false,

  // Metadata
  val name: String = "",
  val description: String = "",
  val icon: String = "star",

  // 1-2: Client & version
  val selectedClient: ClientType = ClientType.QBITTORRENT,
  val selectedClientVersion: String = ClientType.QBITTORRENT.defaultVersion,

  // 3-4: Connection
  val portText: String = "6881",
  val vpnPortSync: Boolean = false,

  // 5-7: Speed & initial completion
  val uploadRateText: String = "500",
  val downloadRateText: String = "0",
  val completionPercentText: String = "100",

  // 8-9: Rate randomization
  val randomizeRates: Boolean = true,
  val randomRangePercentText: String = "20",

  // 10-11: Intervals
  val updateIntervalSecondsText: String = "60",
  val scrapeIntervalText: String = "180",

  // 12-15: Progressive rates
  val progressiveRatesEnabled: Boolean = false,
  val targetUploadRateText: String = "2000",
  val targetDownloadRateText: String = "0",
  val progressiveDurationHoursText: String = "6",

  // 16-25: Stop conditions
  val stopAtRatioEnabled: Boolean = false,
  val stopAtRatioText: String = "2.00",
  val randomizeRatio: Boolean = false,
  val randomRatioRangePercentText: String = "10",
  val stopAtUploadedEnabled: Boolean = false,
  val stopAtUploadedGBText: String = "10",
  val stopAtDownloadedEnabled: Boolean = false,
  val stopAtDownloadedGBText: String = "10",
  val stopAtSeedTimeEnabled: Boolean = false,
  val stopAtSeedTimeHoursText: String = "24",

  // 26-27: Idle conditions
  val idleWhenNoLeechers: Boolean = false,
  val idleWhenNoSeeders: Boolean = false,

  // 28: Post stop action
  val postStopAction: PostStopAction = PostStopAction.IDLE,

  // Dirty check baseline
  val initialSignature: String = "",
) {
  val isEditMode: Boolean
    get() = !editingPresetId.isNullOrBlank()

  val hasThresholdStopCondition: Boolean
    get() =
      stopAtRatioEnabled ||
        stopAtUploadedEnabled ||
        stopAtDownloadedEnabled ||
        stopAtSeedTimeEnabled

  val validationErrors: PresetFormValidationErrors
    get() = validate()

  val hasUnsavedChanges: Boolean
    get() = initialSignature.isNotEmpty() && signature() != initialSignature

  fun signature(): String =
    listOf(
      name,
      description,
      selectedClient.id,
      selectedClientVersion,
      portText,
      vpnPortSync,
      uploadRateText,
      downloadRateText,
      completionPercentText,
      randomizeRates,
      randomRangePercentText,
      updateIntervalSecondsText,
      scrapeIntervalText,
      progressiveRatesEnabled,
      targetUploadRateText,
      targetDownloadRateText,
      progressiveDurationHoursText,
      stopAtRatioEnabled,
      stopAtRatioText,
      randomizeRatio,
      randomRatioRangePercentText,
      stopAtUploadedEnabled,
      stopAtUploadedGBText,
      stopAtDownloadedEnabled,
      stopAtDownloadedGBText,
      stopAtSeedTimeEnabled,
      stopAtSeedTimeHoursText,
      idleWhenNoLeechers,
      idleWhenNoSeeders,
      postStopAction.wireName,
    ).joinToString("|")

  fun toFakerConfig(): FakerConfig? {
    if (validate().hasErrors) return null
    val port = portText.trim().toIntOrNull() ?: return null
    val up = parseNumber(uploadRateText) ?: return null
    val dl = parseNumber(downloadRateText) ?: return null
    val comp = parseNumber(completionPercentText) ?: return null
    val randRange = parseNumber(randomRangePercentText) ?: 20.0
    val updateSec = updateIntervalSecondsText.trim().toIntOrNull() ?: return null
    val scrapeSec = scrapeIntervalText.trim().toIntOrNull() ?: return null
    val targetUp = parseNumber(targetUploadRateText) ?: 0.0
    val targetDl = parseNumber(targetDownloadRateText) ?: 0.0
    val progHours = parseNumber(progressiveDurationHoursText) ?: 1.0
    val ratio = parseNumber(stopAtRatioText) ?: 2.0
    val ratioRange = parseNumber(randomRatioRangePercentText) ?: 10.0
    val upGb = parseNumber(stopAtUploadedGBText) ?: 10.0
    val dlGb = parseNumber(stopAtDownloadedGBText) ?: 10.0
    val seedHours = parseNumber(stopAtSeedTimeHoursText) ?: 24.0

    return FakerConfig(
      uploadRateKBs = up,
      downloadRateKBs = dl,
      port = port,
      vpnPortSync = vpnPortSync,
      clientType = selectedClient,
      clientVersion = selectedClientVersion,
      completionPercent = comp,
      initialUploadedMB = 0L,
      randomizeRates = randomizeRates,
      randomRangePercent = randRange.coerceIn(0.0, 100.0),
      randomizeRatio = randomizeRatio,
      randomRatioRangePercent = ratioRange.coerceIn(0.0, 100.0),
      updateIntervalSeconds = updateSec,
      scrapeIntervalSeconds = scrapeSec,
      stopAtRatioEnabled = stopAtRatioEnabled,
      stopAtRatio = ratio,
      effectiveStopAtRatio = null,
      stopAtUploadedEnabled = stopAtUploadedEnabled,
      stopAtUploadedGB = upGb,
      stopAtDownloadedEnabled = stopAtDownloadedEnabled,
      stopAtDownloadedGB = dlGb,
      stopAtSeedTimeEnabled = stopAtSeedTimeEnabled,
      stopAtSeedTimeHours = seedHours,
      idleWhenNoLeechers = idleWhenNoLeechers,
      idleWhenNoSeeders = idleWhenNoSeeders,
      postStopAction = postStopAction,
      progressiveRatesEnabled = progressiveRatesEnabled,
      targetUploadRateKBs = targetUp,
      targetDownloadRateKBs = targetDl,
      progressiveDurationHours = progHours,
    )
  }

  private fun validate(): PresetFormValidationErrors {
    val cleanName = name.trim()
    val port = portText.trim().toIntOrNull()
    val up = parseNumber(uploadRateText)
    val dl = parseNumber(downloadRateText)
    val comp = parseNumber(completionPercentText)
    val randRange = parseNumber(randomRangePercentText)
    val updateSec = updateIntervalSecondsText.trim().toIntOrNull()
    val scrapeSec = scrapeIntervalText.trim().toIntOrNull()
    val targetUp = parseNumber(targetUploadRateText)
    val targetDl = parseNumber(targetDownloadRateText)
    val progHours = parseNumber(progressiveDurationHoursText)
    val ratio = parseNumber(stopAtRatioText)
    val ratioRange = parseNumber(randomRatioRangePercentText)
    val upGb = parseNumber(stopAtUploadedGBText)
    val dlGb = parseNumber(stopAtDownloadedGBText)
    val seedHours = parseNumber(stopAtSeedTimeHoursText)

    return PresetFormValidationErrors(
      nameError =
        when {
          cleanName.isEmpty() -> "Tên Preset là bắt buộc"
          cleanName.length > 100 -> "Tên Preset tối đa 100 ký tự"
          else -> null
        },
      descriptionError =
        if (description.length > 200) "Mô tả tối đa 200 ký tự" else null,
      portError =
        if (port == null || port !in 1..65535) "Port phải từ 1 đến 65535" else null,
      uploadRateError =
        if (up == null || up < 0.0 || up > 1_000_000.0) "Từ 0 đến 1.000.000 KB/s" else null,
      downloadRateError =
        if (dl == null || dl < 0.0 || dl > 1_000_000.0) "Từ 0 đến 1.000.000 KB/s" else null,
      completionError =
        if (comp == null || comp < 0.0 || comp > 100.0) "Tỷ lệ hoàn tất phải từ 0% đến 100%" else null,
      randomRangeError =
        if (randomizeRates && (randRange == null || randRange < 0.0 || randRange > 100.0)) {
          "Biên độ dao động phải từ 0% đến 100%"
        } else null,
      updateIntervalError =
        if (updateSec == null || updateSec < 1) "Chu kỳ cập nhật phải ≥ 1 giây" else null,
      scrapeIntervalError =
        if (scrapeSec == null || scrapeSec < 10) "Chu kỳ scrape phải ≥ 10 giây" else null,
      targetUploadRateError =
        if (progressiveRatesEnabled && (targetUp == null || targetUp < 0.0 || targetUp > 1_000_000.0)) {
          "Tốc độ mục tiêu ≥ 0 KB/s"
        } else null,
      targetDownloadRateError =
        if (progressiveRatesEnabled && (targetDl == null || targetDl < 0.0 || targetDl > 1_000_000.0)) {
          "Tốc độ mục tiêu ≥ 0 KB/s"
        } else null,
      progressiveDurationError =
        if (progressiveRatesEnabled && (progHours == null || progHours <= 0.0)) {
          "Thời gian tăng tốc phải > 0 giờ"
        } else null,
      stopAtRatioError =
        if (stopAtRatioEnabled && (ratio == null || ratio <= 0.0)) {
          "Ratio mục tiêu phải > 0"
        } else null,
      randomRatioRangeError =
        if (stopAtRatioEnabled && randomizeRatio && (ratioRange == null || ratioRange < 0.0 || ratioRange > 100.0)) {
          "Biên độ Ratio phải từ 0% đến 100%"
        } else null,
      stopAtUploadedGBError =
        if (stopAtUploadedEnabled && (upGb == null || upGb <= 0.0)) {
          "Dung lượng tải lên phải > 0 GB"
        } else null,
      stopAtDownloadedGBError =
        if (stopAtDownloadedEnabled && (dlGb == null || dlGb <= 0.0)) {
          "Dung lượng tải xuống phải > 0 GB"
        } else null,
      stopAtSeedTimeHoursError =
        if (stopAtSeedTimeEnabled && (seedHours == null || seedHours <= 0.0)) {
          "Thời gian seeding phải > 0 giờ"
        } else null,
    )
  }

  companion object {
    fun parseNumber(raw: String): Double? = raw.trim().replace(',', '.').toDoubleOrNull()

    fun formatCleanNumber(value: Double, decimalsIfFraction: Int = 2): String {
      if (value.isNaN() || value.isInfinite()) return "0"
      val rounded = value.roundToLong().toDouble()
      return if (abs(value - rounded) < 1e-6) {
        rounded.toLong().toString()
      } else {
        String.format(Locale.US, "%.${decimalsIfFraction}f", value)
          .trimEnd('0')
          .trimEnd('.')
      }
    }

    fun fromPreset(preset: Preset): CustomPresetEditorUiState {
      val c = preset.config
      val state =
        CustomPresetEditorUiState(
          editingPresetId = preset.id,
          name = preset.name,
          description = preset.description,
          icon = preset.icon.ifBlank { "star" },
          selectedClient = c.clientType,
          selectedClientVersion =
            c.clientVersion.takeIf { it in c.clientType.versions } ?: c.clientType.defaultVersion,
          portText = c.port.toString(),
          vpnPortSync = c.vpnPortSync,
          uploadRateText = formatCleanNumber(c.uploadRateKBs),
          downloadRateText = formatCleanNumber(c.downloadRateKBs),
          completionPercentText = formatCleanNumber(c.completionPercent),
          randomizeRates = c.randomizeRates,
          randomRangePercentText = formatCleanNumber(c.randomRangePercent),
          updateIntervalSecondsText = c.updateIntervalSeconds.toString(),
          scrapeIntervalText = c.scrapeIntervalSeconds.toString(),
          progressiveRatesEnabled = c.progressiveRatesEnabled,
          targetUploadRateText = formatCleanNumber(c.targetUploadRateKBs),
          targetDownloadRateText = formatCleanNumber(c.targetDownloadRateKBs),
          progressiveDurationHoursText = formatCleanNumber(c.progressiveDurationHours),
          stopAtRatioEnabled = c.stopAtRatioEnabled,
          stopAtRatioText = String.format(Locale.US, "%.2f", c.stopAtRatio),
          randomizeRatio = c.randomizeRatio,
          randomRatioRangePercentText = formatCleanNumber(c.randomRatioRangePercent),
          stopAtUploadedEnabled = c.stopAtUploadedEnabled,
          stopAtUploadedGBText = formatCleanNumber(c.stopAtUploadedGB),
          stopAtDownloadedEnabled = c.stopAtDownloadedEnabled,
          stopAtDownloadedGBText = formatCleanNumber(c.stopAtDownloadedGB),
          stopAtSeedTimeEnabled = c.stopAtSeedTimeEnabled,
          stopAtSeedTimeHoursText = formatCleanNumber(c.stopAtSeedTimeHours),
          idleWhenNoLeechers = c.idleWhenNoLeechers,
          idleWhenNoSeeders = c.idleWhenNoSeeders,
          postStopAction = c.postStopAction,
        )
      return state.copy(initialSignature = state.signature())
    }

    fun newBlank(): CustomPresetEditorUiState {
      val blank = CustomPresetEditorUiState()
      return blank.copy(initialSignature = blank.signature())
    }
  }
}

class CustomPresetEditorViewModel(
  private val presetId: String?,
  private val repository: RustatioRepository,
) : ViewModel() {

  private val _uiState =
    MutableStateFlow(
      if (presetId.isNullOrBlank()) CustomPresetEditorUiState.newBlank()
      else CustomPresetEditorUiState(editingPresetId = presetId, isLoading = true)
    )
  val uiState: StateFlow<CustomPresetEditorUiState> = _uiState.asStateFlow()

  init {
    if (!presetId.isNullOrBlank()) {
      viewModelScope.launch {
        val loaded = repository.getCustomPresetById(presetId)
        if (loaded == null) {
          _uiState.update {
            it.copy(
              isLoading = false,
              loadError = "Không tìm thấy Preset tùy chỉnh để chỉnh sửa.",
            )
          }
        } else {
          _uiState.value = CustomPresetEditorUiState.fromPreset(loaded)
        }
      }
    }
  }

  fun update(transform: (CustomPresetEditorUiState) -> CustomPresetEditorUiState) {
    _uiState.update { current -> transform(current).copy(errorMessage = null) }
  }

  fun selectClient(client: ClientType) {
    update { s ->
      val currentPort = s.portText.trim().toIntOrNull()
      val nextPort =
        if (currentPort == s.selectedClient.defaultPort) client.defaultPort.toString()
        else s.portText
      s.copy(
        selectedClient = client,
        selectedClientVersion = client.defaultVersion,
        portText = nextPort,
      )
    }
  }

  fun stepInt(
    currentRaw: String,
    delta: Int,
    minValue: Int,
    maxValue: Int,
    assign: (CustomPresetEditorUiState, String) -> CustomPresetEditorUiState,
  ) {
    val cur = currentRaw.trim().toIntOrNull() ?: minValue
    val next = (cur + delta).coerceIn(minValue, maxValue)
    update { assign(it, next.toString()) }
  }

  fun stepDouble(
    currentRaw: String,
    delta: Double,
    minValue: Double,
    maxValue: Double,
    fixedDecimals: Int? = null,
    assign: (CustomPresetEditorUiState, String) -> CustomPresetEditorUiState,
  ) {
    val cur = CustomPresetEditorUiState.parseNumber(currentRaw) ?: minValue
    val next = (cur + delta).coerceIn(minValue, maxValue)
    val formatted =
      if (fixedDecimals != null) String.format(Locale.US, "%.${fixedDecimals}f", next)
      else CustomPresetEditorUiState.formatCleanNumber(next)
    update { assign(it, formatted) }
  }

  fun setShowHelp(visible: Boolean) {
    _uiState.update { it.copy(showHelpDialog = visible) }
  }

  fun setShowDiscardDialog(visible: Boolean) {
    _uiState.update { it.copy(showDiscardDialog = visible) }
  }

  fun toggleRandomRangeInfo() {
    _uiState.update { it.copy(showRandomRangeInfo = !it.showRandomRangeInfo) }
  }

  fun requestCancel(onNavigateBack: () -> Unit) {
    if (_uiState.value.hasUnsavedChanges) {
      _uiState.update { it.copy(showDiscardDialog = true) }
    } else {
      onNavigateBack()
    }
  }

  fun save(onSaved: (Preset) -> Unit) {
    val current = _uiState.value
    val config = current.toFakerConfig()
    if (config == null) {
      _uiState.update {
        it.copy(
          hasAttemptedSave = true,
          errorMessage = "Vui lòng kiểm tra lại các trường thông tin chưa hợp lệ trước khi lưu.",
        )
      }
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(isSaving = true, errorMessage = null) }
      val result =
        if (current.isEditMode && !current.editingPresetId.isNullOrBlank()) {
          repository.updateCustomPreset(
            id = current.editingPresetId,
            name = current.name,
            description = current.description,
            config = config,
            icon = current.icon,
          )
        } else {
          repository.saveCustomPreset(
            name = current.name,
            description = current.description,
            config = config,
            icon = current.icon,
          )
        }
      result
        .onSuccess { saved ->
          // Sanity verify 28-key serialization leaves no initialUploaded/initialDownloaded keys
          val settingsObj = JsonCodecs.encodePresetSettings(saved.config)
          check(settingsObj.length() == 28 && !settingsObj.has("initialUploaded"))
          _uiState.update { it.copy(isSaving = false, initialSignature = it.signature()) }
          onSaved(saved)
        }
        .onFailure { err ->
          _uiState.update {
            it.copy(
              isSaving = false,
              errorMessage = err.message ?: "Không thể lưu Preset tùy chỉnh.",
            )
          }
        }
    }
  }

  companion object {
    fun factory(
      presetId: String?,
      repository: RustatioRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          CustomPresetEditorViewModel(presetId, repository) as T
      }
  }
}
