package com.example.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.RunMode
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.RustatioSectionHeader
import com.example.ui.navigation.RustatioRoutes
import com.example.ui.theme.RustatioThemeTokens
import com.example.ui.theme.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateSubScreen: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val s = state.settings

  val themeSummary =
    when (s.themeMode) {
      ThemeMode.DARK -> "Tối (Modern Dark)"
      ThemeMode.LIGHT -> "Sáng"
      ThemeMode.SYSTEM -> "Theo hệ thống"
    }

  val modeSummary =
    if (s.runMode == RunMode.SERVER) {
      s.serverUrl.ifBlank { "Chưa cấu hình URL" }
    } else {
      "Cục bộ trên thiết bị"
    }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
        title = {
          Text(
            text = "Cài đặt",
            style = MaterialTheme.typography.headlineMedium,
            color = colors.textPrimary,
          )
        },
      )
    },
  ) { innerPadding ->
    LazyColumn(
      modifier =
        Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp).testTag("settings_list"),
      contentPadding = PaddingValues(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        RustatioSectionHeader("CHUNG")
        RustatioSectionCard {
          SettingsMenuRow(
            icon = Icons.Rounded.Tune,
            title = "Chung",
            subtitle = "Chế độ chạy & Mức nhật ký (${s.logLevel.labelVi})",
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_GENERAL) },
            testTag = "settings_row_general",
          )
          HorizontalDivider(color = colors.border.copy(alpha = 0.6f))
          SettingsMenuRow(
            icon = Icons.Rounded.Palette,
            title = "Giao diện",
            subtitle = themeSummary,
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_APPEARANCE) },
            testTag = "settings_row_appearance",
          )
        }
      }

      item {
        RustatioSectionHeader("MẠNG & KẾT NỐI")
        RustatioSectionCard {
          SettingsMenuRow(
            icon = Icons.Rounded.Dns,
            title = "Kết nối máy chủ",
            subtitle = modeSummary,
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_CONNECTION) },
            testTag = "settings_row_connection",
          )
          HorizontalDivider(color = colors.border.copy(alpha = 0.6f))
          SettingsMenuRow(
            icon = Icons.Rounded.Security,
            title = "Proxy",
            subtitle =
              if (s.proxy.enabled) "${s.proxy.type.label} · ${s.proxy.host}:${s.proxy.port}"
              else "Đang tắt",
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_PROXY) },
            testTag = "settings_row_proxy",
          )
        }
      }

      item {
        RustatioSectionHeader("CẤU HÌNH & PRESETS")
        RustatioSectionCard {
          SettingsMenuRow(
            icon = Icons.Rounded.Star,
            title = "Presets",
            subtitle = "${state.builtInPresets.size} tích hợp · ${state.customPresets.size} tùy chỉnh",
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_PRESETS) },
            testTag = "settings_row_presets",
          )
          HorizontalDivider(color = colors.border.copy(alpha = 0.6f))
          SettingsMenuRow(
            icon = Icons.Rounded.SwapHoriz,
            title = "Nhập / Xuất cấu hình",
            subtitle = "Chia sẻ và sao lưu Preset chuẩn JSON",
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_IMPORT_EXPORT) },
            testTag = "settings_row_import_export",
          )
        }
      }

      item {
        RustatioSectionHeader("HƯỚNG DẪN & THÔNG TIN")
        RustatioSectionCard {
          SettingsMenuRow(
            icon = Icons.Rounded.Shield,
            title = "Mẹo tránh bị phát hiện",
            subtitle = "Nguyên tắc an toàn với tracker riêng tư",
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_TIPS) },
            testTag = "settings_row_tips",
          )
          HorizontalDivider(color = colors.border.copy(alpha = 0.6f))
          SettingsMenuRow(
            icon = Icons.Rounded.Info,
            title = "Thông tin ứng dụng",
            subtitle = "Rustatio Android · Phiên bản 2.14.1",
            onClick = { onNavigateSubScreen(RustatioRoutes.SETTINGS_ABOUT) },
            testTag = "settings_row_about",
          )
        }
      }

      item { Spacer(Modifier.height(8.dp)) }
    }
  }
}

@Composable
private fun SettingsMenuRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  onClick: () -> Unit,
  testTag: String,
) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .defaultMinSize(minHeight = 56.dp)
        .clickable(onClick = onClick)
        .padding(vertical = 8.dp)
        .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    Surface(
      shape = MaterialTheme.shapes.small,
      color = colors.primaryContainer,
      modifier = Modifier.size(40.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = colors.primary,
        modifier = Modifier.padding(9.dp),
      )
    }
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
    }
    Icon(
      imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
      contentDescription = null,
      tint = colors.textSecondary,
    )
  }
}
