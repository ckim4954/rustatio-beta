package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

// Brand & Semantic Tokens from PRD & Rustatio 2.14.1
val BrandViolet = Color(0xFF7777FF)
val BrandVioletLightTheme = Color(0xFF5656E8)
val BrandVioletContainerDark = Color(0xFF23234D)
val BrandVioletContainerLight = Color(0xFFE7E7FF)

val DarkBackground = Color(0xFF0D1110)
val DarkSurface = Color(0xFF151B19)
val DarkSurfaceElevated = Color(0xFF202925)
val DarkSurfaceSubtle = Color(0xFF1A221F)
val DarkBorder = Color(0xFF2A3530)
val DarkTextPrimary = Color(0xFFF1F5F3)
val DarkTextSecondary = Color(0xFF9AA8A2)

val LightBackground = Color(0xFFF5F7F6)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE9EFEC)
val LightSurfaceSubtle = Color(0xFFF0F4F2)
val LightBorder = Color(0xFFD5DFDA)
val LightTextPrimary = Color(0xFF111715)
val LightTextSecondary = Color(0xFF52615B)

val UploadGreen = Color(0xFF22C55E)
val UploadGreenDark = Color(0xFF16A34A)
val PresetEmeraldDark = Color(0xFF34D399)
val PresetEmeraldLight = Color(0xFF0D9488)
val PresetEmeraldContainerDark = Color(0xFF123027)
val PresetEmeraldContainerLight = Color(0xFFCCFBF1)
val DownloadBlue = Color(0xFF3B82F6)
val DownloadBlueDark = Color(0xFF2563EB)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberDark = Color(0xFFD97706)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedDark = Color(0xFFDC2626)

@Immutable
data class RustatioExtendedColors(
  val isDark: Boolean,
  val background: Color,
  val surface: Color,
  val surfaceElevated: Color,
  val surfaceSubtle: Color,
  val border: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val primary: Color,
  val primaryContainer: Color,
  val presetAccent: Color,
  val onPresetAccent: Color,
  val presetAccentContainer: Color,
  val upload: Color,
  val download: Color,
  val warning: Color,
  val error: Color,
  val ratio: Color,
)

val DarkExtendedColors =
  RustatioExtendedColors(
    isDark = true,
    background = DarkBackground,
    surface = DarkSurface,
    surfaceElevated = DarkSurfaceElevated,
    surfaceSubtle = DarkSurfaceSubtle,
    border = DarkBorder,
    textPrimary = DarkTextPrimary,
    textSecondary = DarkTextSecondary,
    primary = BrandViolet,
    primaryContainer = BrandVioletContainerDark,
    presetAccent = PresetEmeraldDark,
    onPresetAccent = Color(0xFF052116),
    presetAccentContainer = PresetEmeraldContainerDark,
    upload = UploadGreen,
    download = DownloadBlue,
    warning = WarningAmber,
    error = ErrorRed,
    ratio = WarningAmber,
  )

val LightExtendedColors =
  RustatioExtendedColors(
    isDark = false,
    background = LightBackground,
    surface = LightSurface,
    surfaceElevated = LightSurfaceElevated,
    surfaceSubtle = LightSurfaceSubtle,
    border = LightBorder,
    textPrimary = LightTextPrimary,
    textSecondary = LightTextSecondary,
    primary = BrandVioletLightTheme,
    primaryContainer = BrandVioletContainerLight,
    presetAccent = PresetEmeraldLight,
    onPresetAccent = Color.White,
    presetAccentContainer = PresetEmeraldContainerLight,
    upload = UploadGreenDark,
    download = DownloadBlueDark,
    warning = WarningAmberDark,
    error = ErrorRedDark,
    ratio = WarningAmberDark,
  )

val LocalRustatioColors = staticCompositionLocalOf { DarkExtendedColors }
