package com.example.ui.sessions

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Label
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.domain.model.InstanceItem
import com.example.domain.model.RunMode
import com.example.ui.components.BannerType
import com.example.ui.components.ExpandableTorrentTitle
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioLoadingSkeleton
import com.example.ui.components.StatusBadge
import com.example.ui.theme.MonoMetricLarge
import com.example.ui.theme.MonoMetricMedium
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SessionsScreen(
  viewModel: SessionsViewModel,
  onOpenSessionDetail: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors

  var showAddSheet by remember { mutableStateOf(false) }
  var showFilterSheet by remember { mutableStateOf(false) }
  var showTagDialog by remember { mutableStateOf(false) }

  val torrentPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
      if (uris.isNotEmpty()) {
        viewModel.importTorrents(uris)
      }
    }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      if (state.isMultiSelectActive) {
        TopAppBar(
          colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.surfaceElevated),
          navigationIcon = {
            IconButton(
              onClick = { viewModel.clearSelection() },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_clear_button"),
            ) {
              Icon(Icons.Rounded.Close, contentDescription = "Bỏ chọn")
            }
          },
          title = {
            Text(
              text = "Đã chọn ${state.selectedIds.size} phiên",
              style = MaterialTheme.typography.titleMedium,
            )
          },
          actions = {
            IconButton(
              onClick = { viewModel.selectAllVisible() },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_select_all_button"),
            ) {
              Icon(Icons.Rounded.SelectAll, contentDescription = "Chọn tất cả")
            }
            IconButton(
              onClick = { viewModel.bulkAction("start") },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_start_button"),
            ) {
              Icon(Icons.Rounded.PlayArrow, contentDescription = "Bắt đầu", tint = colors.upload)
            }
            IconButton(
              onClick = { viewModel.bulkAction("pause") },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_pause_button"),
            ) {
              Icon(Icons.Rounded.Pause, contentDescription = "Tạm dừng", tint = colors.warning)
            }
            IconButton(
              onClick = { viewModel.bulkAction("stop") },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_stop_button"),
            ) {
              Icon(Icons.Rounded.Stop, contentDescription = "Dừng", tint = colors.error)
            }
            IconButton(
              onClick = { showTagDialog = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_tag_button"),
            ) {
              Icon(Icons.AutoMirrored.Rounded.Label, contentDescription = "Gắn thẻ")
            }
            IconButton(
              onClick = { viewModel.requestDeleteSelected() },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_delete_button"),
            ) {
              Icon(Icons.Rounded.Delete, contentDescription = "Xóa", tint = colors.error)
            }
          },
        )
      } else {
        TopAppBar(
          colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
          title = {
            Column {
              Text(
                text = "Phiên",
                style = MaterialTheme.typography.headlineMedium,
                color = colors.textPrimary,
              )
              Text(
                text =
                  if (state.runMode == RunMode.SERVER) {
                    if (state.serverOnline) "Rustatio Server · Đã kết nối"
                    else "Rustatio Server · Ngoại tuyến"
                  } else {
                    "Chế độ cục bộ trên thiết bị"
                  },
                style = MaterialTheme.typography.bodySmall,
                color =
                  if (state.runMode == RunMode.SERVER && !state.serverOnline) colors.warning
                  else colors.textSecondary,
              )
            }
          },
          actions = {
            if (state.runMode == RunMode.SERVER) {
              IconButton(
                onClick = { viewModel.refreshServer() },
                modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("sessions_refresh_button"),
              ) {
                Icon(Icons.Rounded.Refresh, contentDescription = "Làm mới máy chủ")
              }
            }
            IconButton(
              onClick = { showFilterSheet = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("sessions_filter_button"),
            ) {
              BadgedBox(
                badge = {
                  if (state.activeFilterCount > 0) {
                    Badge { Text(state.activeFilterCount.toString()) }
                  }
                }
              ) {
                Icon(Icons.Rounded.FilterList, contentDescription = "Bộ lọc phiên")
              }
            }
          },
        )
      }
    },
    floatingActionButton = {
      if (!state.isMultiSelectActive) {
        ExtendedFloatingActionButton(
          onClick = { showAddSheet = true },
          containerColor = colors.primary,
          contentColor = Color.White,
          icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
          text = { Text("Thêm phiên") },
          modifier = Modifier.testTag("sessions_add_fab"),
        )
      }
    },
  ) { innerPadding ->
    BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      val isTablet = maxWidth >= 600.dp

      Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        if (state.runMode == RunMode.SERVER && !state.serverOnline) {
          RustatioBanner(
            type = BannerType.OFFLINE,
            message =
              state.serverError?.let { "Không kết nối được Rustatio Server ($it). Đang hiển thị phiên cục bộ." }
                ?: "Chưa kết nối máy chủ — đang hiển thị dữ liệu cục bộ.",
            actionLabel = "Thử lại",
            onAction = { viewModel.refreshServer() },
          )
        }

        state.actionMessage?.let { msg ->
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        state.errorMessage?.let { err ->
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        // Status summary cards
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SummaryPillCard(
            label = "Tổng phiên",
            count = state.totalCount,
            selected = state.statusFilter == SessionStatusFilter.ALL,
            accent = colors.primary,
            onClick = { viewModel.setStatusFilter(SessionStatusFilter.ALL) },
            testTag = "summary_all",
          )
          SummaryPillCard(
            label = "Đang chạy",
            count = state.runningCount,
            selected = state.statusFilter == SessionStatusFilter.RUNNING,
            accent = colors.upload,
            onClick = { viewModel.setStatusFilter(SessionStatusFilter.RUNNING) },
            testTag = "summary_running",
          )
          SummaryPillCard(
            label = "Tạm dừng",
            count = state.pausedCount,
            selected = state.statusFilter == SessionStatusFilter.PAUSED,
            accent = colors.warning,
            onClick = { viewModel.setStatusFilter(SessionStatusFilter.PAUSED) },
            testTag = "summary_paused",
          )
          SummaryPillCard(
            label = "Đã dừng",
            count = state.stoppedCount,
            selected = state.statusFilter == SessionStatusFilter.STOPPED,
            accent = colors.textSecondary,
            onClick = { viewModel.setStatusFilter(SessionStatusFilter.STOPPED) },
            testTag = "summary_stopped",
          )
        }

        // Search input
        OutlinedTextField(
          value = state.searchQuery,
          onValueChange = viewModel::setSearchQuery,
          modifier = Modifier.fillMaxWidth().testTag("sessions_search_input"),
          placeholder = { Text("Tìm kiếm theo tên phiên, tag, tracker…") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (state.searchQuery.isNotEmpty()) {
              IconButton(onClick = { viewModel.setSearchQuery("") }) {
                Icon(Icons.Rounded.Close, contentDescription = "Xóa từ khóa")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
        )

        // Active filter chips indicator
        if (state.activeFilterCount > 0) {
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            if (state.tagFilter != null) {
              FilterChip(
                selected = true,
                onClick = { viewModel.setTagFilter(null) },
                label = {
                  Text(
                    if (state.tagFilter == SessionsViewModel.TAG_UNTAGGED) "Thẻ: Chưa gắn thẻ"
                    else "Thẻ: ${state.tagFilter}"
                  )
                },
                trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Bỏ lọc thẻ") },
              )
            }
            if (state.trackerFilter != null) {
              FilterChip(
                selected = true,
                onClick = { viewModel.setTrackerFilter(null) },
                label = { Text("Tracker: ${state.trackerFilter}") },
                trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Bỏ lọc tracker") },
              )
            }
            TextButton(
              onClick = { viewModel.clearAllFilters() },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            ) {
              Text("Xóa tất cả bộ lọc")
            }
          }
        }

        // Content area
        when {
          state.isLoading -> {
            RustatioLoadingSkeleton(cardCount = 3)
          }
          state.allInstances.isEmpty() -> {
            RustatioEmptyState(
              icon = Icons.Rounded.UploadFile,
              title = "Chưa có phiên nào",
              description =
                "Nhấn nút bên dưới để nhập tệp .torrent từ thiết bị hoặc tạo một phiên trống để cấu hình trước.",
              primaryActionLabel = "Nhập tệp .torrent",
              onPrimaryAction = {
                torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*"))
              },
              actionTestTag = "sessions_empty_import_button",
            )
          }
          state.filteredInstances.isEmpty() -> {
            RustatioEmptyState(
              icon = Icons.Rounded.Search,
              title = "Không tìm thấy phiên phù hợp",
              description = "Thử thay đổi từ khóa tìm kiếm hoặc bỏ bớt điều kiện lọc hiện tại.",
              primaryActionLabel = "Đặt lại bộ lọc",
              onPrimaryAction = { viewModel.clearAllFilters() },
              actionTestTag = "sessions_empty_reset_filter",
            )
          }
          isTablet -> {
            LazyVerticalGrid(
              columns = GridCells.Fixed(2),
              verticalArrangement = Arrangement.spacedBy(12.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(bottom = 96.dp),
              modifier = Modifier.fillMaxSize(),
            ) {
              items(state.filteredInstances, key = { it.id }) { item ->
                SessionCard(
                  item = item,
                  selected = state.selectedIds.contains(item.id),
                  selectionMode = state.isMultiSelectActive,
                  onClick = {
                    if (state.isMultiSelectActive) viewModel.toggleSelection(item.id)
                    else onOpenSessionDetail(item.id)
                  },
                  onLongClick = { viewModel.toggleSelection(item.id) },
                  onStart = { viewModel.startSession(item) },
                  onPause = { viewModel.pauseSession(item) },
                  onResume = { viewModel.resumeSession(item) },
                  onStop = { viewModel.stopSession(item) },
                )
              }
              item(span = { GridItemSpan(2) }) { Spacer(Modifier.height(4.dp)) }
            }
          }
          else -> {
            LazyColumn(
              verticalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(bottom = 96.dp),
              modifier = Modifier.fillMaxSize(),
            ) {
              items(state.filteredInstances, key = { it.id }) { item ->
                SessionCard(
                  item = item,
                  selected = state.selectedIds.contains(item.id),
                  selectionMode = state.isMultiSelectActive,
                  onClick = {
                    if (state.isMultiSelectActive) viewModel.toggleSelection(item.id)
                    else onOpenSessionDetail(item.id)
                  },
                  onLongClick = { viewModel.toggleSelection(item.id) },
                  onStart = { viewModel.startSession(item) },
                  onPause = { viewModel.pauseSession(item) },
                  onResume = { viewModel.resumeSession(item) },
                  onStop = { viewModel.stopSession(item) },
                )
              }
            }
          }
        }
      }
    }
  }

  // Add session bottom sheet
  if (showAddSheet) {
    ModalBottomSheet(onDismissRequest = { showAddSheet = false }) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text("Thêm phiên mới", style = MaterialTheme.typography.titleLarge)
        Button(
          onClick = {
            showAddSheet = false
            torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*"))
          },
          modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("add_import_torrent"),
        ) {
          Icon(Icons.Rounded.UploadFile, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text("Nhập tệp .torrent (chọn một hoặc nhiều)")
        }
        OutlinedButton(
          onClick = {
            showAddSheet = false
            viewModel.createEmptySession(onCreated = onOpenSessionDetail)
          },
          modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("add_create_empty"),
        ) {
          Icon(Icons.Rounded.FolderOpen, contentDescription = null)
          Spacer(Modifier.width(8.dp))
          Text("Tạo phiên trống để cấu hình")
        }
        Spacer(Modifier.height(16.dp))
      }
    }
  }

  // Filter bottom sheet
  if (showFilterSheet) {
    ModalBottomSheet(onDismissRequest = { showFilterSheet = false }) {
      Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("Bộ lọc phiên", style = MaterialTheme.typography.titleLarge)
          TextButton(
            onClick = {
              viewModel.clearAllFilters()
              showFilterSheet = false
            }
          ) {
            Text("Đặt lại")
          }
        }
        Text("Trạng thái", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          SessionStatusFilter.entries.forEach { f ->
            FilterChip(
              selected = state.statusFilter == f,
              onClick = { viewModel.setStatusFilter(f) },
              label = { Text(f.labelVi) },
            )
          }
        }
        Text("Thẻ (Tag)", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = state.tagFilter == null,
            onClick = { viewModel.setTagFilter(null) },
            label = { Text("Tất cả") },
          )
          FilterChip(
            selected = state.tagFilter == SessionsViewModel.TAG_UNTAGGED,
            onClick = { viewModel.setTagFilter(SessionsViewModel.TAG_UNTAGGED) },
            label = { Text("Chưa gắn thẻ") },
          )
          state.availableTags.forEach { tag ->
            FilterChip(
              selected = state.tagFilter == tag,
              onClick = { viewModel.setTagFilter(tag) },
              label = { Text(tag) },
            )
          }
        }
        if (state.availableTrackers.isNotEmpty()) {
          Text("Tracker", style = MaterialTheme.typography.titleSmall)
          FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
              selected = state.trackerFilter == null,
              onClick = { viewModel.setTrackerFilter(null) },
              label = { Text("Tất cả") },
            )
            state.availableTrackers.forEach { host ->
              FilterChip(
                selected = state.trackerFilter == host,
                onClick = { viewModel.setTrackerFilter(host) },
                label = { Text(host, maxLines = 1, overflow = TextOverflow.Ellipsis) },
              )
            }
          }
        }
        Button(
          onClick = { showFilterSheet = false },
          modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Áp dụng")
        }
        Spacer(Modifier.height(12.dp))
      }
    }
  }

  // Bulk tag dialog
  if (showTagDialog) {
    var tagInput by remember { mutableStateOf("") }
    AlertDialog(
      onDismissRequest = { showTagDialog = false },
      title = { Text("Gắn thẻ cho ${state.selectedIds.size} phiên") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Nhập danh sách thẻ cách nhau bằng dấu phẩy. Để trống nếu muốn xóa hết thẻ.",
            style = MaterialTheme.typography.bodySmall,
          )
          OutlinedTextField(
            value = tagInput,
            onValueChange = { tagInput = it },
            placeholder = { Text("Ví dụ: tracker-chinh, seedbox, ưu tiên") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            viewModel.saveTagsForSelected(tagInput)
            showTagDialog = false
          },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Lưu thẻ")
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showTagDialog = false },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Hủy")
        }
      },
    )
  }

  // Delete confirmation dialog
  RustatioConfirmDialog(
    visible = state.pendingDeleteIds.isNotEmpty(),
    title = "Xác nhận xóa phiên",
    message =
      if (state.pendingDeleteIds.size == 1) {
        val name =
          state.allInstances.firstOrNull { it.id == state.pendingDeleteIds.first() }?.displayName
            ?: state.pendingDeleteIds.first()
        "Bạn có chắc muốn xóa phiên \"$name\"? Hành động này không thể hoàn tác."
      } else {
        "Bạn có chắc muốn xóa ${state.pendingDeleteIds.size} phiên đã chọn? Hành động này không thể hoàn tác."
      },
    confirmLabel = "Xóa phiên",
    isDestructive = true,
    onConfirm = { viewModel.confirmDelete() },
    onDismiss = { viewModel.dismissDeleteDialog() },
  )
}

@Composable
private fun SummaryPillCard(
  label: String,
  count: Int,
  selected: Boolean,
  accent: Color,
  onClick: () -> Unit,
  testTag: String,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(14.dp),
    color = if (selected) accent.copy(alpha = 0.16f) else colors.surface,
    border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) accent else colors.border),
    modifier = Modifier.defaultMinSize(minWidth = 92.dp, minHeight = 48.dp).testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = if (selected) accent else colors.textSecondary,
      )
      Text(
        text = count.toString(),
        style = MonoMetricLarge,
        color = colors.textPrimary,
      )
    }
  }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
private fun SessionCard(
  item: InstanceItem,
  selected: Boolean,
  selectionMode: Boolean,
  onClick: () -> Unit,
  onLongClick: () -> Unit,
  onStart: () -> Unit,
  onPause: () -> Unit,
  onResume: () -> Unit,
  onStop: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  val torrent = item.torrent
  val stats = item.stats

  val targetProgress =
    when {
      item.config.stopAtRatioEnabled && stats.ratioProgress > 0.0 -> (stats.ratioProgress / 100.0).toFloat()
      item.config.stopAtUploadedEnabled && stats.uploadProgress > 0.0 -> (stats.uploadProgress / 100.0).toFloat()
      item.config.stopAtDownloadedEnabled && stats.downloadProgress > 0.0 -> (stats.downloadProgress / 100.0).toFloat()
      item.config.stopAtSeedTimeEnabled && stats.seedTimeProgress > 0.0 -> (stats.seedTimeProgress / 100.0).toFloat()
      else -> (stats.torrentCompletion / 100.0).toFloat()
    }.coerceIn(0f, 1f)

  Card(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .testTag("session_card_${item.id}"),
    shape = RoundedCornerShape(16.dp),
    colors =
      CardDefaults.cardColors(
        containerColor = if (selected) colors.primaryContainer.copy(alpha = 0.55f) else colors.surface
      ),
    border =
      BorderStroke(
        width = if (selected) 1.5.dp else 1.dp,
        color = if (selected) colors.primary else colors.border,
      ),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (selectionMode) {
          Icon(
            imageVector =
              if (selected) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
            contentDescription = if (selected) "Đã chọn" else "Chưa chọn",
            tint = if (selected) colors.primary else colors.textSecondary,
            modifier = Modifier.padding(top = 2.dp),
          )
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = item.displayName,
            style = MaterialTheme.typography.titleMedium,
            color = colors.textPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(Modifier.height(2.dp))
          Text(
            text =
              buildString {
                append(item.config.clientType.displayName)
                append(" ")
                append(item.config.clientVersion)
                append(" · Cổng ")
                append(item.config.port)
                if (torrent != null) {
                  append(" · ")
                  append(Formatters.formatBytes(torrent.totalSize))
                }
              },
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        StatusBadge(state = item.effectiveState, isIdling = stats.isIdling)
      }

      if (item.tags.isNotEmpty() || torrent != null) {
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          if (torrent != null) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = colors.surfaceSubtle,
            ) {
              Text(
                text = torrent.primaryTrackerHost,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
          item.tags.take(3).forEach { tag ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = colors.primaryContainer,
            ) {
              Text(
                text = "#$tag",
                style = MaterialTheme.typography.labelSmall,
                color = colors.primary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
        }
      }

      // Metrics row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("Tải lên", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
          Text(
            text = Formatters.formatBytes(stats.uploadedBytes),
            style = MonoMetricMedium,
            color = colors.upload,
          )
          Text(
            text = Formatters.formatSpeedKBs(stats.currentUploadRateKBs),
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
        Column(modifier = Modifier.weight(1f)) {
          Text("Tải xuống", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
          Text(
            text = Formatters.formatBytes(stats.downloadedBytes),
            style = MonoMetricMedium,
            color = colors.download,
          )
          Text(
            text = Formatters.formatSpeedKBs(stats.currentDownloadRateKBs),
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
        Column(modifier = Modifier.weight(0.75f), horizontalAlignment = Alignment.End) {
          Text("Tỷ lệ", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
          Text(
            text = Formatters.formatRatio(stats.ratio),
            style = MonoMetricMedium,
            color = colors.ratio,
          )
          Text(
            text = "${stats.seeders}S / ${stats.leechers}L",
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
      }

      LinearProgressIndicator(
        progress = { targetProgress },
        modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(4.dp)),
        color = if (item.effectiveState == FakerState.RUNNING) colors.upload else colors.primary,
        trackColor = colors.surfaceElevated,
      )

      HorizontalDivider(color = colors.border.copy(alpha = 0.6f))

      // Concise 1-2 card action buttons (>= 48dp touch targets)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            if (stats.trackerError != null) "Tracker: ${stats.trackerError}"
            else item.statusMessage,
          style = MaterialTheme.typography.bodySmall,
          color = if (stats.trackerError != null) colors.warning else colors.textSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          when (item.effectiveState) {
            FakerState.RUNNING, FakerState.STARTING -> {
              OutlinedButton(
                onClick = onPause,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("card_pause_${item.id}"),
                contentPadding = PaddingValues(horizontal = 12.dp),
              ) {
                Icon(Icons.Rounded.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Tạm dừng")
              }
              IconButton(
                onClick = onStop,
                modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("card_stop_${item.id}"),
              ) {
                Icon(Icons.Rounded.Stop, contentDescription = "Dừng", tint = colors.error)
              }
            }
            FakerState.PAUSED -> {
              Button(
                onClick = onResume,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("card_resume_${item.id}"),
                contentPadding = PaddingValues(horizontal = 12.dp),
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Tiếp tục")
              }
              IconButton(
                onClick = onStop,
                modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("card_stop_${item.id}"),
              ) {
                Icon(Icons.Rounded.Stop, contentDescription = "Dừng", tint = colors.error)
              }
            }
            else -> {
              Button(
                onClick = onStart,
                enabled = torrent != null,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("card_start_${item.id}"),
                contentPadding = PaddingValues(horizontal = 14.dp),
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Bắt đầu")
              }
            }
          }
        }
      }
    }
  }
}
