package com.example.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@Composable
fun PresetSectionCard(
  icon: ImageVector,
  title: String,
  headerTrailing: @Composable (() -> Unit)? = null,
  content: @Composable ColumnScope.() -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    color = colors.surface,
    border = BorderStroke(1.dp, colors.border),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          modifier = Modifier.weight(1f),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = colors.presetAccent,
            modifier = Modifier.size(20.dp),
          )
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = colors.presetAccent,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
        if (headerTrailing != null) {
          Spacer(Modifier.width(8.dp))
          headerTrailing()
        }
      }
      Spacer(Modifier.height(12.dp))
      content()
    }
  }
}

@Composable
fun EmeraldSwitch(
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = RustatioThemeTokens.colors
  Switch(
    checked = checked,
    onCheckedChange = onCheckedChange,
    colors =
      SwitchDefaults.colors(
        checkedThumbColor = colors.onPresetAccent,
        checkedTrackColor = colors.presetAccent,
        checkedBorderColor = colors.presetAccent,
        uncheckedThumbColor = colors.textSecondary,
        uncheckedTrackColor = colors.surfaceElevated,
        uncheckedBorderColor = colors.border,
      ),
    modifier = modifier,
  )
}

@Composable
fun PresetSwitchRow(
  title: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  switchTag: String,
  leadingIcon: ImageVector? = null,
  subtitle: String? = null,
) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(
      modifier = Modifier.weight(1f).padding(end = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      if (leadingIcon != null) {
        Icon(
          imageVector = leadingIcon,
          contentDescription = null,
          tint = if (checked) colors.presetAccent else colors.textSecondary,
          modifier = Modifier.size(18.dp),
        )
      }
      Column {
        Text(
          text = title,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
          color = colors.textPrimary,
        )
        if (!subtitle.isNullOrBlank()) {
          Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
          )
        }
      }
    }
    EmeraldSwitch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      modifier = Modifier.testTag(switchTag),
    )
  }
}

@Composable
fun PresetStepperBox(
  value: String,
  onValueChange: (String) -> Unit,
  onIncrement: () -> Unit,
  onDecrement: () -> Unit,
  inputTag: String,
  isError: Boolean = false,
  errorText: String? = null,
  isDecimal: Boolean = true,
  modifier: Modifier = Modifier,
) {
  val colors = RustatioThemeTokens.colors
  Column(modifier = modifier) {
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = colors.surfaceSubtle,
      border = BorderStroke(1.dp, if (isError) colors.error else colors.border),
      modifier = Modifier.defaultMinSize(minHeight = 48.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        BasicTextField(
          value = value,
          onValueChange = { raw ->
            val filtered =
              raw.filter { ch ->
                ch.isDigit() || (isDecimal && (ch == '.' || ch == ','))
              }
            onValueChange(filtered)
          },
          singleLine = true,
          textStyle = MonoMetricSmall.copy(color = colors.textPrimary),
          cursorBrush = SolidColor(colors.presetAccent),
          keyboardOptions =
            KeyboardOptions(
              keyboardType = if (isDecimal) KeyboardType.Decimal else KeyboardType.Number,
            ),
          modifier = Modifier.weight(1f).padding(vertical = 12.dp).testTag(inputTag),
        )
        Column(
          verticalArrangement = Arrangement.Center,
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier =
              Modifier.size(width = 36.dp, height = 24.dp)
                .clickable(onClickLabel = "Tăng", onClick = onIncrement)
                .testTag("${inputTag}_inc"),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Rounded.KeyboardArrowUp,
              contentDescription = "Tăng giá trị",
              tint = colors.textSecondary,
              modifier = Modifier.size(16.dp),
            )
          }
          Box(
            modifier =
              Modifier.size(width = 36.dp, height = 24.dp)
                .clickable(onClickLabel = "Giảm", onClick = onDecrement)
                .testTag("${inputTag}_dec"),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Rounded.KeyboardArrowDown,
              contentDescription = "Giảm giá trị",
              tint = colors.textSecondary,
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }
    }
    if (isError && !errorText.isNullOrBlank()) {
      Text(
        text = errorText,
        style = MaterialTheme.typography.bodySmall,
        color = colors.error,
        modifier = Modifier.padding(top = 4.dp, start = 2.dp),
      )
    }
  }
}

@Composable
fun PresetInlineNumericRow(
  label: String,
  value: String,
  onValueChange: (String) -> Unit,
  onIncrement: () -> Unit,
  onDecrement: () -> Unit,
  inputTag: String,
  leadingIcon: ImageVector? = null,
  trailingLabelBadge: (@Composable () -> Unit)? = null,
  isError: Boolean = false,
  errorText: String? = null,
  isDecimal: Boolean = true,
) {
  val colors = RustatioThemeTokens.colors
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        modifier = Modifier.weight(1f).padding(end = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (leadingIcon != null) {
          Icon(
            imageVector = leadingIcon,
            contentDescription = null,
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp),
          )
        }
        Text(
          text = label,
          style = MaterialTheme.typography.bodyMedium,
          color = colors.textSecondary,
        )
        trailingLabelBadge?.invoke()
      }
      PresetStepperBox(
        value = value,
        onValueChange = onValueChange,
        onIncrement = onIncrement,
        onDecrement = onDecrement,
        inputTag = inputTag,
        isError = isError,
        errorText = null,
        isDecimal = isDecimal,
        modifier = Modifier.width(126.dp),
      )
    }
    if (isError && !errorText.isNullOrBlank()) {
      Text(
        text = errorText,
        style = MaterialTheme.typography.bodySmall,
        color = colors.error,
        modifier = Modifier.padding(top = 4.dp),
      )
    }
  }
}

@Composable
fun <T> PresetDropdownSelector(
  selectedLabel: String,
  items: List<Pair<T, String>>,
  onSelect: (T) -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val colors = RustatioThemeTokens.colors
  var expanded by remember { mutableStateOf(false) }

  Box(modifier = modifier) {
    Surface(
      shape = RoundedCornerShape(10.dp),
      color = colors.surfaceSubtle,
      border = BorderStroke(1.dp, if (expanded) colors.presetAccent else colors.border),
      modifier =
        Modifier.fillMaxWidth()
          .defaultMinSize(minHeight = 48.dp)
          .clickable { expanded = true }
          .testTag(testTag),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = selectedLabel,
          style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
          color = colors.textPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        Icon(
          imageVector = Icons.Rounded.ArrowDropDown,
          contentDescription = "Mở danh sách chọn",
          tint = colors.textSecondary,
        )
      }
    }

    DropdownMenu(
      expanded = expanded,
      onDismissRequest = { expanded = false },
    ) {
      items.forEach { (value, label) ->
        DropdownMenuItem(
          text = { Text(label, style = MaterialTheme.typography.bodyMedium) },
          onClick = {
            expanded = false
            onSelect(value)
          },
        )
      }
    }
  }
}

@Composable
fun PresetEditorHelpDialog(onDismiss: () -> Unit) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Hướng dẫn Preset tùy chỉnh") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          "• Client & Phiên bản: Giả lập đúng User-Agent và peer_id gửi tới tracker.",
          style = MaterialTheme.typography.bodySmall,
        )
        Text(
          "• Tốc độ & Biến thiên: Luôn bật dao động ngẫu nhiên (±15% đến ±25%) để hành vi giống đường truyền thật.",
          style = MaterialTheme.typography.bodySmall,
        )
        Text(
          "• Progressive Rates: Tăng/giảm tốc độ tuyến tính từ mức ban đầu tới mức mục tiêu theo số giờ thiết lập.",
          style = MaterialTheme.typography.bodySmall,
        )
        Text(
          "• Điều kiện dừng & Tạm nghỉ: Ngưỡng Ratio, dung lượng hoặc thời gian giúp dừng an toàn; mục Hành động sau khi đạt điều kiện chỉ áp dụng khi có ít nhất 1 điều kiện ngưỡng được bật.",
          style = MaterialTheme.typography.bodySmall,
        )
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.defaultMinSize(minHeight = 48.dp)) {
        Text("Đã hiểu")
      }
    },
  )
}
