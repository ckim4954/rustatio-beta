package com.example.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.LogLevel
import com.example.domain.model.ProxyType
import com.example.domain.model.RunMode
import com.example.ui.components.BannerType
import com.example.ui.components.MetricTile
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioSavingButton
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.RustatioSectionHeader
import com.example.ui.theme.RustatioThemeTokens
import com.example.ui.theme.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSubScreenScaffold(
  title: String,
  onNavigateBack: () -> Unit,
  content: @Composable (PaddingValues) -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Scaffold(
    modifier = Modifier.fillMaxSize().imePadding(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("settings_sub_back"),
          ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Quay lại")
          }
        },
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
      )
    },
    content = content,
  )
}

@Composable
fun GeneralSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors

  SettingsSubScreenScaffold(title = "Cài đặt chung", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 24.dp),
    ) {
      state.actionMessage?.let { msg ->
        item {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      item {
        RustatioSectionHeader("Chế độ hoạt động")
        RustatioSectionCard {
          val modes =
            listOf(
              Triple(
                RunMode.LOCAL,
                "Chạy cục bộ trên Android",
                "Phân tích .torrent và đếm tỷ lệ ngay trên thiết bị, hỗ trợ HTTP/HTTPS tracker.",
              ),
              Triple(
                RunMode.SERVER,
                "Kết nối Rustatio Server API",
                "Đồng bộ phiên, Watch thư mục Server, UDP tracker và VPN port sync từ máy chủ.",
              ),
            )
          modes.forEach { (mode, label, desc) ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .defaultMinSize(minHeight = 56.dp)
                  .clickable { viewModel.setRunMode(mode) }
                  .padding(vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(
                selected = state.settings.runMode == mode,
                onClick = { viewModel.setRunMode(mode) },
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.bodyLarge)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
              }
            }
          }
        }
      }

      item {
        RustatioSectionHeader("Mức nhật ký mặc định")
        RustatioSectionCard {
          LogLevel.entries.forEach { level ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .defaultMinSize(minHeight = 48.dp)
                  .clickable { viewModel.setLogLevel(level) },
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(
                selected = state.settings.logLevel == level,
                onClick = { viewModel.setLogLevel(level) },
              )
              Text(
                text = "${level.labelVi} (${level.wireName})",
                style = MaterialTheme.typography.bodyLarge,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun AppearanceSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors

  SettingsSubScreenScaffold(title = "Giao diện", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 24.dp),
    ) {
      item {
        RustatioSectionHeader("Chủ đề màu sắc")
        RustatioSectionCard {
          val options =
            listOf(
              Triple(ThemeMode.DARK, "Tối (Modern Dark)", "Mặc định — tối ưu pin OLED và đọc ban đêm"),
              Triple(ThemeMode.LIGHT, "Sáng (Light)", "Nền sáng tương phản cao cho môi trường nhiều ánh sáng"),
              Triple(ThemeMode.SYSTEM, "Theo hệ thống", "Tự động chuyển đổi theo cài đặt sáng/tối của Android"),
            )
          options.forEach { (mode, title, desc) ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .defaultMinSize(minHeight = 56.dp)
                  .clickable { viewModel.setThemeMode(mode) }
                  .padding(vertical = 6.dp)
                  .testTag("theme_option_${mode.id}"),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(
                selected = state.settings.themeMode == mode,
                onClick = { viewModel.setThemeMode(mode) },
              )
              Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ConnectionSettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  var showToken by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    viewModel.refreshNetworkStatus()
  }

  SettingsSubScreenScaffold(title = "Kết nối máy chủ", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 24.dp),
    ) {
      state.actionMessage?.let { msg ->
        item {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }
      state.errorMessage?.let { err ->
        item {
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      item {
        RustatioSectionHeader("Thông tin Rustatio Server")
        RustatioSectionCard {
          OutlinedTextField(
            value = state.serverUrlDraft,
            onValueChange = { url -> viewModel.updateServerDraft(url, state.serverTokenDraft) },
            label = { Text("Địa chỉ Rustatio Server") },
            placeholder = { Text("Ví dụ: http://192.168.1.10:8080") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("server_url_input"),
          )
          Spacer(Modifier.height(10.dp))
          OutlinedTextField(
            value = state.serverTokenDraft,
            onValueChange = { tok -> viewModel.updateServerDraft(state.serverUrlDraft, tok) },
            label = { Text("Bearer Token (nếu máy chủ bật xác thực)") },
            visualTransformation =
              if (showToken) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
              IconButton(onClick = { showToken = !showToken }) {
                Icon(
                  imageVector =
                    if (showToken) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                  contentDescription = if (showToken) "Ẩn token" else "Hiện token",
                )
              }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("server_token_input"),
          )

          Spacer(Modifier.height(10.dp))
          OutlinedButton(
            onClick = { viewModel.testServerConnection() },
            enabled = state.serverTestState !is ConnectionTestState.Testing,
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("server_test_btn"),
          ) {
            Text(
              if (state.serverTestState is ConnectionTestState.Testing) "Đang kiểm tra…"
              else "Kiểm tra kết nối máy chủ"
            )
          }

          when (val res = state.serverTestState) {
            is ConnectionTestState.Success -> {
              Spacer(Modifier.height(8.dp))
              RustatioBanner(type = BannerType.SUCCESS, message = res.message)
            }
            is ConnectionTestState.Error -> {
              Spacer(Modifier.height(8.dp))
              RustatioBanner(type = BannerType.ERROR, message = res.message)
            }
            else -> Unit
          }

          Spacer(Modifier.height(10.dp))
          RustatioSavingButton(
            label = "Lưu kết nối máy chủ",
            savingLabel = "Đang lưu…",
            isSaving = state.isSaving,
            testTag = "server_save_btn",
            onClick = { viewModel.saveServerConnection() },
          )
        }
      }

      item {
        RustatioSectionHeader(
          title = "Trạng thái IP & Mạng hiện tại",
          trailing = {
            IconButton(
              onClick = { viewModel.refreshNetworkStatus() },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp),
            ) {
              Icon(Icons.Rounded.Refresh, contentDescription = "Làm mới mạng")
            }
          },
        )
        RustatioSectionCard {
          val net = state.networkStatus
          if (state.isNetworkLoading && net == null) {
            Text("Đang kiểm tra địa chỉ IP…", style = MaterialTheme.typography.bodyMedium)
          } else if (net == null) {
            Text("Chưa có dữ liệu mạng.", style = MaterialTheme.typography.bodyMedium)
          } else {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              MetricTile("IP đầu ra", net.ip ?: "Không rõ", modifier = Modifier.weight(1f))
              MetricTile(
                "VPN / Proxy",
                when {
                  net.isVpn -> net.vpnProvider ?: "Đã phát hiện VPN"
                  net.proxyEnabled -> "Đang bật Proxy"
                  else -> "Kết nối trực tiếp"
                },
                modifier = Modifier.weight(1f),
              )
            }
            if (net.forwardedPort != null || net.country != null) {
              Spacer(Modifier.height(8.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricTile("Quốc gia", net.country ?: "—", modifier = Modifier.weight(1f))
                MetricTile(
                  "Cổng VPN",
                  net.forwardedPort?.toString() ?: "—",
                  modifier = Modifier.weight(1f),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ProxySettingsScreen(
  viewModel: SettingsViewModel,
  onNavigateBack: () -> Unit,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val proxy = state.proxyDraft
  var portText by remember(proxy.port) { mutableStateOf(proxy.port.toString()) }
  var showPassword by remember { mutableStateOf(false) }

  SettingsSubScreenScaffold(title = "Cấu hình Proxy", onNavigateBack = onNavigateBack) { padding ->
    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      contentPadding = PaddingValues(bottom = 24.dp),
    ) {
      state.actionMessage?.let { msg ->
        item {
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }
      state.errorMessage?.let { err ->
        item {
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }
      }

      item {
        RustatioSectionCard {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
              Text("Dùng Proxy cho lưu lượng tracker", style = MaterialTheme.typography.bodyLarge)
              Text(
                "Hỗ trợ SOCKS4, SOCKS4a, SOCKS5, SOCKS5h",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
              )
            }
            Switch(
              checked = proxy.enabled,
              onCheckedChange = { enabled -> viewModel.updateProxyDraft { it.copy(enabled = enabled) } },
              modifier = Modifier.testTag("proxy_enabled_switch"),
            )
          }

          if (proxy.enabled) {
            Spacer(Modifier.height(10.dp))
            Text("Loại Proxy", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(6.dp))
            Row(
              modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              ProxyType.entries.forEach { t ->
                FilterChip(
                  selected = proxy.type == t,
                  onClick = { viewModel.selectProxyType(t) },
                  label = { Text(t.label) },
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp),
                )
              }
            }

            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              OutlinedTextField(
                value = proxy.host,
                onValueChange = { h -> viewModel.updateProxyDraft { it.copy(host = h) } },
                label = { Text("Máy chủ (Host)") },
                placeholder = { Text("127.0.0.1") },
                singleLine = true,
                modifier = Modifier.weight(2f).testTag("proxy_host_input"),
              )
              OutlinedTextField(
                value = portText,
                onValueChange = { raw ->
                  portText = raw
                  raw.toIntOrNull()?.let { p -> viewModel.updateProxyDraft { it.copy(port = p) } }
                },
                label = { Text("Cổng") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("proxy_port_input"),
              )
            }

            Spacer(Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Phân giải tên miền qua Proxy", style = MaterialTheme.typography.bodyMedium)
                Text(
                  "Tránh rò rỉ DNS khi gửi truy vấn tới tracker",
                  style = MaterialTheme.typography.bodySmall,
                  color = colors.textSecondary,
                )
              }
              Switch(
                checked = proxy.resolveHostnameViaProxy,
                enabled = proxy.type.supportsHostnameLookup,
                onCheckedChange = { v ->
                  viewModel.updateProxyDraft { it.copy(resolveHostnameViaProxy = v) }
                },
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Yêu cầu xác thực (Username / Mật khẩu)", style = MaterialTheme.typography.bodyMedium)
              Switch(
                checked = proxy.authentication,
                onCheckedChange = { v -> viewModel.updateProxyDraft { it.copy(authentication = v) } },
              )
            }

            if (proxy.authentication) {
              Spacer(Modifier.height(8.dp))
              OutlinedTextField(
                value = proxy.username,
                onValueChange = { u -> viewModel.updateProxyDraft { it.copy(username = u) } },
                label = { Text("Tên đăng nhập") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
              )
              Spacer(Modifier.height(8.dp))
              OutlinedTextField(
                value = proxy.password,
                onValueChange = { pw -> viewModel.updateProxyDraft { it.copy(password = pw) } },
                label = { Text("Mật khẩu") },
                visualTransformation =
                  if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                  IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(
                      imageVector =
                        if (showPassword) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                      contentDescription = if (showPassword) "Ẩn mật khẩu" else "Hiện mật khẩu",
                    )
                  }
                },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("proxy_password_input"),
              )
              Text(
                text = "Mật khẩu proxy được ẩn mặc định và không bao giờ ghi vào nhật ký.",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(top = 4.dp),
              )
            }

            Spacer(Modifier.height(10.dp))
            OutlinedButton(
              onClick = { viewModel.testProxyConnection() },
              enabled = state.proxyTestState !is ConnectionTestState.Testing,
              modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("proxy_test_btn"),
            ) {
              Text(
                if (state.proxyTestState is ConnectionTestState.Testing) "Đang kiểm tra…"
                else "Kiểm tra kết nối Proxy"
              )
            }

            when (val res = state.proxyTestState) {
              is ConnectionTestState.Success -> {
                Spacer(Modifier.height(8.dp))
                RustatioBanner(type = BannerType.SUCCESS, message = res.message)
              }
              is ConnectionTestState.Error -> {
                Spacer(Modifier.height(8.dp))
                RustatioBanner(type = BannerType.ERROR, message = res.message)
              }
              else -> Unit
            }
          }

          Spacer(Modifier.height(12.dp))
          RustatioSavingButton(
            label = "Lưu cấu hình Proxy",
            savingLabel = "Đang lưu…",
            isSaving = state.isSaving,
            testTag = "proxy_save_btn",
            onClick = { viewModel.saveProxySettings() },
          )
        }
      }
    }
  }
}
