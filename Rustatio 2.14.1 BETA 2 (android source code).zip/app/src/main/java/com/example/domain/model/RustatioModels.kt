package com.example.domain.model

enum class RunMode(val id: String) {
  LOCAL("local"),
  SERVER("server");

  companion object {
    fun fromId(id: String?): RunMode = entries.firstOrNull { it.id == id } ?: LOCAL
  }
}

enum class FakerState(val wireName: String) {
  IDLE("Idle"),
  STARTING("Starting"),
  RUNNING("Running"),
  STOPPING("Stopping"),
  PAUSED("Paused"),
  STOPPED("Stopped");

  val isActive: Boolean
    get() = this == RUNNING || this == STARTING || this == STOPPING

  companion object {
    fun fromWire(value: String?): FakerState =
      entries.firstOrNull { it.wireName.equals(value, ignoreCase = true) } ?: STOPPED
  }
}

enum class ClientType(
  val id: String,
  val displayName: String,
  val defaultVersion: String,
  val defaultPort: Int,
  val versions: List<String>,
  val peerIdPrefix: String,
  val userAgentPrefix: String,
) {
  QBITTORRENT(
    id = "qbittorrent",
    displayName = "qBittorrent",
    defaultVersion = "5.3.0",
    defaultPort = 6881,
    versions = listOf("5.3.0", "5.2.4", "5.2.3", "5.2.0", "5.1.4", "5.0.2", "4.6.7", "4.5.5"),
    peerIdPrefix = "-qB5300-",
    userAgentPrefix = "qBittorrent/",
  ),
  UTORRENT(
    id = "utorrent",
    displayName = "µTorrent",
    defaultVersion = "3.6.0",
    defaultPort = 6881,
    versions = listOf("3.6.0", "3.5.5", "3.5.4", "3.5.3", "3.4.9", "2.2.1"),
    peerIdPrefix = "-UT3600-",
    userAgentPrefix = "uTorrent/",
  ),
  TRANSMISSION(
    id = "transmission",
    displayName = "Transmission",
    defaultVersion = "4.1.4",
    defaultPort = 51413,
    versions = listOf("4.1.4", "4.1.3", "4.1.0", "4.0.6", "4.0.5", "3.00", "2.94"),
    peerIdPrefix = "-TR4140-",
    userAgentPrefix = "Transmission/",
  ),
  DELUGE(
    id = "deluge",
    displayName = "Deluge",
    defaultVersion = "2.2.0",
    defaultPort = 6881,
    versions = listOf("2.2.0", "2.1.1", "2.0.5", "2.0.3", "1.3.15"),
    peerIdPrefix = "-DE2200-",
    userAgentPrefix = "Deluge/",
  ),
  BITTORRENT(
    id = "bittorrent",
    displayName = "BitTorrent",
    defaultVersion = "7.11.0",
    defaultPort = 6881,
    versions = listOf("7.11.0", "7.10.5", "7.10.4", "7.10.0", "7.9.9"),
    peerIdPrefix = "-BT7B00-",
    userAgentPrefix = "BitTorrent/",
  ),
  RTORRENT(
    id = "rtorrent",
    displayName = "rTorrent",
    defaultVersion = "0.16.26",
    defaultPort = 6881,
    versions = listOf("0.16.26", "0.16.25", "0.16.24", "0.15.1", "0.9.8"),
    peerIdPrefix = "-lt0D90-",
    userAgentPrefix = "rtorrent/",
  );

  companion object {
    fun fromId(id: String?): ClientType =
      entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: QBITTORRENT
  }
}

enum class PostStopAction(val wireName: String) {
  IDLE("idle"),
  STOP_SEEDING("stop_seeding"),
  DELETE_INSTANCE("delete_instance");

  companion object {
    fun fromWire(value: String?): PostStopAction =
      entries.firstOrNull { it.wireName.equals(value, ignoreCase = true) } ?: IDLE
  }
}

data class TorrentFile(
  val path: String,
  val size: Long,
)

data class TorrentInfo(
  val infoHashHex: String,
  val announce: String,
  val announceList: List<List<String>> = emptyList(),
  val name: String,
  val totalSize: Long,
  val pieceLength: Long,
  val numPieces: Int,
  val creationDate: Long? = null,
  val comment: String? = null,
  val createdBy: String? = null,
  val isSingleFile: Boolean = true,
  val fileCount: Int = 1,
  val files: List<TorrentFile> = emptyList(),
) {
  val primaryTrackerHost: String
    get() =
      runCatching { java.net.URI(announce).host?.takeIf { it.isNotBlank() } }
        .getOrNull() ?: announce.ifBlank { "Không có tracker" }

  val allTrackers: List<String>
    get() =
      (listOf(announce) + announceList.flatten())
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
}

data class FakerConfig(
  val uploadRateKBs: Double = 50.0,
  val downloadRateKBs: Double = 0.0,
  val port: Int = 6881,
  val vpnPortSync: Boolean = false,
  val clientType: ClientType = ClientType.QBITTORRENT,
  val clientVersion: String = ClientType.QBITTORRENT.defaultVersion,
  val completionPercent: Double = 100.0,
  val initialUploadedMB: Long = 0L,
  val randomizeRates: Boolean = true,
  val randomRangePercent: Double = 20.0,
  val randomizeRatio: Boolean = false,
  val randomRatioRangePercent: Double = 10.0,
  val updateIntervalSeconds: Int = 5,
  val scrapeIntervalSeconds: Int = 60,
  val stopAtRatioEnabled: Boolean = false,
  val stopAtRatio: Double = 2.0,
  val effectiveStopAtRatio: Double? = null,
  val stopAtUploadedEnabled: Boolean = false,
  val stopAtUploadedGB: Double = 10.0,
  val stopAtDownloadedEnabled: Boolean = false,
  val stopAtDownloadedGB: Double = 10.0,
  val stopAtSeedTimeEnabled: Boolean = false,
  val stopAtSeedTimeHours: Double = 24.0,
  val idleWhenNoLeechers: Boolean = false,
  val idleWhenNoSeeders: Boolean = false,
  val postStopAction: PostStopAction = PostStopAction.IDLE,
  val progressiveRatesEnabled: Boolean = false,
  val targetUploadRateKBs: Double = 100.0,
  val targetDownloadRateKBs: Double = 200.0,
  val progressiveDurationHours: Double = 1.0,
) {
  val activeStopConditionsCount: Int
    get() =
      listOf(
        stopAtRatioEnabled,
        stopAtUploadedEnabled,
        stopAtDownloadedEnabled,
        stopAtSeedTimeEnabled,
        idleWhenNoLeechers,
        idleWhenNoSeeders,
      ).count { it }
}

data class FakerStats(
  val state: FakerState = FakerState.STOPPED,
  val uploadedBytes: Long = 0L,
  val downloadedBytes: Long = 0L,
  val ratio: Double = 0.0,
  val leftBytes: Long = 0L,
  val torrentCompletion: Double = 100.0,
  val seeders: Int = 0,
  val leechers: Int = 0,
  val isIdling: Boolean = false,
  val idlingReason: String? = null,
  val trackerError: String? = null,
  val trackerRetryAttempt: Int = 0,
  val sessionUploadedBytes: Long = 0L,
  val sessionDownloadedBytes: Long = 0L,
  val sessionRatio: Double = 0.0,
  val elapsedSeconds: Long = 0L,
  val currentUploadRateKBs: Double = 0.0,
  val currentDownloadRateKBs: Double = 0.0,
  val averageUploadRateKBs: Double = 0.0,
  val averageDownloadRateKBs: Double = 0.0,
  val uploadProgress: Double = 0.0,
  val downloadProgress: Double = 0.0,
  val ratioProgress: Double = 0.0,
  val seedTimeProgress: Double = 0.0,
  val effectiveStopAtRatio: Double? = null,
  val etaRatioSeconds: Long? = null,
  val etaUploadedSeconds: Long? = null,
  val etaSeedTimeSeconds: Long? = null,
  val announceCount: Int = 0,
  val uploadRateHistory: List<Double> = emptyList(),
  val downloadRateHistory: List<Double> = emptyList(),
  val ratioHistory: List<Double> = emptyList(),
  val historyTimestamps: List<Long> = emptyList(),
  val stopConditionMet: Boolean = false,
)

enum class InstanceSource(val wireName: String) {
  MANUAL("manual"),
  WATCH_FOLDER("watch_folder");

  companion object {
    fun fromWire(value: String?): InstanceSource =
      entries.firstOrNull { it.wireName.equals(value, ignoreCase = true) } ?: MANUAL
  }
}

data class InstanceItem(
  val id: String,
  val torrent: TorrentInfo? = null,
  val config: FakerConfig = FakerConfig(),
  val stats: FakerStats = FakerStats(),
  val tags: List<String> = emptyList(),
  val source: InstanceSource = InstanceSource.MANUAL,
  val isRemote: Boolean = false,
  val statusMessage: String = "Sẵn sàng giả lập",
  val createdAtMs: Long = System.currentTimeMillis(),
) {
  val displayName: String
    get() = torrent?.name?.takeIf { it.isNotBlank() } ?: "Phiên #$id (chưa có torrent)"

  val effectiveState: FakerState
    get() = stats.state
}

enum class LogLevel(val wireName: String, val priority: Int, val labelVi: String) {
  ERROR("error", 0, "Lỗi"),
  WARN("warn", 1, "Cảnh báo"),
  INFO("info", 2, "Thông tin"),
  DEBUG("debug", 3, "Gỡ lỗi"),
  TRACE("trace", 4, "Chi tiết");

  companion object {
    fun fromWire(value: String?): LogLevel =
      entries.firstOrNull { it.wireName.equals(value, ignoreCase = true) } ?: INFO
  }
}

data class LogEntry(
  val id: Long,
  val timestampMs: Long,
  val level: LogLevel,
  val instanceId: String? = null,
  val message: String,
)

enum class ProxyType(val id: String, val label: String, val defaultPort: Int, val supportsHostnameLookup: Boolean) {
  SOCKS5("socks5", "SOCKS5", 1080, true),
  SOCKS5H("socks5h", "SOCKS5h (DNS Proxy)", 1080, true),
  SOCKS4("socks4", "SOCKS4", 1080, true),
  SOCKS4A("socks4a", "SOCKS4a", 1080, true),
  HTTP("http", "HTTP (Chỉ Server)", 8080, false);

  companion object {
    fun fromId(id: String?): ProxyType =
      entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: SOCKS5
  }
}

data class ProxySettings(
  val enabled: Boolean = false,
  val type: ProxyType = ProxyType.SOCKS5,
  val host: String = "127.0.0.1",
  val port: Int = 1080,
  val resolveHostnameViaProxy: Boolean = true,
  val authentication: Boolean = false,
  val username: String = "",
  val password: String = "",
) {
  fun toUrl(): String {
    val scheme =
      if (type == ProxyType.SOCKS5 && resolveHostnameViaProxy) "socks5h"
      else if (type == ProxyType.SOCKS4 && resolveHostnameViaProxy) "socks4a"
      else type.id
    return "$scheme://${host.trim()}:$port"
  }
}

data class Preset(
  val id: String,
  val name: String,
  val description: String,
  val icon: String,
  val recommended: Boolean = false,
  val custom: Boolean = false,
  val createdAt: String? = null,
  val config: FakerConfig,
  val tips: List<String> = emptyList(),
)

enum class WatchSourceMode {
  LOCAL_SAF,
  SERVER,
}

enum class WatchFileStatus(val wireName: String) {
  LOADED("loaded"),
  PENDING("pending"),
  INVALID("invalid");

  companion object {
    fun fromWire(value: String?): WatchFileStatus =
      entries.firstOrNull { it.wireName.equals(value, ignoreCase = true) } ?: PENDING
  }
}

data class WatchFileEntry(
  val filename: String,
  val displayName: String,
  val sizeBytes: Long,
  val status: WatchFileStatus,
  val uriString: String? = null,
  val errorMessage: String? = null,
  val infoHashHex: String? = null,
)

data class WatchConfig(
  val watchDir: String = "",
  val maxDepth: Int = 1,
  val autoStart: Boolean = false,
)

data class WatchStatus(
  val watchDir: String = "",
  val loadedCount: Int = 0,
  val totalFiles: Int = 0,
  val pendingCount: Int = 0,
  val invalidCount: Int = 0,
  val folderCount: Int = 0,
  val isWatching: Boolean = false,
)

data class DetectionTip(
  val title: String,
  val description: String,
  val importance: TipImportance,
)

enum class TipImportance(val labelVi: String) {
  CRITICAL("Quan trọng tối đa"),
  HIGH("Quan trọng"),
  MEDIUM("Khuyên dùng"),
}

data class NetworkStatus(
  val ip: String? = null,
  val country: String? = null,
  val city: String? = null,
  val org: String? = null,
  val isVpn: Boolean = false,
  val vpnProvider: String? = null,
  val forwardedPort: Int? = null,
  val proxyEnabled: Boolean = false,
)
