package com.example.domain.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow

object Formatters {
  fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB", "PB")
    val digitGroups = (kotlin.math.log10(bytes.toDouble()) / kotlin.math.log10(1024.0)).toInt()
      .coerceIn(0, units.lastIndex)
    val value = bytes / 1024.0.pow(digitGroups.toDouble())
    val formatted =
      when {
        digitGroups == 0 -> String.format(Locale.US, "%d", bytes)
        value >= 100.0 -> String.format(Locale.US, "%.0f", value)
        value >= 10.0 -> String.format(Locale.US, "%.1f", value)
        else -> String.format(Locale.US, "%.2f", value)
      }
    return "$formatted ${units[digitGroups]}"
  }

  fun formatSpeedKBs(kbs: Double): String {
    val safe = kbs.coerceAtLeast(0.0)
    return if (safe >= 1024.0) {
      String.format(Locale.US, "%.2f MB/s", safe / 1024.0)
    } else if (safe == 0.0) {
      "0 KB/s"
    } else if (safe >= 100.0) {
      String.format(Locale.US, "%.0f KB/s", safe)
    } else {
      String.format(Locale.US, "%.1f KB/s", safe)
    }
  }

  fun formatRatio(ratio: Double): String {
    if (!ratio.isFinite() || ratio < 0.0) return "0.00"
    return String.format(Locale.US, "%.2f", ratio)
  }

  fun formatDuration(totalSeconds: Long?): String {
    if (totalSeconds == null || totalSeconds < 0L) return "—"
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0L) {
      "${hours}g ${minutes}p ${seconds}s"
    } else if (minutes > 0L) {
      "${minutes}p ${seconds}s"
    } else {
      "${seconds}s"
    }
  }

  fun formatTimestamp(ms: Long): String {
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    return sdf.format(Date(ms))
  }

  fun formatDate(epochSeconds: Long?): String {
    if (epochSeconds == null || epochSeconds <= 0L) return "Không rõ"
    val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
    return sdf.format(Date(epochSeconds * 1000L))
  }

  fun stateLabelVi(state: FakerState): String =
    when (state) {
      FakerState.IDLE -> "Sẵn sàng"
      FakerState.STARTING -> "Đang khởi động"
      FakerState.RUNNING -> "Đang chạy"
      FakerState.STOPPING -> "Đang dừng"
      FakerState.PAUSED -> "Tạm dừng"
      FakerState.STOPPED -> "Đã dừng"
    }
}
