package com.example.domain.model

object BuiltInPresets {
  val all: List<Preset> =
    listOf(
      Preset(
        id = "balanced",
        name = "Balanced Seeder",
        description = "Tốc độ tăng tỷ lệ cân bằng với độ an toàn hợp lý",
        icon = "scale",
        recommended = true,
        custom = false,
        config =
          FakerConfig(
            uploadRateKBs = 500.0,
            downloadRateKBs = 0.0,
            randomizeRates = true,
            randomRangePercent = 20.0,
            progressiveRatesEnabled = false,
            updateIntervalSeconds = 5,
            completionPercent = 100.0,
            clientType = ClientType.QBITTORRENT,
            clientVersion = ClientType.QBITTORRENT.defaultVersion,
            port = 6881,
            stopAtRatioEnabled = true,
            stopAtRatio = 2.0,
          ),
        tips =
          listOf(
            "500 KB/s tải lên là mức thực tế với đa số đường truyền hiện đại.",
            "Không tải xuống vì bạn đang seed một torrent đã hoàn tất.",
            "Dao động ngẫu nhiên ±20% giúp hành vi tự nhiên hơn.",
            "Tự động dừng tại tỷ lệ 2.0 — ngưỡng an toàn cho hầu hết tracker.",
          ),
      ),
      Preset(
        id = "fast",
        name = "Fast Seeder",
        description = "Tăng tỷ lệ nhanh — chỉ dùng trên các tracker ít kiểm soát",
        icon = "rocket",
        recommended = false,
        custom = false,
        config =
          FakerConfig(
            uploadRateKBs = 1000.0,
            downloadRateKBs = 0.0,
            randomizeRates = true,
            randomRangePercent = 15.0,
            progressiveRatesEnabled = true,
            targetUploadRateKBs = 2000.0,
            targetDownloadRateKBs = 0.0,
            progressiveDurationHours = 2.0,
            updateIntervalSeconds = 5,
            completionPercent = 100.0,
            clientType = ClientType.UTORRENT,
            clientVersion = ClientType.UTORRENT.defaultVersion,
            port = 6881,
            stopAtRatioEnabled = true,
            stopAtRatio = 3.0,
            stopAtUploadedEnabled = true,
            stopAtUploadedGB = 50.0,
          ),
        tips =
          listOf(
            "Tăng dần từ 1 MB/s lên 2 MB/s để đẩy tỷ lệ nhanh.",
            "Tăng tốc lũy tiến giúp tránh tăng vọt đột ngột lúc mới chạy.",
            "Dừng khi đạt tỷ lệ 3.0 hoặc tải lên đủ 50 GB (tùy điều kiện nào tới trước).",
            "Chỉ nên dùng với tracker nới lỏng kiểm tra tốc độ.",
          ),
      ),
      Preset(
        id = "partial",
        name = "Partial Download",
        description = "Mô phỏng vừa tải xuống vừa tải lên song song",
        icon = "download",
        recommended = false,
        custom = false,
        config =
          FakerConfig(
            uploadRateKBs = 300.0,
            downloadRateKBs = 100.0,
            randomizeRates = true,
            randomRangePercent = 20.0,
            progressiveRatesEnabled = false,
            updateIntervalSeconds = 5,
            completionPercent = 85.0,
            clientType = ClientType.DELUGE,
            clientVersion = ClientType.DELUGE.defaultVersion,
            port = 6881,
            stopAtDownloadedEnabled = true,
            stopAtDownloadedGB = 5.0,
          ),
        tips =
          listOf(
            "Tỷ lệ tải lên/tải xuống 3:1 giúp tăng ratio ngay trong lúc đang tải.",
            "Đặt hoàn thành 85% để mô phỏng tải dở dang tự nhiên.",
            "Tự động dừng sau khi tải xuống 5 GB — mô phỏng hoàn tất tệp.",
            "Luôn giữ tốc độ tải lên cao hơn tải xuống để tăng tỷ lệ.",
          ),
      ),
      Preset(
        id = "seedbox",
        name = "Seedbox Mode",
        description = "Giả lập seedbox chuyên dụng với băng thông rất cao",
        icon = "server",
        recommended = false,
        custom = false,
        config =
          FakerConfig(
            uploadRateKBs = 5000.0,
            downloadRateKBs = 0.0,
            randomizeRates = true,
            randomRangePercent = 10.0,
            progressiveRatesEnabled = false,
            updateIntervalSeconds = 5,
            completionPercent = 100.0,
            port = 51413,
            clientType = ClientType.TRANSMISSION,
            clientVersion = ClientType.TRANSMISSION.defaultVersion,
            idleWhenNoLeechers = true,
          ),
        tips =
          listOf(
            "5 MB/s là tốc độ phổ biến của các seedbox phổ thông.",
            "Độ dao động thấp (±10%) giống kết nối trung tâm dữ liệu ổn định.",
            "Tạm nghỉ khi không có leecher để tránh gửi lưu lượng vô lý.",
            "Chỉ dùng khi lịch sử IP/tài khoản của bạn phù hợp với seedbox.",
          ),
      ),
      Preset(
        id = "stealth",
        name = "Stealth Seeder",
        description = "Tăng tỷ lệ chậm và ổn định — mức độ an toàn tối đa",
        icon = "eye-off",
        recommended = false,
        custom = false,
        config =
          FakerConfig(
            uploadRateKBs = 100.0,
            downloadRateKBs = 0.0,
            randomizeRates = true,
            randomRangePercent = 25.0,
            progressiveRatesEnabled = true,
            targetUploadRateKBs = 300.0,
            targetDownloadRateKBs = 0.0,
            progressiveDurationHours = 4.0,
            updateIntervalSeconds = 10,
            completionPercent = 100.0,
            clientType = ClientType.QBITTORRENT,
            clientVersion = ClientType.QBITTORRENT.defaultVersion,
            port = 6881,
            stopAtRatioEnabled = true,
            stopAtRatio = 1.5,
            stopAtSeedTimeEnabled = true,
            stopAtSeedTimeHours = 48.0,
            idleWhenNoLeechers = true,
          ),
        tips =
          listOf(
            "Tăng dần từ 100 KB/s lên 300 KB/s trong 4 giờ rất tự nhiên.",
            "Dao động cao (±25%) mô phỏng biến động mạng gia đình thực tế.",
            "Giới hạn tỷ lệ an toàn 1.5 giúp tránh bị tracker chú ý.",
            "Tạm nghỉ khi không có leecher và tự dừng sau 48 giờ seed.",
          ),
      ),
    )

  val detectionTips: List<DetectionTip> =
    listOf(
      DetectionTip(
        title = "Sử dụng VPN",
        description =
          "Luôn dùng VPN hoặc Proxy SOCKS5 để ẩn IP thật. Tracker có thể đối chiếu IP giữa nhiều torrent và phát hiện bất thường.",
        importance = TipImportance.CRITICAL,
      ),
      DetectionTip(
        title = "Đồng nhất lịch sử Client",
        description =
          "Nếu bạn thường xuyên dùng qBittorrent trên tracker, không nên đổi đột ngột sang µTorrent. Hãy giữ đúng loại client quen thuộc.",
        importance = TipImportance.HIGH,
      ),
      DetectionTip(
        title = "Tốc độ thực tế",
        description =
          "Không đặt tốc độ tải lên vượt quá băng thông thật của đường truyền. Mạng 10 Mbps không thể seed ổn định ở mức 50 MB/s.",
        importance = TipImportance.HIGH,
      ),
      DetectionTip(
        title = "Bật ngẫu nhiên hóa tốc độ",
        description =
          "Lưu lượng torrent thật luôn dao động. Tốc độ cố định tuyệt đối là dấu hiệu dễ bị phát hiện; luôn bật dao động ngẫu nhiên.",
        importance = TipImportance.HIGH,
      ),
      DetectionTip(
        title = "Dùng tốc độ tăng dần",
        description =
          "Peer thật kết nối dần theo thời gian. Bắt đầu ngay ở tốc độ tối đa trông thiếu tự nhiên — hãy bật tăng tốc lũy tiến.",
        importance = TipImportance.MEDIUM,
      ),
      DetectionTip(
        title = "Tránh các con số quá tròn",
        description =
          "Các mức như đúng 100 KB/s hoặc 50 KB/s dễ gây nghi ngờ. Ngoài bật dao động, hãy chọn mức lẻ như 47 hoặc 103 KB/s.",
        importance = TipImportance.MEDIUM,
      ),
      DetectionTip(
        title = "Khớp trạng thái hoàn thành",
        description =
          "Nếu giả lập đang tải (completion < 100%), hãy cấu hình có tốc độ tải xuống hợp lý thay vì tải lên lớn khi đang 0%.",
        importance = TipImportance.MEDIUM,
      ),
      DetectionTip(
        title = "Không lạm dụng quá mức",
        description =
          "Tăng tỷ lệ từ từ theo thời gian luôn an toàn hơn việc đẩy lên 10x chỉ trong một ngày. Hãy đặt điều kiện dừng hợp lý.",
        importance = TipImportance.MEDIUM,
      ),
    )
}
