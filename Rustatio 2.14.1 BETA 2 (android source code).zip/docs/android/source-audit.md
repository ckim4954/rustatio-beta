# Báo cáo Khảo sát Source & Xác minh Kiến trúc Android (Chặng 01)

**Dự án tham chiếu:** Rustatio 2.14.1 (`rustatio-2.14.1.zip`)  
**Tài liệu đối chiếu:** `PRD.md`, `prompts/00_MASTER_INSTRUCTION.md`, `prompts/01_SOURCE_AUDIT.md`, bộ ảnh `references/`  
**Ngày thực hiện:** 2026-11-14

---

## 1. Sơ đồ thư mục & Kiến trúc Frontend / Backend gốc

Rustatio 2.14.1 được tổ chức dạng Cargo Workspace (Rust) kết hợp giao diện Svelte 5 + Vite 7:

```
rustatio-2.14.1/
├── rustatio-core/          # Lõi nghiệp vụ BitTorrent ratio faker (dùng chung)
│   └── src/
│       ├── config.rs       # AppConfig, InstanceConfig, ClientSettings, FakerSettings, UiSettings
│       ├── faker.rs        # RatioFaker, FakerConfig, FakerStats, FakerState, PostStopAction, PresetSettings
│       ├── grid.rs         # Thao tác nhóm phiên (grid)
│       ├── peer_listener.rs# Lắng nghe kết nối peer TCP (native)
│       ├── protocol/       # Bencode parser, HTTP/UDP tracker client, peer_id generator
│       ├── proxy.rs        # ProxySettings (SOCKS4/4a/5/5h, xác thực)
│       ├── torrent/        # ClientType (6 client & danh sách version), TorrentInfo, TorrentSummary
│       └── validation.rs   # Kiểm tra dữ liệu cấu hình
├── rustatio-desktop/       # Vỏ desktop Tauri 2.9 (Windows/macOS/Linux)
│   ├── Cargo.toml          # tauri (tray-icon), dialog, updater, process, shell, os, os-release
│   ├── tauri.conf.json     # frontendDist = ../ui/dist, cấu hình cửa sổ desktop & updater
│   └── src/                # commands/, scheduler.rs, persistence.rs, watch.rs, logging.rs
├── rustatio-server/        # Máy chủ HTTP REST + SSE (Axum) phục vụ Web & Remote UI
│   └── src/api/routes/     # auth, browse, clients, config, events, faker, grid, instances, network, presets, torrents, watch
├── rustatio-watch/         # Theo dõi thư mục .torrent trên ổ đĩa & đồng bộ instance
├── rustatio-wasm/          # Biên dịch lõi sang WebAssembly cho bản web tĩnh
├── rustatio-cli/           # Giao diện dòng lệnh & TUI
└── ui/                     # Giao diện Svelte 5 + Vite 7 + Tailwind CSS 4 + ECharts 6
    ├── package.json
    └── src/
        ├── App.svelte
        ├── lib/
        │   ├── api.js      # Bộ định tuyến 3 chế độ: Tauri IPC / Server HTTP+SSE / WASM
        │   ├── core/       # instanceStore, fakerConfig, format, aggregate, status, network
        │   ├── presets/    # 5 preset tích hợp (balanced, fast, partial, seedbox, stealth) + custom
        │   ├── themes/     # themeStore (Dark/Light/System & bảng màu)
        │   ├── watch/      # watchTree, watchDuplicates, watchViewState
        │   └── grid/       # gridStore (trạng thái danh sách/lọc phiên)
        └── components/
            ├── grid/       # GridView (bảng danh sách phiên, lọc, nhập, thao tác nhóm)
            ├── config/     # ConfigurationForm, StopConditions, RandomizationSettings, ProgressiveRateSettings
            ├── stats/      # ProgressBars, SessionStats, TotalStats, RateGraph
            ├── watch/      # WatchView (cây thư mục watch, lọc, nạp lại, xóa)
            ├── layout/     # Header, Sidebar, DetailHeader, TransferRail, SettingsDialog
            └── common/     # TorrentSelector, Logs, ProxySettings, AuthPage, ConfirmDialog, ThemeSelect
```

---

## 2. Danh mục chức năng thực tế từ source

### 2.1 Nhóm Phiên & Chi tiết phiên
- **Quản lý danh sách phiên**: Tạo phiên, nhập đơn lẻ hoặc hàng loạt `.torrent`, nhập từ thư mục (desktop/server), tìm kiếm theo tên, lọc theo **Trạng thái** (`Running`, `Paused`, `Stopped`, `Idle`), **Tags** (bao gồm `Untagged`), và **Trackers**, gán/gỡ tag, thao tác nhóm (`Bắt đầu`, `Tạm dừng`, `Tiếp tục`, `Dừng`, `Cập nhật cấu hình`, `Xóa`).
- **Thông tin Torrent (`TorrentInfo` / `TorrentSummary`)**: `info_hash`, tên, tổng dung lượng, kích thước mảnh (`piece_length`), số mảnh (`num_pieces`), số tệp (`file_count`), danh sách tệp, URL tracker chính & `announce_list`, bình luận, ngày tạo, phần mềm tạo.
- **Cấu hình giả lập (`ConfigurationForm` / `FakerConfig`)**:
  - **Client giả lập (`ClientType`)**: `qBittorrent` (5.3.0..4.4.5, port 6881), `µTorrent` (3.6.0..2.2.1, port 6881), `Transmission` (4.1.4..2.93, port 51413), `Deluge` (2.2.0..1.3.15, port 6881), `BitTorrent` (7.11.0..7.9.7, port 6881), `rTorrent` (0.16.26.., port 6881).
  - **Tốc độ & Ngẫu nhiên**: `upload_rate`, `download_rate` (KB/s), `randomize_rates`, `random_range_percent` (±%), `progressive_rates`, `target_upload_rate`, `target_download_rate`, `progressive_duration` (giờ).
  - **Trạng thái ban đầu & Thời gian**: `completion_percent` (0–100%), `initial_uploaded`, `update_interval_seconds` (mặc định 5s), `scrape_interval` (10–3600s, mặc định 60s), `port` (1024–65535), `vpn_port_sync`.
- **Điều kiện dừng (`StopConditions`)**:
  - Dừng khi đạt **Tỷ lệ mục tiêu** (`stop_at_ratio` + tùy chọn `randomize_ratio` & `random_ratio_range_percent`).
  - Dừng khi **Tải lên tối đa** (`stop_at_uploaded` theo GB).
  - Dừng khi **Tải xuống tối đa** (`stop_at_downloaded` theo GB).
  - Dừng sau **Thời gian seed** (`stop_at_seed_time` theo giờ).
  - Tự động **Chờ khi không có leecher** (`idle_when_no_leechers`) / **Chờ khi không có seeder** (`idle_when_no_seeders`).
  - **Hành động sau khi dừng (`post_stop_action`)**: `Idle`, `StopSeeding`, `DeleteInstance`.
- **Thống kê, Biểu đồ & Nhật ký**:
  - `SessionStats`: Đã tải lên, Đã tải xuống, Tốc độ TB lên/xuống, Tỷ lệ phiên, Thời gian chạy, thanh tiến trình mục tiêu & ETA.
  - `TotalStats`: Tỷ lệ tích lũy, Tổng đã tải lên/xuống, Peers kết nối (`seeders` / `leechers`), trạng thái idle / lỗi tracker.
  - `RateGraph`: Lịch sử `upload_rate_history`, `download_rate_history`, `ratio_history`, `history_timestamps`.
  - `Logs`: Bộ lọc theo mức độ (`error`, `warn`, `info`, `debug`, `trace`), tối đa 500 dòng gần nhất.

### 2.2 Nhóm Theo dõi (`WatchView.svelte` + `rustatio-watch`)
- Hiển thị trạng thái thư mục Watch: `watch_dir`, `loaded_count`, tổng số thư mục, số tệp, tệp đã nạp (`loaded`), đang chờ (`pending`), lỗi/không hợp lệ (`invalid`), tổng trên ổ đĩa.
- Cấu hình theo dõi: đường dẫn `watch_dir`, độ sâu tối đa `max_depth` (`0` = không giới hạn), `auto_start` (kèm hộp thoại hỏi có bắt đầu/dừng các torrent watch hiện có hay không).
- Cây thư mục phân cấp mở rộng/thu gọn (`Expand All` / `Collapse All`), tìm kiếm theo tên/đường dẫn, lọc tab `All / Pending / Loaded / Invalid`, chọn một/nhiều tệp hoặc cả thư mục để **Nạp lại** (`Reload`) hoặc **Xóa** (`Delete`, có xác nhận).

### 2.3 Nhóm Cài đặt (`SettingsDialog.svelte`)
- **Chung**: Mức độ log (`error`, `warn`, `info`, `debug`, `trace`), hành vi đóng cửa sổ desktop (`Window Behavior` – chỉ hiện trên Tauri desktop), phóng đại giao diện (`Zoom` – đặc thù desktop/web).
- **Giao diện**: Chọn theme (`Dark`, `Light`, `Automatic`/Theo hệ thống và cặp theme sáng/tối).
- **Kết nối & Proxy**: Bật/tắt proxy cho tracker, loại proxy (`socks4`, `socks4a`, `socks5`, `socks5h`, kèm lưu ý HTTP proxy chưa hỗ trợ trong `rustatio-core`), Host, Port, tra cứu hostname qua proxy, xác thực Username/Password, nút **Lưu** và **Kiểm tra kết nối** (`Test connection`).
- **Presets & Nhập/Xuất**: 5 preset tích hợp (`Balanced Seeder`, `Fast Seeder`, `Partial Download`, `Seedbox Mode`, `Stealth Seeder`), lưu cấu hình hiện tại thành Custom Preset, áp dụng (`Apply`), đặt mặc định (`Set Default`), xóa custom preset, xuất/nhập JSON (`type: "rustatio-preset"`).
- **Mẹo tránh bị phát hiện (`Detection tips`)**: 8 khuyến nghị bảo mật tracker (VPN, giữ lịch sử client, tốc độ thực tế, bật ngẫu nhiên hóa, tăng tốc từ từ, tránh số tròn, khớp trạng thái hoàn thành, không lạm dụng).

---

## 3. Danh mục API & Command đã xác minh từ source

Trong `ui/src/lib/api.js` và `rustatio-server/src/api/routes/`, UI giao tiếp qua 2 nhóm hợp đồng chính:

### 3.1 Server REST + SSE API (`rustatio-server`, prefix `/api`)
- **Xác thực**: `GET /api/auth/status`, `GET /api/auth/verify` (Bearer Token).
- **Phiên & Torrent**:
  - `POST /api/instances`, `GET /api/instances`, `GET /api/instances/summary`, `DELETE /api/instances/{id}?force=bool`
  - `POST /api/torrent/load`, `POST /api/instances/{id}/torrent`, `GET /api/instances/{id}/torrent`, `GET /api/instances/{id}/torrent-summary`
  - `PATCH /api/instances/{id}/config`, `PUT /api/instances/{id}/tags`
- **Điều khiển Faker**:
  - `POST /api/faker/{id}/start`, `POST /api/faker/{id}/update`, `POST /api/faker/{id}/pause`, `POST /api/faker/{id}/resume`, `POST /api/faker/{id}/stop`, `POST /api/faker/{id}/recover-tracker`, `POST /api/faker/{id}/stats-only`, `GET /api/faker/{id}/stats`
- **Thao tác nhóm (Grid)**:
  - `POST /api/grid/import` (multipart), `POST /api/grid/import-folder`, `POST /api/grid/start`, `POST /api/grid/stop`, `POST /api/grid/pause`, `POST /api/grid/resume`, `POST /api/grid/delete`, `POST /api/grid/update-config`, `POST /api/grid/bulk-update-configs`, `POST /api/grid/tag`
- **Client & Mạng & Proxy**:
  - `GET /api/clients`, `GET /api/clients/info`, `GET /api/network/status`
  - `GET /api/network/proxy`, `PUT /api/network/proxy`, `POST /api/network/proxy/test`
- **Watch & Browse**:
  - `GET /api/watch/status`, `GET /api/watch/config`, `PUT /api/watch/config`, `GET /api/watch/files`, `DELETE /api/watch/files?path=...`, `POST /api/watch/files/reload?path=...`, `POST /api/watch/reload`, `GET /api/browse?path=...`
- **Cấu hình mặc định & Presets**:
  - `GET/PUT/DELETE /api/config/default`, `GET/PUT/DELETE /api/config/default-preset`, `GET /api/presets/custom`, `PUT/DELETE /api/presets/custom/{id}`
- **Sự kiện thời gian thực**: `GET /api/stream?token=...` (SSE cho logs, `instance-created`, `instance-deleted`, `instance-summaries`).

### 3.2 Tauri 2 IPC Commands (`rustatio-desktop`)
- Dùng cho bản desktop: `create_instance`, `delete_instance`, `list_instances`, `load_torrent`, `load_instance_torrent`, `start_faker`, `update_faker`, `stop_faker`, `pause_faker`, `resume_faker`, `recover_tracker_faker`, `update_stats_only`, `get_stats`, `scrape_tracker`, `get_client_types`, `get_client_infos`, `get_network_status`, `get_proxy_settings`, `set_proxy_settings`, `test_proxy`, `get_config`, `update_config`, `get_watch_*`, `set_watch_config`, `list_watch_files`, `delete_watch_file`, `reload_watch_file`, `reload_all_watch_files`, `grid_*`, `close_to_tray`, `quit_app`.

---

## 4. Kết quả xác minh khả năng build Android & Chọn kiến trúc

### 4.1 Kiểm tra toolchain và cấu hình Tauri trong môi trường
- **Toolchain có sẵn trong container**: `gradle 9.3.1`, `java`, `node`, `npm` và Android SDK (`compileSdk 36`, `minSdk 24`, `targetSdk 36`, Jetpack Compose BOM 2024.09.00, Room 2.7.0, Retrofit 2.12.0, OkHttp 4.10.0, Moshi 1.15.2, DataStore 1.1.7).
- **Toolchain không có trong container**: Không có `cargo`, `rustc`, `tauri-cli`, `wasm-pack` hay Android NDK cross-compile cho Rust.
- **Tương thích Tauri Mobile trong `rustatio-2.14.1`**:
  - Không có thư mục `src-tauri/gen/android`.
  - `rustatio-desktop/Cargo.toml` phụ thuộc trực tiếp các API desktop-only: `tauri` feature `"tray-icon"`, `tauri-plugin-updater`, `tauri-plugin-process`, `tauri-plugin-shell`, `os-release`, `close_to_tray`, `quit_app`, và chọn thư mục theo đường dẫn filesystem tuyệt đối (`@tauri-apps/plugin-dialog`) vốn không tương thích với Scoped Storage / `content://` URI của Android.
  - Thư mục `ui/src/lib/wasm/rustatio_wasm.js` không được đóng gói sẵn (cần biên dịch từ Rust sang WASM).

### 4.2 So sánh phương án & Kiến trúc đã chọn
| Tiêu chí | Tauri 2 Android | Chỉ Remote Client | **Hybrid Native Kotlin/Compose (Đã chọn)** |
|---|---|---|---|
| Khả năng build trong môi trường | Không thể (thiếu Rust/Cargo/NDK) | Build được APK | **Build được APK chuẩn Android SDK** |
| Dùng độc lập không cần PC | Có (nếu biên dịch được Rust) | Không (chỉ màn hình chờ server) | **Có (Bencode parser + Faker engine Kotlin)** |
| Kết nối `rustatio-server` | Qua JS `fetch` | Có (`/api/*` + SSE) | **Có đầy đủ (`/api/*`, Bearer token, Proxy, SSE)** |
| Truy cập tệp & thư mục Android | Hạn chế (cần plugin SAF riêng) | Chỉ duyệt server | **Chuẩn Android SAF (`OpenDocument` / `OpenDocumentTree`)** |
| Giữ nguyên source PC/Web | Cần sửa `Cargo.toml` / `ui/` | Không đụng source PC | **Không sửa source `rustatio-2.14.1` gốc** |

**Kết luận kiến trúc**: Triển khai **Rustatio Android Native (Kotlin + Jetpack Compose + Material 3)** theo mô hình **Hybrid (Kết nối Rustatio Server API + Chạy cục bộ trên Android)** với Room + DataStore + OkHttp/Retrofit + Storage Access Framework.

---

## 5. Bảng ánh xạ giao diện PC → Màn hình Android & Điều hướng

| Thành phần PC (`ui/src/components/`) | Màn hình / Thành phần Android | Ghi chú thích ứng Mobile |
|---|---|---|
| `Sidebar` + `ViewMode` | **Bottom Navigation (3 tab gốc)**: `Phiên`, `Theo dõi`, `Cài đặt` | Chỉ hiện ở 3 màn hình gốc; ẩn ở mọi màn hình con |
| `GridView.svelte` | Màn hình **Phiên** (thẻ thống kê + tìm kiếm/lọc + thẻ dọc) | Thay bảng ngang bằng Card dọc, thanh chọn nhiều chỉ hiện khi chọn ≥1 phiên |
| `App.svelte` (Instance Detail) | Màn hình **Chi tiết phiên** (6 Tab + thanh điều khiển đáy) | 6 tab: `Tổng quan`, `Cấu hình`, `Điều kiện dừng`, `Thống kê`, `Hiệu suất`, `Nhật ký` |
| `TorrentSelector.svelte` | Card thông tin Torrent + nút chọn tệp `.torrent` qua SAF | Hiển thị đầy đủ kích thước, mảnh, số tệp, trackers, info hash |
| `ConfigurationForm.svelte` + `StopConditions.svelte` | Tab **Cấu hình** & Tab **Điều kiện dừng** (Accordion + Switch) | Nhóm gọn bằng thẻ/accordion, bàn phím số, giữ nháp chưa lưu |
| `ProgressBars`, `SessionStats`, `TotalStats`, `RateGraph` | Tab **Tổng quan**, **Thống kê** & **Hiệu suất** | Biểu đồ Canvas thích ứng chiều rộng màn hình |
| `Logs.svelte` | Tab **Nhật ký** | Lọc theo level (`Error`..`Trace`), giữ nguyên nội dung log kỹ thuật |
| `WatchView.svelte` | Màn hình **Theo dõi** | Tổng quan chỉ số, cây thư mục mở/thu gọn, nguồn SAF cục bộ hoặc Server |
| `SettingsDialog.svelte` + `ProxySettings` + `ThemeSelect` | Màn hình **Cài đặt** & các trang con phân nhóm | Ẩn `Window Behavior` và `Zoom` (chỉ dành cho desktop); giữ đầy đủ tùy chọn còn lại |

---

## 6. Rủi ro, phụ thuộc & Thứ tự triển khai

1. **Rủi ro & Cách xử lý**:
   - *Không có môi trường Android Emulator trực tiếp / không có `rustatio-server` chạy sẵn*: Sử dụng Robolectric + Unit Test để kiểm chứng logic Bencode, Faker Engine, Presets, Proxy validation, Watch Tree và điều hướng Compose; cung cấp cấu hình kết nối server thật qua URL + Token.
   - *Chế độ chạy nền trên Android*: Khi phiên chạy ở chế độ cục bộ, dùng Coroutine scheduler trong `ViewModel`/Repository (và cảnh báo rõ hành vi hệ điều hành nếu app bị tắt).
   - *Chống mất dữ liệu khi rời màn hình*: Theo dõi trạng thái chỉnh sửa (`hasUnsavedChanges`) ở Chi tiết phiên và xác nhận trước khi thoát nếu chưa áp dụng.
2. **Thứ tự triển khai 6 chặng**:
   - Chặng 01: Khảo sát source (`docs/android/source-audit.md`) — **Hoàn thành**
   - Chặng 02: Nền tảng Android, Design System, Icon, Typography, Việt hóa tập trung & Điều hướng gốc
   - Chặng 03: Nhóm Phiên (Danh sách + Chi tiết 6 tab + Local Engine + Server Sync)
   - Chặng 04: Nhóm Theo dõi (Cây thư mục SAF + Server Watch API)
   - Chặng 05: Nhóm Cài đặt (Chung, Giao diện, Kết nối/Proxy, Presets, Nhập/Xuất, Mẹo, Thông tin)
   - Chặng 06: Kiểm thử toàn diện, Build APK và Báo cáo nghiệm thu (`docs/android/final-acceptance-report.md`).

---

## Tóm tắt ngắn gọn

Ứng dụng **Rustatio** gốc trên máy tính dùng giao diện web (Svelte 5) kết hợp lõi Rust/Tauri 2. Vì môi trường tạo ứng dụng Android hiện tại sử dụng hệ thống Android thuần (Kotlin/Jetpack Compose) và không có trình biên dịch Rust, giải pháp tối ưu nhất là xây dựng **Rustatio Android thuần** hỗ trợ cả **hai chế độ**: tự chạy phân tích file `.torrent` và giả lập tỷ lệ ngay trên điện thoại, đồng thời **kết nối trực tiếp tới Rustatio Server** từ xa khi bạn cần điều khiển máy chủ. Giao diện được thiết kế lại hoàn toàn cho màn hình dọc cảm ứng với 3 mục chính (**Phiên**, **Theo dõi**, **Cài đặt**), sử dụng **100% tiếng Việt có dấu** và hỗ trợ giao diện **Tối / Sáng / Theo hệ thống**.
