# Báo cáo Nghiệm thu Cuối cùng — Rustatio Android (Chặng 06)

**Ứng dụng:** Rustatio Android  
**Phiên bản tham chiếu:** 2.14.1 (`rustatio-2.14.1.zip`)  
**Nền tảng:** Android (Kotlin, Jetpack Compose, Material Design 3, Room, DataStore, OkHttp)  
**Tài liệu đối chiếu:** `PRD.md`, `prompts/00_MASTER_INSTRUCTION.md` → `prompts/06_QA_RELEASE.md`, bộ ảnh `references/`  

---

## 1. Kiến trúc Android được chọn và lý do

Vì môi trường build Android không có toolchain Rust/Cargo/Tauri/NDK để biên dịch trực tiếp `rustatio-desktop` (Tauri 2.9 với tray icon/updater/shell desktop) hoặc `rustatio-wasm`, ứng dụng được xây dựng theo kiến trúc **Hybrid Native Kotlin + Jetpack Compose**:

1. **Chạy cục bộ độc lập trên thiết bị (`RunMode.LOCAL`)**:
   - `BencodeParser.kt`: Phân tích tệp `.torrent` chuẩn Bencode và tính SHA-1 `info_hash` trực tiếp bằng Kotlin.
   - `LocalFakerEngine.kt`: Bộ đếm tỷ lệ chạy nền bằng Kotlin Coroutines, hỗ trợ 6 trình khách giả lập (`qBittorrent`, `µTorrent`, `Transmission`, `Deluge`, `BitTorrent`, `rTorrent`), dao động tốc độ ngẫu nhiên (±%), tăng tốc lũy tiến, 6 điều kiện dừng tự động, lịch sử biểu đồ và gửi request HTTP/HTTPS tracker announce thật.
   - Room (`RustatioDatabase`) + DataStore (`AppPreferences`) lưu trữ phiên, tổng tích lũy, preset tùy chỉnh và cài đặt người dùng bền vững trên thiết bị.
2. **Kết nối Rustatio Server API (`RunMode.SERVER`)**:
   - `RustatioServerClient.kt` giao tiếp trực tiếp với các endpoint REST `/api/*` của `rustatio-server` (xác thực Bearer Token, quản lý phiên, điều khiển faker, thao tác nhóm `/api/grid/*`, Proxy, Network status, Watch folder `/api/watch/*`).
   - Hỗ trợ chuyển đổi liền mạch và hiển thị banner ngoại tuyến + dữ liệu cục bộ khi chưa kết nối được server.

---

## 2. Các màn hình và chức năng đã hoàn thành

### 2.1 Điều hướng & Design System
- **3 đích gốc** trên Bottom Navigation (điện thoại) / Navigation Rail (tablet ≥ 840dp): **Phiên**, **Theo dõi**, **Cài đặt** (chỉ hiện ở 3 màn hình gốc, tự động ẩn ở mọi màn hình con).
- **Chủ đề**: Mặc định **Tối (Modern Dark)** (`#0D1110`, `#151B19`, `#202925`, `#7777FF`, `#22C55E`, `#3B82F6`, `#F59E0B`, `#EF4444`), hỗ trợ **Sáng** và **Theo hệ thống**.
- **Typography & Localization**: Tích hợp cục bộ font `Inter` và `JetBrains Mono` (`tabular-nums` cho tốc độ/tỷ lệ/dung lượng); 100% nhãn giao diện tiếng Việt có dấu, bảo toàn tên riêng/đơn vị/giao thức và nội dung log kỹ thuật gốc.
- **Khả năng tiếp cận & Responsive**: Vùng chạm tối thiểu `48dp`, `enableEdgeToEdge()`, xử lý `WindowInsets.safeDrawing` & `imePadding()` (tránh trùng lặp giữa Scaffold ngoài và Scaffold trong), Adaptive Grid 2 cột cho tablet.

### 2.2 Nhóm Phiên (`Phiên` & `Chi tiết phiên`)
- **Danh sách Phiên (`SessionsScreen`)**: Thẻ tóm tắt 4 trạng thái (`Tổng phiên`, `Đang chạy`, `Tạm dừng`, `Đã dừng`), thanh tìm kiếm, bộ lọc BottomSheet (Trạng thái, Thẻ gồm `Chưa gắn thẻ`, Tracker), card dọc tối ưu một tay (nhấn mở chi tiết, nhấn giữ chọn nhiều để Bắt đầu/Tạm dừng/Dừng/Gắn thẻ/Xóa có xác nhận), nút `+` nhập một/nhiều `.torrent` qua SAF hoặc tạo phiên trống.
- **Chi tiết phiên (`SessionDetailScreen`)**: Thanh tiêu đề + Back kèm `BackHandler` cảnh báo khi có thay đổi chưa lưu (`Lưu & Thoát`, `Bỏ thay đổi`, `Ở lại`); 6 tab ngang (`Tổng quan`, `Cấu hình`, `Điều kiện dừng`, `Thống kê`, `Hiệu suất` dùng biểu đồ `Canvas` đa đường, `Nhật ký` lọc 5 mức độ); thanh điều khiển dính ở đáy màn hình.

### 2.3 Nhóm Theo dõi (`Theo dõi`)
- **Watch Folder (`WatchScreen`)**: Chuyển đổi giữa **Thư mục Android (SAF)** (`OpenDocumentTree` + `takePersistableUriPermission`) và **Thư mục trên Server** (`/api/watch/*`).
- Hiển thị thẻ tổng quan (đường dẫn mở rộng được, số thư mục, tổng tệp, đã nạp, đang chờ), cây thư mục phân cấp giữ nguyên trạng thái mở/thu gọn & vị trí cuộn, tìm kiếm, lọc trạng thái (`Tất cả`, `Đang chờ`, `Đã nạp`, `Không hợp lệ`), nạp đơn lẻ/nhiều tệp vào Phiên, xóa tệp có hộp thoại xác nhận, cấu hình `maxDepth` và `autoStart`.

### 2.4 Nhóm Cài đặt (`Cài đặt` & 8 màn hình con)
- **Chung**: Chọn chế độ Cục bộ / Server và mức nhật ký mặc định.
- **Giao diện**: Tối (Modern Dark) / Sáng / Theo hệ thống.
- **Kết nối máy chủ**: Cấu hình URL, Bearer Token (ẩn mặc định), kiểm tra kết nối và xem IP/VPN hiện tại.
- **Proxy**: Bật/tắt Proxy, chọn loại (`SOCKS5`, `SOCKS5h`, `SOCKS4`, `SOCKS4a`, `HTTP Chỉ Server`), host/port, DNS lookup qua proxy, username/mật khẩu (ẩn mặc định, không ghi log), kiểm tra kết nối Proxy.
- **Presets**: 5 preset tích hợp (`Balanced Seeder`, `Fast Seeder`, `Partial Download`, `Seedbox Mode`, `Stealth Seeder`) kèm lời giải thích *"Tại sao dùng cấu hình này?"*, tạo/đặt mặc định/xóa preset tùy chỉnh.
- **Nhập / Xuất cấu hình**: Nhập và xuất tệp `.json` chuẩn `rustatio-preset` tương thích với Desktop/Web qua SAF.
- **Mẹo tránh bị phát hiện** & **Thông tin ứng dụng**.

---

## 3. Bảo toàn & Danh sách tệp thay đổi

- **Bảo toàn mã nguồn gốc**: Không sửa đổi source `rustatio-2.14.1` (Desktop Tauri và Web/Server giữ nguyên vẹn). Đã xóa thư mục trích xuất tạm `.rustatio_ref/` sau khi hoàn tất.
- **Các tệp đã thêm / cập nhật chính**:
  - Cấu hình & Tài nguyên: `app/build.gradle.kts`, `settings.gradle.kts`, `metadata.json`, `app/src/main/AndroidManifest.xml`, `app/src/main/res/values/{strings.xml,themes.xml}`, `app/src/main/res/font/{inter,jetbrains_mono}.ttf`, adaptive launcher icon (`drawable/ic_launcher_*`, `mipmap-*`).
  - Theme & Navigation & Core: `ui/theme/{Color,Type,Shapes,Theme}.kt`, `ui/components/RustatioComponents.kt`, `ui/navigation/RustatioRoutes.kt`, `AppContainer.kt`, `MainActivity.kt`.
  - Domain & Data: `domain/model/{RustatioModels,BuiltInPresets,Formatters}.kt`, `data/torrent/BencodeParser.kt`, `data/local/{AppPreferences,JsonCodecs,Entities,Daos,RustatioDatabase}.kt`, `data/remote/RustatioServerClient.kt`, `data/engine/LocalFakerEngine.kt`, `data/repository/RustatioRepository.kt`.
  - UI & ViewModels: `ui/sessions/{SessionsViewModel,SessionsScreen,SessionDetailViewModel,SessionDetailScreen,SessionDetailTabsA,SessionDetailTabsB}.kt`, `ui/watch/{WatchViewModel,WatchScreen}.kt`, `ui/settings/{SettingsViewModel,SettingsScreen,SettingsSubScreensA,SettingsSubScreensB}.kt`.
  - Kiểm thử & Tài liệu: `app/src/test/java/com/example/{ExampleRobolectricTest,RustatioDomainTests}.kt`, `docs/android/{source-audit,implementation-log,final-acceptance-report}.md`.

---

## 4. Kết quả kiểm tra và build thực tế

- **Build Android (`compile_applet`)**: Thành công (`Build succeeded - the applet is compiled`).
- **Tệp APK Debug đã tạo**: `app/build/outputs/apk/debug/app-debug.apk`.
- **Kiểm thử Unit + Robolectric (`gradle :app:testDebugUnitTest --console=plain`)**: **BUILD SUCCESSFUL** — **10/10 bài kiểm thử đạt** (0 lỗi, 0 bỏ qua):
  - `RustatioDomainTests` (5/5): Bencode parser + SHA-1 `info_hash`, từ chối input lỗi, 5 preset + 8 mẹo, tạo URL SOCKS5/SOCKS5h, định dạng byte/tốc độ/nhãn trạng thái tiếng Việt.
  - `ExampleRobolectricTest` (4/4): tên app `Rustatio`, tương thích JSON `rustatio-preset`, luồng điều hướng gốc (`Phiên` / `Theo dõi` / `Cài đặt` → `Giao diện` + ẩn/hiện Bottom Nav + nút Back), tạo phiên mới → mở `Chi tiết phiên` → kiểm tra tab `Cấu hình` và cuộn tới nút lưu.
  - `ExampleUnitTest` (1/1): kiểm tra cơ bản đạt.

---

## 5. Giới hạn còn tồn tại & Cách sử dụng

1. **Giới hạn môi trường & nền tảng**:
   - Container hiện tại không có Android Emulator hoặc `adb` vật lý nên các màn hình được kiểm chứng qua biên dịch APK đầy đủ và Compose Robolectric UI Test (`@Config(sdk = [36])`), chưa chạy trực tiếp trên thiết bị thật.
   - Tracker giao thức `udp://` trong chế độ Cục bộ thuần trên Android sẽ ghi cảnh báo rõ ràng và khuyến nghị kết nối qua `Rustatio Server`; tracker `http://` và `https://` hoạt động trực tiếp trên Android.
   - Nếu ứng dụng bị hệ điều hành đóng hoàn toàn khi đang chạy chế độ Cục bộ, tác vụ giả lập sẽ dừng lại (chế độ Kết nối `Rustatio Server` chạy liên tục 24/7 trên máy chủ của bạn).
2. **Cách chạy và tạo bản build Android**:
   - Mở dự án trong Android Studio hoặc chạy lệnh Gradle: `gradle assembleDebug` để xuất `app/build/outputs/apk/debug/app-debug.apk`, hoặc `gradle :app:testDebugUnitTest` để chạy toàn bộ kiểm thử.

---

## Tóm tắt dành cho người không chuyên lập trình

Ứng dụng **Rustatio Android** đã được hoàn thiện với giao diện thiết kế riêng cho điện thoại, sử dụng **100% tiếng Việt có dấu** và mặc định nền tối dễ nhìn (có thể đổi sang Sáng hoặc Theo hệ thống trong **Cài đặt → Giao diện**). Ứng dụng gồm 3 mục chính ở thanh dưới cùng:
- **Phiên**: Xem nhanh số phiên đang chạy/tạm dừng/đã dừng, tìm kiếm, lọc theo thẻ hoặc tracker, nhấn `+` để nhập tệp `.torrent` từ điện thoại, chạm vào từng phiên để chỉnh tốc độ, điều kiện tự động dừng, xem thống kê, biểu đồ hiệu suất và nhật ký.
- **Theo dõi**: Chọn trực tiếp thư mục chứa tệp `.torrent` trên điện thoại (hoặc kết nối thư mục trên Rustatio Server) để duyệt theo cây thư mục và nạp nhanh vào Phiên.
- **Cài đặt**: Thiết lập chế độ chạy độc lập trên điện thoại hoặc kết nối tới máy chủ Rustatio Server, cấu hình Proxy SOCKS4/SOCKS5, quản lý các cấu hình mẫu (Presets), sao lưu/khôi phục file JSON và xem các mẹo sử dụng an toàn.
