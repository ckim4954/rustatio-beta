# Nhật ký triển khai Rustatio Android

Tài liệu này ghi nhận chi tiết từng chặng triển khai ứng dụng Rustatio Android từ Chặng 02 đến Chặng 06.

---

## Chặng 02 — Nền tảng Android, Design System, Điều hướng và Tiếng Việt

### Các tệp đã tạo / cập nhật
- **Cấu hình & Metadata**:
  - `app/build.gradle.kts`: Giữ nguyên `namespace = "com.example"`, cập nhật `applicationId = "com.aistudio.rustatio.kxmpzq"`, bật `navigation-compose` và `datastore-preferences`, vô hiệu hóa các thư viện Firebase chưa dùng.
  - `settings.gradle.kts` & `metadata.json`: Cập nhật tên dự án `Rustatio` và mô tả tiếng Việt, giữ nguyên `MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API`.
  - `app/src/main/AndroidManifest.xml` & `app/src/main/res/values/themes.xml`: Khai báo quyền `INTERNET`, `ACCESS_NETWORK_STATE`, `windowSoftInputMode="adjustResize"`, `usesCleartextTraffic="true"` cho LAN HTTP `rustatio-server`, và theme `Theme.Rustatio`.
- **Launcher Icon tùy chỉnh**:
  - Tạo adaptive icon với nền `#0D1110` và foreground `rustatio_launcher_fg_1794664469284.jpg` cùng đầy đủ các kích thước `mipmap-*`.
- **Design System & Typography**:
  - Tải cục bộ `Inter` (`res/font/inter.ttf`) và `JetBrains Mono` (`res/font/jetbrains_mono.ttf`).
  - `ui/theme/Color.kt`, `Type.kt`, `Shapes.kt`, `Theme.kt`: Bảng màu Modern Dark mặc định (`#0D1110`, `#151B19`, `#202925`, `#7777FF`, `#22C55E`, `#3B82F6`, `#F59E0B`, `#EF4444`) kèm Light và System mode; `MonoMetric*` hỗ trợ `tnum`.
  - `res/values/strings.xml`: Toàn bộ chuỗi UI tiếng Việt chuẩn hóa.
- **Lớp Domain & Data (Hybrid Local + Server)**:
  - `domain/model/RustatioModels.kt`, `BuiltInPresets.kt`, `Formatters.kt`.
  - `data/torrent/BencodeParser.kt`, `data/local/*`, `data/remote/RustatioServerClient.kt`, `data/engine/LocalFakerEngine.kt`, `data/repository/RustatioRepository.kt`.
- **Component & Điều hướng dùng chung**:
  - `ui/components/RustatioComponents.kt`, `ui/navigation/RustatioRoutes.kt`, `AppContainer.kt`.

---

## Chặng 03 — Nhóm màn hình Phiên & Chi tiết phiên

### Các tệp đã tạo
- `ui/sessions/SessionsViewModel.kt` & `ui/sessions/SessionsScreen.kt`:
  - Tiêu đề `Phiên`, thanh tóm tắt 4 trạng thái (`Tổng phiên`, `Đang chạy`, `Tạm dừng`, `Đã dừng`), tìm kiếm và bộ lọc BottomSheet (Trạng thái, Thẻ bao gồm `Chưa gắn thẻ`, Tracker).
  - Danh sách card dọc thích ứng 2 cột trên tablet, chạm để mở chi tiết, nhấn giữ để chọn nhiều và hiện thanh thao tác hàng loạt (`Bắt đầu`, `Tạm dừng`, `Dừng`, `Gắn thẻ`, `Xóa` kèm hộp thoại xác nhận).
  - Nút FAB `+` nhập một hoặc nhiều tệp `.torrent` qua SAF (`OpenMultipleDocuments`) hoặc tạo phiên trống.
- `ui/sessions/SessionDetailViewModel.kt`, `SessionDetailScreen.kt`, `SessionDetailTabsA.kt`, `SessionDetailTabsB.kt`:
  - Thanh tiêu đề + Back kèm `BackHandler` cảnh báo khi có thay đổi chưa lưu (`Lưu & Thoát`, `Bỏ thay đổi`, `Ở lại`).
  - 6 tab ngang: `Tổng quan`, `Cấu hình` (6 trình khách giả lập, phiên bản, cổng, VPN port sync, tốc độ, dao động ±%, tăng tốc lũy tiến, hoàn thành %, chu kỳ update/scrape + validation), `Điều kiện dừng` (6 điều kiện + randomize ratio + hành động sau dừng), `Thống kê` (phiên, tổng, tiến độ & ETA), `Hiệu suất` (biểu đồ `Canvas` đa đường tốc độ & tỷ lệ), `Nhật ký` (lọc theo 5 mức độ + font monospace giữ nguyên log kỹ thuật).
  - Thanh điều khiển dính ở đáy màn hình (`Bắt đầu giả lập` / `Tạm dừng` / `Tiếp tục` / `Dừng`).

---

## Chặng 04 — Nhóm màn hình Theo dõi (Watch)

### Các tệp đã tạo
- `ui/watch/WatchViewModel.kt` & `ui/watch/WatchScreen.kt`:
  - Chuyển đổi hai nguồn: `Thư mục Android (SAF)` (`OpenDocumentTree` + `takePersistableUriPermission`) và `Thư mục trên Server` (`/api/watch/*`).
  - Thẻ tổng quan hiển thị đường dẫn đang theo dõi, số thư mục, tổng tệp, đã nạp, đang chờ.
  - Cây thư mục phân cấp giữ trạng thái đóng/mở thư mục và vị trí cuộn, có `Mở tất cả` / `Thu gọn`, tìm kiếm, lọc (`Tất cả`, `Đang chờ`, `Đã nạp`, `Không hợp lệ`), chọn nhiều tệp để nạp hoặc xóa (có hộp thoại xác nhận), và bảng tùy chọn `maxDepth` + `autoStart`.

---

## Chặng 05 — Nhóm màn hình Cài đặt & Tích hợp MainActivity

### Các tệp đã tạo / cập nhật
- `ui/settings/SettingsViewModel.kt`, `SettingsScreen.kt`, `SettingsSubScreensA.kt`, `SettingsSubScreensB.kt`:
  - Trang gốc `Cài đặt` phân nhóm `CHUNG`, `MẠNG & KẾT NỐI`, `CẤU HÌNH & PRESETS`, `HƯỚNG DẪN & THÔNG TIN`.
  - Màn hình con: `Cài đặt chung`, `Giao diện` (Tối / Sáng / Theo hệ thống), `Kết nối máy chủ` (URL, Bearer Token ẩn mặc định, kiểm tra kết nối & IP/VPN), `Proxy` (SOCKS4/4a/5/5h, DNS qua Proxy, mật khẩu ẩn không ghi log, nút Kiểm tra), `Presets` (5 tích hợp + tùy chỉnh, đặt mặc định, xóa có xác nhận), `Nhập / Xuất cấu hình` (JSON chuẩn `rustatio-preset` qua SAF), `Mẹo tránh bị phát hiện`, `Thông tin ứng dụng`.
- `MainActivity.kt`: Bật `enableEdgeToEdge()`, áp dụng `RustatioTheme` động theo DataStore, Bottom `NavigationBar` trên điện thoại / `NavigationRail` trên tablet chỉ hiển thị tại 3 màn hình gốc.

---

## Chặng 06 — Kiểm thử, Build & Nghiệm thu

- Viết kiểm thử Unit (`RustatioDomainTests.kt`) và Robolectric Compose CUJ (`ExampleRobolectricTest.kt`).
- Dọn dẹp thư mục trích xuất tạm `.rustatio_ref/` và xuất báo cáo `docs/android/final-acceptance-report.md`.
