# Rustatio Android – Kế hoạch triển khai 6 chặng

Xây dựng ứng dụng **Rustatio Android** bằng Kotlin và Jetpack Compose, kế thừa đầy đủ cấu trúc chức năng, hệ thống thiết kế Modern Dark (kèm Sáng & Theo hệ thống), và trải nghiệm di động 100% tiếng Việt dựa trên `PRD.md`, 6 chặng `prompts/01..06`, ảnh mockup tham khảo và source `rustatio-2.14.1`.

## User Review & Critical Decisions

> [!IMPORTANT]
> Trong môi trường Android hiện tại, hệ thống dùng **Gradle + Kotlin + Jetpack Compose** và không có toolchain Rust/Cargo/Tauri CLI để biên dịch trực tiếp `rustatio-desktop` (vốn dùng Tauri 2 desktop với `tray-icon`, `tauri-plugin-updater` và chưa có `gen/android`). Toàn bộ các lựa chọn kiến trúc cốt lõi dưới đây đã được xác nhận ở Bước 1:

- **Kiến trúc thực thi (Đã xác nhận)**: Mô hình **Hybrid (Kết nối Rustatio Server API + Chạy cục bộ trên Android)**. Ứng dụng vừa giao tiếp trực tiếp với `rustatio-server` (`/api/*` + SSE `/api/stream` với Bearer token & Proxy) khi có máy chủ, vừa có engine Kotlin cục bộ (phân tích tệp `.torrent` chuẩn Bencode + SHA-1 `info_hash`, giả lập 6 client BitTorrent gồm qBittorrent, µTorrent, Transmission, Deluge, BitTorrent, rTorrent, tính toán tốc độ ngẫu nhiên/tăng dần, kiểm tra điều kiện dừng, và gửi announce HTTP/HTTPS thật tới tracker) để dùng ngay trên điện thoại.
- **Giao diện mặc định (Đã xác nhận)**: Mặc định **Tối (Modern Dark)** với màu nền `#0D1110` và màu nhấn `#7777FF`, hỗ trợ chuyển đổi linh hoạt giữa **Tối**, **Sáng** và **Theo hệ thống**.
- **Theo dõi thư mục (Đã xác nhận)**: Hỗ trợ đồng thời **Android Storage Access Framework (SAF)** cho thư mục `.torrent` cục bộ (không cần quyền bộ nhớ rộng) và **Server Watch API** (`/api/watch/*`) khi kết nối `rustatio-server`.
- **Chiến lược giữ nguyên bản gốc**: Không sửa đổi bất kỳ file nào của source `rustatio-2.14.1` (chỉ trích xuất tham chiếu, không làm ảnh hưởng desktop/web/server mode); mọi tài liệu kiểm toán, nhật ký triển khai và báo cáo nghiệm thu theo đúng yêu cầu của 6 prompt sẽ được ghi tại thư mục tài liệu Android của dự án.

---

## 1. Overview & Core Concept

- **Mục tiêu sản phẩm**: Mang toàn bộ trải nghiệm quản lý phiên BitTorrent ratio faker của Rustatio 2.14.1 lên màn hình cảm ứng điện thoại Android một cách tự nhiên (mobile-first), thay thế hoàn toàn bảng ngang desktop bằng các thẻ dọc, tab phân nhóm, accordion và biểu mẫu tối ưu thao tác một tay.
- **Đối tượng sử dụng**: Người dùng sử dụng Rustatio trên điện thoại Android (cả người dùng phổ thông không chuyên kỹ thuật cần nhãn tiếng Việt rõ ràng lẫn người dùng nâng cao kết nối tới `rustatio-server` từ xa).
- **Giá trị cốt lõi**:
  - Hoạt động tin cậy cả khi ngoại tuyến với máy chủ (chạy phiên cục bộ bằng Kotlin engine) lẫn khi điều khiển từ xa `rustatio-server`.
  - Đồng nhất 100% tiếng Việt có dấu tự nhiên, giữ nguyên tên thương hiệu, giao thức và đơn vị kỹ thuật (`Rustatio`, `BitTorrent`, `qBittorrent`, `SOCKS5`, `KB/s`, `MB/s`, `GB`, `TB`).
  - Bảo toàn dữ liệu biểu mẫu, bộ lọc, tìm kiếm, vị trí cuộn và trạng thái chưa lưu khi chuyển tab hoặc xoay màn hình.

---

## 2. User Experience & Visual Design

### Luồng người dùng chính
1. **Khởi chạy & Điều hướng gốc**: Ứng dụng mở vào màn hình **Phiên** với Bottom Navigation gồm 3 mục gốc duy nhất: **Phiên**, **Theo dõi**, **Cài đặt**. Bottom Navigation tự động ẩn khi đi vào bất kỳ màn hình con nào (dùng TopAppBar kèm nút Quay lại và hỗ trợ Android Back).
2. **Nhóm Phiên**:
   - Xem tổng quan số lượng phiên theo trạng thái (Tổng, Đang chạy, Tạm dừng, Đã dừng).
   - Tìm kiếm tức thì, lọc theo trạng thái / tag / tracker; danh sách thẻ dọc hiển thị tên phiên, trạng thái, thanh tiến trình, dung lượng, tốc độ Tải lên / Tải xuống, Tỷ lệ và tracker chính.
   - Nhấn giữ hoặc chọn nhiều thẻ để mở thanh thao tác nhóm (Bắt đầu, Tạm dừng, Dừng, Gắn tag, Xóa có hộp thoại xác nhận).
   - Nhấn `+` để nhập tệp `.torrent` qua trình chọn tệp hệ thống Android hoặc thêm vào hàng đợi phiên.
   - Chạm vào thẻ để vào **Chi tiết phiên** gồm 6 tab mobile rõ ràng: **Tổng quan**, **Cấu hình**, **Điều kiện dừng**, **Thống kê**, **Hiệu suất** (biểu đồ tốc độ Canvas thích ứng), **Nhật ký** (lọc theo mức độ log, không cắt sửa nội dung kỹ thuật gốc) cùng thanh điều khiển nhanh ở đáy màn hình (**Bắt đầu / Tạm dừng / Dừng**).
3. **Nhóm Theo dõi**:
   - Hiển thị tổng quan thư mục đang theo dõi (Thư mục, Tệp, Đã nạp, Chờ xử lý, Không hợp lệ, Trên ổ đĩa) và chọn nguồn **Cục bộ (SAF)** hoặc **Máy chủ**.
   - Cây thư mục phân cấp có thể mở rộng/thu gọn, tìm kiếm theo tên/đường dẫn, lọc theo trạng thái (`Tất cả`, `Chờ xử lý`, `Đã nạp`, `Không hợp lệ`), chọn một hoặc nhiều tệp để nạp lại hoặc xóa (có xác nhận).
4. **Nhóm Cài đặt**:
   - Danh sách nhóm rõ ràng dẫn vào các màn hình con: **Chung** (mức log, chế độ hoạt động Cục bộ / Máy chủ), **Giao diện** (Tối, Sáng, Theo hệ thống), **Kết nối & Proxy** (URL Rustatio Server, Bearer Token, kiểm tra kết nối, cấu hình SOCKS4/SOCKS5/HTTP proxy, ẩn mật khẩu mặc định), **Presets** (5 preset có sẵn từ Rustatio 2.14.1: Balanced Seeder, Fast Seeder, Partial Download, Seedbox Mode, Stealth Seeder + Custom Presets + lưu/áp dụng/đặt mặc định), **Nhập / Xuất cấu hình** (JSON qua SAF), **Mẹo tránh bị phát hiện** (8 hướng dẫn bảo mật tracker), và **Thông tin ứng dụng** (phiên bản 2.14.1, trạng thái kết nối).

### Hệ thống thiết kế & Thẩm mỹ
- **Ngôn ngữ hình ảnh**: *Modern Dark* tối giản, sắc nét, độ tương phản cao, màu tím điện làm điểm nhấn, tuân thủ Material Design 3 và hệ thống lưới `4dp / 8dp` (lề chuẩn `16dp`, bo góc card `12–16dp`, vùng chạm tối thiểu `48×48dp`).
- **Bảng màu chuẩn (Dark Theme mặc định & Light Theme tương ứng)**:
  - Nền chính Dark: `#0D1110` | Bề mặt: `#151B19` | Bề mặt nâng: `#202925` | Viền mảnh: `#28332E`
  - Màu nhấn chính (Primary): `#7777FF`
  - Tải lên / Hoạt động (Upload): `#22C55E`
  - Tải xuống (Download): `#3B82F6`
  - Cảnh báo / Tạm dừng (Warning): `#F59E0B`
  - Lỗi / Dừng / Leechers (Error): `#EF4444`
  - Light Theme sử dụng nền sáng trung tính sạch (`#F6F8F7` / `#FFFFFF` / `#EBF0EE`) giữ nguyên các màu ngữ nghĩa và màu nhấn `#5B5BF0` đạt chuẩn tương phản WCAG.
- **Typography**: Cài đặt cục bộ **Inter** (hiển thị & nội dung tiếng Việt có dấu sắc nét) kết hợp **JetBrains Mono** (cho thông số kỹ thuật, tốc độ, tỷ lệ, info-hash và nhật ký) thông qua `font-util`, luôn dùng `tabular-nums` (`fontFeatureSettings = "tnum"`) cho các số liệu nhảy theo thời gian thực.
- **Trạng thái giao diện chuẩn hóa**: Mọi màn hình đều tách biệt rõ 6 trạng thái: **Đang tải** (skeleton/progress), **Có dữ liệu**, **Trống** (icon + giải thích + CTA), **Lỗi** (thông điệp tiếng Việt + nút Thử lại), **Mất kết nối** (banner cảnh báo giữ dữ liệu hiện có), **Đang lưu** (khóa nút & phản hồi sau khi xác nhận).

---

## 3. Key Product Decisions & Trade-Offs

- **Quyết định 1 — Kiến trúc Android Native (Kotlin/Compose) kết hợp Hybrid Engine thay vì ép biên dịch Tauri 2 Android**
  - *Giải pháp chọn*: Xây dựng ứng dụng Android thuần Kotlin + Jetpack Compose với hai nguồn dữ liệu: **Remote Server Repository** (gọi đầy đủ REST API & SSE của `rustatio-server`) và **Local Engine Repository** (Bencode parser, mô phỏng 6 client BitTorrent, tính tỷ lệ/tốc độ, bộ điều kiện dừng, tracker announce).
  - *Lý do*: Môi trường build hiện tại không có `cargo`/`rustc`/Android NDK để build Tauri mobile; ngoài ra các plugin desktop trong `rustatio-desktop` (`tray-icon`, `updater`, `os-release`) không chạy trên Android. Phương án Hybrid cho phép dùng ngay trên thiết bị Android mà vẫn tương thích giao thức 100% với `rustatio-server` 2.14.1, đồng thời giữ nguyên toàn bộ source PC/Web không bị xáo trộn.
  - *Phương án khác đã cân nhắc*: Chỉ làm Remote Client (sẽ vô dụng nếu người dùng chưa chạy `rustatio-server` trên PC/NAS) hoặc cố giữ WebView tĩnh (mất hiệu năng native, không dùng được SAF/Back handler/Material 3 chuẩn).

- **Quyết định 2 — Lưu trữ bền vững cục bộ bằng Room + DataStore**
  - *Giải pháp chọn*: Lưu danh sách phiên cục bộ, cấu hình phiên, custom presets và cấu hình thư mục SAF trong **Room**; lưu cài đặt giao diện (Tối/Sáng/Hệ thống), mức log, chế độ kết nối Server/Cục bộ và URL/Token trong **Preferences DataStore**.
  - *Lý do*: Dữ liệu người dùng cấu hình và lịch sử phiên cần tồn tại qua các lần đóng mở ứng dụng mà không cần đăng nhập cloud bắt buộc.

- **Quyết định 3 — Tuân thủ chặt chẽ Google Play Policy & An toàn thông tin**
  - *Giải pháp chọn*: Dùng **Storage Access Framework (`OpenDocument` / `OpenDocumentTree`)** cho mọi thao tác chọn tệp `.torrent`, thư mục Watch và nhập/xuất JSON preset — tuyệt đối không xin quyền lưu trữ rộng (`READ_EXTERNAL_STORAGE`). Mật khẩu Proxy và Bearer Token mặc định bị che (`PasswordVisualTransformation`) và không bao giờ được ghi vào nhật ký ứng dụng.

- **Quyết định 4 — Triển khai tuần tự 6 chặng chuẩn PRD**
  - Thực hiện đúng thứ tự Prompt 01 → 06, cập nhật đầy đủ `docs/android/source-audit.md`, `docs/android/implementation-log.md` và `docs/android/final-acceptance-report.md`, kiểm tra build & test (Robolectric + unit test cho Bencode/Faker/Presets/ViewModels) sau mỗi chặng.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Sơ đồ kiến trúc hệ thống

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    JETPACK COMPOSE UI (100% Tiếng Việt)                 │
│  ┌─────────────┐  ┌──────────────────┐  ┌────────────┐  ┌────────────┐  │
│  │    Phiên    │  │  Chi tiết phiên  │  │  Theo dõi  │  │  Cài đặt   │  │
│  │ (Thẻ/Lọc)   │─▶│ (6 Tabs + Action)│  │ (Cây SAF/  │  │ (Chung, UI │  │
│  │             │  │                  │  │  Server)   │  │ Proxy,     │  │
│  └─────────────┘  └──────────────────┘  └────────────┘  │ Presets)   │  │
│         ▲                   ▲                  ▲        └────────────┘  │
│         └───────────────────┴──────────────────┴──────────────┘         │
│                        Navigation Compose (M3 Adaptive)                 │
└─────────────────────────────────┬───────────────────────────────────────┘
                                  │ StateFlow / UiState
┌─────────────────────────────────▼───────────────────────────────────────┐
│                         VIEWMODEL LAYER (MVVM)                          │
│   InstancesViewModel │ DetailViewModel │ WatchViewModel │ SettingsVM    │
└─────────────────────────────────┬───────────────────────────────────────┘
                                  │ Repository Interfaces
┌─────────────────────────────────▼───────────────────────────────────────┐
│                      HYBRID DOMAIN & DATA LAYER                         │
│  ┌───────────────────────────────┐   ┌───────────────────────────────┐  │
│  │      LOCAL ENGINE (Kotlin)    │   │   RUSTATIO SERVER CLIENT      │  │
│  │ • Bencode Parser + SHA-1 Hash │   │ • OkHttp + Retrofit (/api/*)  │  │
│  │ • Ratio Faker Scheduler Loop  │   │ • SSE Stream (/api/stream)    │  │
│  │ • 6 Client Emulators          │   │ • Bearer Token & SOCKS Proxy  │  │
│  │ • Stop Conditions & Rate Graph│   │ • Server Watch / Browse API   │  │
│  │ • Android SAF Document Tree   │   └───────────────┬───────────────┘  │
│  └───────────────┬───────────────┘                   │                  │
│                  ▼                                   ▼                  │
│  ┌───────────────────────────────┐   ┌───────────────────────────────┐  │
│  │   ROOM DB & DATASTORE PREFS   │   │    REMOTE RUSTATIO-SERVER     │  │
│  │ • Sessions, Presets, WatchURI │   │   (External Host / Docker)    │  │
│  └───────────────────────────────┘   └───────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Mô hình dữ liệu & Trạng thái chính
- **TorrentInfo**: `infoHashHex`, `announce`, `announceList`, `name`, `totalSize`, `pieceLength`, `numPieces`, `isSingleFile`, `fileCount`, `files`, `comment`, `createdBy`, `creationDate`.
- **FakerConfig**: `uploadRate`, `downloadRate`, `port`, `vpnPortSync`, `clientType`, `clientVersion`, `completionPercent`, `initialUploaded`, `initialDownloaded`, `randomizeRates`, `randomRangePercent`, `randomizeRatio`, `randomRatioRangePercent`, `stopAtRatio`, `stopAtUploadedGb`, `stopAtDownloadedGb`, `stopAtSeedTimeHours`, `idleWhenNoLeechers`, `idleWhenNoSeeders`, `postStopAction`, `progressiveRatesEnabled`, `targetUploadRate`, `targetDownloadRate`, `progressiveDurationHours`, `updateIntervalSeconds`, `scrapeIntervalSeconds`.
- **FakerStats**: `state` (`Idle`, `Starting`, `Running`, `Stopping`, `Paused`, `Stopped`), `uploaded`, `downloaded`, `ratio`, `sessionUploaded`, `sessionDownloaded`, `sessionRatio`, `elapsedSeconds`, `left`, `torrentCompletion`, `seeders`, `leechers`, `currentUploadRate`, `currentDownloadRate`, `averageUploadRate`, `averageDownloadRate`, `uploadProgress`, `downloadProgress`, `ratioProgress`, `seedTimeProgress`, `etaRatioSeconds`, `etaUploadedSeconds`, `etaSeedTimeSeconds`, `isIdling`, `idlingReason`, `trackerError`, `uploadRateHistory`, `downloadRateHistory`, `ratioHistory`, `historyTimestamps`.
- **WatchEntry & WatchStatus**: trạng thái thư mục (`watchDir`, `loadedCount`, `totalFiles`, `pendingCount`, `invalidCount`), cấu hình (`maxDepth`, `autoStart`), phân cấp thư mục/tệp (`path`, `name`, `size`, `status`, `isFolder`, `children`).
- **Preset & ProxySettings**: 5 built-in presets đồng nhất JSON gốc + custom presets lưu Room/Server; cấu hình proxy (`enabled`, `type` SOCKS4/SOCKS4A/SOCKS5/SOCKS5H/HTTP, `host`, `port`, `resolveHostnameViaProxy`, `authentication`, `username`, `password`).

### Ánh xạ 6 chặng triển khai
1. **Chặng 01 (Source Audit)**: Lập `docs/android/source-audit.md` ghi nhận cấu trúc `rustatio-2.14.1`, danh mục toàn bộ API/command thực tế, kết quả kiểm tra toolchain, đánh đổi Tauri Android vs Hybrid Kotlin/Compose và bảng ánh xạ component PC → màn hình Android.
2. **Chặng 02 (Foundation, Design System, Việt hóa, Navigation)**: Cập nhật `applicationId`, tên app `Rustatio`, biểu tượng adaptive launcher icon riêng, font `Inter` + `JetBrains Mono`, bảng màu Dark/Light/System, hệ thống chuỗi tập trung `strings.xml`, điều hướng 3 tab gốc + trạng thái Loading/Empty/Error/Offline/Saving/Success, cập nhật `docs/android/implementation-log.md`.
3. **Chặng 03 (Nhóm Phiên)**: Danh sách Phiên dạng thẻ dọc, thống kê nhanh theo trạng thái, tìm kiếm + bộ lọc trạng thái/tag/tracker, chọn nhiều phiên, nhập `.torrent` qua SAF, và Chi tiết phiên 6 tab (`Tổng quan`, `Cấu hình`, `Điều kiện dừng`, `Thống kê`, `Hiệu suất` với biểu đồ tốc độ Canvas, `Nhật ký`), bảo vệ form chưa lưu và chạy local faker engine / server API.
4. **Chặng 04 (Nhóm Theo dõi)**: Tổng quan thư mục Watch, trình duyệt cây thư mục phân cấp mở rộng/thu gọn, hỗ trợ SAF `OpenDocumentTree` + Server Watch API, tìm kiếm, lọc trạng thái, chọn nhiều tệp nạp lại/xóa có xác nhận, giữ trạng thái cây & vị trí cuộn.
5. **Chặng 05 (Nhóm Cài đặt)**: Trang Cài đặt phân nhóm đầy đủ (`Chung`, `Giao diện`, `Kết nối & Proxy`, `Presets`, `Nhập/Xuất cấu hình`, `Mẹo tránh bị phát hiện`, `Thông tin ứng dụng`), hỗ trợ kiểm tra kết nối Server/Proxy, ẩn mật khẩu, không ghi secret vào log, quản lý 5 built-in presets + custom presets + JSON import/export qua SAF.
6. **Chặng 06 (QA & Release)**: Kiểm thử toàn diện điều hướng, responsive (màn hình nhỏ/lớn/tablet, dọc/ngang), Light/Dark/System, tiếng Việt có dấu, trạng thái dữ liệu, unit/Robolectric tests, `compile_applet` (debug APK build) và xuất báo cáo `docs/android/final-acceptance-report.md`.
