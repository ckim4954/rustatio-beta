package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sessions")
data class SessionEntity(
  @PrimaryKey val id: String,
  val name: String,
  val createdAtMs: Long,
)

@Entity(tableName = "local_instances")
data class LocalInstanceEntity(
  @PrimaryKey val id: String,
  val sessionId: String = "default-session",
  val torrentJson: String?,
  val configJson: String,
  val tagsJson: String,
  val source: String,
  val cumulativeUploadedBytes: Long,
  val cumulativeDownloadedBytes: Long,
  val createdAtMs: Long,
  val wasActiveBeforeStop: Boolean = false,
)

@Entity(tableName = "custom_presets")
data class CustomPresetEntity(
  @PrimaryKey val id: String,
  val name: String,
  val description: String,
  val icon: String,
  val createdAt: String?,
  val settingsJson: String,
)
