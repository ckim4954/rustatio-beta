package com.example.data.torrent

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.example.domain.model.PendingImportFile

object TorrentImportHelper {

  fun previewUris(
    context: Context,
    uris: List<Uri>,
    existingHashes: Set<String>,
  ): List<PendingImportFile> {
    val seenBatch = mutableSetOf<String>()
    return uris.map { uri ->
      val fileName = queryDisplayName(context, uri) ?: "torrent.torrent"
      val bytes =
        runCatching {
          context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        }.getOrNull()
      if (bytes == null) {
        PendingImportFile(
          uriString = uri.toString(),
          fileName = fileName,
          error = "Không thể đọc dữ liệu tệp",
        )
      } else {
        parseFileEntry(uri.toString(), fileName, bytes, existingHashes, seenBatch)
      }
    }
  }

  fun previewFolderTree(
    context: Context,
    treeUri: Uri,
    maxDepth: Int,
    existingHashes: Set<String>,
  ): List<PendingImportFile> {
    val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
    val results = mutableListOf<PendingImportFile>()
    val seenBatch = mutableSetOf<String>()

    fun walk(docId: String, relPrefix: String, depth: Int) {
      val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
      val projection =
        arrayOf(
          DocumentsContract.Document.COLUMN_DOCUMENT_ID,
          DocumentsContract.Document.COLUMN_DISPLAY_NAME,
          DocumentsContract.Document.COLUMN_MIME_TYPE,
        )
      context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
        val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
        val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
        while (cursor.moveToNext()) {
          val childId = cursor.getString(idIdx) ?: continue
          val childName = cursor.getString(nameIdx) ?: continue
          val mime = cursor.getString(mimeIdx).orEmpty()
          val relPath = if (relPrefix.isBlank()) childName else "$relPrefix/$childName"
          if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
            if (maxDepth == 0 || depth < maxDepth) {
              walk(childId, relPath, depth + 1)
            }
          } else if (childName.endsWith(".torrent", ignoreCase = true)) {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
            val bytes =
              runCatching {
                context.contentResolver.openInputStream(docUri)?.use { it.readBytes() }
              }.getOrNull()
            if (bytes == null) {
              results.add(
                PendingImportFile(
                  uriString = docUri.toString(),
                  fileName = relPath,
                  error = "Không thể đọc tệp từ thư mục SAF",
                )
              )
            } else {
              results.add(parseFileEntry(docUri.toString(), relPath, bytes, existingHashes, seenBatch))
            }
          }
        }
      }
    }

    walk(rootDocId, "", 1)
    return results.sortedBy { it.fileName.lowercase() }
  }

  private fun parseFileEntry(
    uriString: String,
    fileName: String,
    bytes: ByteArray,
    existingHashes: Set<String>,
    seenBatch: MutableSet<String>,
  ): PendingImportFile {
    val parsed = BencodeParser.parseTorrent(bytes, fileName.substringAfterLast('/'))
    val torrent = parsed.getOrNull()
    if (torrent == null) {
      return PendingImportFile(
        uriString = uriString,
        fileName = fileName,
        bytes = bytes,
        error = parsed.exceptionOrNull()?.message ?: "Tệp .torrent không hợp lệ",
      )
    }
    val hash = torrent.infoHashHex.lowercase()
    val duplicate = existingHashes.contains(hash) || !seenBatch.add(hash)
    return PendingImportFile(
      uriString = uriString,
      fileName = fileName,
      bytes = bytes,
      torrent = torrent,
      isDuplicate = duplicate,
    )
  }

  fun queryDisplayName(context: Context, uri: Uri): String? {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
      ?.use { c ->
        if (c.moveToFirst()) {
          val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
          if (idx >= 0) return c.getString(idx)
        }
      }
    return uri.lastPathSegment?.substringAfterLast('/')
  }
}
