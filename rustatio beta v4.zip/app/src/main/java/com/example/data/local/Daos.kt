package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SessionDao {
  @Query("SELECT * FROM sessions ORDER BY createdAtMs ASC")
  fun observeAll(): Flow<List<SessionEntity>>

  @Query("SELECT * FROM sessions ORDER BY createdAtMs ASC")
  suspend fun getAll(): List<SessionEntity>

  @Query("SELECT * FROM sessions WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): SessionEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(entity: SessionEntity)

  @Query("UPDATE sessions SET name = :name WHERE id = :id")
  suspend fun rename(id: String, name: String)

  @Query("DELETE FROM sessions WHERE id = :id")
  suspend fun deleteById(id: String)
}

@Dao
interface LocalInstanceDao {
  @Query("SELECT * FROM local_instances ORDER BY createdAtMs DESC")
  fun observeAll(): Flow<List<LocalInstanceEntity>>

  @Query("SELECT * FROM local_instances ORDER BY createdAtMs DESC")
  suspend fun getAll(): List<LocalInstanceEntity>

  @Query("SELECT * FROM local_instances WHERE sessionId = :sessionId ORDER BY createdAtMs DESC")
  suspend fun getBySessionId(sessionId: String): List<LocalInstanceEntity>

  @Query("SELECT * FROM local_instances WHERE wasActiveBeforeStop = 1")
  suspend fun getActiveBeforeStop(): List<LocalInstanceEntity>

  @Query("UPDATE local_instances SET wasActiveBeforeStop = :active WHERE id = :id")
  suspend fun setWasActiveBeforeStop(id: String, active: Boolean)

  @Query("UPDATE local_instances SET wasActiveBeforeStop = 0")
  suspend fun clearAllWasActiveBeforeStop()

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(entity: LocalInstanceEntity)

  @Query("DELETE FROM local_instances WHERE id = :id")
  suspend fun deleteById(id: String)

  @Query("DELETE FROM local_instances WHERE id IN (:ids)")
  suspend fun deleteByIds(ids: List<String>)

  @Query("DELETE FROM local_instances WHERE sessionId = :sessionId")
  suspend fun deleteBySessionId(sessionId: String)
}

@Dao
interface CustomPresetDao {
  @Query("SELECT * FROM custom_presets ORDER BY name ASC")
  fun observeAll(): Flow<List<CustomPresetEntity>>

  @Query("SELECT * FROM custom_presets WHERE id = :id LIMIT 1")
  suspend fun getById(id: String): CustomPresetEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsert(entity: CustomPresetEntity)

  @Query("DELETE FROM custom_presets WHERE id = :id")
  suspend fun deleteById(id: String)
}
