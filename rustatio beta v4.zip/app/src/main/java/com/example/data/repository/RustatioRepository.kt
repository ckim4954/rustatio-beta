package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.data.engine.LocalFakerEngine
import com.example.data.local.AppPreferences
import com.example.data.local.AppSettingsSnapshot
import com.example.data.local.CustomPresetEntity
import com.example.data.local.JsonCodecs
import com.example.data.local.LocalInstanceEntity
import com.example.data.local.RustatioDatabase
import com.example.data.local.SessionEntity
import com.example.data.remote.RustatioServerClient
import com.example.data.torrent.BencodeParser
import com.example.data.torrent.TorrentImportHelper
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.FakerStats
import com.example.domain.model.ImportBatchResult
import com.example.domain.model.InstanceItem
import com.example.domain.model.InstanceSource
import com.example.domain.model.LogEntry
import com.example.domain.model.LogLevel
import com.example.domain.model.NetworkStatus
import com.example.domain.model.PendingImportFile
import com.example.domain.model.Preset
import com.example.domain.model.ProxySettings
import com.example.domain.model.RunMode
import com.example.domain.model.SessionItem
import com.example.domain.model.TorrentImportOptions
import com.example.domain.model.TorrentInfo
import com.example.domain.model.WatchConfig
import com.example.domain.model.WatchFileEntry
import com.example.domain.model.WatchFileStatus
import com.example.domain.model.WatchStatus
import com.example.service.RustatioForegroundService
import com.example.ui.theme.ThemeMode
import java.util.UUID
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RustatioRepository(
  private val context: Context,
  val preferences: AppPreferences,
  private val database: RustatioDatabase,
  private val serverClient: RustatioServerClient,
  val localEngine: LocalFakerEngine,
) {
  private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private val sessionDao = database.sessionDao()
  private val instanceDao = database.localInstanceDao()
  private val presetDao = database.customPresetDao()

  private val _remoteInstances = MutableStateFlow<List<InstanceItem>>(emptyList())
  private val _serverOnline = MutableStateFlow(false)
  val serverOnline: StateFlow<Boolean> = _serverOnline.asStateFlow()

  private val _serverError = MutableStateFlow<String?>(null)
  val serverError: StateFlow<String?> = _serverError.asStateFlow()

  private val _interruptedInstances = MutableStateFlow<List<InstanceItem>>(emptyList())
  val interruptedInstances: StateFlow<List<InstanceItem>> = _interruptedInstances.asStateFlow()

  private val latestLocalSessions = AtomicReference<List<SessionItem>>(emptyList())
  private var staggerStartJob: Job? = null

  val settingsFlow: Flow<AppSettingsSnapshot> = preferences.settingsFlow
  val logsFlow: StateFlow<List<LogEntry>> = localEngine.logs

  val customPresetsFlow: Flow<List<Preset>> =
    presetDao.observeAll()
      .catch { e -> if (isClosedPoolError(e)) emit(emptyList()) else throw e }
      .map { entities ->
        entities.map { entity ->
          Preset(
            id = entity.id,
            name = entity.name,
            description = entity.description,
            icon = entity.icon,
            recommended = false,
            custom = true,
            createdAt = entity.createdAt,
            config = JsonCodecs.decodePresetConfig(entity.settingsJson),
          )
        }
      }

  private val localInstancesFlow: Flow<List<InstanceItem>> =
    combine(
      instanceDao.observeAll().catch { e -> if (isClosedPoolError(e)) emit(emptyList()) else throw e },
      localEngine.statsMap,
    ) { localEntities, statsMap ->
      localEntities.map { entity -> entityToInstanceItem(entity, statsMap[entity.id]) }
    }

  val localSessionsFlow: Flow<List<SessionItem>> =
    combine(
      sessionDao.observeAll().catch { e -> if (isClosedPoolError(e)) emit(emptyList()) else throw e },
      localInstancesFlow,
    ) { sessions, instances ->
      val list = buildLocalSessions(sessions, instances)
      latestLocalSessions.set(list)
      list
    }

  val instancesFlow: Flow<List<InstanceItem>> =
    combine(localInstancesFlow, _remoteInstances, settingsFlow) { localList, remoteList, settings ->
      if (settings.runMode == RunMode.SERVER && _serverOnline.value) remoteList else localList
    }

  val sessionsFlow: Flow<List<SessionItem>> =
    combine(localSessionsFlow, _remoteInstances, settingsFlow) { localList, remoteList, settings ->
      if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
        listOf(
          SessionItem(
            id = InstanceItem.SERVER_SESSION_ID,
            name = InstanceItem.SERVER_SESSION_NAME,
            createdAtMs = 0L,
            instances = remoteList,
            isRemoteSession = true,
          )
        )
      } else {
        localList
      }
    }

  fun sessionFlow(sessionId: String): Flow<SessionItem?> =
    sessionsFlow.map { list -> list.firstOrNull { it.id == sessionId } }

  init {
    localEngine.attachCallbacks(
      persistTotals = { id, up, dl ->
        val current = instanceDao.getAll().firstOrNull { it.id == id }
        if (current != null) {
          instanceDao.upsert(
            current.copy(cumulativeUploadedBytes = up, cumulativeDownloadedBytes = dl)
          )
        }
      },
      deleteInstance = { id ->
        instanceDao.deleteById(id)
        syncServiceIfNeeded()
      },
      onStopped = { id ->
        instanceDao.setWasActiveBeforeStop(id, false)
        syncServiceIfNeeded()
      },
    )

    repoScope.launch {
      runCatching {
        // Detect any instances that were RUNNING when OS killed the previous process
        val liveIds = localEngine.statsMap.value.filterValues { it.state.isActive }.keys
        val orphanedActive = instanceDao.getActiveBeforeStop().filter { !liveIds.contains(it.id) }
        if (orphanedActive.isNotEmpty()) {
          _interruptedInstances.value = orphanedActive.map { entityToInstanceItem(it, null) }
          localEngine.appendLog(
            LogLevel.WARN,
            null,
            "Phát hiện ${orphanedActive.size} torrent từng chạy khi tiến trình bị đóng trước đó.",
          )
        }
      }
    }
  }

  @androidx.annotation.VisibleForTesting
  fun shutdownForTests() {
    staggerStartJob?.cancel()
    repoScope.cancel()
  }

  private fun isClosedPoolError(e: Throwable): Boolean =
    e is IllegalStateException && (e.message?.contains("closed", ignoreCase = true) == true)

  fun currentLocalSessionSnapshot(): List<SessionItem> = latestLocalSessions.get()

  suspend fun refreshServerInstances(): Result<Unit> {
    val settings = settingsFlow.first()
    if (settings.runMode != RunMode.SERVER || settings.serverUrl.isBlank()) {
      _serverOnline.value = false
      return Result.failure(IllegalStateException("Chưa cấu hình địa chỉ Rustatio Server."))
    }
    return serverClient.listInstances(settings.serverUrl, settings.serverToken).map { list ->
      _remoteInstances.value = list
      _serverOnline.value = true
      _serverError.value = null
    }.onFailure { err ->
      _serverOnline.value = false
      _serverError.value = err.message
      localEngine.appendLog(LogLevel.ERROR, null, "Lỗi đồng bộ server: ${err.message}")
    }
  }

  // ---- Session CRUD (1 Session -> N Torrents) ----

  suspend fun ensureDefaultSession(): String =
    withContext(Dispatchers.IO) {
      val existing = sessionDao.getById(InstanceItem.DEFAULT_SESSION_ID)
      if (existing == null) {
        sessionDao.upsert(
          SessionEntity(
            id = InstanceItem.DEFAULT_SESSION_ID,
            name = InstanceItem.DEFAULT_SESSION_NAME,
            createdAtMs = System.currentTimeMillis(),
          )
        )
      }
      InstanceItem.DEFAULT_SESSION_ID
    }

  suspend fun createSession(name: String): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Vui lòng nhập tên phiên." }
        val sessionId = "session-${UUID.randomUUID().toString().take(8)}"
        sessionDao.upsert(
          SessionEntity(
            id = sessionId,
            name = cleanName,
            createdAtMs = System.currentTimeMillis(),
          )
        )
        localEngine.appendLog(LogLevel.INFO, null, "Đã tạo phiên mới '$cleanName'")
        sessionId
      }
    }

  suspend fun renameSession(sessionId: String, newName: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val clean = newName.trim()
        require(clean.isNotEmpty()) { "Tên phiên không được để trống." }
        sessionDao.rename(sessionId, clean)
      }
    }

  suspend fun deleteSession(sessionId: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val childIds = instanceDao.getBySessionId(sessionId).map { it.id }
        childIds.forEach { localEngine.stop(it) }
        instanceDao.deleteBySessionId(sessionId)
        sessionDao.deleteById(sessionId)
        localEngine.appendLog(LogLevel.INFO, null, "Đã xóa phiên và ${childIds.size} torrent bên trong.")
        syncServiceIfNeeded()
      }
    }

  suspend fun sessionAction(sessionId: String, action: String): Result<Int> {
    val all = instancesFlow.first().filter { it.sessionId == sessionId }
    if (all.isEmpty()) return Result.success(0)
    val targets =
      when (action) {
        "start" -> all.filter { !it.effectiveState.isActive && it.effectiveState != FakerState.PAUSED && it.torrent != null }
        "pause" -> all.filter { it.effectiveState.isActive }
        "resume" -> all.filter { it.effectiveState == FakerState.PAUSED }
        "stop" -> all.filter { it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED }
        else -> emptyList()
      }
    if (targets.isEmpty()) return Result.success(0)
    return bulkAction(action, targets).map { targets.size }
  }

  // ---- Torrent Import Preview & Batch Import ----

  suspend fun previewTorrentUris(
    uris: List<Uri>,
    targetSessionId: String? = null,
  ): Result<List<PendingImportFile>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val existingHashes = collectExistingHashes(targetSessionId)
        TorrentImportHelper.previewUris(context, uris, existingHashes)
      }
    }

  suspend fun previewFolderTree(
    treeUri: Uri,
    maxDepth: Int = 0,
    targetSessionId: String? = null,
  ): Result<List<PendingImportFile>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val existingHashes = collectExistingHashes(targetSessionId)
        TorrentImportHelper.previewFolderTree(context, treeUri, maxDepth, existingHashes)
      }
    }

  suspend fun importPendingTorrents(
    files: List<PendingImportFile>,
    options: TorrentImportOptions,
    source: InstanceSource = InstanceSource.MANUAL,
  ): Result<ImportBatchResult> =
    withContext(Dispatchers.IO) {
      runCatching {
        val settings = settingsFlow.first()
        val validFiles = files.filter { it.isValidNew && it.torrent != null && it.bytes != null }
        val skippedDuplicates = files.filter { it.isDuplicate }.map { it.fileName }
        val errors = files.filter { it.error != null }.map { "${it.fileName}: ${it.error}" }

        if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
          if (validFiles.isEmpty()) {
            return@runCatching ImportBatchResult(
              importedCount = 0,
              skippedDuplicates = skippedDuplicates,
              errors = errors,
              sessionId = InstanceItem.SERVER_SESSION_ID,
              autoStarted = false,
              staggerStartSeconds = 0,
            )
          }
          val uploadPairs = validFiles.map { it.fileName to it.bytes!! }
          val (srvCount, srvDups, srvErrs) =
            serverClient.gridImportTorrents(settings.serverUrl, settings.serverToken, uploadPairs, options).getOrThrow()
          refreshServerInstances()
          return@runCatching ImportBatchResult(
            importedCount = srvCount,
            skippedDuplicates = skippedDuplicates + srvDups,
            errors = errors + srvErrs,
            sessionId = InstanceItem.SERVER_SESSION_ID,
            autoStarted = options.autoStart,
            staggerStartSeconds = options.staggerStartSeconds,
          )
        }

        // Resolve target local Session (create if requested, otherwise append to chosen session)
        val resolvedSessionId =
          if (!options.createNewSessionName.isNullOrBlank()) {
            createSession(options.createNewSessionName).getOrThrow()
          } else {
            val chosen = options.targetSessionId
            if (!chosen.isNullOrBlank() && sessionDao.getById(chosen) != null) chosen
            else ensureDefaultSession()
          }

        val resolvedConfig = options.toFakerConfig()
        val cleanTags = options.tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        val existingHashes = collectExistingLocalHashes(resolvedSessionId).toMutableSet()
        val extraDupes = mutableListOf<String>()
        val createdItems = mutableListOf<InstanceItem>()

        for (file in validFiles) {
          val torrent = file.torrent!!
          val hash = torrent.infoHashHex.lowercase()
          if (!existingHashes.add(hash)) {
            extraDupes.add(file.fileName)
            continue
          }
          val id = UUID.randomUUID().toString().take(8)
          val entity =
            LocalInstanceEntity(
              id = id,
              sessionId = resolvedSessionId,
              torrentJson = JsonCodecs.encodeTorrent(torrent),
              configJson = JsonCodecs.encodeConfig(resolvedConfig),
              tagsJson = JsonCodecs.encodeTags(cleanTags),
              source = source.wireName,
              cumulativeUploadedBytes = 0L,
              cumulativeDownloadedBytes = 0L,
              createdAtMs = System.currentTimeMillis(),
              wasActiveBeforeStop = false,
            )
          instanceDao.upsert(entity)
          createdItems.add(entityToInstanceItem(entity, null))
          localEngine.appendLog(
            LogLevel.INFO,
            id,
            "[Torrent $id] Đã nhập '${torrent.name}' vào phiên #$resolvedSessionId",
          )
        }

        if (options.autoStart && createdItems.isNotEmpty()) {
          startBatchWithStagger(createdItems, options.staggerStartSeconds)
        }

        ImportBatchResult(
          importedCount = createdItems.size,
          skippedDuplicates = skippedDuplicates + extraDupes,
          errors = errors,
          sessionId = resolvedSessionId,
          autoStarted = options.autoStart,
          staggerStartSeconds = options.staggerStartSeconds,
        )
      }
    }

  private fun startBatchWithStagger(items: List<InstanceItem>, staggerSeconds: Int) {
    staggerStartJob?.cancel()
    if (staggerSeconds <= 0) {
      repoScope.launch {
        items.forEach { startSession(it) }
      }
      return
    }
    staggerStartJob =
      repoScope.launch {
        items.forEachIndexed { index, item ->
          if (index > 0) delay(staggerSeconds * 1000L)
          startSession(item)
        }
      }
  }

  suspend fun importTorrentUris(
    uris: List<Uri>,
    source: InstanceSource = InstanceSource.MANUAL,
  ): Result<Int> =
    withContext(Dispatchers.IO) {
      runCatching {
        val settings = settingsFlow.first()
        val defaultConfig = resolveDefaultConfig(settings.defaultPresetId)
        val preview = previewTorrentUris(uris).getOrThrow()
        val res =
          importPendingTorrents(
            files = preview,
            options =
              TorrentImportOptions(
                targetSessionId = ensureDefaultSession(),
                baseConfig = defaultConfig,
                clientType = defaultConfig.clientType,
                clientVersion = defaultConfig.clientVersion,
                port = defaultConfig.port,
                vpnPortSync = defaultConfig.vpnPortSync,
                uploadRateKBs = defaultConfig.uploadRateKBs,
                downloadRateKBs = defaultConfig.downloadRateKBs,
                updateIntervalSeconds = defaultConfig.updateIntervalSeconds,
                scrapeIntervalSeconds = defaultConfig.scrapeIntervalSeconds,
              ),
            source = source,
          ).getOrThrow()
        res.importedCount
      }
    }

  suspend fun createEmptySession(sessionId: String? = null): Result<String> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      serverClient.createInstance(settings.serverUrl, settings.serverToken).also {
        refreshServerInstances()
      }
    } else {
      val resolvedSession =
        if (!sessionId.isNullOrBlank() && sessionDao.getById(sessionId) != null) sessionId
        else ensureDefaultSession()
      createEmptyInstanceInSession(resolvedSession)
    }
  }

  private suspend fun createEmptyInstanceInSession(sessionId: String): Result<String> {
    val settings = settingsFlow.first()
    val defaultConfig = resolveDefaultConfig(settings.defaultPresetId)
    val id = UUID.randomUUID().toString().take(8)
    instanceDao.upsert(
      LocalInstanceEntity(
        id = id,
        sessionId = sessionId,
        torrentJson = null,
        configJson = JsonCodecs.encodeConfig(defaultConfig),
        tagsJson = "[]",
        source = InstanceSource.MANUAL.wireName,
        cumulativeUploadedBytes = 0L,
        cumulativeDownloadedBytes = 0L,
        createdAtMs = System.currentTimeMillis(),
        wasActiveBeforeStop = false,
      )
    )
    localEngine.appendLog(LogLevel.INFO, id, "Đã tạo torrent trống #$id trong phiên #$sessionId")
    return Result.success(id)
  }

  suspend fun replaceSessionTorrent(instanceId: String, uri: Uri): Result<TorrentInfo> =
    withContext(Dispatchers.IO) {
      runCatching {
        val bytes =
          context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: error("Không thể đọc tệp .torrent.")
        val name = TorrentImportHelper.queryDisplayName(context, uri) ?: "torrent.torrent"
        val settings = settingsFlow.first()
        if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
          val info =
            serverClient
              .uploadInstanceTorrent(settings.serverUrl, settings.serverToken, instanceId, name, bytes)
              .getOrThrow()
          refreshServerInstances()
          info
        } else {
          val info = BencodeParser.parseTorrent(bytes, name).getOrThrow()
          val existing = instanceDao.getAll().firstOrNull { it.id == instanceId }
            ?: error("Không tìm thấy torrent.")
          instanceDao.upsert(existing.copy(torrentJson = JsonCodecs.encodeTorrent(info)))
          info
        }
      }
    }

  suspend fun updateSessionConfig(instanceId: String, config: FakerConfig): Result<Unit> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      val item = _remoteInstances.value.firstOrNull { it.id == instanceId }
      serverClient
        .updateInstanceConfig(
          settings.serverUrl,
          settings.serverToken,
          instanceId,
          config,
          item?.torrent?.totalSize ?: 0L,
        )
        .also { refreshServerInstances() }
    } else {
      val existing = instanceDao.getAll().firstOrNull { it.id == instanceId }
        ?: return Result.failure(IllegalArgumentException("Không tìm thấy torrent"))
      instanceDao.upsert(existing.copy(configJson = JsonCodecs.encodeConfig(config)))
      localEngine.appendLog(LogLevel.DEBUG, instanceId, "[Torrent $instanceId] Đã lưu cấu hình mới")
      Result.success(Unit)
    }
  }

  suspend fun updateSessionTags(instanceId: String, tags: List<String>): Result<Unit> {
    val clean = tags.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      serverClient.setInstanceTags(settings.serverUrl, settings.serverToken, instanceId, clean)
        .also { refreshServerInstances() }
    } else {
      val existing = instanceDao.getAll().firstOrNull { it.id == instanceId }
        ?: return Result.failure(IllegalArgumentException("Không tìm thấy torrent"))
      instanceDao.upsert(existing.copy(tagsJson = JsonCodecs.encodeTags(clean)))
      Result.success(Unit)
    }
  }

  suspend fun startSession(item: InstanceItem): Result<Unit> {
    val torrent =
      item.torrent
        ?: return Result.failure(IllegalStateException("Vui lòng chọn tệp .torrent trước khi bắt đầu."))
    val settings = settingsFlow.first()
    localEngine.updateProxy(settings.proxy)
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.startFaker(settings.serverUrl, settings.serverToken, item.id, torrent, item.config)
        .also { refreshServerInstances() }
    } else {
      instanceDao.setWasActiveBeforeStop(item.id, true)
      localEngine.start(
        instanceId = item.id,
        torrent = torrent,
        config = item.config,
        baseUploadedBytes = item.stats.uploadedBytes,
        baseDownloadedBytes = item.stats.downloadedBytes,
      )
      RustatioForegroundService.startOrUpdate(
        context = context,
        forceKeepAlive = true,
        activeSessionId = item.sessionId,
      )
      Result.success(Unit)
    }
  }

  suspend fun pauseSession(item: InstanceItem): Result<Unit> {
    val settings = settingsFlow.first()
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.pauseFaker(settings.serverUrl, settings.serverToken, item.id)
        .also { refreshServerInstances() }
    } else {
      instanceDao.setWasActiveBeforeStop(item.id, false)
      localEngine.pause(item.id)
      syncServiceIfNeeded()
      Result.success(Unit)
    }
  }

  suspend fun resumeSession(item: InstanceItem): Result<Unit> {
    val settings = settingsFlow.first()
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.resumeFaker(settings.serverUrl, settings.serverToken, item.id)
        .also { refreshServerInstances() }
    } else {
      instanceDao.setWasActiveBeforeStop(item.id, true)
      localEngine.resume(item.id)
      RustatioForegroundService.startOrUpdate(
        context = context,
        forceKeepAlive = true,
        activeSessionId = item.sessionId,
      )
      Result.success(Unit)
    }
  }

  suspend fun stopSession(item: InstanceItem): Result<Unit> {
    val settings = settingsFlow.first()
    return if (item.isRemote && settings.runMode == RunMode.SERVER) {
      serverClient.stopFaker(settings.serverUrl, settings.serverToken, item.id)
        .also { refreshServerInstances() }
    } else {
      instanceDao.setWasActiveBeforeStop(item.id, false)
      localEngine.stop(item.id)
      syncServiceIfNeeded()
      Result.success(Unit)
    }
  }

  suspend fun deleteTorrents(ids: List<String>): Result<Unit> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      serverClient.gridAction(settings.serverUrl, settings.serverToken, "delete", ids)
        .also { refreshServerInstances() }
    } else {
      ids.forEach {
        instanceDao.setWasActiveBeforeStop(it, false)
        localEngine.stop(it)
      }
      instanceDao.deleteByIds(ids)
      syncServiceIfNeeded()
      Result.success(Unit)
    }
  }

  suspend fun bulkAction(action: String, items: List<InstanceItem>): Result<Unit> {
    val settings = settingsFlow.first()
    val ids = items.map { it.id }
    if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      return serverClient.gridAction(settings.serverUrl, settings.serverToken, action, ids)
        .also { refreshServerInstances() }
    }
    if (action == "stop") staggerStartJob?.cancel()
    items.forEach { item ->
      when (action) {
        "start" -> if (item.torrent != null) startSession(item)
        "pause" -> pauseSession(item)
        "resume" -> resumeSession(item)
        "stop" -> stopSession(item)
      }
    }
    return Result.success(Unit)
  }

  // ---- Notification & Service Recovery Actions ----

  suspend fun pauseAllLocalActive(sessionId: String? = null) {
    val running =
      localInstancesFlow.first().filter {
        it.effectiveState.isActive && (sessionId == null || it.sessionId == sessionId)
      }
    running.forEach { pauseSession(it) }
  }

  suspend fun resumeAllLocalPaused(sessionId: String? = null) {
    val paused =
      localInstancesFlow.first().filter {
        it.effectiveState == FakerState.PAUSED && (sessionId == null || it.sessionId == sessionId)
      }
    paused.forEach { resumeSession(it) }
  }

  suspend fun stopAllLocalActiveOrPaused(
    sessionId: String? = null,
    markRecovered: Boolean = false,
  ) {
    if (sessionId == null) staggerStartJob?.cancel()
    val active =
      localInstancesFlow.first().filter {
        (it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED) &&
          (sessionId == null || it.sessionId == sessionId)
      }
    active.forEach {
      if (!markRecovered) instanceDao.setWasActiveBeforeStop(it.id, false)
      localEngine.stop(it.id)
    }
    syncServiceIfNeeded()
  }

  suspend fun recoverInterruptedInstances() {
    val items = _interruptedInstances.value
    _interruptedInstances.value = emptyList()
    if (items.isEmpty()) return
    items.forEach { item ->
      if (item.torrent != null) startSession(item)
      else instanceDao.setWasActiveBeforeStop(item.id, false)
    }
  }

  suspend fun dismissInterruptedRecovery() {
    _interruptedInstances.value = emptyList()
    instanceDao.clearAllWasActiveBeforeStop()
  }

  private fun syncServiceIfNeeded() {
    val stats = localEngine.statsMap.value.values
    val foregroundCount = stats.count { it.state.isActive || it.state == FakerState.PAUSED }
    if (foregroundCount == 0) {
      RustatioForegroundService.stop(context)
    }
  }

  // ---- Watch folder SAF + Server ----

  suspend fun scanLocalWatchTree(treeUriStr: String, maxDepth: Int): Result<Pair<WatchStatus, List<WatchFileEntry>>> =
    withContext(Dispatchers.IO) {
      runCatching {
        val treeUri = Uri.parse(treeUriStr)
        val existingHashes = collectExistingLocalHashes()
        val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val entries = mutableListOf<WatchFileEntry>()
        val folders = mutableSetOf<String>()

        fun walk(docId: String, relPrefix: String, depth: Int) {
          val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
          val projection =
            arrayOf(
              DocumentsContract.Document.COLUMN_DOCUMENT_ID,
              DocumentsContract.Document.COLUMN_DISPLAY_NAME,
              DocumentsContract.Document.COLUMN_MIME_TYPE,
              DocumentsContract.Document.COLUMN_SIZE,
            )
          context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)
            val sizeIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
            while (cursor.moveToNext()) {
              val childId = cursor.getString(idIdx)
              val childName = cursor.getString(nameIdx) ?: continue
              val mime = cursor.getString(mimeIdx).orEmpty()
              val size = if (sizeIdx >= 0) cursor.getLong(sizeIdx) else 0L
              val relPath = if (relPrefix.isBlank()) childName else "$relPrefix/$childName"
              if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                folders.add(relPath)
                if (maxDepth == 0 || depth < maxDepth) {
                  walk(childId, relPath, depth + 1)
                }
              } else if (childName.endsWith(".torrent", ignoreCase = true)) {
                val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                val parsed =
                  context.contentResolver.openInputStream(docUri)?.use { input ->
                    BencodeParser.parseTorrent(input.readBytes(), childName)
                  }
                val infoHash = parsed?.getOrNull()?.infoHashHex
                val status =
                  when {
                    parsed == null || parsed.isFailure -> WatchFileStatus.INVALID
                    infoHash != null && existingHashes.contains(infoHash.lowercase()) -> WatchFileStatus.LOADED
                    else -> WatchFileStatus.PENDING
                  }
                entries.add(
                  WatchFileEntry(
                    filename = relPath,
                    displayName = childName,
                    sizeBytes = size,
                    status = status,
                    uriString = docUri.toString(),
                    errorMessage = parsed?.exceptionOrNull()?.message,
                    infoHashHex = infoHash,
                  )
                )
              }
            }
          }
        }

        walk(rootDocId, "", 1)

        val displayPath =
          treeUri.lastPathSegment?.substringAfter(':', treeUri.lastPathSegment.orEmpty())
            ?.ifBlank { treeUriStr } ?: treeUriStr
        val status =
          WatchStatus(
            watchDir = displayPath,
            loadedCount = entries.count { it.status == WatchFileStatus.LOADED },
            totalFiles = entries.size,
            pendingCount = entries.count { it.status == WatchFileStatus.PENDING },
            invalidCount = entries.count { it.status == WatchFileStatus.INVALID },
            folderCount = folders.size,
            isWatching = true,
          )
        status to entries.sortedBy { it.filename.lowercase() }
      }
    }

  suspend fun deleteLocalSafWatchFile(uriString: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val deleted = DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(uriString))
        if (!deleted) error("Hệ thống từ chối xóa tệp khỏi thư mục SAF.")
      }
    }

  suspend fun fetchServerWatch() =
    settingsFlow.first().let { s ->
      if (s.serverUrl.isBlank()) Result.failure(IllegalStateException("Chưa cấu hình địa chỉ máy chủ."))
      else serverClient.fetchWatchData(s.serverUrl, s.serverToken)
    }

  suspend fun setServerWatchConfig(config: WatchConfig) =
    settingsFlow.first().let { s -> serverClient.setWatchConfig(s.serverUrl, s.serverToken, config) }

  suspend fun reloadServerWatchFile(path: String) =
    settingsFlow.first().let { s -> serverClient.reloadWatchFile(s.serverUrl, s.serverToken, path) }

  suspend fun reloadAllServerWatch() =
    settingsFlow.first().let { s -> serverClient.reloadAllWatchFiles(s.serverUrl, s.serverToken) }

  suspend fun deleteServerWatchFile(path: String) =
    settingsFlow.first().let { s -> serverClient.deleteWatchFile(s.serverUrl, s.serverToken, path) }

  // ---- Presets & Settings ----

  suspend fun getCustomPresetById(id: String): Preset? =
    withContext(Dispatchers.IO) {
      presetDao.getById(id)?.let { entity ->
        Preset(
          id = entity.id,
          name = entity.name,
          description = entity.description,
          icon = entity.icon,
          recommended = false,
          custom = true,
          createdAt = entity.createdAt,
          config = JsonCodecs.decodePresetConfig(entity.settingsJson),
        )
      }
    }

  suspend fun saveCustomPreset(
    name: String,
    description: String,
    config: FakerConfig,
    icon: String = "star",
  ): Result<Preset> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Vui lòng nhập tên Preset." }
        val cleanDesc = description.trim()
        require(cleanDesc.length <= 200) { "Mô tả Preset không được vượt quá 200 ký tự." }
        val id = "custom-${System.currentTimeMillis()}"
        val nowIso =
          java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", java.util.Locale.US)
            .apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
            .format(java.util.Date())
        val finalDesc = cleanDesc.ifBlank { "Preset tùy chỉnh" }
        val entity =
          CustomPresetEntity(
            id = id,
            name = cleanName,
            description = finalDesc,
            icon = icon.ifBlank { "star" },
            createdAt = nowIso,
            settingsJson = JsonCodecs.encodePresetSettings(config).toString(),
          )
        presetDao.upsert(entity)
        getCustomPresetById(id) ?: error("Không thể đọc lại Preset vừa lưu từ cơ sở dữ liệu.")
      }
    }

  suspend fun updateCustomPreset(
    id: String,
    name: String,
    description: String,
    config: FakerConfig,
    icon: String = "star",
  ): Result<Preset> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Vui lòng nhập tên Preset." }
        val cleanDesc = description.trim()
        require(cleanDesc.length <= 200) { "Mô tả Preset không được vượt quá 200 ký tự." }
        val existing = presetDao.getById(id) ?: error("Không tìm thấy Preset tùy chỉnh để cập nhật.")
        val entity =
          existing.copy(
            name = cleanName,
            description = cleanDesc.ifBlank { "Preset tùy chỉnh" },
            icon = icon.ifBlank { existing.icon.ifBlank { "star" } },
            settingsJson = JsonCodecs.encodePresetSettings(config).toString(),
          )
        presetDao.upsert(entity)
        getCustomPresetById(id) ?: error("Không thể đọc lại Preset sau khi cập nhật.")
      }
    }

  suspend fun applyPresetToInstance(instanceId: String, preset: Preset): Result<InstanceItem> =
    withContext(Dispatchers.IO) {
      runCatching {
        val settings = settingsFlow.first()
        if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
          val current =
            _remoteInstances.value.firstOrNull { it.id == instanceId }
              ?: error("Không tìm thấy torrent trên Server.")
          val merged = preset.config.copy(initialUploadedMB = current.config.initialUploadedMB)
          updateSessionConfig(instanceId, merged).getOrThrow()
          val refreshedList =
            serverClient.listInstances(settings.serverUrl, settings.serverToken).getOrThrow()
          _remoteInstances.value = refreshedList
          refreshedList.firstOrNull { it.id == instanceId }
            ?: error("Không thể xác minh torrent sau khi áp dụng Preset trên Server.")
        } else {
          val existing =
            instanceDao.getAll().firstOrNull { it.id == instanceId }
              ?: error("Không tìm thấy torrent #$instanceId trong cơ sở dữ liệu.")
          val existingConfig = JsonCodecs.decodeConfig(existing.configJson)
          val merged = preset.config.copy(initialUploadedMB = existingConfig.initialUploadedMB)
          updateSessionConfig(instanceId, merged).getOrThrow()
          val reloaded =
            instanceDao.getAll().firstOrNull { it.id == instanceId }
              ?: error("Không thể đọc lại torrent #$instanceId sau khi áp dụng Preset.")
          entityToInstanceItem(reloaded, localEngine.statsMap.value[reloaded.id])
        }
      }
    }

  suspend fun importCustomPreset(jsonText: String): Result<Preset> =
    JsonCodecs.importPresetJson(jsonText).onSuccess { preset ->
      presetDao.upsert(
        CustomPresetEntity(
          id = preset.id,
          name = preset.name,
          description = preset.description,
          icon = preset.icon,
          createdAt = preset.createdAt,
          settingsJson = JsonCodecs.encodePresetSettings(preset.config).toString(),
        )
      )
    }

  suspend fun deleteCustomPreset(id: String) {
    presetDao.deleteById(id)
    val defaultId = settingsFlow.first().defaultPresetId
    if (defaultId == id) preferences.setDefaultPresetId(null)
  }

  suspend fun setThemeMode(mode: ThemeMode) = preferences.setThemeMode(mode)

  suspend fun setRunMode(mode: RunMode) = preferences.setRunMode(mode)

  suspend fun saveServerConnection(url: String, token: String) =
    preferences.setServerConnection(url, token)

  suspend fun testServerConnection(url: String, token: String): Result<Boolean> =
    serverClient.checkServerConnection(url, token)

  suspend fun setLogLevel(level: LogLevel) = preferences.setLogLevel(level)

  suspend fun saveProxySettings(proxy: ProxySettings): Result<Unit> {
    preferences.setProxySettings(proxy)
    localEngine.updateProxy(proxy)
    val settings = settingsFlow.first()
    if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank() && _serverOnline.value) {
      return serverClient.setProxySettings(settings.serverUrl, settings.serverToken, proxy)
    }
    return Result.success(Unit)
  }

  suspend fun testProxyConnection(proxy: ProxySettings): Result<String> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank() && _serverOnline.value) {
      serverClient.testProxyOnServer(settings.serverUrl, settings.serverToken, proxy)
    } else {
      serverClient.testProxyDirect(proxy)
    }
  }

  suspend fun fetchNetworkStatus(): Result<NetworkStatus> {
    val settings = settingsFlow.first()
    val url = if (settings.runMode == RunMode.SERVER) settings.serverUrl else null
    return serverClient.fetchNetworkStatus(url, settings.serverToken, settings.proxy)
  }

  private fun entityToInstanceItem(entity: LocalInstanceEntity, liveStats: FakerStats?): InstanceItem {
    val torrent = JsonCodecs.decodeTorrent(entity.torrentJson)
    val config = JsonCodecs.decodeConfig(entity.configJson)
    val tags = JsonCodecs.decodeTags(entity.tagsJson)
    val stats =
      liveStats
        ?: FakerStats(
          state = FakerState.STOPPED,
          uploadedBytes = entity.cumulativeUploadedBytes,
          downloadedBytes = entity.cumulativeDownloadedBytes,
          ratio =
            if (torrent != null && torrent.totalSize > 0L) {
              entity.cumulativeUploadedBytes.toDouble() / torrent.totalSize
            } else 0.0,
          torrentCompletion = config.completionPercent,
        )
    return InstanceItem(
      id = entity.id,
      sessionId = entity.sessionId,
      torrent = torrent,
      config = config,
      stats = stats,
      tags = tags,
      source = InstanceSource.fromWire(entity.source),
      isRemote = false,
      statusMessage =
        if (torrent == null) "Chưa chọn tệp .torrent"
        else when (stats.state) {
          FakerState.RUNNING -> "Đang giả lập tỷ lệ"
          FakerState.PAUSED -> "Đang tạm dừng"
          FakerState.STARTING -> "Đang kết nối tracker"
          else -> "Sẵn sàng giả lập"
        },
      createdAtMs = entity.createdAtMs,
    )
  }

  private fun buildLocalSessions(
    sessions: List<SessionEntity>,
    instances: List<InstanceItem>,
  ): List<SessionItem> {
    val bySession = instances.groupBy { it.sessionId }.toMutableMap()
    val result = mutableListOf<SessionItem>()
    for (session in sessions) {
      val children = bySession.remove(session.id).orEmpty()
      result.add(
        SessionItem(
          id = session.id,
          name = session.name,
          createdAtMs = session.createdAtMs,
          instances = children,
          isRemoteSession = false,
        )
      )
    }
    // Safety net: any instance pointing to an unknown sessionId still renders in Phiên mặc định
    val leftover = bySession.values.flatten()
    if (leftover.isNotEmpty()) {
      result.add(
        0,
        SessionItem(
          id = InstanceItem.DEFAULT_SESSION_ID,
          name = InstanceItem.DEFAULT_SESSION_NAME,
          createdAtMs = 0L,
          instances = leftover,
          isRemoteSession = false,
        ),
      )
    }
    return result
  }

  private suspend fun collectExistingHashes(targetSessionId: String? = null): Set<String> {
    val settings = settingsFlow.first()
    return if (settings.runMode == RunMode.SERVER && _serverOnline.value) {
      _remoteInstances.value.mapNotNull { it.torrent?.infoHashHex?.lowercase() }.toSet()
    } else {
      collectExistingLocalHashes(targetSessionId)
    }
  }

  private suspend fun collectExistingLocalHashes(targetSessionId: String? = null): Set<String> {
    val entities =
      if (targetSessionId.isNullOrBlank()) instanceDao.getAll()
      else instanceDao.getBySessionId(targetSessionId)
    return entities
      .mapNotNull { JsonCodecs.decodeTorrent(it.torrentJson)?.infoHashHex?.lowercase() }
      .toSet()
  }

  private suspend fun resolveDefaultConfig(defaultPresetId: String?): FakerConfig {
    if (defaultPresetId.isNullOrBlank()) return FakerConfig()
    BuiltInPresets.all.firstOrNull { it.id == defaultPresetId }?.let { return it.config }
    return customPresetsFlow.first().firstOrNull { it.id == defaultPresetId }?.config ?: FakerConfig()
  }
}
