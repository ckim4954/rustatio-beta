package com.example.data.local

import android.content.Context
import androidx.annotation.VisibleForTesting
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.domain.model.InstanceItem

@Database(
  entities = [SessionEntity::class, LocalInstanceEntity::class, CustomPresetEntity::class],
  version = 2,
  exportSchema = false,
)
abstract class RustatioDatabase : RoomDatabase() {
  abstract fun sessionDao(): SessionDao

  abstract fun localInstanceDao(): LocalInstanceDao

  abstract fun customPresetDao(): CustomPresetDao

  companion object {
    @Volatile private var instance: RustatioDatabase? = null

    val MIGRATION_1_2: Migration =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `sessions` (
              `id` TEXT NOT NULL,
              `name` TEXT NOT NULL,
              `createdAtMs` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL(
            "INSERT OR IGNORE INTO `sessions` (`id`, `name`, `createdAtMs`) VALUES (?, ?, ?)",
            arrayOf(
              InstanceItem.DEFAULT_SESSION_ID,
              InstanceItem.DEFAULT_SESSION_NAME,
              System.currentTimeMillis(),
            ),
          )
          db.execSQL(
            "ALTER TABLE `local_instances` ADD COLUMN `sessionId` TEXT NOT NULL DEFAULT '${InstanceItem.DEFAULT_SESSION_ID}'"
          )
          db.execSQL(
            "ALTER TABLE `local_instances` ADD COLUMN `wasActiveBeforeStop` INTEGER NOT NULL DEFAULT 0"
          )
        }
      }

    internal fun buildDatabase(
      context: Context,
      dbName: String = "rustatio_db",
    ): RustatioDatabase =
      Room.databaseBuilder(
          context.applicationContext,
          RustatioDatabase::class.java,
          dbName,
        )
        .addMigrations(MIGRATION_1_2)
        .fallbackToDestructiveMigration(dropAllTables = true)
        .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
        .build()

    fun getInstance(context: Context): RustatioDatabase =
      instance
        ?: synchronized(this) {
          instance ?: buildDatabase(context).also { instance = it }
        }

    @VisibleForTesting
    fun closeAndResetForTests() {
      val prev =
        synchronized(this) {
          val p = instance
          instance = null
          p
        }
      prev?.close()
    }
  }
}
