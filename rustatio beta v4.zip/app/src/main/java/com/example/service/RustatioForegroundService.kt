package com.example.service

import android.app.ForegroundServiceStartNotAllowedException
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.RustatioAppContainer
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.domain.model.LogLevel
import com.example.domain.model.SessionItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class ForegroundSummary(
  val title: String,
  val body: String,
  val bigText: String,
  val hasRunning: Boolean,
  val hasPaused: Boolean,
  val totalForegroundTorrents: Int,
  val activeSessionsCount: Int,
  val controlledSessionId: String?,
  val controlledSessionName: String?,
  val controlledSessionHasRunning: Boolean,
  val controlledSessionHasPaused: Boolean,
)

class RustatioForegroundService : Service() {
  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var observerJob: Job? = null
  @Volatile private var preferredControlledSessionId: String? = null

  override fun onCreate() {
    super.onCreate()
    ensureNotificationChannel(this)
    startObservingSessions()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    ensureNotificationChannel(this)
    val container = RustatioAppContainer.get(applicationContext)
    val targetSessionId = intent?.getStringExtra(EXTRA_SESSION_ID)
    if (!targetSessionId.isNullOrBlank()) {
      preferredControlledSessionId = targetSessionId
    }

    when (intent?.action) {
      ACTION_PAUSE_SESSION, ACTION_PAUSE_ALL -> {
        serviceScope.launch(Dispatchers.IO) {
          container.repository.pauseAllLocalActive(targetSessionId)
        }
      }
      ACTION_RESUME_SESSION, ACTION_RESUME_ALL -> {
        serviceScope.launch(Dispatchers.IO) {
          container.repository.resumeAllLocalPaused(targetSessionId)
        }
      }
      ACTION_STOP_SESSION -> {
        serviceScope.launch(Dispatchers.IO) {
          container.repository.stopAllLocalActiveOrPaused(sessionId = targetSessionId)
        }
      }
      ACTION_STOP_ALL -> {
        serviceScope.launch(Dispatchers.IO) {
          container.repository.stopAllLocalActiveOrPaused(sessionId = null)
          kotlinx.coroutines.withContext(Dispatchers.Main.immediate) {
            stopServiceCleanly()
          }
        }
        return START_NOT_STICKY
      }
    }

    val summary =
      buildForegroundSummary(
        sessions = container.repository.currentLocalSessionSnapshot(),
        preferredSessionId = preferredControlledSessionId,
      )
    promoteToForeground(buildNotification(this, summary))
    if (summary.totalForegroundTorrents == 0 && intent?.action != ACTION_START_KEEPALIVE) {
      stopServiceCleanly()
      return START_NOT_STICKY
    }
    return START_STICKY
  }

  override fun onTimeout(startId: Int, fgsType: Int) {
    val container = RustatioAppContainer.get(applicationContext)
    container.localEngine.appendLog(
      LogLevel.WARN,
      null,
      "Hệ điều hành đã đạt giới hạn thời gian dịch vụ chạy nền dataSync; tạm dừng và lưu trạng thái an toàn.",
    )
    serviceScope.launch {
      container.repository.stopAllLocalActiveOrPaused(sessionId = null, markRecovered = false)
      stopServiceCleanly()
    }
    super.onTimeout(startId, fgsType)
  }

  override fun onDestroy() {
    observerJob?.cancel()
    serviceScope.cancel()
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun startObservingSessions() {
    observerJob?.cancel()
    val container = RustatioAppContainer.get(applicationContext)
    observerJob =
      serviceScope.launch {
        container.repository.localSessionsFlow.collectLatest { sessions ->
          val summary =
            buildForegroundSummary(
              sessions = sessions,
              preferredSessionId = preferredControlledSessionId,
            )
          if (summary.totalForegroundTorrents == 0) {
            stopServiceCleanly()
          } else {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIFICATION_ID, buildNotification(this@RustatioForegroundService, summary))
          }
        }
      }
  }

  private fun promoteToForeground(notification: Notification) {
    try {
      val fgsType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
          0
        }
      ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)
    } catch (_: Throwable) {
      // Handles ForegroundServiceStartNotAllowedException cleanly if OS restricts background start
    }
  }

  private fun stopServiceCleanly() {
    runCatching {
      ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }
    stopSelf()
  }

  companion object {
    const val CHANNEL_ID = "rustatio_background_channel"
    const val NOTIFICATION_ID = 2141
    const val EXTRA_SESSION_ID = "extra_session_id"
    const val EXTRA_OPEN_SESSION_ID = "extra_open_session_id"

    const val ACTION_START_KEEPALIVE = "com.example.action.FGS_KEEPALIVE"
    const val ACTION_PAUSE_ALL = "com.example.action.FGS_PAUSE_ALL"
    const val ACTION_RESUME_ALL = "com.example.action.FGS_RESUME_ALL"
    const val ACTION_STOP_ALL = "com.example.action.FGS_STOP_ALL"
    const val ACTION_PAUSE_SESSION = "com.example.action.FGS_PAUSE_SESSION"
    const val ACTION_RESUME_SESSION = "com.example.action.FGS_RESUME_SESSION"
    const val ACTION_STOP_SESSION = "com.example.action.FGS_STOP_SESSION"

    fun ensureNotificationChannel(context: Context) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
          val channel =
            NotificationChannel(
                CHANNEL_ID,
                "Hoạt động chạy nền Rustatio",
                NotificationManager.IMPORTANCE_LOW,
              )
              .apply {
                description = "Hiển thị trạng thái phiên, tốc độ giả lập và nút điều khiển nhanh."
                setShowBadge(false)
              }
          manager.createNotificationChannel(channel)
        }
      }
    }

    fun startOrUpdate(
      context: Context,
      forceKeepAlive: Boolean = false,
      activeSessionId: String? = null,
    ) {
      val appCtx = context.applicationContext
      ensureNotificationChannel(appCtx)
      val intent =
        Intent(appCtx, RustatioForegroundService::class.java).apply {
          action = if (forceKeepAlive) ACTION_START_KEEPALIVE else null
          if (!activeSessionId.isNullOrBlank()) {
            putExtra(EXTRA_SESSION_ID, activeSessionId)
          }
        }
      try {
        ContextCompat.startForegroundService(appCtx, intent)
      } catch (e: Throwable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
          e is ForegroundServiceStartNotAllowedException
        ) {
          runCatching {
            RustatioAppContainer.get(appCtx).localEngine.appendLog(
              LogLevel.WARN,
              null,
              "Không thể khởi chạy dịch vụ nền khi ứng dụng đang bị hệ thống hạn chế nền.",
            )
          }
        }
      }
    }

    fun stop(context: Context) {
      val appCtx = context.applicationContext
      runCatching {
        appCtx.stopService(Intent(appCtx, RustatioForegroundService::class.java))
      }
    }

    fun buildForegroundSummary(
      sessions: List<SessionItem>,
      preferredSessionId: String? = null,
    ): ForegroundSummary {
      val runningInstances = sessions.flatMap { it.instances }.filter { it.effectiveState.isActive }
      val pausedInstances =
        sessions.flatMap { it.instances }.filter { it.effectiveState == FakerState.PAUSED }
      val total = runningInstances.size + pausedInstances.size

      val activeSessions =
        sessions.filter { s ->
          s.instances.any { it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED }
        }
      val controlled =
        activeSessions.firstOrNull { it.id == preferredSessionId } ?: activeSessions.firstOrNull()

      val upRate = runningInstances.sumOf { it.stats.currentUploadRateKBs }
      val dlRate = runningInstances.sumOf { it.stats.currentDownloadRateKBs }

      val title =
        when {
          activeSessions.size == 1 && controlled != null -> {
            val sRun = controlled.activeCount
            val sPause = controlled.pausedCount
            when {
              sRun > 0 && sPause > 0 -> "${controlled.name} · $sRun chạy, $sPause tạm dừng"
              sRun > 0 -> "${controlled.name} · $sRun torrent đang chạy"
              else -> "${controlled.name} · $sPause torrent tạm dừng"
            }
          }
          activeSessions.size > 1 ->
            "Rustatio · ${activeSessions.size} phiên (${runningInstances.size} chạy, ${pausedInstances.size} tạm dừng)"
          else -> "Rustatio · Sẵn sàng"
        }

      val body =
        when {
          activeSessions.isEmpty() ->
            "Không có phiên chạy nền · ↑ ${Formatters.formatSpeedKBs(upRate)} · ↓ ${Formatters.formatSpeedKBs(dlRate)}"
          activeSessions.size == 1 && controlled != null ->
            "Phiên: ${controlled.name} · ↑ ${Formatters.formatSpeedKBs(upRate)} · ↓ ${Formatters.formatSpeedKBs(dlRate)}"
          else ->
            "Điều khiển: ${controlled?.name ?: "Tất cả"} · ↑ ${Formatters.formatSpeedKBs(upRate)} · ↓ ${Formatters.formatSpeedKBs(dlRate)}"
        }

      val bigText =
        if (activeSessions.size <= 1) {
          body
        } else {
          buildString {
            append("Đang điều khiển: ${controlled?.name ?: "Tất cả"}\n")
            activeSessions.forEachIndexed { idx, s ->
              if (idx > 0) append('\n')
              append("• ${s.name}: ${s.activeCount} chạy, ${s.pausedCount} tạm dừng · ↑ ${Formatters.formatSpeedKBs(s.totalUploadRateKBs)}")
            }
          }
        }

      return ForegroundSummary(
        title = title,
        body = body,
        bigText = bigText,
        hasRunning = runningInstances.isNotEmpty(),
        hasPaused = pausedInstances.isNotEmpty(),
        totalForegroundTorrents = total,
        activeSessionsCount = activeSessions.size,
        controlledSessionId = controlled?.id,
        controlledSessionName = controlled?.name,
        controlledSessionHasRunning = (controlled?.activeCount ?: 0) > 0,
        controlledSessionHasPaused = (controlled?.pausedCount ?: 0) > 0,
      )
    }

    fun buildNotification(context: Context, summary: ForegroundSummary): Notification {
      val openAppIntent =
        Intent(context, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
          if (!summary.controlledSessionId.isNullOrBlank()) {
            putExtra(EXTRA_OPEN_SESSION_ID, summary.controlledSessionId)
          }
        }
      val contentPending =
        PendingIntent.getActivity(
          context,
          summary.controlledSessionId?.hashCode() ?: 0,
          openAppIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

      val builder =
        NotificationCompat.Builder(context, CHANNEL_ID)
          .setSmallIcon(R.mipmap.ic_launcher)
          .setContentTitle(summary.title)
          .setContentText(summary.body)
          .setStyle(NotificationCompat.BigTextStyle().bigText(summary.bigText))
          .setContentIntent(contentPending)
          .setOngoing(summary.totalForegroundTorrents > 0)
          .setOnlyAlertOnce(true)
          .setPriority(NotificationCompat.PRIORITY_LOW)
          .setCategory(NotificationCompat.CATEGORY_SERVICE)
          .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

      val targetId = summary.controlledSessionId
      val targetLabel =
        if (summary.activeSessionsCount > 1 && !summary.controlledSessionName.isNullOrBlank()) {
          " (${summary.controlledSessionName})"
        } else {
          ""
        }

      if (summary.controlledSessionHasRunning || (targetId == null && summary.hasRunning)) {
        builder.addAction(
          0,
          "Tạm dừng$targetLabel",
          actionPendingIntent(
            context = context,
            actionName = if (targetId != null) ACTION_PAUSE_SESSION else ACTION_PAUSE_ALL,
            sessionId = targetId,
            requestCode = 1,
          ),
        )
      }
      if (summary.controlledSessionHasPaused || (targetId == null && summary.hasPaused)) {
        builder.addAction(
          0,
          "Tiếp tục$targetLabel",
          actionPendingIntent(
            context = context,
            actionName = if (targetId != null) ACTION_RESUME_SESSION else ACTION_RESUME_ALL,
            sessionId = targetId,
            requestCode = 2,
          ),
        )
      }
      if (summary.hasRunning || summary.hasPaused) {
        builder.addAction(
          0,
          if (summary.activeSessionsCount > 1) "Dừng tất cả" else "Dừng",
          actionPendingIntent(
            context = context,
            actionName = ACTION_STOP_ALL,
            sessionId = null,
            requestCode = 3,
          ),
        )
      }
      return builder.build()
    }

    private fun actionPendingIntent(
      context: Context,
      actionName: String,
      sessionId: String?,
      requestCode: Int,
    ): PendingIntent {
      val intent =
        Intent(context, RustatioForegroundService::class.java).apply {
          action = actionName
          if (!sessionId.isNullOrBlank()) {
            putExtra(EXTRA_SESSION_ID, sessionId)
          }
        }
      return PendingIntent.getService(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    }
  }
}
