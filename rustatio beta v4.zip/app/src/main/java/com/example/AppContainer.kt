package com.example

import android.content.Context
import androidx.annotation.VisibleForTesting
import com.example.data.engine.LocalFakerEngine
import com.example.data.local.AppPreferences
import com.example.data.local.RustatioDatabase
import com.example.data.remote.RustatioServerClient
import com.example.data.repository.RustatioRepository

class RustatioAppContainer private constructor(context: Context) {
  private val appContext = context.applicationContext

  val preferences: AppPreferences by lazy { AppPreferences(appContext) }
  val database: RustatioDatabase by lazy { RustatioDatabase.getInstance(appContext) }
  val serverClient: RustatioServerClient by lazy { RustatioServerClient() }
  val localEngine: LocalFakerEngine by lazy { LocalFakerEngine(serverClient) }
  val repository: RustatioRepository by lazy {
    RustatioRepository(
      context = appContext,
      preferences = preferences,
      database = database,
      serverClient = serverClient,
      localEngine = localEngine,
    )
  }

  companion object {
    @Volatile private var instance: RustatioAppContainer? = null

    fun get(context: Context): RustatioAppContainer =
      instance
        ?: synchronized(this) {
          instance ?: RustatioAppContainer(context).also { instance = it }
        }

    @VisibleForTesting
    fun resetForTests() {
      val prev =
        synchronized(this) {
          val p = instance
          instance = null
          p
        }
      prev?.repository?.shutdownForTests()
      prev?.localEngine?.shutdownForTests()
      RustatioDatabase.closeAndResetForTests()
    }
  }
}
