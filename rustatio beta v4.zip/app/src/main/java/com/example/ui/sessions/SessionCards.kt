package com.example.ui.sessions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.Formatters
import com.example.domain.model.SessionItem
import com.example.ui.components.StatusBadge
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

/**
 * Thẻ hiển thị một Phiên trên Màn hình danh sách phiên (Màn hình 1).
 * Chỉ hiển thị thông tin cấp Phiên (tên, số torrent, trạng thái tổng quan, thống kê tổng hợp)
 * và thao tác quản lý phiên (mở chi tiết, đổi tên, xóa phiên).
 * Không chứa danh sách torrent hay điều khiển từng torrent.
 */
@Composable
fun SessionCard(
  session: SessionItem,
  onClick: () -> Unit,
  onRenameSession: () -> Unit,
  onDeleteSession: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  var menuExpanded by remember { mutableStateOf(false) }

  Card(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .clickable(onClick = onClick)
        .testTag("session_card_${session.id}"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = colors.surface),
    border =
      BorderStroke(
        width = 1.dp,
        color = if (session.activeCount > 0) colors.primary.copy(alpha = 0.65f) else colors.border,
      ),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = colors.primaryContainer,
          modifier = Modifier.size(42.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.Rounded.Folder,
              contentDescription = null,
              tint = colors.primary,
            )
          }
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = session.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text =
              if (session.totalTorrents == 0) "Chưa có torrent nào"
              else "${session.totalTorrents} torrent · ${session.activeCount} chạy · ${session.pausedCount} tạm dừng · ${session.stoppedCount} dừng",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        StatusBadge(state = session.aggregateState, isIdling = false)

        if (!session.isRemoteSession) {
          Box {
            IconButton(
              onClick = { menuExpanded = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_menu_${session.id}"),
            ) {
              Icon(Icons.Rounded.MoreVert, contentDescription = "Tùy chọn phiên")
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = null) },
                text = { Text("Đổi tên phiên") },
                onClick = {
                  menuExpanded = false
                  onRenameSession()
                },
                modifier = Modifier.testTag("session_menu_rename_${session.id}"),
              )
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = colors.error) },
                text = { Text("Xóa phiên", color = colors.error) },
                onClick = {
                  menuExpanded = false
                  onDeleteSession()
                },
                modifier = Modifier.testTag("session_menu_delete_${session.id}"),
              )
            }
          }
        }
      }

      HorizontalDivider(color = colors.border.copy(alpha = 0.55f))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            text =
              "↑ ${Formatters.formatSpeedKBs(session.totalUploadRateKBs)} · ↓ ${Formatters.formatSpeedKBs(session.totalDownloadRateKBs)}",
            style = MonoMetricSmall,
            color = if (session.activeCount > 0) colors.upload else colors.textSecondary,
          )
          Text(
            text =
              "Tổng đã truyền: ↑ ${Formatters.formatBytes(session.totalUploadedBytes)} · ↓ ${Formatters.formatBytes(session.totalDownloadedBytes)}",
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Chi tiết",
            style = MaterialTheme.typography.labelMedium,
            color = colors.primary,
          )
          Spacer(Modifier.width(2.dp))
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
            contentDescription = "Mở chi tiết phiên ${session.name}",
            tint = colors.primary,
          )
        }
      }
    }
  }
}
