package com.example.ui.sessions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.Formatters
import com.example.domain.model.RunMode
import com.example.ui.theme.MonoMetricLarge
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionsTopBar(
  state: SessionsUiState,
  onRefreshServer: () -> Unit,
  onOpenFilters: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  TopAppBar(
    colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
    title = {
      Column {
        Text(
          text = "Phiên",
          style = MaterialTheme.typography.headlineMedium,
          color = colors.textPrimary,
        )
        Text(
          text =
            if (state.runMode == RunMode.SERVER) {
              if (state.serverOnline) {
                "Rustatio Server · Đã kết nối (${state.totalTorrentsCount} torrent)"
              } else {
                "Rustatio Server · Ngoại tuyến"
              }
            } else {
              "${state.totalSessionsCount} phiên · ${state.totalTorrentsCount} torrent · ↑ ${Formatters.formatSpeedKBs(state.totalUploadRateKBs)}"
            },
          style = MaterialTheme.typography.bodySmall,
          color =
            if (state.runMode == RunMode.SERVER && !state.serverOnline) colors.warning
            else colors.textSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    },
    actions = {
      if (state.runMode == RunMode.SERVER) {
        IconButton(
          onClick = onRefreshServer,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("sessions_refresh_button"),
        ) {
          Icon(Icons.Rounded.Refresh, contentDescription = "Làm mới máy chủ")
        }
      }
      IconButton(
        onClick = onOpenFilters,
        modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("sessions_filter_button"),
      ) {
        BadgedBox(
          badge = {
            if (state.activeFilterCount > 0) {
              Badge { Text(state.activeFilterCount.toString()) }
            }
          }
        ) {
          Icon(Icons.Rounded.FilterList, contentDescription = "Bộ lọc phiên")
        }
      }
    },
  )
}

@Composable
fun SessionsRecoveryBanner(
  count: Int,
  onDismiss: () -> Unit,
  onRestore: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    modifier = Modifier.fillMaxWidth().testTag("sessions_recovery_banner"),
    shape = RoundedCornerShape(14.dp),
    color = colors.download.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, colors.download.copy(alpha = 0.4f)),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Text(
        text = "Phát hiện $count torrent từng chạy khi ứng dụng bị hệ thống đóng. Bạn có muốn khôi phục?",
        style = MaterialTheme.typography.bodyMedium,
        color = colors.textPrimary,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
      ) {
        TextButton(
          onClick = onDismiss,
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("recovery_dismiss_btn"),
        ) {
          Text("Bỏ qua")
        }
        Spacer(Modifier.width(8.dp))
        Button(
          onClick = onRestore,
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("recovery_restore_btn"),
        ) {
          Text("Khôi phục chạy")
        }
      }
    }
  }
}

@Composable
fun SessionsSummaryPillRow(
  state: SessionsUiState,
  onSelectFilter: (SessionStatusFilter) -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    SummaryPillCard(
      label = "Tổng phiên",
      count = state.totalSessionsCount,
      selected = state.statusFilter == SessionStatusFilter.ALL,
      accent = colors.primary,
      onClick = { onSelectFilter(SessionStatusFilter.ALL) },
      testTag = "summary_all",
    )
    SummaryPillCard(
      label = "Đang chạy",
      count = state.runningSessionsCount,
      selected = state.statusFilter == SessionStatusFilter.RUNNING,
      accent = colors.upload,
      onClick = { onSelectFilter(SessionStatusFilter.RUNNING) },
      testTag = "summary_running",
    )
    SummaryPillCard(
      label = "Tạm dừng",
      count = state.pausedSessionsCount,
      selected = state.statusFilter == SessionStatusFilter.PAUSED,
      accent = colors.warning,
      onClick = { onSelectFilter(SessionStatusFilter.PAUSED) },
      testTag = "summary_paused",
    )
    SummaryPillCard(
      label = "Đã dừng",
      count = state.stoppedSessionsCount,
      selected = state.statusFilter == SessionStatusFilter.STOPPED,
      accent = colors.textSecondary,
      onClick = { onSelectFilter(SessionStatusFilter.STOPPED) },
      testTag = "summary_stopped",
    )
  }
}

@Composable
private fun SummaryPillCard(
  label: String,
  count: Int,
  selected: Boolean,
  accent: Color,
  onClick: () -> Unit,
  testTag: String,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(14.dp),
    color = if (selected) accent.copy(alpha = 0.16f) else colors.surface,
    border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) accent else colors.border),
    modifier = Modifier.defaultMinSize(minWidth = 88.dp, minHeight = 48.dp).testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = if (selected) accent else colors.textSecondary,
      )
      Text(
        text = count.toString(),
        style = MonoMetricLarge,
        color = colors.textPrimary,
      )
    }
  }
}
