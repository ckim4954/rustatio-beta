package com.example.ui.sessions

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.RunMode
import com.example.domain.model.SessionItem
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioLoadingSkeleton
import com.example.ui.theme.RustatioThemeTokens

@Composable
fun SessionsScreen(
  viewModel: SessionsViewModel,
  onOpenSessionDetail: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val context = LocalContext.current

  var showCreateSessionDialog by remember { mutableStateOf(false) }
  var renameTargetSession by remember { mutableStateOf<SessionItem?>(null) }
  var showFilterSheet by remember { mutableStateOf(false) }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      viewModel.onNotificationPermissionResult(granted)
    }

  fun requestNotificationPermissionIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      SessionsTopBar(
        state = state,
        onRefreshServer = { viewModel.refreshServer() },
        onOpenFilters = { showFilterSheet = true },
      )
    },
    floatingActionButton = {
      // Chỉ hiển thị 1 nút "Thêm phiên" duy nhất: khi đã có phiên thì dùng FAB, khi trống dùng Empty State.
      if (!state.isLoading && state.sessions.isNotEmpty() && !(state.runMode == RunMode.SERVER && state.serverOnline)) {
        ExtendedFloatingActionButton(
          onClick = { showCreateSessionDialog = true },
          containerColor = colors.primary,
          contentColor = Color.White,
          icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
          text = { Text("Thêm phiên") },
          modifier = Modifier.testTag("sessions_add_fab"),
        )
      }
    },
  ) { innerPadding ->
    BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      val isTablet = maxWidth >= 600.dp

      Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (state.runMode == RunMode.SERVER && !state.serverOnline) {
          RustatioBanner(
            type = BannerType.OFFLINE,
            message =
              state.serverError?.let { "Không kết nối được Rustatio Server ($it). Đang hiển thị phiên cục bộ." }
                ?: "Chưa kết nối máy chủ — đang hiển thị dữ liệu cục bộ.",
            actionLabel = "Thử lại",
            onAction = { viewModel.refreshServer() },
          )
        }

        if (state.interruptedRecoveryCount > 0) {
          SessionsRecoveryBanner(
            count = state.interruptedRecoveryCount,
            onDismiss = { viewModel.dismissInterrupted() },
            onRestore = {
              requestNotificationPermissionIfNeeded()
              viewModel.recoverInterrupted()
            },
          )
        }

        if (state.showNotificationPermissionBanner) {
          RustatioBanner(
            type = BannerType.INFO,
            message =
              "Quyền thông báo đang tắt — giả lập vẫn chạy bình thường nhưng thông báo điều khiển nhanh sẽ không hiển thị.",
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        state.actionMessage?.let { msg ->
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        state.errorMessage?.let { err ->
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        if (state.sessions.isNotEmpty()) {
          SessionsSummaryPillRow(
            state = state,
            onSelectFilter = viewModel::setStatusFilter,
          )

          OutlinedTextField(
            value = state.searchQuery,
            onValueChange = viewModel::setSearchQuery,
            modifier = Modifier.fillMaxWidth().testTag("sessions_search_input"),
            placeholder = { Text("Tìm kiếm theo tên phiên…") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
              if (state.searchQuery.isNotEmpty()) {
                IconButton(onClick = { viewModel.setSearchQuery("") }) {
                  Icon(Icons.Rounded.Close, contentDescription = "Xóa từ khóa")
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
          )
        }

        val renderSessionCard: @Composable (SessionItem) -> Unit = { session ->
          SessionCard(
            session = session,
            onClick = { onOpenSessionDetail(session.id) },
            onRenameSession = { renameTargetSession = session },
            onDeleteSession = { viewModel.requestDeleteSession(session) },
          )
        }

        when {
          state.isLoading -> {
            Box(
              modifier = Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())
            ) {
              RustatioLoadingSkeleton(cardCount = 3)
            }
          }
          state.sessions.isEmpty() -> {
            Box(
              modifier =
                Modifier.weight(1f)
                  .fillMaxWidth()
                  .verticalScroll(rememberScrollState())
                  .padding(bottom = 24.dp)
            ) {
              RustatioEmptyState(
                icon = Icons.Rounded.CreateNewFolder,
                title = "Chưa có phiên nào",
                description =
                  "Nhấn \"Thêm phiên\" để tạo một phiên mới, sau đó mở phiên để thêm và quản lý các torrent.",
                primaryActionLabel = "Thêm phiên",
                onPrimaryAction = { showCreateSessionDialog = true },
                actionTestTag = "sessions_add_empty_btn",
              )
            }
          }
          state.filteredSessions.isEmpty() -> {
            Box(
              modifier =
                Modifier.weight(1f)
                  .fillMaxWidth()
                  .verticalScroll(rememberScrollState())
                  .padding(bottom = 24.dp)
            ) {
              RustatioEmptyState(
                icon = Icons.Rounded.Search,
                title = "Không tìm thấy phiên phù hợp",
                description = "Thử thay đổi từ khóa tìm kiếm hoặc đặt lại bộ lọc trạng thái.",
                primaryActionLabel = "Đặt lại bộ lọc",
                onPrimaryAction = { viewModel.clearAllFilters() },
                actionTestTag = "sessions_empty_reset_filter",
              )
            }
          }
          isTablet -> {
            LazyVerticalGrid(
              columns = GridCells.Fixed(2),
              verticalArrangement = Arrangement.spacedBy(12.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(bottom = 96.dp),
              modifier = Modifier.weight(1f).fillMaxWidth().testTag("sessions_list"),
            ) {
              items(state.filteredSessions, key = { it.id }) { renderSessionCard(it) }
              item(span = { GridItemSpan(2) }) { Spacer(Modifier.height(4.dp)) }
            }
          }
          else -> {
            LazyColumn(
              verticalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(bottom = 96.dp),
              modifier = Modifier.weight(1f).fillMaxWidth().testTag("sessions_list"),
            ) {
              items(state.filteredSessions, key = { it.id }) { renderSessionCard(it) }
            }
          }
        }
      }
    }
  }

  CreateSessionDialog(
    visible = showCreateSessionDialog,
    onConfirm = { name ->
      showCreateSessionDialog = false
      viewModel.createSession(name = name, onCreated = onOpenSessionDetail)
    },
    onDismiss = { showCreateSessionDialog = false },
  )

  RenameSessionDialog(
    sessionName = renameTargetSession?.name,
    onConfirm = { newName ->
      val target = renameTargetSession
      renameTargetSession = null
      if (target != null) viewModel.renameSession(target.id, newName)
    },
    onDismiss = { renameTargetSession = null },
  )

  SessionsFilterSheet(
    visible = showFilterSheet,
    statusFilter = state.statusFilter,
    onStatusFilter = viewModel::setStatusFilter,
    onReset = viewModel::clearAllFilters,
    onDismiss = { showFilterSheet = false },
  )

  val pendingDelete = state.pendingDeleteSession
  RustatioConfirmDialog(
    visible = pendingDelete != null,
    title = "Xác nhận xóa phiên",
    message =
      if ((pendingDelete?.totalTorrents ?: 0) > 0) {
        "Bạn có chắc muốn xóa phiên \"${pendingDelete?.name}\" cùng toàn bộ ${pendingDelete?.totalTorrents} torrent bên trong?"
      } else {
        "Bạn có chắc muốn xóa phiên trống \"${pendingDelete?.name}\"?"
      },
    confirmLabel = "Xóa phiên",
    isDestructive = true,
    onConfirm = { viewModel.confirmDeleteSession() },
    onDismiss = { viewModel.dismissDeleteSession() },
  )
}
