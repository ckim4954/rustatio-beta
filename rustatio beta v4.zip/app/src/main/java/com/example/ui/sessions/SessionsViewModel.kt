package com.example.ui.sessions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppSettingsSnapshot
import com.example.data.repository.RustatioRepository
import com.example.domain.model.FakerState
import com.example.domain.model.RunMode
import com.example.domain.model.SessionItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SessionStatusFilter(val id: String, val labelVi: String) {
  ALL("all", "Tất cả"),
  RUNNING("running", "Đang chạy"),
  PAUSED("paused", "Tạm dừng"),
  STOPPED("stopped", "Đã dừng"),
}

data class SessionsUiState(
  val isLoading: Boolean = true,
  val runMode: RunMode = RunMode.LOCAL,
  val serverOnline: Boolean = false,
  val serverError: String? = null,
  val sessions: List<SessionItem> = emptyList(),
  val filteredSessions: List<SessionItem> = emptyList(),
  val totalSessionsCount: Int = 0,
  val totalTorrentsCount: Int = 0,
  val runningSessionsCount: Int = 0,
  val pausedSessionsCount: Int = 0,
  val stoppedSessionsCount: Int = 0,
  val totalUploadRateKBs: Double = 0.0,
  val totalDownloadRateKBs: Double = 0.0,
  val searchQuery: String = "",
  val statusFilter: SessionStatusFilter = SessionStatusFilter.ALL,
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingDeleteSession: SessionItem? = null,
  val interruptedRecoveryCount: Int = 0,
  val showNotificationPermissionBanner: Boolean = false,
) {
  val activeFilterCount: Int
    get() = if (statusFilter != SessionStatusFilter.ALL) 1 else 0
}

private data class SessionsLocalControls(
  val searchQuery: String = "",
  val statusFilter: SessionStatusFilter = SessionStatusFilter.ALL,
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingDeleteSession: SessionItem? = null,
  val notificationDeniedNotice: Boolean = false,
)

class SessionsViewModel(
  private val repository: RustatioRepository,
) : ViewModel() {

  private val controls = MutableStateFlow(SessionsLocalControls())

  private val baseStream =
    combine(
      repository.sessionsFlow,
      repository.settingsFlow,
      repository.serverOnline,
      repository.serverError,
    ) { sessions, settings, online, serverErr ->
      Quad(sessions, settings, online, serverErr)
    }

  val uiState: StateFlow<SessionsUiState> =
    combine(
      baseStream,
      repository.interruptedInstances,
      controls,
    ) { (sessions, settings, online, serverErr), interrupted, ctrl ->
      val query = ctrl.searchQuery.trim().lowercase()

      val filteredSessions =
        sessions.filter { session ->
          val matchesQuery =
            query.isEmpty() || session.name.lowercase().contains(query)

          val matchesStatus =
            when (ctrl.statusFilter) {
              SessionStatusFilter.ALL -> true
              SessionStatusFilter.RUNNING -> session.aggregateState.isActive
              SessionStatusFilter.PAUSED -> session.aggregateState == FakerState.PAUSED
              SessionStatusFilter.STOPPED ->
                session.aggregateState == FakerState.STOPPED || session.aggregateState == FakerState.IDLE
            }

          matchesQuery && matchesStatus
        }

      SessionsUiState(
        isLoading = false,
        runMode = settings.runMode,
        serverOnline = online,
        serverError = serverErr,
        sessions = sessions,
        filteredSessions = filteredSessions,
        totalSessionsCount = sessions.size,
        totalTorrentsCount = sessions.sumOf { it.totalTorrents },
        runningSessionsCount = sessions.count { it.aggregateState.isActive },
        pausedSessionsCount = sessions.count { it.aggregateState == FakerState.PAUSED },
        stoppedSessionsCount =
          sessions.count {
            it.aggregateState == FakerState.STOPPED || it.aggregateState == FakerState.IDLE
          },
        totalUploadRateKBs = sessions.sumOf { it.totalUploadRateKBs },
        totalDownloadRateKBs = sessions.sumOf { it.totalDownloadRateKBs },
        searchQuery = ctrl.searchQuery,
        statusFilter = ctrl.statusFilter,
        isBusy = ctrl.isBusy,
        actionMessage = ctrl.actionMessage,
        errorMessage = ctrl.errorMessage,
        pendingDeleteSession = ctrl.pendingDeleteSession,
        interruptedRecoveryCount = interrupted.size,
        showNotificationPermissionBanner = ctrl.notificationDeniedNotice,
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000L),
      initialValue = SessionsUiState(isLoading = true),
    )

  init {
    viewModelScope.launch {
      repository.settingsFlow.collect { settings: AppSettingsSnapshot ->
        if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank()) {
          repository.refreshServerInstances()
        }
      }
    }
  }

  fun setSearchQuery(q: String) {
    controls.update { it.copy(searchQuery = q) }
  }

  fun setStatusFilter(filter: SessionStatusFilter) {
    controls.update { it.copy(statusFilter = filter) }
  }

  fun clearAllFilters() {
    controls.update { it.copy(searchQuery = "", statusFilter = SessionStatusFilter.ALL) }
  }

  fun refreshServer() {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .refreshServerInstances()
        .onSuccess {
          controls.update {
            it.copy(isBusy = false, actionMessage = "Đã đồng bộ dữ liệu từ Rustatio Server")
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể kết nối máy chủ")
          }
        }
    }
  }

  fun createSession(name: String, onCreated: (String) -> Unit) {
    val cleanName = name.trim().ifBlank { "Phiên mới" }
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .createSession(cleanName)
        .onSuccess { sessionId ->
          controls.update {
            it.copy(isBusy = false, actionMessage = "Đã tạo phiên \"$cleanName\"")
          }
          onCreated(sessionId)
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể tạo phiên mới")
          }
        }
    }
  }

  fun renameSession(sessionId: String, newName: String) {
    viewModelScope.launch {
      repository
        .renameSession(sessionId, newName)
        .onSuccess {
          controls.update { it.copy(actionMessage = "Đã đổi tên phiên thành \"${newName.trim()}\"") }
        }
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể đổi tên phiên") }
        }
    }
  }

  fun requestDeleteSession(session: SessionItem) {
    controls.update { it.copy(pendingDeleteSession = session) }
  }

  fun dismissDeleteSession() {
    controls.update { it.copy(pendingDeleteSession = null) }
  }

  fun confirmDeleteSession() {
    val target = controls.value.pendingDeleteSession ?: return
    controls.update { it.copy(pendingDeleteSession = null, isBusy = true, errorMessage = null) }
    viewModelScope.launch {
      repository
        .deleteSession(target.id)
        .onSuccess {
          controls.update {
            it.copy(isBusy = false, actionMessage = "Đã xóa phiên \"${target.name}\"")
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể xóa phiên")
          }
        }
    }
  }

  fun recoverInterrupted() {
    viewModelScope.launch {
      repository.recoverInterruptedInstances()
      controls.update { it.copy(actionMessage = "Đã khôi phục các torrent đang chạy trước đó") }
    }
  }

  fun dismissInterrupted() {
    viewModelScope.launch {
      repository.dismissInterruptedRecovery()
    }
  }

  fun onNotificationPermissionResult(granted: Boolean) {
    controls.update { it.copy(notificationDeniedNotice = !granted) }
  }

  fun dismissMessages() {
    controls.update {
      it.copy(actionMessage = null, errorMessage = null, notificationDeniedNotice = false)
    }
  }

  private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

  companion object {
    fun factory(repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          SessionsViewModel(repository) as T
      }
  }
}
