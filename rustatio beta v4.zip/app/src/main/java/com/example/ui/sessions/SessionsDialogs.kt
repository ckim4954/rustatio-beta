package com.example.ui.sessions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties

@Composable
fun CreateSessionDialog(
  visible: Boolean,
  onConfirm: (name: String) -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  var nameInput by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
    modifier = Modifier.padding(horizontal = 24.dp).widthIn(min = 280.dp, max = 520.dp),
    title = { Text("Thêm phiên mới") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          "Tạo một phiên trống để chứa và quản lý nhiều torrent độc lập.",
          style = MaterialTheme.typography.bodySmall,
        )
        OutlinedTextField(
          value = nameInput,
          onValueChange = { nameInput = it },
          label = { Text("Tên phiên") },
          placeholder = { Text("Ví dụ: Phiên Seed Đêm") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("create_session_name_input"),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(nameInput.trim().ifBlank { "Phiên mới" }) },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("create_session_confirm_btn"),
      ) {
        Text("Tạo phiên")
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.defaultMinSize(minHeight = 48.dp),
      ) {
        Text("Hủy")
      }
    },
  )
}

@Composable
fun RenameSessionDialog(
  sessionName: String?,
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  if (sessionName == null) return
  var nameInput by remember(sessionName) { mutableStateOf(sessionName) }
  AlertDialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
    modifier = Modifier.padding(horizontal = 24.dp).widthIn(min = 280.dp, max = 520.dp),
    title = { Text("Đổi tên phiên") },
    text = {
      OutlinedTextField(
        value = nameInput,
        onValueChange = { nameInput = it },
        label = { Text("Tên phiên mới *") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("rename_session_input"),
      )
    },
    confirmButton = {
      Button(
        onClick = { if (nameInput.isNotBlank()) onConfirm(nameInput.trim()) },
        enabled = nameInput.isNotBlank(),
        modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("rename_session_confirm_btn"),
      ) {
        Text("Lưu")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.defaultMinSize(minHeight = 48.dp)) {
        Text("Hủy")
      }
    },
  )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SessionsFilterSheet(
  visible: Boolean,
  statusFilter: SessionStatusFilter,
  onStatusFilter: (SessionStatusFilter) -> Unit,
  onReset: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Bộ lọc phiên", style = MaterialTheme.typography.titleLarge)
        TextButton(
          onClick = {
            onReset()
            onDismiss()
          }
        ) {
          Text("Đặt lại")
        }
      }
      Text("Trạng thái tổng quan", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SessionStatusFilter.entries.forEach { f ->
          FilterChip(
            selected = statusFilter == f,
            onClick = { onStatusFilter(f) },
            label = { Text(f.labelVi) },
            modifier = Modifier.defaultMinSize(minHeight = 48.dp),
          )
        }
      }
      Button(
        onClick = onDismiss,
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
      ) {
        Text("Áp dụng")
      }
      Spacer(Modifier.height(12.dp))
    }
  }
}
