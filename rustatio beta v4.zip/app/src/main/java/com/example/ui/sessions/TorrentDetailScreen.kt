package com.example.ui.sessions

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Label
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.ui.components.BannerType
import com.example.ui.components.ExpandableTorrentTitle
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioLoadingSkeleton
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens
import kotlin.math.roundToInt

/**
 * Màn hình 3 — Chi tiết torrent.
 * Mở khi chọn một torrent từ Màn hình chi tiết phiên (Màn hình 2).
 * Không đặt nút Import / Chọn tệp .torrent tại màn hình này.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TorrentDetailScreen(
  viewModel: TorrentDetailViewModel,
  onNavigateBack: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val context = LocalContext.current

  var showTagsDialog by remember { mutableStateOf(false) }
  var showDeleteConfirm by remember { mutableStateOf(false) }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      viewModel.onNotificationPermissionResult(granted)
    }

  fun requestNotificationPermissionIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  BackHandler(enabled = state.hasUnsavedChanges) {
    viewModel.requestBackNavigation(onNavigateBack)
  }

  val tabTitles =
    listOf(
      "Tổng quan",
      "Cấu hình",
      "Điều kiện dừng",
      "Thống kê",
      "Hiệu suất",
      "Nhật ký",
    )

  Scaffold(
    modifier = modifier.fillMaxSize().imePadding(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
        navigationIcon = {
          IconButton(
            onClick = { viewModel.requestBackNavigation(onNavigateBack) },
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("detail_back_button"),
          ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Quay lại chi tiết phiên")
          }
        },
        title = {
          Text(
            text = "Chi tiết torrent",
            style = MaterialTheme.typography.titleLarge,
            color = colors.textPrimary,
          )
        },
        actions = {
          if (state.hasUnsavedChanges) {
            TextButton(
              onClick = { viewModel.saveConfig() },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("detail_top_save"),
            ) {
              Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(4.dp))
              Text("Lưu")
            }
          }
          state.instance?.let {
            IconButton(
              onClick = { showTagsDialog = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("detail_tags_button"),
            ) {
              Icon(Icons.AutoMirrored.Rounded.Label, contentDescription = "Gắn thẻ torrent")
            }
            IconButton(
              onClick = { showDeleteConfirm = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("detail_delete_button"),
            ) {
              Icon(Icons.Rounded.Delete, contentDescription = "Xóa torrent", tint = colors.error)
            }
          }
        },
      )
    },
    bottomBar = {
      val item = state.instance
      if (item != null) {
        Surface(
          color = colors.surface,
          tonalElevation = 2.dp,
          shadowElevation = 6.dp,
          modifier = Modifier.fillMaxWidth().navigationBarsPadding(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            when (item.effectiveState) {
              FakerState.RUNNING, FakerState.STARTING -> {
                OutlinedButton(
                  onClick = { viewModel.pause() },
                  modifier = Modifier.weight(1f).defaultMinSize(minHeight = 50.dp).testTag("detail_pause_btn"),
                ) {
                  Icon(Icons.Rounded.Pause, contentDescription = null)
                  Spacer(Modifier.width(6.dp))
                  Text("Tạm dừng")
                }
                Button(
                  onClick = { viewModel.stop() },
                  colors = ButtonDefaults.buttonColors(containerColor = colors.error),
                  modifier = Modifier.weight(1f).defaultMinSize(minHeight = 50.dp).testTag("detail_stop_btn"),
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = null)
                  Spacer(Modifier.width(6.dp))
                  Text("Dừng")
                }
              }
              FakerState.PAUSED -> {
                Button(
                  onClick = {
                    requestNotificationPermissionIfNeeded()
                    viewModel.resume()
                  },
                  modifier = Modifier.weight(1f).defaultMinSize(minHeight = 50.dp).testTag("detail_resume_btn"),
                ) {
                  Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                  Spacer(Modifier.width(6.dp))
                  Text("Tiếp tục")
                }
                OutlinedButton(
                  onClick = { viewModel.stop() },
                  modifier = Modifier.weight(1f).defaultMinSize(minHeight = 50.dp).testTag("detail_stop_btn"),
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = null, tint = colors.error)
                  Spacer(Modifier.width(6.dp))
                  Text("Dừng", color = colors.error)
                }
              }
              else -> {
                Button(
                  onClick = {
                    requestNotificationPermissionIfNeeded()
                    viewModel.start()
                  },
                  enabled = item.torrent != null,
                  modifier = Modifier.weight(1f).defaultMinSize(minHeight = 50.dp).testTag("detail_start_btn"),
                ) {
                  Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                  Spacer(Modifier.width(6.dp))
                  Text(if (item.torrent == null) "Thiếu dữ liệu .torrent" else "Bắt đầu giả lập")
                }
              }
            }
          }
        }
      }
    },
  ) { innerPadding ->
    val item = state.instance
    when {
      state.isLoading -> {
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
          RustatioLoadingSkeleton(cardCount = 3)
        }
      }
      item == null -> {
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
          RustatioEmptyState(
            icon = Icons.Rounded.FolderOpen,
            title = "Không tìm thấy torrent",
            description = "Torrent này có thể đã bị xóa hoặc tự động gỡ bỏ sau khi đạt điều kiện dừng.",
            primaryActionLabel = "Quay lại chi tiết phiên",
            onPrimaryAction = onNavigateBack,
          )
        }
      }
      else -> {
        Column(
          modifier = Modifier.fillMaxSize().padding(innerPadding),
        ) {
          Column(
            modifier = Modifier.padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            if (state.showNotificationPermissionBanner) {
              RustatioBanner(
                type = BannerType.INFO,
                message =
                  "Quyền thông báo đang tắt — giả lập vẫn chạy bình thường nhưng thông báo điều khiển nhanh sẽ không hiển thị.",
                actionLabel = "Đóng",
                onAction = { viewModel.dismissMessages() },
              )
            }
            state.actionMessage?.let { msg ->
              RustatioBanner(
                type = BannerType.SUCCESS,
                message = msg,
                actionLabel = "Đóng",
                onAction = { viewModel.dismissMessages() },
              )
            }
            state.errorMessage?.let { err ->
              RustatioBanner(
                type = BannerType.ERROR,
                message = err,
                actionLabel = "Đóng",
                onAction = { viewModel.dismissMessages() },
              )
            }

            RustatioSectionCard {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
              ) {
                ExpandableTorrentTitle(
                  title = item.displayName,
                  subtitle =
                    if (item.torrent != null) {
                      "${Formatters.formatBytes(item.torrent.totalSize)} · ${item.torrent.fileCount} tệp · ${item.torrent.primaryTrackerHost}"
                    } else {
                      "Chưa có dữ liệu tệp .torrent"
                    },
                  modifier = Modifier.weight(1f).padding(end = 8.dp),
                )
                StatusBadge(state = item.effectiveState, isIdling = item.stats.isIdling)
              }

              item.torrent?.let { torrent ->
                Text(
                  text = "Info Hash: ${torrent.infoHashHex}",
                  style = MonoMetricSmall,
                  color = colors.textSecondary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.padding(top = 6.dp).testTag("torrent_detail_info_hash"),
                )
              }

              Text(
                text =
                  "Hoàn thành: ${item.stats.torrentCompletion.roundToInt()}% · Tỷ lệ: ${Formatters.formatRatio(item.stats.ratio)} · ↑ ${Formatters.formatSpeedKBs(item.stats.currentUploadRateKBs)} · ↓ ${Formatters.formatSpeedKBs(item.stats.currentDownloadRateKBs)}",
                style = MonoMetricSmall,
                color = colors.primary,
                modifier = Modifier.padding(top = 4.dp),
              )

              if (item.tags.isNotEmpty()) {
                FlowRow(
                  modifier = Modifier.padding(top = 6.dp),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  item.tags.forEach { tag ->
                    Surface(
                      shape = MaterialTheme.shapes.small,
                      color = colors.primaryContainer,
                    ) {
                      Text(
                        text = "#$tag",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                      )
                    }
                  }
                }
              }
            }
          }

          ScrollableTabRow(
            selectedTabIndex = state.selectedTabIndex,
            containerColor = colors.background,
            contentColor = colors.primary,
            edgePadding = 16.dp,
            modifier = Modifier.padding(top = 8.dp),
          ) {
            tabTitles.forEachIndexed { idx, title ->
              Box(
                modifier = Modifier.testTag("detail_tab_$idx"),
                propagateMinConstraints = true,
              ) {
                Tab(
                  selected = state.selectedTabIndex == idx,
                  onClick = { viewModel.setTab(idx) },
                  text = { Text(title, maxLines = 1) },
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp),
                )
              }
            }
          }

          Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (state.selectedTabIndex) {
              0 -> SessionOverviewTab(item = item, state = state, viewModel = viewModel)
              1 -> SessionConfigTab(item = item, state = state, viewModel = viewModel)
              2 -> SessionStopConditionsTab(item = item, state = state, viewModel = viewModel)
              3 -> SessionStatsTab(item = item)
              4 -> SessionPerformanceTab(item = item)
              5 -> SessionLogsTab(state = state, viewModel = viewModel)
            }
          }
        }
      }
    }
  }

  if (state.showUnsavedDialog) {
    AlertDialog(
      onDismissRequest = { viewModel.dismissUnsavedDialog() },
      properties = DialogProperties(usePlatformDefaultWidth = false),
      modifier = Modifier.padding(horizontal = 24.dp).widthIn(min = 280.dp, max = 520.dp),
      title = { Text("Thay đổi chưa được lưu") },
      text = {
        Text("Bạn đang có thay đổi cấu hình chưa lưu. Bạn muốn lưu trước khi quay lại hay bỏ các thay đổi này?")
      },
      confirmButton = {
        Button(
          onClick = { viewModel.saveConfig(onSaved = onNavigateBack) },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("unsaved_save_exit"),
        ) {
          Text("Lưu & Thoát")
        }
      },
      dismissButton = {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          TextButton(
            onClick = {
              viewModel.discardChanges()
              onNavigateBack()
            },
            modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("unsaved_discard"),
          ) {
            Text("Bỏ thay đổi", color = colors.error)
          }
          TextButton(
            onClick = { viewModel.dismissUnsavedDialog() },
            modifier = Modifier.defaultMinSize(minHeight = 48.dp),
          ) {
            Text("Ở lại")
          }
        }
      },
    )
  }

  if (showTagsDialog && state.instance != null) {
    var tagInput by remember(state.instance) {
      mutableStateOf(state.instance?.tags?.joinToString(", ").orEmpty())
    }
    AlertDialog(
      onDismissRequest = { showTagsDialog = false },
      properties = DialogProperties(usePlatformDefaultWidth = false),
      modifier = Modifier.padding(horizontal = 24.dp).widthIn(min = 280.dp, max = 520.dp),
      title = { Text("Quản lý thẻ torrent") },
      text = {
        OutlinedTextField(
          value = tagInput,
          onValueChange = { tagInput = it },
          label = { Text("Thẻ (cách nhau bằng dấu phẩy)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val tags = tagInput.split(",").map { it.trim() }.filter { it.isNotEmpty() }.distinct()
            viewModel.updateTags(tags)
            showTagsDialog = false
          },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Lưu thẻ")
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showTagsDialog = false },
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text("Hủy")
        }
      },
    )
  }

  RustatioConfirmDialog(
    visible = showDeleteConfirm && state.instance != null,
    title = "Xác nhận xóa torrent",
    message =
      "Bạn có chắc muốn xóa torrent \"${state.instance?.displayName}\" khỏi phiên hiện tại? Phiên và các torrent khác vẫn được giữ nguyên.",
    confirmLabel = "Xóa torrent",
    isDestructive = true,
    onConfirm = {
      showDeleteConfirm = false
      viewModel.deleteTorrent(onDeleted = onNavigateBack)
    },
    onDismiss = { showDeleteConfirm = false },
  )
}
