package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudOff
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.ui.theme.MonoMetricMedium
import com.example.ui.theme.RustatioThemeTokens

enum class BannerType {
  INFO,
  OFFLINE,
  WARNING,
  ERROR,
  SUCCESS,
}

@Composable
fun RustatioSectionCard(
  modifier: Modifier = Modifier,
  onClick: (() -> Unit)? = null,
  highlighted: Boolean = false,
  content: @Composable ColumnScope.() -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  val borderColor = if (highlighted) colors.primary else colors.border
  val container = if (highlighted) colors.surfaceElevated else colors.surface
  Card(
    modifier =
      modifier.fillMaxWidth().let { base ->
        if (onClick != null) base.clickable(onClick = onClick) else base
      },
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = container),
    border = BorderStroke(if (highlighted) 1.5.dp else 1.dp, borderColor),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
  ) {
    Column(modifier = Modifier.padding(16.dp), content = content)
  }
}

@Composable
fun RustatioSectionHeader(
  title: String,
  modifier: Modifier = Modifier,
  trailing: (@Composable () -> Unit)? = null,
) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier = modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = title.uppercase(),
      style = MaterialTheme.typography.labelSmall,
      color = colors.textSecondary,
      fontWeight = FontWeight.SemiBold,
    )
    if (trailing != null) trailing()
  }
}

@Composable
fun StatusBadge(
  state: FakerState,
  modifier: Modifier = Modifier,
  isIdling: Boolean = false,
) {
  val colors = RustatioThemeTokens.colors
  val (dotColor, bgColor, label) =
    when {
      state == FakerState.RUNNING && isIdling ->
        Triple(colors.warning, colors.warning.copy(alpha = 0.14f), "Đang chờ peer")
      state == FakerState.RUNNING ->
        Triple(colors.upload, colors.upload.copy(alpha = 0.15f), Formatters.stateLabelVi(state))
      state == FakerState.PAUSED ->
        Triple(colors.warning, colors.warning.copy(alpha = 0.15f), Formatters.stateLabelVi(state))
      state == FakerState.STARTING || state == FakerState.STOPPING ->
        Triple(colors.download, colors.download.copy(alpha = 0.15f), Formatters.stateLabelVi(state))
      state == FakerState.IDLE ->
        Triple(colors.primary, colors.primary.copy(alpha = 0.15f), Formatters.stateLabelVi(state))
      else ->
        Triple(colors.textSecondary, colors.surfaceElevated, Formatters.stateLabelVi(state))
    }

  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(999.dp),
    color = bgColor,
    border = BorderStroke(1.dp, dotColor.copy(alpha = 0.35f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(dotColor))
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = dotColor,
        maxLines = 1,
      )
    }
  }
}

@Composable
fun MetricTile(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
  accentColor: Color? = null,
) {
  val colors = RustatioThemeTokens.colors
  Column(
    modifier =
      modifier
        .clip(RoundedCornerShape(12.dp))
        .background(colors.surfaceSubtle)
        .padding(horizontal = 12.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = colors.textSecondary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
    Text(
      text = value,
      style = MonoMetricMedium,
      color = accentColor ?: colors.textPrimary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun ExpandableTorrentTitle(
  title: String,
  modifier: Modifier = Modifier,
  subtitle: String? = null,
) {
  val colors = RustatioThemeTokens.colors
  var expanded by remember(title) { mutableStateOf(false) }
  Column(
    modifier =
      modifier.animateContentSize().clickable { expanded = !expanded },
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleMedium,
      color = colors.textPrimary,
      maxLines = if (expanded) 8 else 2,
      overflow = TextOverflow.Ellipsis,
    )
    if (!subtitle.isNullOrBlank()) {
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodySmall,
        color = colors.textSecondary,
        maxLines = if (expanded) 4 else 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
fun RustatioBanner(
  type: BannerType,
  message: String,
  modifier: Modifier = Modifier,
  actionLabel: String? = null,
  onAction: (() -> Unit)? = null,
) {
  val colors = RustatioThemeTokens.colors
  val (accent, icon) =
    when (type) {
      BannerType.INFO -> colors.download to Icons.Rounded.Info
      BannerType.OFFLINE -> colors.warning to Icons.Rounded.CloudOff
      BannerType.WARNING -> colors.warning to Icons.Rounded.WarningAmber
      BannerType.ERROR -> colors.error to Icons.Rounded.ErrorOutline
      BannerType.SUCCESS -> colors.upload to Icons.Rounded.CheckCircle
    }

  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(14.dp),
    color = accent.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, accent.copy(alpha = 0.4f)),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = accent,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = colors.textPrimary,
        modifier = Modifier.weight(1f),
      )
      if (!actionLabel.isNullOrBlank() && onAction != null) {
        TextButton(
          onClick = onAction,
          modifier = Modifier.defaultMinSize(minHeight = 48.dp),
        ) {
          Text(actionLabel, color = accent, fontWeight = FontWeight.SemiBold)
        }
      }
    }
  }
}

@Composable
fun RustatioLoadingSkeleton(
  modifier: Modifier = Modifier,
  cardCount: Int = 3,
) {
  val colors = RustatioThemeTokens.colors
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    repeat(cardCount) {
      RustatioSectionCard {
        Box(
          modifier =
            Modifier.fillMaxWidth(0.65f)
              .height(16.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(colors.surfaceElevated)
        )
        Spacer(modifier = Modifier.height(10.dp))
        Box(
          modifier =
            Modifier.fillMaxWidth(0.45f)
              .height(12.dp)
              .clip(RoundedCornerShape(6.dp))
              .background(colors.surfaceSubtle)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Box(
            modifier =
              Modifier.weight(1f)
                .height(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(colors.surfaceSubtle)
          )
          Box(
            modifier =
              Modifier.weight(1f)
                .height(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(colors.surfaceSubtle)
          )
        }
      }
    }
  }
}

@Composable
fun RustatioEmptyState(
  icon: ImageVector,
  title: String,
  description: String,
  modifier: Modifier = Modifier,
  primaryActionLabel: String? = null,
  onPrimaryAction: (() -> Unit)? = null,
  actionTestTag: String = "empty_primary_action",
) {
  val colors = RustatioThemeTokens.colors
  RustatioSectionCard(modifier = modifier) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Surface(
        shape = CircleShape,
        color = colors.primaryContainer,
        modifier = Modifier.size(56.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = colors.primary,
            modifier = Modifier.size(28.dp),
          )
        }
      }
      Text(
        text = title,
        style = MaterialTheme.typography.titleMedium,
        color = colors.textPrimary,
      )
      Text(
        text = description,
        style = MaterialTheme.typography.bodyMedium,
        color = colors.textSecondary,
      )
      if (!primaryActionLabel.isNullOrBlank() && onPrimaryAction != null) {
        Spacer(modifier = Modifier.height(4.dp))
        Button(
          onClick = onPrimaryAction,
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag(actionTestTag),
        ) {
          Text(primaryActionLabel)
        }
      }
    }
  }
}

@Composable
fun RustatioSavingButton(
  label: String,
  savingLabel: String,
  isSaving: Boolean,
  enabled: Boolean = true,
  modifier: Modifier = Modifier,
  testTag: String = "saving_button",
  onClick: () -> Unit,
) {
  Button(
    onClick = onClick,
    enabled = enabled && !isSaving,
    modifier = modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag(testTag),
  ) {
    if (isSaving) {
      CircularProgressIndicator(
        modifier = Modifier.size(18.dp),
        strokeWidth = 2.dp,
        color = MaterialTheme.colorScheme.onPrimary,
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(savingLabel)
    } else {
      Text(label)
    }
  }
}

@Composable
fun RustatioConfirmDialog(
  visible: Boolean,
  title: String,
  message: String,
  confirmLabel: String,
  cancelLabel: String = "Hủy",
  isDestructive: Boolean = false,
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  val colors = RustatioThemeTokens.colors
  AlertDialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
    modifier = Modifier.padding(horizontal = 24.dp).widthIn(min = 280.dp, max = 520.dp),
    title = { Text(title, style = MaterialTheme.typography.titleLarge) },
    text = { Text(message, style = MaterialTheme.typography.bodyMedium) },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors =
          if (isDestructive) {
            ButtonDefaults.buttonColors(
              containerColor = colors.error,
              contentColor = Color.White,
            )
          } else {
            ButtonDefaults.buttonColors()
          },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("dialog_confirm_button"),
      ) {
        Text(confirmLabel)
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("dialog_cancel_button"),
      ) {
        Text(cancelLabel)
      }
    },
  )
}
