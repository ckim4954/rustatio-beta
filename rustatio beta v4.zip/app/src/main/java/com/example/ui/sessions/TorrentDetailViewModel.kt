package com.example.ui.sessions

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RustatioRepository
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.InstanceItem
import com.example.domain.model.LogEntry
import com.example.domain.model.LogLevel
import com.example.domain.model.Preset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ConfigValidationErrors(
  val uploadRateError: String? = null,
  val downloadRateError: String? = null,
  val portError: String? = null,
  val completionError: String? = null,
  val intervalError: String? = null,
  val ratioTargetError: String? = null,
) {
  val hasErrors: Boolean
    get() =
      listOf(
        uploadRateError,
        downloadRateError,
        portError,
        completionError,
        intervalError,
        ratioTargetError,
      ).any { it != null }
}

data class TorrentDetailUiState(
  val isLoading: Boolean = true,
  val instance: InstanceItem? = null,
  val draftConfig: FakerConfig = FakerConfig(),
  val hasUnsavedChanges: Boolean = false,
  val validationErrors: ConfigValidationErrors = ConfigValidationErrors(),
  val selectedTabIndex: Int = 0,
  val selectedLogLevel: LogLevel = LogLevel.INFO,
  val logs: List<LogEntry> = emptyList(),
  val presets: List<Preset> = BuiltInPresets.all,
  val isSaving: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val showUnsavedDialog: Boolean = false,
  val showNotificationPermissionBanner: Boolean = false,
)

private data class TorrentDetailLocalState(
  val draftConfig: FakerConfig? = null,
  val selectedTabIndex: Int = 0,
  val selectedLogLevel: LogLevel = LogLevel.INFO,
  val isSaving: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val showUnsavedDialog: Boolean = false,
  val notificationDeniedNotice: Boolean = false,
)

class TorrentDetailViewModel(
  private val instanceId: String,
  private val repository: RustatioRepository,
) : ViewModel() {

  private val localState = MutableStateFlow(TorrentDetailLocalState())

  val uiState: StateFlow<TorrentDetailUiState> =
    combine(
      repository.instancesFlow,
      repository.logsFlow,
      repository.customPresetsFlow,
      localState,
    ) { instances, allLogs, customPresets, local ->
      val instance = instances.firstOrNull { it.id == instanceId }
      val saved = instance?.config ?: FakerConfig()
      val draft = local.draftConfig ?: saved
      val unsaved = local.draftConfig != null && local.draftConfig != saved
      val filteredLogs =
        allLogs.filter { entry ->
          (entry.instanceId == null || entry.instanceId == instanceId) &&
            entry.level.priority <= local.selectedLogLevel.priority
        }
      TorrentDetailUiState(
        isLoading = false,
        instance = instance,
        draftConfig = draft,
        hasUnsavedChanges = unsaved,
        validationErrors = validateConfig(draft),
        selectedTabIndex = local.selectedTabIndex,
        selectedLogLevel = local.selectedLogLevel,
        logs = filteredLogs.asReversed(),
        presets = BuiltInPresets.all + customPresets,
        isSaving = local.isSaving,
        actionMessage = local.actionMessage,
        errorMessage = local.errorMessage,
        showUnsavedDialog = local.showUnsavedDialog,
        showNotificationPermissionBanner = local.notificationDeniedNotice,
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000L),
      initialValue = TorrentDetailUiState(isLoading = true),
    )

  fun setTab(index: Int) {
    localState.update { it.copy(selectedTabIndex = index) }
  }

  fun setLogLevel(level: LogLevel) {
    localState.update { it.copy(selectedLogLevel = level) }
  }

  fun updateDraft(transform: (FakerConfig) -> FakerConfig) {
    val current = uiState.value.draftConfig
    localState.update {
      it.copy(draftConfig = transform(current), actionMessage = null, errorMessage = null)
    }
  }

  fun selectClient(clientType: ClientType) {
    updateDraft { cfg ->
      cfg.copy(
        clientType = clientType,
        clientVersion = clientType.defaultVersion,
        port = if (cfg.port == cfg.clientType.defaultPort) clientType.defaultPort else cfg.port,
      )
    }
  }

  fun applyPreset(preset: Preset) {
    val currentInitialUp = uiState.value.draftConfig.initialUploadedMB
    localState.update {
      it.copy(
        draftConfig = preset.config.copy(initialUploadedMB = currentInitialUp),
        actionMessage = "Đã nạp cấu hình từ preset '${preset.name}'. Nhấn Lưu để áp dụng.",
      )
    }
  }

  fun saveConfig(onSaved: (() -> Unit)? = null) {
    val draft = uiState.value.draftConfig
    val validation = validateConfig(draft)
    if (validation.hasErrors) {
      localState.update {
        it.copy(errorMessage = "Vui lòng kiểm tra lại các giá trị cấu hình chưa hợp lệ.")
      }
      return
    }
    viewModelScope.launch {
      localState.update { it.copy(isSaving = true, errorMessage = null, actionMessage = null) }
      repository
        .updateSessionConfig(instanceId, draft)
        .onSuccess {
          localState.update {
            it.copy(
              isSaving = false,
              draftConfig = null,
              showUnsavedDialog = false,
              actionMessage = "Đã lưu cấu hình torrent thành công",
            )
          }
          onSaved?.invoke()
        }
        .onFailure { err ->
          localState.update {
            it.copy(
              isSaving = false,
              errorMessage = err.message ?: "Không thể lưu cấu hình",
            )
          }
        }
    }
  }

  fun discardChanges() {
    localState.update { it.copy(draftConfig = null, showUnsavedDialog = false) }
  }

  fun requestBackNavigation(onCanLeave: () -> Unit) {
    if (uiState.value.hasUnsavedChanges) {
      localState.update { it.copy(showUnsavedDialog = true) }
    } else {
      onCanLeave()
    }
  }

  fun dismissUnsavedDialog() {
    localState.update { it.copy(showUnsavedDialog = false) }
  }

  fun start() {
    val item = uiState.value.instance ?: return
    val currentItem = item.copy(config = uiState.value.draftConfig)
    viewModelScope.launch {
      if (uiState.value.hasUnsavedChanges) {
        repository.updateSessionConfig(instanceId, uiState.value.draftConfig)
        localState.update { it.copy(draftConfig = null) }
      }
      repository
        .startSession(currentItem)
        .onFailure { err -> localState.update { it.copy(errorMessage = err.message) } }
    }
  }

  fun pause() {
    val item = uiState.value.instance ?: return
    viewModelScope.launch {
      repository.pauseSession(item).onFailure { err ->
        localState.update { it.copy(errorMessage = err.message) }
      }
    }
  }

  fun resume() {
    val item = uiState.value.instance ?: return
    viewModelScope.launch {
      repository.resumeSession(item).onFailure { err ->
        localState.update { it.copy(errorMessage = err.message) }
      }
    }
  }

  fun stop() {
    val item = uiState.value.instance ?: return
    viewModelScope.launch {
      repository.stopSession(item).onFailure { err ->
        localState.update { it.copy(errorMessage = err.message) }
      }
    }
  }

  fun deleteTorrent(onDeleted: () -> Unit) {
    viewModelScope.launch {
      localState.update { it.copy(isSaving = true, errorMessage = null) }
      repository
        .deleteTorrents(listOf(instanceId))
        .onSuccess {
          localState.update { it.copy(isSaving = false) }
          onDeleted()
        }
        .onFailure { err ->
          localState.update { it.copy(isSaving = false, errorMessage = err.message ?: "Không thể xóa torrent") }
        }
    }
  }

  fun updateTags(tags: List<String>) {
    viewModelScope.launch {
      repository
        .updateSessionTags(instanceId, tags)
        .onSuccess { localState.update { it.copy(actionMessage = "Đã cập nhật thẻ torrent") } }
        .onFailure { err -> localState.update { it.copy(errorMessage = err.message) } }
    }
  }

  fun clearLogs() {
    repository.localEngine.clearLogs()
  }

  fun onNotificationPermissionResult(granted: Boolean) {
    localState.update { it.copy(notificationDeniedNotice = !granted) }
  }

  fun dismissMessages() {
    localState.update {
      it.copy(actionMessage = null, errorMessage = null, notificationDeniedNotice = false)
    }
  }

  private fun validateConfig(c: FakerConfig): ConfigValidationErrors {
    return ConfigValidationErrors(
      uploadRateError =
        if (c.uploadRateKBs < 0.0 || c.uploadRateKBs > 1_000_000.0) "Tốc độ tải lên phải từ 0 đến 1,000,000 KB/s"
        else null,
      downloadRateError =
        if (c.downloadRateKBs < 0.0 || c.downloadRateKBs > 1_000_000.0) "Tốc độ tải xuống phải từ 0 đến 1,000,000 KB/s"
        else null,
      portError =
        if (c.port !in 1..65535) "Cổng phải nằm trong khoảng 1–65535" else null,
      completionError =
        if (c.completionPercent < 0.0 || c.completionPercent > 100.0) "Hoàn thành phải từ 0% đến 100%"
        else null,
      intervalError =
        if (c.updateIntervalSeconds < 1 || c.scrapeIntervalSeconds < 10)
          "Chu kỳ cập nhật ≥ 1s và Scrape ≥ 10s"
        else null,
      ratioTargetError =
        if (c.stopAtRatioEnabled && c.stopAtRatio <= 0.0) "Tỷ lệ mục tiêu phải lớn hơn 0"
        else null,
    )
  }

  companion object {
    fun factory(instanceId: String, repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          TorrentDetailViewModel(instanceId, repository) as T
      }
  }
}
