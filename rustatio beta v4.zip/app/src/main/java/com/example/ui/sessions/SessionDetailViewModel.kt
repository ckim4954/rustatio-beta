package com.example.ui.sessions

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.repository.RustatioRepository
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.ImportMode
import com.example.domain.model.InstanceItem
import com.example.domain.model.InstanceSource
import com.example.domain.model.PendingImportFile
import com.example.domain.model.Preset
import com.example.domain.model.RunMode
import com.example.domain.model.SessionItem
import com.example.domain.model.TorrentImportOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ImportDialogState(
  val files: List<PendingImportFile>,
  val options: TorrentImportOptions,
  val tagsText: String = "",
  val uploadRateText: String = "50",
  val downloadRateText: String = "0",
  val portText: String = "6881",
  val updateIntervalText: String = "5",
  val scrapeIntervalText: String = "60",
  val customPercentText: String = "100",
  val staggerSecondsText: String = "0",
  val validationError: String? = null,
) {
  val validCount: Int get() = files.count { it.isValidNew }
  val duplicateCount: Int get() = files.count { it.isDuplicate }
  val invalidCount: Int get() = files.count { it.error != null }
}

sealed interface SessionDetailConfirmAction {
  val title: String
  val message: String
  val confirmLabel: String
  val isDestructive: Boolean

  data class DeleteSession(
    val sessionId: String,
    val sessionName: String,
    val torrentCount: Int,
  ) : SessionDetailConfirmAction {
    override val title: String = "Xác nhận xóa phiên"
    override val message: String =
      if (torrentCount > 0) {
        "Bạn có chắc muốn xóa phiên \"$sessionName\" cùng toàn bộ $torrentCount torrent bên trong?"
      } else {
        "Bạn có chắc muốn xóa phiên trống \"$sessionName\"?"
      }
    override val confirmLabel: String = "Xóa phiên"
    override val isDestructive: Boolean = true
  }

  data class DeleteTorrent(
    val instance: InstanceItem,
  ) : SessionDetailConfirmAction {
    override val title: String = "Xác nhận xóa torrent"
    override val message: String =
      "Bạn có chắc muốn xóa torrent \"${instance.displayName}\" khỏi phiên này? Phiên và các torrent khác vẫn được giữ nguyên."
    override val confirmLabel: String = "Xóa torrent"
    override val isDestructive: Boolean = true
  }

  data class StopAllInSession(
    val sessionName: String,
    val affectedCount: Int,
  ) : SessionDetailConfirmAction {
    override val title: String = "Dừng tất cả torrent trong phiên"
    override val message: String =
      "Dừng $affectedCount torrent đang chạy hoặc tạm dừng trong phiên \"$sessionName\"?"
    override val confirmLabel: String = "Dừng tất cả"
    override val isDestructive: Boolean = true
  }
}

data class SessionDetailUiState(
  val isLoading: Boolean = true,
  val session: SessionItem? = null,
  val runMode: RunMode = RunMode.LOCAL,
  val serverOnline: Boolean = false,
  val presets: List<Preset> = BuiltInPresets.all,
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val importDialog: ImportDialogState? = null,
  val pendingConfirm: SessionDetailConfirmAction? = null,
  val showNotificationPermissionBanner: Boolean = false,
)

private data class SessionDetailLocalControls(
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val importDialog: ImportDialogState? = null,
  val pendingConfirm: SessionDetailConfirmAction? = null,
  val notificationDeniedNotice: Boolean = false,
)

class SessionDetailViewModel(
  private val sessionId: String,
  private val repository: RustatioRepository,
) : ViewModel() {

  private val controls = MutableStateFlow(SessionDetailLocalControls())

  val uiState: StateFlow<SessionDetailUiState> =
    combine(
      repository.sessionFlow(sessionId),
      repository.settingsFlow,
      repository.serverOnline,
      repository.customPresetsFlow,
      controls,
    ) { session, settings, online, customPresets, ctrl ->
      SessionDetailUiState(
        isLoading = false,
        session = session,
        runMode = settings.runMode,
        serverOnline = online,
        presets = BuiltInPresets.all + customPresets,
        isBusy = ctrl.isBusy,
        actionMessage = ctrl.actionMessage,
        errorMessage = ctrl.errorMessage,
        importDialog = ctrl.importDialog,
        pendingConfirm = ctrl.pendingConfirm,
        showNotificationPermissionBanner = ctrl.notificationDeniedNotice,
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000L),
      initialValue = SessionDetailUiState(isLoading = true),
    )

  fun refreshServer() {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .refreshServerInstances()
        .onSuccess {
          controls.update { it.copy(isBusy = false, actionMessage = "Đã làm mới danh sách torrent") }
        }
        .onFailure { err ->
          controls.update { it.copy(isBusy = false, errorMessage = err.message ?: "Không thể kết nối máy chủ") }
        }
    }
  }

  fun renameSession(newName: String) {
    viewModelScope.launch {
      repository
        .renameSession(sessionId, newName)
        .onSuccess {
          controls.update { it.copy(actionMessage = "Đã đổi tên phiên thành \"${newName.trim()}\"") }
        }
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể đổi tên phiên") }
        }
    }
  }

  fun requestDeleteSession() {
    val session = uiState.value.session ?: return
    controls.update {
      it.copy(
        pendingConfirm =
          SessionDetailConfirmAction.DeleteSession(
            sessionId = session.id,
            sessionName = session.name,
            torrentCount = session.totalTorrents,
          )
      )
    }
  }

  fun requestDeleteTorrent(item: InstanceItem) {
    controls.update {
      it.copy(pendingConfirm = SessionDetailConfirmAction.DeleteTorrent(item))
    }
  }

  fun requestSessionBatchAction(action: String) {
    val session = uiState.value.session ?: return
    val affected =
      when (action) {
        "start" ->
          session.instances.count {
            !it.effectiveState.isActive && it.effectiveState != FakerState.PAUSED && it.torrent != null
          }
        "pause" -> session.instances.count { it.effectiveState.isActive }
        "resume" -> session.instances.count { it.effectiveState == FakerState.PAUSED }
        "stop" ->
          session.instances.count {
            it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED
          }
        else -> 0
      }
    if (affected == 0) {
      controls.update {
        it.copy(errorMessage = "Không có torrent nào trong phiên phù hợp với thao tác này.")
      }
      return
    }
    if (action == "stop") {
      controls.update {
        it.copy(
          pendingConfirm =
            SessionDetailConfirmAction.StopAllInSession(
              sessionName = session.name,
              affectedCount = affected,
            )
        )
      }
    } else {
      executeSessionBatchAction(action)
    }
  }

  private fun executeSessionBatchAction(action: String) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .sessionAction(sessionId, action)
        .onSuccess { count ->
          val verb =
            when (action) {
              "start" -> "bắt đầu"
              "pause" -> "tạm dừng"
              "resume" -> "tiếp tục"
              "stop" -> "dừng"
              else -> "cập nhật"
            }
          controls.update {
            it.copy(isBusy = false, actionMessage = "Đã $verb $count torrent trong phiên")
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isBusy = false, errorMessage = err.message) }
        }
    }
  }

  fun dismissPendingConfirm() {
    controls.update { it.copy(pendingConfirm = null) }
  }

  fun confirmPendingAction(onSessionDeleted: () -> Unit) {
    val pending = controls.value.pendingConfirm ?: return
    controls.update { it.copy(pendingConfirm = null) }
    when (pending) {
      is SessionDetailConfirmAction.DeleteSession -> {
        viewModelScope.launch {
          controls.update { it.copy(isBusy = true, errorMessage = null) }
          repository
            .deleteSession(pending.sessionId)
            .onSuccess {
              controls.update { it.copy(isBusy = false) }
              onSessionDeleted()
            }
            .onFailure { err ->
              controls.update { it.copy(isBusy = false, errorMessage = err.message) }
            }
        }
      }
      is SessionDetailConfirmAction.DeleteTorrent -> {
        viewModelScope.launch {
          controls.update { it.copy(isBusy = true, errorMessage = null) }
          repository
            .deleteTorrents(listOf(pending.instance.id))
            .onSuccess {
              controls.update {
                it.copy(
                  isBusy = false,
                  actionMessage = "Đã xóa torrent \"${pending.instance.displayName}\" khỏi phiên",
                )
              }
            }
            .onFailure { err ->
              controls.update { it.copy(isBusy = false, errorMessage = err.message) }
            }
        }
      }
      is SessionDetailConfirmAction.StopAllInSession -> {
        executeSessionBatchAction("stop")
      }
    }
  }

  // ---- Per-Torrent Controls ----

  fun startTorrent(item: InstanceItem) {
    viewModelScope.launch {
      repository.startSession(item).onFailure { err ->
        controls.update { it.copy(errorMessage = err.message ?: "Không thể bắt đầu torrent") }
      }
    }
  }

  fun pauseTorrent(item: InstanceItem) {
    viewModelScope.launch {
      repository.pauseSession(item).onFailure { err ->
        controls.update { it.copy(errorMessage = err.message ?: "Không thể tạm dừng torrent") }
      }
    }
  }

  fun resumeTorrent(item: InstanceItem) {
    viewModelScope.launch {
      repository.resumeSession(item).onFailure { err ->
        controls.update { it.copy(errorMessage = err.message ?: "Không thể tiếp tục torrent") }
      }
    }
  }

  fun stopTorrent(item: InstanceItem) {
    viewModelScope.launch {
      repository.stopSession(item).onFailure { err ->
        controls.update { it.copy(errorMessage = err.message ?: "Không thể dừng torrent") }
      }
    }
  }

  // ---- Import Torrent into THIS Session ----

  fun onImportFilesPicked(uris: List<Uri>) {
    if (uris.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .previewTorrentUris(uris, targetSessionId = sessionId)
        .onSuccess { previewFiles -> openImportDialogWithFiles(previewFiles) }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể đọc tệp .torrent")
          }
        }
    }
  }

  fun onImportFolderPicked(treeUri: Uri) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .previewFolderTree(treeUri, maxDepth = 0, targetSessionId = sessionId)
        .onSuccess { previewFiles ->
          if (previewFiles.isEmpty()) {
            controls.update {
              it.copy(
                isBusy = false,
                errorMessage = "Không tìm thấy tệp .torrent nào trong thư mục đã chọn.",
              )
            }
          } else {
            openImportDialogWithFiles(previewFiles)
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể quét thư mục SAF")
          }
        }
    }
  }

  private suspend fun openImportDialogWithFiles(previewFiles: List<PendingImportFile>) {
    val settings = repository.settingsFlow.first()
    val allPresets = BuiltInPresets.all + repository.customPresetsFlow.first()
    val defaultPreset = allPresets.firstOrNull { it.id == settings.defaultPresetId }
    val baseConfig = defaultPreset?.config ?: FakerConfig()

    val mode =
      when {
        baseConfig.completionPercent >= 99.9 -> ImportMode.SEED
        baseConfig.completionPercent <= 0.1 -> ImportMode.LEECH
        else -> ImportMode.CUSTOM
      }

    val options =
      TorrentImportOptions(
        targetSessionId = sessionId,
        createNewSessionName = null,
        presetId = defaultPreset?.id,
        mode = mode,
        customCompletionPercent = baseConfig.completionPercent,
        clientType = baseConfig.clientType,
        clientVersion = baseConfig.clientVersion,
        port = baseConfig.port,
        vpnPortSync = baseConfig.vpnPortSync,
        uploadRateKBs = baseConfig.uploadRateKBs,
        downloadRateKBs = baseConfig.downloadRateKBs,
        updateIntervalSeconds = baseConfig.updateIntervalSeconds,
        scrapeIntervalSeconds = baseConfig.scrapeIntervalSeconds,
        baseConfig = baseConfig,
      )

    controls.update {
      it.copy(
        isBusy = false,
        importDialog =
          ImportDialogState(
            files = previewFiles,
            options = options,
            uploadRateText = formatNumber(options.uploadRateKBs),
            downloadRateText = formatNumber(options.downloadRateKBs),
            portText = options.port.toString(),
            updateIntervalText = options.updateIntervalSeconds.toString(),
            scrapeIntervalText = options.scrapeIntervalSeconds.toString(),
            customPercentText = formatNumber(options.customCompletionPercent),
            staggerSecondsText = options.staggerStartSeconds.toString(),
          ),
      )
    }
  }

  fun updateImportDialog(transform: (ImportDialogState) -> ImportDialogState) {
    controls.update { ctrl ->
      val current = ctrl.importDialog ?: return@update ctrl
      ctrl.copy(importDialog = transform(current).copy(validationError = null))
    }
  }

  fun selectImportPreset(preset: Preset?) {
    controls.update { ctrl ->
      val current = ctrl.importDialog ?: return@update ctrl
      if (preset == null) {
        return@update ctrl.copy(
          importDialog = current.copy(options = current.options.copy(presetId = null))
        )
      }
      val cfg = preset.config
      val mode =
        when {
          cfg.completionPercent >= 99.9 -> ImportMode.SEED
          cfg.completionPercent <= 0.1 -> ImportMode.LEECH
          else -> ImportMode.CUSTOM
        }
      val nextOptions =
        current.options.copy(
          targetSessionId = sessionId,
          createNewSessionName = null,
          presetId = preset.id,
          mode = mode,
          customCompletionPercent = cfg.completionPercent,
          clientType = cfg.clientType,
          clientVersion = cfg.clientVersion,
          port = cfg.port,
          vpnPortSync = cfg.vpnPortSync,
          uploadRateKBs = cfg.uploadRateKBs,
          downloadRateKBs = cfg.downloadRateKBs,
          updateIntervalSeconds = cfg.updateIntervalSeconds,
          scrapeIntervalSeconds = cfg.scrapeIntervalSeconds,
          baseConfig = cfg,
        )
      ctrl.copy(
        importDialog =
          current.copy(
            options = nextOptions,
            uploadRateText = formatNumber(cfg.uploadRateKBs),
            downloadRateText = formatNumber(cfg.downloadRateKBs),
            portText = cfg.port.toString(),
            updateIntervalText = cfg.updateIntervalSeconds.toString(),
            scrapeIntervalText = cfg.scrapeIntervalSeconds.toString(),
            customPercentText = formatNumber(cfg.completionPercent),
            validationError = null,
          )
      )
    }
  }

  fun selectImportClient(client: ClientType) {
    controls.update { ctrl ->
      val current = ctrl.importDialog ?: return@update ctrl
      val nextOptions =
        current.options.copy(
          clientType = client,
          clientVersion = client.defaultVersion,
          port = client.defaultPort,
        )
      ctrl.copy(
        importDialog =
          current.copy(
            options = nextOptions,
            portText = client.defaultPort.toString(),
            validationError = null,
          )
      )
    }
  }

  fun dismissImportDialog() {
    controls.update { it.copy(importDialog = null) }
  }

  fun confirmImport(onAutoStarted: () -> Unit = {}) {
    val draft = controls.value.importDialog ?: return
    if (draft.validCount == 0) {
      controls.update {
        it.copy(
          importDialog =
            draft.copy(
              validationError =
                "Không có tệp .torrent hợp lệ mới để thêm vào phiên (${draft.duplicateCount} trùng info_hash, ${draft.invalidCount} lỗi)."
            )
        )
      }
      return
    }

    val upload = draft.uploadRateText.toDoubleOrNull()
    val download = draft.downloadRateText.toDoubleOrNull()
    val port = draft.portText.toIntOrNull()
    val updateSec = draft.updateIntervalText.toIntOrNull()
    val scrapeSec = draft.scrapeIntervalText.toIntOrNull()
    val customPct = draft.customPercentText.toDoubleOrNull() ?: 100.0
    val staggerSec = draft.staggerSecondsText.toIntOrNull() ?: 0

    val error =
      when {
        upload == null || upload < 0.0 -> "Tốc độ tải lên phải ≥ 0 KB/s."
        download == null || download < 0.0 -> "Tốc độ tải xuống phải ≥ 0 KB/s."
        port == null || port !in 1..65535 -> "Port phải nằm trong khoảng 1 – 65535."
        updateSec == null || updateSec !in 1..3600 -> "Chu kỳ cập nhật phải từ 1 – 3600 giây."
        scrapeSec == null || scrapeSec !in 10..86400 -> "Chu kỳ scrape phải từ 10 – 86400 giây."
        draft.options.mode == ImportMode.CUSTOM && customPct !in 0.0..100.0 ->
          "Mức hoàn thành tùy chỉnh phải từ 0 – 100%."
        draft.options.autoStart && staggerSec < 0 -> "Độ trễ khởi động phải ≥ 0 giây."
        else -> null
      }
    if (error != null) {
      controls.update { it.copy(importDialog = draft.copy(validationError = error)) }
      return
    }

    val tags =
      draft.tagsText
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()

    val finalOptions =
      draft.options.copy(
        targetSessionId = sessionId,
        createNewSessionName = null,
        uploadRateKBs = upload!!,
        downloadRateKBs = download!!,
        port = port!!,
        updateIntervalSeconds = updateSec!!,
        scrapeIntervalSeconds = scrapeSec!!,
        customCompletionPercent = customPct.coerceIn(0.0, 100.0),
        tags = tags,
        staggerStartSeconds = if (draft.options.autoStart) staggerSec else 0,
      )

    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, importDialog = null, errorMessage = null) }
      repository
        .importPendingTorrents(draft.files, finalOptions, InstanceSource.MANUAL)
        .onSuccess { res ->
          val msg =
            buildString {
              append("Đã thêm ${res.importedCount} torrent vào phiên")
              if (res.autoStarted) {
                append(" và tự động chạy")
                if (res.staggerStartSeconds > 0) append(" (giãn cách ${res.staggerStartSeconds}s)")
              }
              if (res.skippedDuplicates.isNotEmpty()) {
                append(" · Bỏ qua ${res.skippedDuplicates.size} torrent trùng info_hash")
              }
              if (res.errors.isNotEmpty()) {
                append(" · ${res.errors.size} lỗi đọc tệp")
              }
            }
          controls.update { it.copy(isBusy = false, actionMessage = msg) }
          if (res.autoStarted && res.importedCount > 0) {
            onAutoStarted()
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Lỗi thêm torrent")
          }
        }
    }
  }

  fun onNotificationPermissionResult(granted: Boolean) {
    controls.update { it.copy(notificationDeniedNotice = !granted) }
  }

  fun dismissMessages() {
    controls.update {
      it.copy(actionMessage = null, errorMessage = null, notificationDeniedNotice = false)
    }
  }

  private fun formatNumber(value: Double): String {
    val asLong = value.toLong()
    return if (value == asLong.toDouble()) asLong.toString() else value.toString()
  }

  companion object {
    fun factory(sessionId: String, repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          SessionDetailViewModel(sessionId, repository) as T
      }
  }
}
