package com.example.ui.sessions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.ClientType
import com.example.domain.model.ImportMode
import com.example.domain.model.Preset
import com.example.domain.model.RunMode
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TorrentImportSheet(
  dialogState: ImportDialogState,
  lockedSessionName: String,
  runMode: RunMode,
  serverOnline: Boolean,
  presets: List<Preset>,
  onUpdate: ((ImportDialogState) -> ImportDialogState) -> Unit,
  onSelectPreset: (Preset?) -> Unit,
  onSelectClient: (ClientType) -> Unit,
  onPickMoreFiles: () -> Unit,
  onPickMoreFolder: () -> Unit,
  onDismiss: () -> Unit,
  onConfirm: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var clientExpanded by remember { mutableStateOf(false) }
  var versionExpanded by remember { mutableStateOf(false) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = colors.surface,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "Thêm Torrent vào phiên",
        style = MaterialTheme.typography.titleLarge,
        color = colors.textPrimary,
      )

      // Phiên đích cố định — không tạo phiên mới, không thay thế torrent cũ
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = colors.primaryContainer.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, colors.primary.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(Icons.Rounded.Folder, contentDescription = null, tint = colors.primary)
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Phiên đích: $lockedSessionName",
              style = MaterialTheme.typography.titleSmall,
              color = colors.textPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text =
                if (runMode == RunMode.SERVER && serverOnline) "Đích thực thi: Rustatio Server (từ xa)"
                else "Các torrent mới sẽ được thêm độc lập vào phiên này.",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
        }
      }

      // File inspection summary
      Surface(
        shape = RoundedCornerShape(14.dp),
        color = colors.surfaceSubtle,
        border = BorderStroke(1.dp, colors.border),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Text(
            text =
              "Tệp đã chọn: ${dialogState.files.size} · Hợp lệ mới: ${dialogState.validCount}" +
                (if (dialogState.duplicateCount > 0) " · Trùng info_hash: ${dialogState.duplicateCount}" else "") +
                (if (dialogState.invalidCount > 0) " · Lỗi: ${dialogState.invalidCount}" else ""),
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (dialogState.validCount > 0) colors.primary else colors.warning,
          )
          dialogState.files.take(4).forEach { f ->
            val label =
              when {
                f.error != null -> "• ${f.fileName} (Lỗi: ${f.error})"
                f.isDuplicate -> "• ${f.fileName} (Bỏ qua do trùng info_hash trong phiên)"
                else -> "• ${f.torrent?.name ?: f.fileName}"
              }
            Text(
              text = label,
              style = MaterialTheme.typography.bodySmall,
              color = if (f.isValidNew) colors.textSecondary else colors.warning,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
          if (dialogState.files.size > 4) {
            Text(
              text = "… và ${dialogState.files.size - 4} tệp khác",
              style = MaterialTheme.typography.labelSmall,
              color = colors.textSecondary,
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
              onClick = onPickMoreFiles,
              modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("import_repick_files"),
            ) {
              Icon(Icons.Rounded.UploadFile, contentDescription = null)
              Spacer(Modifier.width(6.dp))
              Text("Chọn lại tệp", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            OutlinedButton(
              onClick = onPickMoreFolder,
              modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("import_repick_folder"),
            ) {
              Icon(Icons.Rounded.FolderOpen, contentDescription = null)
              Spacer(Modifier.width(6.dp))
              Text("Thư mục SAF", maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
          }
        }
      }

      // Preset picker
      Text("Áp dụng nhanh Preset", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        FilterChip(
          selected = dialogState.options.presetId == null,
          onClick = { onSelectPreset(null) },
          label = { Text("Tùy chỉnh") },
        )
        presets.forEach { preset ->
          FilterChip(
            selected = dialogState.options.presetId == preset.id,
            onClick = { onSelectPreset(preset) },
            label = { Text(preset.name) },
            modifier = Modifier.testTag("import_preset_${preset.id}"),
          )
        }
      }

      // Mode (Seed / Leech / Custom)
      Text("Chế độ hoàn thành ban đầu", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        ImportMode.entries.forEach { mode ->
          FilterChip(
            selected = dialogState.options.mode == mode,
            onClick = { onUpdate { it.copy(options = it.options.copy(mode = mode)) } },
            label = { Text(mode.labelVi) },
            modifier = Modifier.testTag("import_mode_${mode.id}"),
          )
        }
      }
      if (dialogState.options.mode == ImportMode.CUSTOM) {
        OutlinedTextField(
          value = dialogState.customPercentText,
          onValueChange = { txt -> onUpdate { it.copy(customPercentText = txt) } },
          label = { Text("Mức hoàn thành (%)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("import_custom_percent"),
        )
      }

      // Client & Version
      Text("Client & Phiên bản giả lập", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Box(modifier = Modifier.weight(1f)) {
          OutlinedButton(
            onClick = { clientExpanded = true },
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("import_client_btn"),
          ) {
            Text(
              dialogState.options.clientType.displayName,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f),
            )
            Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
          }
          DropdownMenu(expanded = clientExpanded, onDismissRequest = { clientExpanded = false }) {
            ClientType.entries.forEach { ct ->
              DropdownMenuItem(
                text = { Text(ct.displayName) },
                onClick = {
                  clientExpanded = false
                  onSelectClient(ct)
                },
              )
            }
          }
        }
        Box(modifier = Modifier.weight(1f)) {
          OutlinedButton(
            onClick = { versionExpanded = true },
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("import_version_btn"),
          ) {
            Text(
              dialogState.options.clientVersion,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f),
            )
            Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
          }
          DropdownMenu(expanded = versionExpanded, onDismissRequest = { versionExpanded = false }) {
            dialogState.options.clientType.versions.forEach { ver ->
              DropdownMenuItem(
                text = { Text(ver) },
                onClick = {
                  versionExpanded = false
                  onUpdate { it.copy(options = it.options.copy(clientVersion = ver)) }
                },
              )
            }
          }
        }
      }

      // Port & VPN Sync
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        OutlinedTextField(
          value = dialogState.portText,
          onValueChange = { txt -> onUpdate { it.copy(portText = txt) } },
          label = { Text("Port") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("import_port_input"),
        )
        Column(modifier = Modifier.weight(1f)) {
          Text("Đồng bộ Port VPN", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
          Switch(
            checked = dialogState.options.vpnPortSync,
            onCheckedChange = { checked ->
              onUpdate { it.copy(options = it.options.copy(vpnPortSync = checked)) }
            },
            modifier = Modifier.testTag("import_vpn_sync_switch"),
          )
        }
      }

      // Upload / Download rate
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = dialogState.uploadRateText,
          onValueChange = { txt -> onUpdate { it.copy(uploadRateText = txt) } },
          label = { Text("Tải lên (KB/s)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("import_upload_rate"),
        )
        OutlinedTextField(
          value = dialogState.downloadRateText,
          onValueChange = { txt -> onUpdate { it.copy(downloadRateText = txt) } },
          label = { Text("Tải xuống (KB/s)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("import_download_rate"),
        )
      }

      // Update / Scrape intervals
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = dialogState.updateIntervalText,
          onValueChange = { txt -> onUpdate { it.copy(updateIntervalText = txt) } },
          label = { Text("Chu kỳ cập nhật (s)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("import_update_interval"),
        )
        OutlinedTextField(
          value = dialogState.scrapeIntervalText,
          onValueChange = { txt -> onUpdate { it.copy(scrapeIntervalText = txt) } },
          label = { Text("Chu kỳ scrape (s)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.weight(1f).testTag("import_scrape_interval"),
        )
      }

      // Tags
      OutlinedTextField(
        value = dialogState.tagsText,
        onValueChange = { txt -> onUpdate { it.copy(tagsText = txt) } },
        label = { Text("Thẻ gắn (phân tách bởi dấu phẩy)") },
        placeholder = { Text("Ví dụ: seedbox, tracker-vn") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().testTag("import_tags_input"),
      )

      // Auto-start & Stagger start
      HorizontalDivider(color = colors.border.copy(alpha = 0.6f))
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
          Text("Tự động chạy sau khi thêm", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
          Text(
            "Khởi chạy giả lập ngay khi thêm vào phiên.",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
          )
        }
        Switch(
          checked = dialogState.options.autoStart,
          onCheckedChange = { checked ->
            onUpdate { it.copy(options = it.options.copy(autoStart = checked)) }
          },
          modifier = Modifier.testTag("import_autostart_switch"),
        )
      }

      if (dialogState.options.autoStart) {
        OutlinedTextField(
          value = dialogState.staggerSecondsText,
          onValueChange = { txt -> onUpdate { it.copy(staggerSecondsText = txt) } },
          label = { Text("Độ trễ khởi động luân phiên (giây)") },
          supportingText = { Text("Giãn cách thời gian giữa mỗi torrent (0 = chạy đồng thời).") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("import_stagger_seconds"),
        )
      }

      dialogState.validationError?.let { err ->
        RustatioBanner(type = BannerType.ERROR, message = err)
      }

      Row(
        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedButton(
          onClick = onDismiss,
          modifier = Modifier.weight(1f).defaultMinSize(minHeight = 50.dp).testTag("import_cancel_btn"),
        ) {
          Text("Hủy")
        }
        Button(
          onClick = onConfirm,
          enabled = dialogState.validCount > 0,
          modifier = Modifier.weight(1.4f).defaultMinSize(minHeight = 50.dp).testTag("import_confirm_btn"),
        ) {
          Text("Thêm ${dialogState.validCount} torrent")
        }
      }
    }
  }
}
