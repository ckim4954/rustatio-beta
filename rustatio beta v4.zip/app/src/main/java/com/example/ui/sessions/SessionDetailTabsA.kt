package com.example.ui.sessions

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.ClientType
import com.example.domain.model.Formatters
import com.example.domain.model.InstanceItem
import com.example.domain.model.PostStopAction
import com.example.ui.components.BannerType
import com.example.ui.components.MetricTile
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioSavingButton
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.RustatioSectionHeader
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SessionOverviewTab(
  item: InstanceItem,
  state: TorrentDetailUiState,
  viewModel: TorrentDetailViewModel,
) {
  val colors = RustatioThemeTokens.colors
  val torrent = item.torrent
  val config = state.draftConfig
  var showAllFiles by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      RustatioSectionHeader("Preset nhanh")
      Row(
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        state.presets.forEach { preset ->
          FilterChip(
            selected = false,
            onClick = { viewModel.applyPreset(preset) },
            label = { Text(preset.name) },
            modifier = Modifier.defaultMinSize(minHeight = 48.dp),
          )
        }
      }
    }

    item {
      RustatioSectionHeader("Thông số giả lập hiện tại")
      RustatioSectionCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Tải lên cấu hình",
            value = Formatters.formatSpeedKBs(config.uploadRateKBs),
            accentColor = colors.upload,
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Tải xuống cấu hình",
            value = Formatters.formatSpeedKBs(config.downloadRateKBs),
            accentColor = colors.download,
            modifier = Modifier.weight(1f),
          )
        }
        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          MetricTile(
            label = "Client",
            value = "${config.clientType.displayName} ${config.clientVersion}",
            modifier = Modifier.weight(1f),
          )
          MetricTile(
            label = "Cổng · Hoàn thành",
            value = "${config.port} · ${config.completionPercent.roundToInt()}%",
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    if (torrent != null) {
      item {
        RustatioSectionHeader("Chi tiết tệp Torrent")
        RustatioSectionCard {
          InfoRow("Dung lượng tổng", Formatters.formatBytes(torrent.totalSize))
          InfoRow("Số mảnh / Kích thước", "${torrent.numPieces} × ${Formatters.formatBytes(torrent.pieceLength)}")
          InfoRow("Số tệp tin", "${torrent.fileCount} (${if (torrent.isSingleFile) "Đơn tệp" else "Nhiều tệp"})")
          InfoRow("Info Hash", torrent.infoHashHex)
          torrent.createdBy?.let { InfoRow("Tạo bởi", it) }
          torrent.comment?.let { InfoRow("Ghi chú", it) }
          InfoRow("Ngày tạo", Formatters.formatDate(torrent.creationDate))

          if (torrent.allTrackers.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Danh sách Tracker (${torrent.allTrackers.size})", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(4.dp))
            torrent.allTrackers.take(6).forEach { tracker ->
              Text(
                text = "• $tracker",
                style = MonoMetricSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(vertical = 2.dp),
              )
            }
          }

          if (torrent.files.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Danh sách tệp (${torrent.files.size})", style = MaterialTheme.typography.titleSmall)
              if (torrent.files.size > 4) {
                androidx.compose.material3.TextButton(onClick = { showAllFiles = !showAllFiles }) {
                  Text(if (showAllFiles) "Thu gọn" else "Xem tất cả")
                }
              }
            }
            val visibleFiles = if (showAllFiles) torrent.files else torrent.files.take(4)
            visibleFiles.forEach { file ->
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = file.path,
                  style = MaterialTheme.typography.bodySmall,
                  color = colors.textPrimary,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f).padding(end = 8.dp),
                )
                Text(
                  text = Formatters.formatBytes(file.size),
                  style = MonoMetricSmall,
                  color = colors.textSecondary,
                )
              }
            }
          }
        }
      }
    }
    item { Spacer(Modifier.height(16.dp)) }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SessionConfigTab(
  item: InstanceItem,
  state: TorrentDetailUiState,
  viewModel: TorrentDetailViewModel,
) {
  val colors = RustatioThemeTokens.colors
  val cfg = state.draftConfig
  val isRunning = item.effectiveState.isActive
  val errs = state.validationErrors

  var upText by remember(cfg.uploadRateKBs, item.id) { mutableStateOf(cfg.uploadRateKBs.toString()) }
  var dlText by remember(cfg.downloadRateKBs, item.id) { mutableStateOf(cfg.downloadRateKBs.toString()) }
  var portText by remember(cfg.port, item.id) { mutableStateOf(cfg.port.toString()) }
  var initialUpText by remember(cfg.initialUploadedMB, item.id) { mutableStateOf(cfg.initialUploadedMB.toString()) }
  var targetUpText by remember(cfg.targetUploadRateKBs, item.id) { mutableStateOf(cfg.targetUploadRateKBs.toString()) }
  var targetDlText by remember(cfg.targetDownloadRateKBs, item.id) { mutableStateOf(cfg.targetDownloadRateKBs.toString()) }
  var progHoursText by remember(cfg.progressiveDurationHours, item.id) { mutableStateOf(cfg.progressiveDurationHours.toString()) }
  var refreshText by remember(cfg.updateIntervalSeconds, item.id) { mutableStateOf(cfg.updateIntervalSeconds.toString()) }
  var scrapeText by remember(cfg.scrapeIntervalSeconds, item.id) { mutableStateOf(cfg.scrapeIntervalSeconds.toString()) }

  LazyColumn(
    modifier = Modifier.fillMaxSize().testTag("config_tab_list"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    if (isRunning) {
      item {
        RustatioBanner(
          type = BannerType.WARNING,
          message = "Torrent đang chạy. Tạm dừng hoặc dừng torrent để thay đổi một số tham số nhạy cảm.",
        )
      }
    }

    // Client emulation card
    item {
      RustatioSectionHeader("Trình khách giả lập (Client)")
      RustatioSectionCard {
        Text("Loại Client", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          ClientType.entries.forEach { client ->
            FilterChip(
              selected = cfg.clientType == client,
              enabled = !isRunning,
              onClick = { viewModel.selectClient(client) },
              label = { Text(client.displayName) },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            )
          }
        }

        Spacer(Modifier.height(10.dp))
        Text("Phiên bản (${cfg.clientType.displayName})", style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          cfg.clientType.versions.forEach { ver ->
            FilterChip(
              selected = cfg.clientVersion == ver,
              enabled = !isRunning,
              onClick = { viewModel.updateDraft { it.copy(clientVersion = ver) } },
              label = { Text(ver) },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            )
          }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
          value = portText,
          onValueChange = { raw ->
            portText = raw
            raw.toIntOrNull()?.let { p -> viewModel.updateDraft { it.copy(port = p) } }
          },
          enabled = !isRunning && !cfg.vpnPortSync,
          label = { Text("Cổng BitTorrent (1–65535)") },
          isError = errs.portError != null,
          supportingText = errs.portError?.let { msg -> { Text(msg) } },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("config_port_input"),
        )

        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text("Đồng bộ cổng VPN chuyển tiếp", style = MaterialTheme.typography.bodyLarge)
            Text(
              "Tự động lấy cổng forward từ VPN khi chạy qua Server hỗ trợ",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Switch(
            checked = cfg.vpnPortSync,
            enabled = !isRunning,
            onCheckedChange = { v -> viewModel.updateDraft { it.copy(vpnPortSync = v) } },
          )
        }
      }
    }

    // Transfer rates card
    item {
      RustatioSectionHeader("Tốc độ truyền tải & Dao động")
      RustatioSectionCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = upText,
            onValueChange = { raw ->
              upText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(uploadRateKBs = v) } }
            },
            label = { Text("Tải lên (KB/s)") },
            isError = errs.uploadRateError != null,
            supportingText = errs.uploadRateError?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("config_upload_input"),
          )
          OutlinedTextField(
            value = dlText,
            onValueChange = { raw ->
              dlText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(downloadRateKBs = v) } }
            },
            label = { Text("Tải xuống (KB/s)") },
            isError = errs.downloadRateError != null,
            supportingText = errs.downloadRateError?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.weight(1f).testTag("config_download_input"),
          )
        }

        Spacer(Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text("Ngẫu nhiên hóa tốc độ", style = MaterialTheme.typography.bodyLarge)
            Text(
              "Tạo dao động tự nhiên quanh mức cấu hình",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Switch(
            checked = cfg.randomizeRates,
            onCheckedChange = { v -> viewModel.updateDraft { it.copy(randomizeRates = v) } },
          )
        }

        if (cfg.randomizeRates) {
          val pct = cfg.randomRangePercent.toFloat().coerceIn(0f, 50f)
          Spacer(Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text("Độ dao động", style = MaterialTheme.typography.bodyMedium)
            Text("±${pct.roundToInt()}%", style = MonoMetricSmall, color = colors.primary)
          }
          Slider(
            value = pct,
            onValueChange = { v -> viewModel.updateDraft { it.copy(randomRangePercent = v.roundToInt().toDouble()) } },
            valueRange = 0f..50f,
          )
          val minUp = (cfg.uploadRateKBs * (1.0 - pct / 100.0)).coerceAtLeast(0.0)
          val maxUp = cfg.uploadRateKBs * (1.0 + pct / 100.0)
          val minDl = (cfg.downloadRateKBs * (1.0 - pct / 100.0)).coerceAtLeast(0.0)
          val maxDl = cfg.downloadRateKBs * (1.0 + pct / 100.0)
          Text(
            text = "Khoảng tải lên: ${Formatters.formatSpeedKBs(minUp)} – ${Formatters.formatSpeedKBs(maxUp)}",
            style = MonoMetricSmall,
            color = colors.upload,
          )
          Text(
            text = "Khoảng tải xuống: ${Formatters.formatSpeedKBs(minDl)} – ${Formatters.formatSpeedKBs(maxDl)}",
            style = MonoMetricSmall,
            color = colors.download,
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = colors.border)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text("Điều chỉnh tốc độ tăng dần", style = MaterialTheme.typography.bodyLarge)
            Text(
              "Tăng/giảm tuyến tính từ tốc độ ban đầu đến mục tiêu",
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Switch(
            checked = cfg.progressiveRatesEnabled,
            onCheckedChange = { v -> viewModel.updateDraft { it.copy(progressiveRatesEnabled = v) } },
          )
        }

        if (cfg.progressiveRatesEnabled) {
          Spacer(Modifier.height(8.dp))
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = targetUpText,
              onValueChange = { raw ->
                targetUpText = raw
                raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(targetUploadRateKBs = v) } }
              },
              label = { Text("Tải lên mục tiêu (KB/s)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
            OutlinedTextField(
              value = targetDlText,
              onValueChange = { raw ->
                targetDlText = raw
                raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(targetDownloadRateKBs = v) } }
              },
              label = { Text("Tải xuống mục tiêu") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
              singleLine = true,
              modifier = Modifier.weight(1f),
            )
          }
          Spacer(Modifier.height(8.dp))
          OutlinedTextField(
            value = progHoursText,
            onValueChange = { raw ->
              progHoursText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(progressiveDurationHours = v) } }
            },
            label = { Text("Thời gian đạt mục tiêu (giờ)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }
    }

    // Initial state & intervals
    item {
      RustatioSectionHeader("Trạng thái ban đầu & Chu kỳ")
      RustatioSectionCard {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text("Mức hoàn thành torrent", style = MaterialTheme.typography.bodyLarge)
          Text("${cfg.completionPercent.roundToInt()}%", style = MonoMetricSmall, color = colors.primary)
        }
        Slider(
          value = cfg.completionPercent.toFloat().coerceIn(0f, 100f),
          enabled = !isRunning,
          onValueChange = { v -> viewModel.updateDraft { it.copy(completionPercent = v.roundToInt().toDouble()) } },
          valueRange = 0f..100f,
        )

        OutlinedTextField(
          value = initialUpText,
          onValueChange = { raw ->
            initialUpText = raw
            raw.toLongOrNull()?.let { v -> viewModel.updateDraft { it.copy(initialUploadedMB = v.coerceAtLeast(0L)) } }
          },
          enabled = !isRunning,
          label = { Text("Đã tải lên trước đó (MB)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          OutlinedTextField(
            value = refreshText,
            onValueChange = { raw ->
              refreshText = raw
              raw.toIntOrNull()?.let { v -> viewModel.updateDraft { it.copy(updateIntervalSeconds = v) } }
            },
            label = { Text("Chu kỳ cập nhật (giây)") },
            isError = errs.intervalError != null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
          OutlinedTextField(
            value = scrapeText,
            onValueChange = { raw ->
              scrapeText = raw
              raw.toIntOrNull()?.let { v -> viewModel.updateDraft { it.copy(scrapeIntervalSeconds = v) } }
            },
            label = { Text("Chu kỳ Scrape (giây)") },
            isError = errs.intervalError != null,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f),
          )
        }
        errs.intervalError?.let {
          Text(it, style = MaterialTheme.typography.bodySmall, color = colors.error, modifier = Modifier.padding(top = 4.dp))
        }
      }
    }

    item {
      RustatioSavingButton(
        label = "Lưu cấu hình",
        savingLabel = "Đang lưu…",
        isSaving = state.isSaving,
        enabled = !errs.hasErrors,
        testTag = "config_save_button",
        onClick = { viewModel.saveConfig() },
      )
    }
    item { Spacer(Modifier.height(16.dp)) }
  }
}

@Composable
fun SessionStopConditionsTab(
  item: InstanceItem,
  state: TorrentDetailUiState,
  viewModel: TorrentDetailViewModel,
) {
  val colors = RustatioThemeTokens.colors
  val cfg = state.draftConfig

  var ratioText by remember(cfg.stopAtRatio, item.id) { mutableStateOf(cfg.stopAtRatio.toString()) }
  var uploadedGbText by remember(cfg.stopAtUploadedGB, item.id) { mutableStateOf(cfg.stopAtUploadedGB.toString()) }
  var downloadedGbText by remember(cfg.stopAtDownloadedGB, item.id) { mutableStateOf(cfg.stopAtDownloadedGB.toString()) }
  var seedHoursText by remember(cfg.stopAtSeedTimeHours, item.id) { mutableStateOf(cfg.stopAtSeedTimeHours.toString()) }

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    item {
      RustatioSectionHeader(
        title = "Điều kiện dừng tự động",
        trailing = {
          Text(
            text = "${cfg.activeStopConditionsCount} đang bật",
            style = MaterialTheme.typography.labelSmall,
            color = if (cfg.activeStopConditionsCount > 0) colors.primary else colors.textSecondary,
          )
        },
      )

      RustatioSectionCard {
        ToggleConditionRow(
          title = "Dừng khi đạt tỷ lệ (Ratio)",
          subtitle = "Tự động dừng khi tỷ lệ phiên đạt ngưỡng mục tiêu",
          checked = cfg.stopAtRatioEnabled,
          onCheckedChange = { v -> viewModel.updateDraft { it.copy(stopAtRatioEnabled = v) } },
        )
        if (cfg.stopAtRatioEnabled) {
          OutlinedTextField(
            value = ratioText,
            onValueChange = { raw ->
              ratioText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(stopAtRatio = v) } }
            },
            label = { Text("Tỷ lệ mục tiêu") },
            isError = state.validationErrors.ratioTargetError != null,
            supportingText = state.validationErrors.ratioTargetError?.let { msg -> { Text(msg) } },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
          )
          ToggleConditionRow(
            title = "Ngẫu nhiên hóa tỷ lệ dừng",
            subtitle = "Dao động nhẹ mục tiêu tỷ lệ để tự nhiên hơn",
            checked = cfg.randomizeRatio,
            onCheckedChange = { v -> viewModel.updateDraft { it.copy(randomizeRatio = v) } },
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.border)

        ToggleConditionRow(
          title = "Giới hạn dung lượng tải lên (GB)",
          subtitle = "Dừng khi dung lượng tải lên trong phiên đạt ngưỡng",
          checked = cfg.stopAtUploadedEnabled,
          onCheckedChange = { v -> viewModel.updateDraft { it.copy(stopAtUploadedEnabled = v) } },
        )
        if (cfg.stopAtUploadedEnabled) {
          OutlinedTextField(
            value = uploadedGbText,
            onValueChange = { raw ->
              uploadedGbText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(stopAtUploadedGB = v) } }
            },
            label = { Text("Tải lên tối đa (GB)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.border)

        ToggleConditionRow(
          title = "Giới hạn dung lượng tải xuống (GB)",
          subtitle = "Dừng khi dung lượng tải xuống đạt ngưỡng",
          checked = cfg.stopAtDownloadedEnabled,
          onCheckedChange = { v -> viewModel.updateDraft { it.copy(stopAtDownloadedEnabled = v) } },
        )
        if (cfg.stopAtDownloadedEnabled) {
          OutlinedTextField(
            value = downloadedGbText,
            onValueChange = { raw ->
              downloadedGbText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(stopAtDownloadedGB = v) } }
            },
            label = { Text("Tải xuống tối đa (GB)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.border)

        ToggleConditionRow(
          title = "Giới hạn thời gian Seed (giờ)",
          subtitle = "Dừng sau khi phiên đã chạy đủ số giờ chỉ định",
          checked = cfg.stopAtSeedTimeEnabled,
          onCheckedChange = { v -> viewModel.updateDraft { it.copy(stopAtSeedTimeEnabled = v) } },
        )
        if (cfg.stopAtSeedTimeEnabled) {
          OutlinedTextField(
            value = seedHoursText,
            onValueChange = { raw ->
              seedHoursText = raw
              raw.toDoubleOrNull()?.let { v -> viewModel.updateDraft { it.copy(stopAtSeedTimeHours = v) } }
            },
            label = { Text("Thời gian seed tối đa (giờ)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
          )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.border)

        ToggleConditionRow(
          title = "Tạm nghỉ khi không có Leecher",
          subtitle = "Tạm dừng truyền tải lên (0 KB/s) khi tracker báo 0 leecher",
          checked = cfg.idleWhenNoLeechers,
          onCheckedChange = { v -> viewModel.updateDraft { it.copy(idleWhenNoLeechers = v) } },
        )
        ToggleConditionRow(
          title = "Tạm nghỉ khi không có Seeder",
          subtitle = "Tạm dừng truyền tải xuống khi tracker báo 0 seeder",
          checked = cfg.idleWhenNoSeeders,
          onCheckedChange = { v -> viewModel.updateDraft { it.copy(idleWhenNoSeeders = v) } },
        )
      }
    }

    item {
      RustatioSectionHeader("Hành động sau khi đạt điều kiện dừng")
      RustatioSectionCard {
        val options =
          listOf(
            PostStopAction.IDLE to "Chuyển về trạng thái chờ (giữ torrent)",
            PostStopAction.STOP_SEEDING to "Dừng hoàn toàn (gửi sự kiện stopped)",
            PostStopAction.DELETE_INSTANCE to "Tự động xóa torrent khỏi phiên",
          )
        options.forEach { (action, label) ->
          Row(
            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            RadioButton(
              selected = cfg.postStopAction == action,
              onClick = { viewModel.updateDraft { it.copy(postStopAction = action) } },
            )
            Text(text = label, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }
    }

    item {
      RustatioSavingButton(
        label = "Lưu điều kiện dừng",
        savingLabel = "Đang lưu…",
        isSaving = state.isSaving,
        enabled = !state.validationErrors.hasErrors,
        testTag = "stop_save_button",
        onClick = { viewModel.saveConfig() },
      )
    }
    item { Spacer(Modifier.height(16.dp)) }
  }
}

@Composable
private fun InfoRow(label: String, value: String) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(label, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
    Spacer(Modifier.padding(horizontal = 8.dp))
    Text(
      text = value,
      style = MaterialTheme.typography.bodySmall,
      color = colors.textPrimary,
      maxLines = 2,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
private fun ToggleConditionRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
      Text(title, style = MaterialTheme.typography.bodyLarge, color = colors.textPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
    }
    Switch(checked = checked, onCheckedChange = onCheckedChange)
  }
}
