package com.example.ui.sessions

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.Formatters
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioLoadingSkeleton
import com.example.ui.components.RustatioSectionCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

/**
 * Màn hình 2 — Chi tiết phiên.
 * Quản lý các torrent thuộc phiên đang mở, chứa nút "Thêm Torrent" duy nhất trong toàn ứng dụng
 * và các điều khiển tác động lên danh sách torrent của phiên này.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SessionDetailScreen(
  viewModel: SessionDetailViewModel,
  onNavigateBack: () -> Unit,
  onOpenTorrentDetail: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val context = LocalContext.current

  var showRenameDialog by remember { mutableStateOf(false) }

  val torrentPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
      if (uris.isNotEmpty()) {
        viewModel.onImportFilesPicked(uris)
      }
    }

  val folderPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
      if (treeUri != null) {
        viewModel.onImportFolderPicked(treeUri)
      }
    }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      viewModel.onNotificationPermissionResult(granted)
    }

  fun requestNotificationPermissionIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  val session = state.session

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
        navigationIcon = {
          IconButton(
            onClick = onNavigateBack,
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_detail_back_btn"),
          ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Quay lại danh sách phiên")
          }
        },
        title = {
          Column {
            Text(
              text = session?.name ?: "Chi tiết phiên",
              style = MaterialTheme.typography.titleLarge,
              color = colors.textPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.testTag("session_detail_title"),
            )
            if (session != null) {
              Text(
                text = "${session.totalTorrents} torrent · ${Formatters.stateLabelVi(session.aggregateState)}",
                style = MaterialTheme.typography.bodySmall,
                color = colors.textSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        },
        actions = {
          if (session != null && !session.isRemoteSession) {
            IconButton(
              onClick = { showRenameDialog = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_detail_rename_btn"),
            ) {
              Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = "Chỉnh sửa tên phiên")
            }
            IconButton(
              onClick = { viewModel.requestDeleteSession() },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_detail_delete_btn"),
            ) {
              Icon(Icons.Rounded.Delete, contentDescription = "Xóa phiên", tint = colors.error)
            }
          } else if (session?.isRemoteSession == true) {
            IconButton(
              onClick = { viewModel.refreshServer() },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_detail_refresh_btn"),
            ) {
              Icon(Icons.Rounded.Refresh, contentDescription = "Làm mới máy chủ")
            }
          }
        },
      )
    },
  ) { innerPadding ->
    when {
      state.isLoading -> {
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
          RustatioLoadingSkeleton(cardCount = 3)
        }
      }
      session == null -> {
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)) {
          RustatioEmptyState(
            icon = Icons.Rounded.FolderOpen,
            title = "Không tìm thấy phiên",
            description = "Phiên này có thể đã bị xóa.",
            primaryActionLabel = "Quay lại danh sách phiên",
            onPrimaryAction = onNavigateBack,
          )
        }
      }
      else -> {
        LazyColumn(
          modifier = Modifier.fillMaxSize().padding(innerPadding).testTag("session_detail_list"),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          if (state.showNotificationPermissionBanner) {
            item {
              RustatioBanner(
                type = BannerType.INFO,
                message =
                  "Quyền thông báo đang tắt — giả lập vẫn chạy bình thường nhưng thông báo điều khiển nhanh sẽ không hiển thị.",
                actionLabel = "Đóng",
                onAction = { viewModel.dismissMessages() },
              )
            }
          }

          state.actionMessage?.let { msg ->
            item {
              RustatioBanner(
                type = BannerType.SUCCESS,
                message = msg,
                actionLabel = "Đóng",
                onAction = { viewModel.dismissMessages() },
              )
            }
          }

          state.errorMessage?.let { err ->
            item {
              RustatioBanner(
                type = BannerType.ERROR,
                message = err,
                actionLabel = "Đóng",
                onAction = { viewModel.dismissMessages() },
              )
            }
          }

          // Thống kê phiên & Điều khiển phiên
          item {
            RustatioSectionCard {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text(
                    text = "Tổng quan phiên (${session.totalTorrents} torrent)",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                  )
                  Text(
                    text = "${session.activeCount} chạy · ${session.pausedCount} tạm dừng · ${session.stoppedCount} dừng",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                  )
                }
                StatusBadge(state = session.aggregateState, isIdling = false)
              }

              Text(
                text =
                  "Tốc độ phiên: ↑ ${Formatters.formatSpeedKBs(session.totalUploadRateKBs)} · ↓ ${Formatters.formatSpeedKBs(session.totalDownloadRateKBs)}",
                style = MonoMetricSmall,
                color = if (session.activeCount > 0) colors.upload else colors.textSecondary,
                modifier = Modifier.padding(top = 8.dp),
              )
              Text(
                text =
                  "Tổng đã truyền: ↑ ${Formatters.formatBytes(session.totalUploadedBytes)} · ↓ ${Formatters.formatBytes(session.totalDownloadedBytes)}",
                style = MonoMetricSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(top = 2.dp, bottom = 10.dp),
              )

              FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Button(
                  onClick = {
                    requestNotificationPermissionIfNeeded()
                    viewModel.requestSessionBatchAction("start")
                  },
                  enabled = session.instances.any { !it.effectiveState.isActive && it.effectiveState != com.example.domain.model.FakerState.PAUSED && it.torrent != null },
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_start_all_btn"),
                ) {
                  Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(Modifier.width(4.dp))
                  Text("Bắt đầu tất cả")
                }

                OutlinedButton(
                  onClick = { viewModel.requestSessionBatchAction("pause") },
                  enabled = session.activeCount > 0,
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_pause_all_btn"),
                ) {
                  Icon(Icons.Rounded.Pause, contentDescription = null, modifier = Modifier.size(18.dp), tint = colors.warning)
                  Spacer(Modifier.width(4.dp))
                  Text("Tạm dừng tất cả")
                }

                OutlinedButton(
                  onClick = {
                    requestNotificationPermissionIfNeeded()
                    viewModel.requestSessionBatchAction("resume")
                  },
                  enabled = session.pausedCount > 0,
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_resume_all_btn"),
                ) {
                  Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp), tint = colors.primary)
                  Spacer(Modifier.width(4.dp))
                  Text("Tiếp tục tất cả")
                }

                OutlinedButton(
                  onClick = { viewModel.requestSessionBatchAction("stop") },
                  enabled = session.activeCount > 0 || session.pausedCount > 0,
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.error),
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_stop_all_btn"),
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = null, modifier = Modifier.size(18.dp), tint = colors.error)
                  Spacer(Modifier.width(4.dp))
                  Text("Dừng tất cả")
                }
              }
            }
          }

          // Nút Import Torrent duy nhất trong ứng dụng
          item {
            Button(
              onClick = { torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*")) },
              modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("session_add_torrent_btn"),
            ) {
              Icon(Icons.Rounded.UploadFile, contentDescription = null)
              Spacer(Modifier.width(8.dp))
              Text("Thêm Torrent")
            }
          }

          if (session.instances.isEmpty()) {
            item {
              RustatioSectionCard(modifier = Modifier.testTag("session_detail_empty_torrents")) {
                Column(
                  modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                  verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.FolderOpen,
                    contentDescription = null,
                    tint = colors.textSecondary,
                    modifier = Modifier.size(36.dp),
                  )
                  Text(
                    text = "Chưa có torrent nào trong phiên này",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary,
                  )
                  Text(
                    text = "Nhấn nút \"Thêm Torrent\" phía trên để chọn một hoặc nhiều tệp .torrent vào phiên.",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                  )
                }
              }
            }
          } else {
            item {
              Text(
                text = "Danh sách Torrent (${session.instances.size})",
                style = MaterialTheme.typography.titleSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(top = 4.dp),
              )
            }

            items(session.instances, key = { it.id }) { item ->
              TorrentInstanceCard(
                item = item,
                onClick = { onOpenTorrentDetail(item.id) },
                onStart = {
                  requestNotificationPermissionIfNeeded()
                  viewModel.startTorrent(item)
                },
                onPause = { viewModel.pauseTorrent(item) },
                onResume = {
                  requestNotificationPermissionIfNeeded()
                  viewModel.resumeTorrent(item)
                },
                onStop = { viewModel.stopTorrent(item) },
                onDelete = { viewModel.requestDeleteTorrent(item) },
              )
            }
          }
        }
      }
    }
  }

  if (showRenameDialog && session != null) {
    RenameSessionDialog(
      sessionName = session.name,
      onConfirm = { newName ->
        showRenameDialog = false
        viewModel.renameSession(newName)
      },
      onDismiss = { showRenameDialog = false },
    )
  }

  state.importDialog?.let { importDraft ->
    TorrentImportSheet(
      dialogState = importDraft,
      lockedSessionName = session?.name ?: "Phiên hiện tại",
      runMode = state.runMode,
      serverOnline = state.serverOnline,
      presets = state.presets,
      onUpdate = viewModel::updateImportDialog,
      onSelectPreset = viewModel::selectImportPreset,
      onSelectClient = viewModel::selectImportClient,
      onPickMoreFiles = { torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*")) },
      onPickMoreFolder = { folderPicker.launch(null) },
      onDismiss = { viewModel.dismissImportDialog() },
      onConfirm = {
        viewModel.confirmImport(onAutoStarted = { requestNotificationPermissionIfNeeded() })
      },
    )
  }

  val pending = state.pendingConfirm
  RustatioConfirmDialog(
    visible = pending != null,
    title = pending?.title.orEmpty(),
    message = pending?.message.orEmpty(),
    confirmLabel = pending?.confirmLabel ?: "Xác nhận",
    isDestructive = pending?.isDestructive == true,
    onConfirm = { viewModel.confirmPendingAction(onSessionDeleted = onNavigateBack) },
    onDismiss = { viewModel.dismissPendingConfirm() },
  )
}
