package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.JsonCodecs
import com.example.data.local.LocalInstanceEntity
import com.example.data.local.RustatioDatabase
import com.example.data.local.SessionEntity
import com.example.data.torrent.BencodeParser
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.ImportMode
import com.example.domain.model.InstanceItem
import com.example.domain.model.PendingImportFile
import com.example.domain.model.TorrentImportOptions
import com.example.domain.model.TorrentInfo
import com.example.service.RustatioForegroundService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h891dp-xxhdpi")
class MasterFeatureAcceptanceTest {

  @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

  @After
  fun tearDown() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    RustatioAppContainer.resetForTests()
    context.deleteDatabase("rustatio_db")
    context.deleteDatabase("migration_verify_db")
  }

  private fun sampleTorrentBytes(name: String, pieceByte: String): ByteArray {
    val announce = "http://tracker.example.invalid:8080/announce"
    val infoDict =
      "d6:lengthi1048576e4:name${name.toByteArray().size}:$name" +
        "12:piece lengthi16384e6:pieces20:${pieceByte.repeat(20)}e"
    return "d8:announce${announce.length}:${announce}4:info${infoDict}e".toByteArray(Charsets.ISO_8859_1)
  }

  private fun sampleTorrentInfo(name: String, hashHex: String): TorrentInfo =
    TorrentInfo(
      infoHashHex = hashHex,
      announce = "http://tracker.example.invalid:8080/announce",
      name = name,
      totalSize = 1048576L * 100L,
      pieceLength = 16384L,
      numPieces = 6400,
    )

  @Test
  fun `room migration 1 to 2 preserves existing v1 instances and custom presets cleanly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    context.deleteDatabase("migration_verify_db")

    val helperConfig =
      SupportSQLiteOpenHelper.Configuration.builder(context)
        .name("migration_verify_db")
        .callback(
          object : SupportSQLiteOpenHelper.Callback(1) {
            override fun onCreate(db: SupportSQLiteDatabase) {
              db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `local_instances` (
                  `id` TEXT NOT NULL,
                  `torrentJson` TEXT,
                  `configJson` TEXT NOT NULL,
                  `tagsJson` TEXT NOT NULL,
                  `source` TEXT NOT NULL,
                  `cumulativeUploadedBytes` INTEGER NOT NULL,
                  `cumulativeDownloadedBytes` INTEGER NOT NULL,
                  `createdAtMs` INTEGER NOT NULL,
                  PRIMARY KEY(`id`)
                )
                """.trimIndent()
              )
              db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `custom_presets` (
                  `id` TEXT NOT NULL,
                  `name` TEXT NOT NULL,
                  `description` TEXT NOT NULL,
                  `icon` TEXT NOT NULL,
                  `createdAt` TEXT,
                  `settingsJson` TEXT NOT NULL,
                  PRIMARY KEY(`id`)
                )
                """.trimIndent()
              )
              val tJson = JsonCodecs.encodeTorrent(sampleTorrentInfo("Ubuntu 24.04", "a".repeat(40)))
              val cJson = JsonCodecs.encodeConfig(FakerConfig(uploadRateKBs = 321.0))
              db.execSQL(
                "INSERT INTO `local_instances` VALUES ('v1-inst', ?, ?, '[\"linux\"]', 'manual', 123456, 654321, 1700000000000)",
                arrayOf(tJson, cJson),
              )
              val pJson = JsonCodecs.encodePresetSettings(FakerConfig(uploadRateKBs = 777.0)).toString()
              db.execSQL(
                "INSERT INTO `custom_presets` VALUES ('custom-v1', 'Preset Cu', 'Giu nguyen', 'star', '2026-01-01T00:00:00Z', ?)",
                arrayOf(pJson),
              )
            }

            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
          }
        )
        .build()

    val v1Db = FrameworkSQLiteOpenHelperFactory().create(helperConfig).writableDatabase
    v1Db.close()

    val v2Db =
      androidx.room.Room.databaseBuilder(context, RustatioDatabase::class.java, "migration_verify_db")
        .addMigrations(RustatioDatabase.MIGRATION_1_2)
        .allowMainThreadQueries()
        .build()

    runBlocking {
      val sessions = v2Db.sessionDao().getAll()
      assertTrue(sessions.any { it.id == InstanceItem.DEFAULT_SESSION_ID && it.name == InstanceItem.DEFAULT_SESSION_NAME })

      val instances = v2Db.localInstanceDao().getAll()
      assertEquals(1, instances.size)
      assertEquals("v1-inst", instances.first().id)
      assertEquals(InstanceItem.DEFAULT_SESSION_ID, instances.first().sessionId)
      assertEquals(123456L, instances.first().cumulativeUploadedBytes)
      assertEquals(654321L, instances.first().cumulativeDownloadedBytes)
      assertFalse(instances.first().wasActiveBeforeStop)
      assertEquals(321.0, JsonCodecs.decodeConfig(instances.first().configJson).uploadRateKBs, 0.01)

      val preset = v2Db.customPresetDao().getById("custom-v1")
      assertNotNull(preset)
      assertEquals("Preset Cu", preset!!.name)
      assertEquals(777.0, JsonCodecs.decodePresetConfig(preset.settingsJson).uploadRateKBs, 0.01)
    }
    v2Db.close()
  }

  @Test
  fun `three screen session torrent separation repeated imports isolation and persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val container = RustatioAppContainer.get(context)
    val repo = container.repository

    composeRule.waitForIdle()

    // Scenario A: Screen 1 empty state -> ONLY 1 "Thêm phiên" button, NO torrent import
    composeRule.onNodeWithTag("sessions_add_empty_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_add_fab").assertDoesNotExist()
    assertEquals(0, composeRule.onAllNodesWithText("Thêm Torrent").fetchSemanticsNodes().size)
    assertEquals(0, composeRule.onAllNodesWithText("Nhập Torrent").fetchSemanticsNodes().size)

    // Create empty Session A via UI -> navigates straight to Screen 2 ("Chi tiết phiên")
    composeRule.onNodeWithTag("sessions_add_empty_btn").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("create_session_name_input").performTextInput("Phiên A")
    composeRule.onNodeWithTag("create_session_confirm_btn").performClick()

    composeRule.waitUntil(5_000L) {
      composeRule.onAllNodesWithText("Phiên A").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("session_detail_title").assertIsDisplayed()
    composeRule.onNodeWithText("Phiên A").assertIsDisplayed()
    composeRule.onNodeWithTag("session_detail_empty_torrents").assertIsDisplayed()
    composeRule.onNodeWithTag("session_add_torrent_btn").assertIsDisplayed()

    val sessionAId = runBlocking { repo.sessionsFlow.first().first { it.name == "Phiên A" }.id }

    // Scenario B: Repeatedly add torrents into THIS Session A (first Torrent A1, then Torrent A2 + dup A1)
    val bytesA1 = sampleTorrentBytes("Torrent A1", "1")
    val bytesA2 = sampleTorrentBytes("Torrent A2", "2")
    val infoA1 = BencodeParser.parseTorrent(bytesA1, "a1.torrent").getOrThrow()
    val infoA2 = BencodeParser.parseTorrent(bytesA2, "a2.torrent").getOrThrow()

    runBlocking {
      val batch1 =
        repo.importPendingTorrents(
          files = listOf(PendingImportFile("u1", "a1.torrent", bytesA1, infoA1)),
          options =
            TorrentImportOptions(
              targetSessionId = sessionAId,
              mode = ImportMode.LEECH,
              clientType = ClientType.TRANSMISSION,
              clientVersion = "4.1.4",
              port = 51413,
              uploadRateKBs = 250.0,
              downloadRateKBs = 100.0,
              tags = listOf("hd"),
            ),
        ).getOrThrow()
      assertEquals(1, batch1.importedCount)
      assertEquals(sessionAId, batch1.sessionId)

      val preview2 =
        repo.previewTorrentUris(emptyList(), targetSessionId = sessionAId).getOrThrow()
      assertTrue(preview2.isEmpty())

      // Second import into SAME sessionAId (with duplicate A1 + new A2)
      val batch2 =
        repo.importPendingTorrents(
          files =
            listOf(
              PendingImportFile("u1-dup", "a1.torrent", bytesA1, infoA1, isDuplicate = false),
              PendingImportFile("u2", "a2.torrent", bytesA2, infoA2, isDuplicate = false),
            ),
          options =
            TorrentImportOptions(
              targetSessionId = sessionAId,
              uploadRateKBs = 400.0,
            ),
        ).getOrThrow()
      assertEquals(1, batch2.importedCount)
      assertEquals(listOf("a1.torrent"), batch2.skippedDuplicates)
    }

    // Create independent Session B with Torrent B1
    val sessionBId = runBlocking { repo.createSession("Phiên B").getOrThrow() }
    val bytesB1 = sampleTorrentBytes("Torrent B1", "3")
    val infoB1 = BencodeParser.parseTorrent(bytesB1, "b1.torrent").getOrThrow()
    runBlocking {
      repo.importPendingTorrents(
        files = listOf(PendingImportFile("u3", "b1.torrent", bytesB1, infoB1)),
        options = TorrentImportOptions(targetSessionId = sessionBId, uploadRateKBs = 90.0),
      ).getOrThrow()
    }

    val sessionA = runBlocking { repo.sessionsFlow.first().first { it.id == sessionAId } }
    assertEquals(2, sessionA.totalTorrents)
    val a1 = sessionA.instances.first { it.torrent?.name == "Torrent A1" }
    val a2 = sessionA.instances.first { it.torrent?.name == "Torrent A2" }

    // Screen 2 displays both Torrent cards + "Thêm Torrent" remains available
    composeRule.waitUntil(5_000L) {
      composeRule.onAllNodesWithTag("torrent_card_${a1.id}").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("session_add_torrent_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("session_detail_list").performScrollToNode(hasTestTag("torrent_card_${a2.id}"))
    composeRule.onNodeWithTag("torrent_card_${a2.id}").assertIsDisplayed()

    // Scenario C: Session-level "Bắt đầu tất cả" on Screen 2 starts ONLY Session A; Session B stays STOPPED
    composeRule.onNodeWithTag("session_detail_list").performScrollToNode(hasTestTag("session_start_all_btn"))
    composeRule.onNodeWithTag("session_start_all_btn").performClick()
    awaitUntil {
      runBlocking {
        val all = repo.sessionsFlow.first()
        all.first { it.id == sessionAId }.activeCount == 2 &&
          all.first { it.id == sessionBId }.activeCount == 0
      }
    }

    // Open Screen 3 ("Chi tiết torrent") for Torrent A1, verify no torrent file picker on Screen 3
    composeRule.onNodeWithTag("session_detail_list").performScrollToNode(hasTestTag("torrent_card_${a1.id}"))
    composeRule.onNodeWithTag("torrent_card_${a1.id}").performClick()
    composeRule.waitUntil(5_000L) {
      composeRule.onAllNodesWithTag("torrent_detail_info_hash").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithText("Chi tiết torrent").assertIsDisplayed()
    composeRule.onNodeWithTag("detail_pick_torrent_btn").assertDoesNotExist()
    assertEquals(0, composeRule.onAllNodesWithText("Chọn .torrent").fetchSemanticsNodes().size)
    assertEquals(0, composeRule.onAllNodesWithText("Đổi .torrent").fetchSemanticsNodes().size)

    // Edit Torrent A1 config independently without affecting sibling Torrent A2
    composeRule.onNodeWithTag("detail_tab_1").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("config_upload_input").performTextReplacement("999")
    composeRule.onNodeWithTag("config_tab_list").performScrollToNode(hasTestTag("config_save_button"))
    composeRule.onNodeWithTag("config_save_button").performClick()
    awaitUntil {
      runBlocking {
        val currentA = repo.sessionsFlow.first().first { it.id == sessionAId }
        val cfg1 = currentA.instances.first { it.id == a1.id }.config.uploadRateKBs
        val cfg2 = currentA.instances.first { it.id == a2.id }.config.uploadRateKBs
        cfg1 == 999.0 && cfg2 == 400.0
      }
    }

    // Back from Screen 3 returns to Screen 2 ("Phiên A")
    composeRule.onNodeWithTag("detail_back_button").performClick()
    composeRule.waitUntil(5_000L) {
      composeRule.onAllNodesWithTag("session_detail_title").fetchSemanticsNodes().isNotEmpty()
    }

    // Delete Torrent A1 on Screen 2 -> Torrent A2 AND Session A stay intact
    composeRule.onNodeWithTag("session_detail_list").performScrollToNode(hasTestTag("card_delete_${a1.id}"))
    composeRule.onNodeWithTag("card_delete_${a1.id}").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("dialog_confirm_button").performClick()
    awaitUntil {
      runBlocking {
        val s = repo.sessionsFlow.first().firstOrNull { it.id == sessionAId }
        s != null && s.totalTorrents == 1 && s.instances.first().id == a2.id
      }
    }

    // Stop remaining active torrent in Session A via "Dừng tất cả" -> Confirm Dialog
    composeRule.onNodeWithTag("session_detail_list").performScrollToNode(hasTestTag("session_stop_all_btn"))
    composeRule.onNodeWithTag("session_stop_all_btn").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("dialog_confirm_button").performClick()
    awaitUntil {
      runBlocking { repo.sessionsFlow.first().first { it.id == sessionAId }.activeCount == 0 }
    }

    // Back to Screen 1 -> Session A and Session B exist, only 1 "Thêm phiên" FAB visible
    composeRule.onNodeWithTag("session_detail_back_btn").performClick()
    composeRule.waitUntil(5_000L) {
      composeRule.onAllNodesWithTag("session_card_$sessionAId").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("sessions_add_fab").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_add_empty_btn").assertDoesNotExist()
  }

  private fun awaitUntil(timeoutMs: Long = 5_000L, predicate: () -> Boolean) {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (!predicate() && System.currentTimeMillis() < deadline) {
      Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
      Thread.sleep(20)
    }
    Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    assertTrue("Timed out waiting for condition", predicate())
  }

  @Test
  fun `foreground service distinguishes multi session controls and stops cleanly when idle`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val container = RustatioAppContainer.get(context)
    val repo = container.repository

    val bytes1 = sampleTorrentBytes("Service Torrent 1", "7")
    val info1 = BencodeParser.parseTorrent(bytes1, "svc1.torrent").getOrThrow()
    val bytes2 = sampleTorrentBytes("Service Torrent 2", "8")
    val info2 = BencodeParser.parseTorrent(bytes2, "svc2.torrent").getOrThrow()

    val (s1Id, s2Id) =
      runBlocking {
        val id1 = repo.createSession("Phiên Một").getOrThrow()
        val id2 = repo.createSession("Phiên Hai").getOrThrow()
        repo.importPendingTorrents(
          files = listOf(PendingImportFile("s1", "svc1.torrent", bytes1, info1)),
          options = TorrentImportOptions(targetSessionId = id1, uploadRateKBs = 500.0),
        ).getOrThrow()
        repo.importPendingTorrents(
          files = listOf(PendingImportFile("s2", "svc2.torrent", bytes2, info2)),
          options = TorrentImportOptions(targetSessionId = id2, uploadRateKBs = 300.0),
        ).getOrThrow()
        repo.sessionAction(id1, "start").getOrThrow()
        repo.sessionAction(id2, "start").getOrThrow()
        id1 to id2
      }

    awaitUntil {
      container.localEngine.statsMap.value.values.count { it.state == FakerState.RUNNING } == 2
    }

    val sessions = runBlocking { repo.localSessionsFlow.first() }
    val multiSummary =
      RustatioForegroundService.buildForegroundSummary(sessions, preferredSessionId = s1Id)
    assertTrue(multiSummary.hasRunning)
    assertEquals(2, multiSummary.totalForegroundTorrents)
    assertEquals(2, multiSummary.activeSessionsCount)
    assertEquals(s1Id, multiSummary.controlledSessionId)
    assertTrue(multiSummary.bigText.contains("Phiên Một"))
    assertTrue(multiSummary.bigText.contains("Phiên Hai"))

    val notif = RustatioForegroundService.buildNotification(context, multiSummary)
    assertEquals(2, notif.actions.size)
    assertEquals("Tạm dừng (Phiên Một)", notif.actions[0].title.toString())
    assertEquals("Dừng tất cả", notif.actions[1].title.toString())

    // Drive real RustatioForegroundService with session-targeted pause/resume & global stop
    val controller = Robolectric.buildService(RustatioForegroundService::class.java).create()
    val service = controller.get()
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java).putExtra(RustatioForegroundService.EXTRA_SESSION_ID, s1Id),
      0,
      1,
    )

    // ACTION_PAUSE_SESSION pauses ONLY Phiên Một, Phiên Hai keeps running
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java)
        .setAction(RustatioForegroundService.ACTION_PAUSE_SESSION)
        .putExtra(RustatioForegroundService.EXTRA_SESSION_ID, s1Id),
      0,
      2,
    )
    awaitUntil {
      val list = runBlocking { repo.localSessionsFlow.first() }
      list.first { it.id == s1Id }.pausedCount == 1 &&
        list.first { it.id == s2Id }.activeCount == 1
    }

    // ACTION_RESUME_SESSION resumes Phiên Một
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java)
        .setAction(RustatioForegroundService.ACTION_RESUME_SESSION)
        .putExtra(RustatioForegroundService.EXTRA_SESSION_ID, s1Id),
      0,
      3,
    )
    awaitUntil {
      val list = runBlocking { repo.localSessionsFlow.first() }
      list.first { it.id == s1Id }.activeCount == 1
    }

    // ACTION_STOP_ALL stops both sessions and stops service cleanly
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java).setAction(RustatioForegroundService.ACTION_STOP_ALL),
      0,
      4,
    )
    awaitUntil {
      container.localEngine.statsMap.value.values.all { it.state == FakerState.STOPPED } &&
        Shadows.shadowOf(service).isStoppedBySelf
    }
    assertTrue(Shadows.shadowOf(service).isStoppedBySelf)
    controller.destroy()
  }

  @Test
  fun `cold restart with interrupted active flag detects process kill honestly without faking running state`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = RustatioDatabase.getInstance(context)
    runBlocking {
      db.sessionDao().upsert(SessionEntity("s-kill", "Phiên Bị Đóng", 1000L))
      db.localInstanceDao().upsert(
        LocalInstanceEntity(
          id = "killed-1",
          sessionId = "s-kill",
          torrentJson = JsonCodecs.encodeTorrent(sampleTorrentInfo("Killed Torrent", "b".repeat(40))),
          configJson = JsonCodecs.encodeConfig(FakerConfig()),
          tagsJson = "[]",
          source = "manual",
          cumulativeUploadedBytes = 2048L,
          cumulativeDownloadedBytes = 0L,
          createdAtMs = 1000L,
          wasActiveBeforeStop = true,
        )
      )
    }

    RustatioAppContainer.resetForTests()
    val repo = RustatioAppContainer.get(context).repository

    awaitUntil { repo.interruptedInstances.value.size == 1 }
    runBlocking {
      val interrupted = repo.interruptedInstances.value
      assertEquals(1, interrupted.size)
      assertEquals("killed-1", interrupted.first().id)
      val current = repo.instancesFlow.first().first { it.id == "killed-1" }
      assertEquals(FakerState.STOPPED, current.effectiveState)

      repo.dismissInterruptedRecovery()
      assertTrue(repo.interruptedInstances.value.isEmpty())
      assertTrue(RustatioAppContainer.get(context).database.localInstanceDao().getActiveBeforeStop().isEmpty())
    }
  }
}
