package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.JsonCodecs
import com.example.data.local.RustatioDatabase
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.ClientType
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

  @After
  fun cleanup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    RustatioAppContainer.resetForTests()
    context.deleteDatabase("rustatio_db")
  }

  @Test
  fun `app_name matches Rustatio`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Rustatio", appName)
  }

  @Test
  fun `preset json export and import stays compatible with rustatio-preset format`() {
    val balanced = BuiltInPresets.all.first { it.id == "balanced" }
    val exported = JsonCodecs.exportPresetJson(balanced)
    assertTrue(exported.contains("\"type\": \"rustatio-preset\""))

    val imported = JsonCodecs.importPresetJson(exported)
    assertTrue(imported.isSuccess)
    val preset = imported.getOrThrow()
    assertEquals(balanced.name, preset.name)
    assertEquals(balanced.config.uploadRateKBs, preset.config.uploadRateKBs, 0.01)
    assertEquals(ClientType.QBITTORRENT, preset.config.clientType)

    val invalid = JsonCodecs.importPresetJson("{\"type\":\"other\"}")
    assertFalse(invalid.isSuccess)
  }

  @Test
  fun `root navigation and settings subscreen CUJ works in Vietnamese`() {
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("nav_sessions").assertIsDisplayed()
    composeRule.onNodeWithTag("nav_watch").assertIsDisplayed()
    composeRule.onNodeWithTag("nav_settings").assertIsDisplayed()

    // Navigate to Watch ("Theo dõi")
    composeRule.onNodeWithTag("nav_watch").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("watch_mode_saf").assertIsDisplayed()
    composeRule.onNodeWithTag("watch_mode_server").assertIsDisplayed()

    // Navigate to Settings ("Cài đặt") and open Appearance ("Giao diện")
    composeRule.onNodeWithTag("nav_settings").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("settings_row_appearance").performClick()
    composeRule.waitForIdle()

    // Subscreen hides bottom nav and shows theme options
    composeRule.onNodeWithTag("nav_sessions").assertDoesNotExist()
    composeRule.onNodeWithTag("theme_option_light").assertIsDisplayed()
    composeRule.onNodeWithTag("theme_option_dark").performClick()
    composeRule.waitForIdle()

    // Back returns to Settings root with bottom nav visible again
    composeRule.onNodeWithTag("settings_sub_back").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("nav_sessions").assertIsDisplayed()
  }

  @Test
  fun `screen 1 shows single add session button and creates empty session navigating to screen 2`() {
    composeRule.waitForIdle()

    // Screen 1 empty state: only 1 "Thêm phiên" button (empty state), no FAB, no torrent import
    composeRule.onNodeWithTag("sessions_add_empty_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_add_fab").assertDoesNotExist()
    composeRule.onAllNodesWithText("Nhập Torrent").apply {
      assertEquals(0, fetchSemanticsNodes().size)
    }
    composeRule.onAllNodesWithText("Thêm Torrent").apply {
      assertEquals(0, fetchSemanticsNodes().size)
    }

    // Create empty session without selecting any torrent
    composeRule.onNodeWithTag("sessions_add_empty_btn").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("create_session_name_input").performTextInput("Phiên Thử Nghiệm")
    composeRule.onNodeWithTag("create_session_confirm_btn").performClick()

    // Navigates to Screen 2 ("session_detail")
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithText("Phiên Thử Nghiệm").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("session_detail_title").assertIsDisplayed()
    composeRule.onNodeWithText("Phiên Thử Nghiệm").assertIsDisplayed()
    composeRule.onNodeWithTag("session_detail_empty_torrents").assertIsDisplayed()
    composeRule.onNodeWithTag("session_add_torrent_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("nav_sessions").assertDoesNotExist()

    // Back returns to Screen 1; now FAB is shown and empty-state button is gone
    composeRule.onNodeWithTag("session_detail_back_btn").performClick()
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithTag("sessions_add_fab").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("sessions_add_empty_btn").assertDoesNotExist()
    composeRule.onNodeWithText("Phiên Thử Nghiệm").assertIsDisplayed()
  }

  @Test
  fun `room database recovers cleanly from pre-existing higher version database`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbName = "rustatio_downgrade_test_db"
    context.deleteDatabase(dbName)

    val legacyHelper =
      object : SQLiteOpenHelper(context, dbName, null, 3) {
        override fun onCreate(db: SQLiteDatabase) {
          db.execSQL("CREATE TABLE IF NOT EXISTS legacy_table (id INTEGER PRIMARY KEY)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
      }
    legacyHelper.writableDatabase.close()
    legacyHelper.close()

    val db = RustatioDatabase.buildDatabase(context, dbName)
    try {
      assertEquals(2, db.openHelper.writableDatabase.version)
    } finally {
      db.close()
      context.deleteDatabase(dbName)
    }
  }
}
