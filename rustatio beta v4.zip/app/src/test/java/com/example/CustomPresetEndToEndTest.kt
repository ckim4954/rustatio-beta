package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class CustomPresetEndToEndTest {

  @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

  @After
  fun cleanup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    runCatching<Unit> {
      val container = RustatioAppContainer.get(context)
      runBlocking {
        val presets = container.database.customPresetDao().observeAll().first()
        for (p in presets) {
          container.database.customPresetDao().deleteById(p.id)
        }
        val instances = container.database.localInstanceDao().getAll()
        for (inst in instances) {
          container.database.localInstanceDao().deleteById(inst.id)
        }
      }
    }
    RustatioAppContainer.resetForTests()
    context.deleteDatabase("rustatio_db")
  }

  @Test
  fun `ui end to end create edit conditional postStopAction and apply preset to instance`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    composeRule.waitForIdle()

    // 1. Seed a Session and an instance inside it so Apply Preset has a torrent target
    val container = RustatioAppContainer.get(context)
    val instanceId =
      runBlocking {
        val sessionId = container.repository.createSession("Phiên Preset").getOrThrow()
        container.repository.createEmptySession(sessionId).getOrThrow()
      }

    // 2. Navigate Settings -> Presets -> Create Custom Preset
    composeRule.onNodeWithTag("nav_settings").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("settings_list").performScrollToNode(hasTestTag("settings_row_presets"))
    composeRule.onNodeWithTag("settings_row_presets").performClick()
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("presets_create_btn").performClick()
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithTag("preset_name_input").fetchSemanticsNodes().isNotEmpty()
    }

    composeRule.onNodeWithText("Tạo Preset tùy chỉnh").assertIsDisplayed()
    composeRule.onNodeWithTag("nav_settings").assertDoesNotExist()

    // 3. Initially all threshold stop conditions are OFF -> postStopAction section must NOT exist
    composeRule.onNodeWithTag("preset_post_stop_action_dropdown").assertDoesNotExist()

    // 4. Fill metadata & upload speed
    composeRule.onNodeWithTag("preset_name_input").performTextInput("UI Preset Đầy Đủ")
    composeRule.onNodeWithTag("preset_desc_input").performTextInput("Kiểm tra UI 28 trường")
    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_upload_rate_input"))
    composeRule.onNodeWithTag("preset_upload_rate_input").performTextReplacement("1250")

    // 5. Enable Progressive Rates and verify dependent inputs appear
    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_progressive_switch"))
    composeRule.onNodeWithTag("preset_progressive_switch").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_target_upload_input"))
    composeRule.onNodeWithTag("preset_target_upload_input").assertIsDisplayed()

    // 6. Toggle stopAtRatio ON -> postStopAction appears; toggle OFF -> disappears; toggle stopAtUploaded ON -> reappears
    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_stop_ratio_switch"))
    composeRule.onNodeWithTag("preset_stop_ratio_switch").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_post_stop_action_dropdown"))
    composeRule.onNodeWithTag("preset_post_stop_action_dropdown").assertIsDisplayed()

    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_stop_ratio_switch"))
    composeRule.onNodeWithTag("preset_stop_ratio_switch").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("preset_post_stop_action_dropdown").assertDoesNotExist()

    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_stop_uploaded_switch"))
    composeRule.onNodeWithTag("preset_stop_uploaded_switch").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("preset_editor_list").performScrollToNode(hasTestTag("preset_post_stop_action_dropdown"))
    composeRule.onNodeWithTag("preset_post_stop_action_dropdown").assertIsDisplayed()

    // 7. Save Preset -> return to Presets screen -> scroll LazyColumn to find saved preset
    composeRule.onNodeWithTag("preset_save_btn").performClick()
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithTag("presets_list").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("presets_list").performScrollToNode(hasText("UI Preset Đầy Đủ"))
    composeRule.onNodeWithText("UI Preset Đầy Đủ").assertIsDisplayed()

    val createdPreset =
      runBlocking {
        container.database.customPresetDao().observeAll().first().firstOrNull {
          it.name == "UI Preset Đầy Đủ"
        }
      }
    assertNotNull(createdPreset)
    val presetId = createdPreset!!.id

    // 8. Reopen in Edit mode via Edit button on PresetCard, verify title + edit name -> save
    composeRule.onNodeWithTag("presets_list").performScrollToNode(hasTestTag("preset_edit_$presetId"))
    composeRule.onNodeWithTag("preset_edit_$presetId").performClick()
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithText("Chỉnh sửa Preset tùy chỉnh").fetchSemanticsNodes().isNotEmpty() &&
        composeRule.onAllNodesWithTag("preset_name_input").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithText("UI Preset Đầy Đủ").assertIsDisplayed()
    composeRule.onNodeWithTag("preset_name_input").performTextReplacement("UI Preset Đã Sửa")
    composeRule.onNodeWithTag("preset_save_btn").performClick()

    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithTag("presets_list").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("presets_list").performScrollToNode(hasText("UI Preset Đã Sửa"))
    composeRule.onNodeWithText("UI Preset Đã Sửa").assertIsDisplayed()

    // 9. Apply preset to our Instance via Apply button -> select instance in dialog -> verify DB read-back
    composeRule.onNodeWithTag("presets_list").performScrollToNode(hasTestTag("preset_apply_$presetId"))
    composeRule.onNodeWithTag("preset_apply_$presetId").performClick()
    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule.onAllNodesWithTag("apply_preset_instance_$instanceId").fetchSemanticsNodes().isNotEmpty()
    }
    composeRule.onNodeWithTag("apply_preset_instance_$instanceId").performClick()

    composeRule.waitUntil(timeoutMillis = 5_000L) {
      composeRule
        .onAllNodesWithText("Đã áp dụng preset", substring = true)
        .fetchSemanticsNodes()
        .isNotEmpty()
    }

    val updatedInstance = runBlocking {
      container.repository.instancesFlow.first().first { it.id == instanceId }
    }
    assertEquals(1250.0, updatedInstance.config.uploadRateKBs, 0.01)
    assertTrue(updatedInstance.config.progressiveRatesEnabled)
    assertTrue(updatedInstance.config.stopAtUploadedEnabled)
  }
}
