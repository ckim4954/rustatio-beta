package com.example

import android.content.Context
import android.content.Intent
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTextInput
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.CustomPresetEntity
import com.example.data.local.JsonCodecs
import com.example.data.local.LocalInstanceEntity
import com.example.data.local.RustatioDatabase
import com.example.data.torrent.BencodeParser
import com.example.domain.model.ClientType
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.ImportMode
import com.example.domain.model.InstanceItem
import com.example.domain.model.PendingImportFile
import com.example.domain.model.TorrentImportOptions
import com.example.domain.model.TorrentInfo
import com.example.service.RustatioForegroundService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h891dp-xxhdpi")
class MasterFeatureAcceptanceTest {

  @get:Rule val composeRule = createAndroidComposeRule<MainActivity>()

  @After
  fun tearDown() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    RustatioAppContainer.resetForTests()
    context.deleteDatabase("rustatio_db")
    context.deleteDatabase("migration_verify_db")
  }

  private fun sampleTorrentBytes(name: String, pieceByte: String): ByteArray {
    val announce = "http://tracker.example.invalid:8080/announce"
    val infoDict =
      "d6:lengthi1048576e4:name${name.toByteArray().size}:$name" +
        "12:piece lengthi16384e6:pieces20:${pieceByte.repeat(20)}e"
    return "d8:announce${announce.length}:${announce}4:info${infoDict}e".toByteArray(Charsets.ISO_8859_1)
  }

  private fun sampleTorrentInfo(name: String, hashHex: String): TorrentInfo =
    TorrentInfo(
      infoHashHex = hashHex,
      announce = "http://tracker.example.invalid:8080/announce",
      name = name,
      totalSize = 1048576L * 100L,
      pieceLength = 16384L,
      numPieces = 6400,
    )

  @Test
  fun `room migration 1 to 2 preserves existing v1 instances and custom presets cleanly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    context.deleteDatabase("migration_verify_db")

    // Create genuine SQLite v1 schema on disk
    val helperConfig =
      SupportSQLiteOpenHelper.Configuration.builder(context)
        .name("migration_verify_db")
        .callback(
          object : SupportSQLiteOpenHelper.Callback(1) {
            override fun onCreate(db: SupportSQLiteDatabase) {
              db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `local_instances` (
                  `id` TEXT NOT NULL,
                  `torrentJson` TEXT,
                  `configJson` TEXT NOT NULL,
                  `tagsJson` TEXT NOT NULL,
                  `source` TEXT NOT NULL,
                  `cumulativeUploadedBytes` INTEGER NOT NULL,
                  `cumulativeDownloadedBytes` INTEGER NOT NULL,
                  `createdAtMs` INTEGER NOT NULL,
                  PRIMARY KEY(`id`)
                )
                """.trimIndent()
              )
              db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS `custom_presets` (
                  `id` TEXT NOT NULL,
                  `name` TEXT NOT NULL,
                  `description` TEXT NOT NULL,
                  `icon` TEXT NOT NULL,
                  `createdAt` TEXT,
                  `settingsJson` TEXT NOT NULL,
                  PRIMARY KEY(`id`)
                )
                """.trimIndent()
              )
              val tJson = JsonCodecs.encodeTorrent(sampleTorrentInfo("Ubuntu 24.04", "a".repeat(40)))
              val cJson = JsonCodecs.encodeConfig(FakerConfig(uploadRateKBs = 321.0))
              db.execSQL(
                "INSERT INTO `local_instances` VALUES ('v1-inst', ?, ?, '[\"linux\"]', 'manual', 123456, 654321, 1700000000000)",
                arrayOf(tJson, cJson),
              )
              val pJson = JsonCodecs.encodePresetSettings(FakerConfig(uploadRateKBs = 777.0)).toString()
              db.execSQL(
                "INSERT INTO `custom_presets` VALUES ('custom-v1', 'Preset Cu', 'Giu nguyen', 'star', '2026-01-01T00:00:00Z', ?)",
                arrayOf(pJson),
              )
            }

            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {}
          }
        )
        .build()

    val v1Db = FrameworkSQLiteOpenHelperFactory().create(helperConfig).writableDatabase
    v1Db.close()

    // Open with Room v2 and verify MIGRATION_1_2
    val v2Db =
      androidx.room.Room.databaseBuilder(context, RustatioDatabase::class.java, "migration_verify_db")
        .addMigrations(RustatioDatabase.MIGRATION_1_2)
        .allowMainThreadQueries()
        .build()

    runBlocking {
      val sessions = v2Db.sessionDao().getAll()
      assertTrue(sessions.any { it.id == InstanceItem.DEFAULT_SESSION_ID && it.name == InstanceItem.DEFAULT_SESSION_NAME })

      val instances = v2Db.localInstanceDao().getAll()
      assertEquals(1, instances.size)
      assertEquals("v1-inst", instances.first().id)
      assertEquals(InstanceItem.DEFAULT_SESSION_ID, instances.first().sessionId)
      assertEquals(123456L, instances.first().cumulativeUploadedBytes)
      assertEquals(654321L, instances.first().cumulativeDownloadedBytes)
      assertFalse(instances.first().wasActiveBeforeStop)
      assertEquals(321.0, JsonCodecs.decodeConfig(instances.first().configJson).uploadRateKBs, 0.01)

      val preset = v2Db.customPresetDao().getById("custom-v1")
      assertNotNull(preset)
      assertEquals("Preset Cu", preset!!.name)
      assertEquals(777.0, JsonCodecs.decodePresetConfig(preset.settingsJson).uploadRateKBs, 0.01)
    }
    v2Db.close()
  }

  @Test
  fun `import torrent remains visible after importing and supports config duplicate skip and two-level session isolation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val container = RustatioAppContainer.get(context)
    val repo = container.repository

    composeRule.waitForIdle()
    // 1. Both Nhập Torrent and Thêm phiên visible when list is empty
    composeRule.onNodeWithTag("sessions_import_torrent_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_add_session_btn").assertIsDisplayed()

    // 2. Import 2 valid torrents + 1 duplicate into a new Session ("Phiên A")
    val bytesA1 = sampleTorrentBytes("Torrent A1", "1")
    val bytesA2 = sampleTorrentBytes("Torrent A2", "2")
    val infoA1 = BencodeParser.parseTorrent(bytesA1, "a1.torrent").getOrThrow()
    val infoA2 = BencodeParser.parseTorrent(bytesA2, "a2.torrent").getOrThrow()

    val pendingBatch =
      listOf(
        PendingImportFile("u1", "a1.torrent", bytesA1, infoA1, isDuplicate = false),
        PendingImportFile("u2", "a2.torrent", bytesA2, infoA2, isDuplicate = false),
        PendingImportFile("u3", "a1-dup.torrent", bytesA1, infoA1, isDuplicate = true),
      )

    val importRes =
      runBlocking {
        repo.importPendingTorrents(
          files = pendingBatch,
          options =
            TorrentImportOptions(
              createNewSessionName = "Phiên A",
              mode = ImportMode.LEECH,
              clientType = ClientType.TRANSMISSION,
              clientVersion = "4.1.4",
              port = 51413,
              vpnPortSync = true,
              uploadRateKBs = 250.0,
              downloadRateKBs = 100.0,
              updateIntervalSeconds = 10,
              scrapeIntervalSeconds = 120,
              tags = listOf("movie", "hd"),
              autoStart = false,
            ),
        ).getOrThrow()
      }
    assertEquals(2, importRes.importedCount)
    assertEquals(listOf("a1-dup.torrent"), importRes.skippedDuplicates)

    // 3. Create independent Session B with 1 torrent B1
    val sessionBId = runBlocking { repo.createSessionGroup("Phiên B").getOrThrow().first }
    val bytesB1 = sampleTorrentBytes("Torrent B1", "3")
    val infoB1 = BencodeParser.parseTorrent(bytesB1, "b1.torrent").getOrThrow()
    runBlocking {
      repo.importPendingTorrents(
        files = listOf(PendingImportFile("u4", "b1.torrent", bytesB1, infoB1)),
        options = TorrentImportOptions(targetSessionId = sessionBId, uploadRateKBs = 90.0),
      ).getOrThrow()
    }

    composeRule.waitUntil(5_000L) {
      composeRule.onAllNodesWithTag("session_group_card_${importRes.sessionId}").fetchSemanticsNodes().isNotEmpty()
    }

    // 4. CRITICAL: Both Nhập Torrent and Thêm phiên STILL visible after importing & creating sessions
    composeRule.onNodeWithTag("sessions_import_torrent_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_add_session_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_multiselect_toggle").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_global_controls_btn").assertIsDisplayed()

    // Also filter with search -> buttons STILL visible!
    composeRule.onNodeWithTag("sessions_search_input").performTextInput("Phiên A")
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("sessions_import_torrent_btn").assertIsDisplayed()
    composeRule.onNodeWithTag("sessions_add_session_btn").assertIsDisplayed()

    // 5. Two-level Session control strictly isolated: start Session A, verify Session B stays STOPPED
    runBlocking {
      val startedCount = repo.sessionAction(importRes.sessionId, "start").getOrThrow()
      assertEquals(2, startedCount)
      val groups = repo.sessionGroupsFlow.first()
      val groupA = groups.first { it.id == importRes.sessionId }
      val groupB = groups.first { it.id == sessionBId }
      assertEquals(2, groupA.activeCount)
      assertEquals(0, groupB.activeCount)
      assertEquals(FakerState.STOPPED, groupB.instances.first().effectiveState)

      // Edit 1 torrent inside Session A independently without affecting sibling
      val a1 = groupA.instances.first { it.torrent?.name == "Torrent A1" }
      val a2 = groupA.instances.first { it.torrent?.name == "Torrent A2" }
      repo.updateSessionConfig(a1.id, a1.config.copy(uploadRateKBs = 999.0)).getOrThrow()
      val updatedGroups = repo.sessionGroupsFlow.first()
      val updatedA = updatedGroups.first { it.id == importRes.sessionId }
      assertEquals(999.0, updatedA.instances.first { it.id == a1.id }.config.uploadRateKBs, 0.01)
      assertEquals(250.0, updatedA.instances.first { it.id == a2.id }.config.uploadRateKBs, 0.01)
    }

    // 6. Verify Global Controls Dropdown & Multi-Select + Stop Confirm Dialog in Compose UI
    composeRule.onNodeWithTag("sessions_global_controls_btn").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithText("Dừng tất cả").assertIsDisplayed()
    composeRule.onNodeWithText("Tạm dừng tất cả").assertIsDisplayed()
    // Select "Dừng tất cả" -> opens RustatioConfirmDialog -> confirm -> stops Session A
    composeRule.onNodeWithText("Dừng tất cả").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("dialog_confirm_button").assertIsDisplayed().performClick()
    awaitUntil {
      runBlocking { repo.sessionGroupsFlow.first().first { it.id == importRes.sessionId }.activeCount == 0 }
    }

    // 7. Dismiss success banner & toggle Multi-Select mode via UI button -> verify Session checkbox + Bulk bar
    composeRule.onNodeWithText("Đóng").performClick()
    composeRule.onNodeWithTag("sessions_multiselect_toggle").performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("session_select_${importRes.sessionId}").assertIsDisplayed().performClick()
    composeRule.onNodeWithTag("bulk_delete_button").assertIsDisplayed()
    composeRule.onNodeWithTag("bulk_clear_button").performClick()
    composeRule.waitForIdle()
  }

  private fun awaitUntil(timeoutMs: Long = 5_000L, predicate: () -> Boolean) {
    val deadline = System.currentTimeMillis() + timeoutMs
    while (!predicate() && System.currentTimeMillis() < deadline) {
      Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
      Thread.sleep(20)
    }
    Shadows.shadowOf(android.os.Looper.getMainLooper()).idle()
    assertTrue("Timed out waiting for condition", predicate())
  }

  @Test
  fun `foreground service handles pause resume stop notification intents and stops itself when idle`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val container = RustatioAppContainer.get(context)
    val repo = container.repository

    val bytes = sampleTorrentBytes("Service Torrent", "7")
    val info = BencodeParser.parseTorrent(bytes, "svc.torrent").getOrThrow()
    runBlocking {
      val sessionId = repo.createSessionGroup("Phiên Nền").getOrThrow().first
      repo.importPendingTorrents(
        files = listOf(PendingImportFile("s1", "svc.torrent", bytes, info)),
        options = TorrentImportOptions(targetSessionId = sessionId, uploadRateKBs = 500.0),
      ).getOrThrow()
      val item = repo.instancesFlow.first().first()
      repo.startSession(item).getOrThrow()
    }

    awaitUntil {
      container.localEngine.statsMap.value.values.firstOrNull()?.state == FakerState.RUNNING
    }

    val groups = runBlocking { repo.localSessionGroupsFlow.first() }
    val runningSummary = RustatioForegroundService.buildForegroundSummary(groups)
    assertTrue(runningSummary.hasRunning)
    assertEquals(1, runningSummary.totalForegroundTorrents)
    assertTrue(runningSummary.body.contains("Phiên Nền"))

    val notif = RustatioForegroundService.buildNotification(context, runningSummary)
    assertEquals(2, notif.actions.size) // Tạm dừng + Dừng

    // Drive real RustatioForegroundService through notification action Intents
    val controller = Robolectric.buildService(RustatioForegroundService::class.java).create()
    val service = controller.get()
    service.onStartCommand(Intent(context, RustatioForegroundService::class.java), 0, 1)

    // Send ACTION_PAUSE_ALL
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java).setAction(RustatioForegroundService.ACTION_PAUSE_ALL),
      0,
      2,
    )
    awaitUntil {
      container.localEngine.statsMap.value.values.firstOrNull()?.state == FakerState.PAUSED
    }

    val pausedSummary =
      RustatioForegroundService.buildForegroundSummary(runBlocking { repo.localSessionGroupsFlow.first() })
    assertTrue(pausedSummary.hasPaused)
    val pausedNotif = RustatioForegroundService.buildNotification(context, pausedSummary)
    assertEquals("Tiếp tục", pausedNotif.actions[0].title.toString())

    // Send ACTION_RESUME_ALL
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java).setAction(RustatioForegroundService.ACTION_RESUME_ALL),
      0,
      3,
    )
    awaitUntil {
      container.localEngine.statsMap.value.values.firstOrNull()?.state == FakerState.RUNNING
    }

    // Send ACTION_STOP_ALL -> service stops engine & stops itself cleanly
    service.onStartCommand(
      Intent(context, RustatioForegroundService::class.java).setAction(RustatioForegroundService.ACTION_STOP_ALL),
      0,
      4,
    )
    awaitUntil {
      container.localEngine.statsMap.value.values.firstOrNull()?.state == FakerState.STOPPED &&
        Shadows.shadowOf(service).isStoppedBySelf
    }
    assertTrue(Shadows.shadowOf(service).isStoppedBySelf)
    controller.destroy()
  }

  @Test
  fun `cold restart with interrupted active flag detects process kill honestly without faking running state`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db = RustatioDatabase.getInstance(context)
    runBlocking {
      db.sessionDao().upsert(com.example.data.local.SessionEntity("s-kill", "Phiên Bị Đóng", 1000L))
      db.localInstanceDao().upsert(
        LocalInstanceEntity(
          id = "killed-1",
          sessionId = "s-kill",
          torrentJson = JsonCodecs.encodeTorrent(sampleTorrentInfo("Killed Torrent", "b".repeat(40))),
          configJson = JsonCodecs.encodeConfig(FakerConfig()),
          tagsJson = "[]",
          source = "manual",
          cumulativeUploadedBytes = 2048L,
          cumulativeDownloadedBytes = 0L,
          createdAtMs = 1000L,
          wasActiveBeforeStop = true,
        )
      )
    }

    // Re-create container cleanly as cold process start and force repository init
    RustatioAppContainer.resetForTests()
    val repo = RustatioAppContainer.get(context).repository

    awaitUntil { repo.interruptedInstances.value.size == 1 }
    runBlocking {
      val interrupted = repo.interruptedInstances.value
      assertEquals(1, interrupted.size)
      assertEquals("killed-1", interrupted.first().id)
      // Must report STOPPED honestly — never fake RUNNING when no engine job exists!
      val current = repo.instancesFlow.first().first { it.id == "killed-1" }
      assertEquals(FakerState.STOPPED, current.effectiveState)

      repo.dismissInterruptedRecovery()
      assertTrue(repo.interruptedInstances.value.isEmpty())
      assertTrue(RustatioAppContainer.get(context).database.localInstanceDao().getActiveBeforeStop().isEmpty())
    }
  }
}
