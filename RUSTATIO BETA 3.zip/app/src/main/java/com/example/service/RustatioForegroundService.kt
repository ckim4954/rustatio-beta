package com.example.service

import android.app.ForegroundServiceStartNotAllowedException
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.RustatioAppContainer
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.domain.model.LogLevel
import com.example.domain.model.SessionGroup
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

data class ForegroundSummary(
  val title: String,
  val body: String,
  val hasRunning: Boolean,
  val hasPaused: Boolean,
  val totalForegroundTorrents: Int,
)

class RustatioForegroundService : Service() {
  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var observerJob: Job? = null

  override fun onCreate() {
    super.onCreate()
    ensureNotificationChannel(this)
    startObservingSessions()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    ensureNotificationChannel(this)
    val container = RustatioAppContainer.get(applicationContext)
    when (intent?.action) {
      ACTION_PAUSE_ALL -> {
        serviceScope.launch(Dispatchers.IO) { container.repository.pauseAllLocalActive() }
      }
      ACTION_RESUME_ALL -> {
        serviceScope.launch(Dispatchers.IO) { container.repository.resumeAllLocalPaused() }
      }
      ACTION_STOP_ALL -> {
        serviceScope.launch(Dispatchers.IO) {
          container.repository.stopAllLocalActiveOrPaused()
          kotlinx.coroutines.withContext(Dispatchers.Main.immediate) {
            stopServiceCleanly()
          }
        }
        return START_NOT_STICKY
      }
    }

    val summary =
      buildForegroundSummary(container.repository.currentLocalSessionSnapshot())
    promoteToForeground(buildNotification(this, summary))
    if (summary.totalForegroundTorrents == 0 && intent?.action != ACTION_START_KEEPALIVE) {
      stopServiceCleanly()
      return START_NOT_STICKY
    }
    return START_STICKY
  }

  override fun onTimeout(startId: Int, fgsType: Int) {
    val container = RustatioAppContainer.get(applicationContext)
    container.localEngine.appendLog(
      LogLevel.WARN,
      null,
      "Hệ điều hành đã đạt giới hạn thời gian dịch vụ chạy nền dataSync; tạm dừng và lưu trạng thái an toàn.",
    )
    serviceScope.launch {
      container.repository.stopAllLocalActiveOrPaused(markRecovered = false)
      stopServiceCleanly()
    }
    super.onTimeout(startId, fgsType)
  }

  override fun onDestroy() {
    observerJob?.cancel()
    serviceScope.cancel()
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun startObservingSessions() {
    observerJob?.cancel()
    val container = RustatioAppContainer.get(applicationContext)
    observerJob =
      serviceScope.launch {
        container.repository.localSessionGroupsFlow.collectLatest { groups ->
          val summary = buildForegroundSummary(groups)
          if (summary.totalForegroundTorrents == 0) {
            stopServiceCleanly()
          } else {
            val nm = getSystemService(NotificationManager::class.java)
            nm?.notify(NOTIFICATION_ID, buildNotification(this@RustatioForegroundService, summary))
          }
        }
      }
  }

  private fun promoteToForeground(notification: Notification) {
    try {
      val fgsType =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
          ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        } else {
          0
        }
      ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)
    } catch (_: Throwable) {
      // Handles ForegroundServiceStartNotAllowedException cleanly if OS restricts bg start
    }
  }

  private fun stopServiceCleanly() {
    runCatching {
      ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    }
    stopSelf()
  }

  companion object {
    const val CHANNEL_ID = "rustatio_background_channel"
    const val NOTIFICATION_ID = 2141
    const val ACTION_START_KEEPALIVE = "com.example.action.FGS_KEEPALIVE"
    const val ACTION_PAUSE_ALL = "com.example.action.FGS_PAUSE_ALL"
    const val ACTION_RESUME_ALL = "com.example.action.FGS_RESUME_ALL"
    const val ACTION_STOP_ALL = "com.example.action.FGS_STOP_ALL"

    fun ensureNotificationChannel(context: Context) {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
          val channel =
            NotificationChannel(
                CHANNEL_ID,
                "Hoạt động chạy nền Rustatio",
                NotificationManager.IMPORTANCE_LOW,
              )
              .apply {
                description = "Hiển thị trạng thái phiên, tốc độ giả lập và nút điều khiển nhanh."
                setShowBadge(false)
              }
          manager.createNotificationChannel(channel)
        }
      }
    }

    fun startOrUpdate(context: Context, forceKeepAlive: Boolean = false) {
      val appCtx = context.applicationContext
      ensureNotificationChannel(appCtx)
      val intent =
        Intent(appCtx, RustatioForegroundService::class.java).apply {
          action = if (forceKeepAlive) ACTION_START_KEEPALIVE else null
        }
      try {
        ContextCompat.startForegroundService(appCtx, intent)
      } catch (e: Throwable) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
          e is ForegroundServiceStartNotAllowedException
        ) {
          // App in background restriction: engine logs notice without crashing
          runCatching {
            RustatioAppContainer.get(appCtx).localEngine.appendLog(
              LogLevel.WARN,
              null,
              "Không thể khởi chạy dịch vụ nền khi ứng dụng đang bị hệ thống hạn chế nền.",
            )
          }
        }
      }
    }

    fun stop(context: Context) {
      val appCtx = context.applicationContext
      runCatching {
        appCtx.stopService(Intent(appCtx, RustatioForegroundService::class.java))
      }
    }

    fun buildForegroundSummary(groups: List<SessionGroup>): ForegroundSummary {
      val runningInstances = groups.flatMap { it.instances }.filter { it.effectiveState.isActive }
      val pausedInstances =
        groups.flatMap { it.instances }.filter { it.effectiveState == FakerState.PAUSED }
      val total = runningInstances.size + pausedInstances.size

      val activeSessions =
        groups.filter { g ->
          g.instances.any { it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED }
        }
      val sessionLabel =
        when {
          activeSessions.isEmpty() -> "Không có phiên chạy nền"
          activeSessions.size == 1 -> "Phiên: ${activeSessions.first().name}"
          else -> "${activeSessions.size} phiên đang mở"
        }

      val upRate = runningInstances.sumOf { it.stats.currentUploadRateKBs }
      val dlRate = runningInstances.sumOf { it.stats.currentDownloadRateKBs }

      val title =
        when {
          runningInstances.isNotEmpty() && pausedInstances.isNotEmpty() ->
            "Rustatio · ${runningInstances.size} đang chạy, ${pausedInstances.size} tạm dừng"
          runningInstances.isNotEmpty() ->
            "Rustatio đang chạy · ${runningInstances.size} torrent"
          pausedInstances.isNotEmpty() ->
            "Rustatio đang tạm dừng · ${pausedInstances.size} torrent"
          else -> "Rustatio · Sẵn sàng"
        }

      val body =
        "$sessionLabel · ↑ ${Formatters.formatSpeedKBs(upRate)} · ↓ ${Formatters.formatSpeedKBs(dlRate)}"

      return ForegroundSummary(
        title = title,
        body = body,
        hasRunning = runningInstances.isNotEmpty(),
        hasPaused = pausedInstances.isNotEmpty(),
        totalForegroundTorrents = total,
      )
    }

    fun buildNotification(context: Context, summary: ForegroundSummary): Notification {
      val openAppIntent =
        Intent(context, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
      val contentPending =
        PendingIntent.getActivity(
          context,
          0,
          openAppIntent,
          PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

      val builder =
        NotificationCompat.Builder(context, CHANNEL_ID)
          .setSmallIcon(R.mipmap.ic_launcher)
          .setContentTitle(summary.title)
          .setContentText(summary.body)
          .setStyle(NotificationCompat.BigTextStyle().bigText(summary.body))
          .setContentIntent(contentPending)
          .setOngoing(summary.totalForegroundTorrents > 0)
          .setOnlyAlertOnce(true)
          .setPriority(NotificationCompat.PRIORITY_LOW)
          .setCategory(NotificationCompat.CATEGORY_SERVICE)
          .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)

      if (summary.hasRunning) {
        builder.addAction(
          0,
          "Tạm dừng",
          actionPendingIntent(context, ACTION_PAUSE_ALL, 1),
        )
      }
      if (summary.hasPaused) {
        builder.addAction(
          0,
          "Tiếp tục",
          actionPendingIntent(context, ACTION_RESUME_ALL, 2),
        )
      }
      if (summary.hasRunning || summary.hasPaused) {
        builder.addAction(
          0,
          "Dừng",
          actionPendingIntent(context, ACTION_STOP_ALL, 3),
        )
      }
      return builder.build()
    }

    private fun actionPendingIntent(
      context: Context,
      actionName: String,
      requestCode: Int,
    ): PendingIntent {
      val intent = Intent(context, RustatioForegroundService::class.java).apply { action = actionName }
      return PendingIntent.getService(
        context,
        requestCode,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    }
  }
}
