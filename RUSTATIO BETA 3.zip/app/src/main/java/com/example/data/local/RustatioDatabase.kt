package com.example.data.local

import android.content.Context
import androidx.annotation.VisibleForTesting
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
  entities = [SessionEntity::class, LocalInstanceEntity::class, CustomPresetEntity::class],
  version = 2,
  exportSchema = false,
)
abstract class RustatioDatabase : RoomDatabase() {
  abstract fun sessionDao(): SessionDao

  abstract fun localInstanceDao(): LocalInstanceDao

  abstract fun customPresetDao(): CustomPresetDao

  companion object {
    val MIGRATION_1_2: Migration =
      object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `sessions` (
              `id` TEXT NOT NULL,
              `name` TEXT NOT NULL,
              `createdAtMs` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL(
            """
            INSERT OR IGNORE INTO `sessions` (`id`, `name`, `createdAtMs`)
            VALUES ('default-session', 'Phiên mặc định', ${System.currentTimeMillis()})
            """.trimIndent()
          )
          db.execSQL(
            "ALTER TABLE `local_instances` ADD COLUMN `sessionId` TEXT NOT NULL DEFAULT 'default-session'"
          )
          db.execSQL(
            "ALTER TABLE `local_instances` ADD COLUMN `wasActiveBeforeStop` INTEGER NOT NULL DEFAULT 0"
          )
        }
      }

    @Volatile private var instance: RustatioDatabase? = null

    fun getInstance(context: Context): RustatioDatabase =
      instance
        ?: synchronized(this) {
          instance
            ?: Room.databaseBuilder(
                context.applicationContext,
                RustatioDatabase::class.java,
                "rustatio_db",
              )
              .addMigrations(MIGRATION_1_2)
              .build()
              .also { instance = it }
        }

    @VisibleForTesting
    fun closeAndResetForTests() {
      synchronized(this) {
        instance?.let { db ->
          runCatching { db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close() }
          runCatching { db.close() }
        }
        instance = null
      }
    }
  }
}
