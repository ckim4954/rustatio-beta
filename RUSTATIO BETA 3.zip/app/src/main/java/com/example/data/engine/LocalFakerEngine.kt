package com.example.data.engine

import com.example.data.remote.RustatioServerClient
import com.example.domain.model.FakerConfig
import com.example.domain.model.FakerState
import com.example.domain.model.FakerStats
import com.example.domain.model.LogEntry
import com.example.domain.model.LogLevel
import com.example.domain.model.PostStopAction
import com.example.domain.model.ProxySettings
import com.example.domain.model.TorrentInfo
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Local Android ratio faker engine mirroring `rustatio-core/src/faker.rs`:
 * - Rate randomization (±randomRangePercent)
 * - Progressive rate ramp-up
 * - Stop conditions (ratio, uploaded GB, downloaded GB, seed time, idle when no leechers/seeders)
 * - Real HTTP/HTTPS tracker announces (and honest warning when UDP tracker requires rustatio-server)
 */
class LocalFakerEngine(
  private val serverClient: RustatioServerClient,
) {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  private val jobs = ConcurrentHashMap<String, Job>()
  private val logCounter = AtomicLong(1L)

  private val _statsMap = MutableStateFlow<Map<String, FakerStats>>(emptyMap())
  val statsMap: StateFlow<Map<String, FakerStats>> = _statsMap.asStateFlow()

  private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
  val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

  private var currentProxy: ProxySettings = ProxySettings()
  private var onStatsPersisted: (suspend (String, Long, Long) -> Unit)? = null
  private var onAutoDeleteRequested: (suspend (String) -> Unit)? = null
  private var onStoppedCallback: (suspend (String) -> Unit)? = null

  fun attachCallbacks(
    persistTotals: suspend (String, Long, Long) -> Unit,
    deleteInstance: suspend (String) -> Unit,
    onStopped: suspend (String) -> Unit = {},
  ) {
    onStatsPersisted = persistTotals
    onAutoDeleteRequested = deleteInstance
    onStoppedCallback = onStopped
  }

  fun updateProxy(proxy: ProxySettings) {
    currentProxy = proxy
  }

  fun appendLog(level: LogLevel, instanceId: String?, message: String) {
    val entry =
      LogEntry(
        id = logCounter.getAndIncrement(),
        timestampMs = System.currentTimeMillis(),
        level = level,
        instanceId = instanceId,
        message = message,
      )
    _logs.update { current ->
      val next = current + entry
      if (next.size > 500) next.takeLast(500) else next
    }
  }

  fun clearLogs() {
    _logs.value = emptyList()
  }

  fun start(
    instanceId: String,
    torrent: TorrentInfo,
    config: FakerConfig,
    baseUploadedBytes: Long,
    baseDownloadedBytes: Long,
  ) {
    jobs[instanceId]?.cancel()

    val peerId = buildPeerId(config.clientType.peerIdPrefix)
    val key = "%08X".format(Random.nextInt())
    val effectiveStopRatio =
      if (config.stopAtRatioEnabled) {
        if (config.randomizeRatio && config.randomRatioRangePercent > 0.0) {
          val delta = config.stopAtRatio * (config.randomRatioRangePercent / 100.0)
          (config.stopAtRatio + Random.nextDouble(-delta, delta)).coerceAtLeast(0.01)
        } else {
          config.stopAtRatio
        }
      } else null

    val initialDl =
      if (baseDownloadedBytes > 0L) baseDownloadedBytes
      else ((torrent.totalSize * config.completionPercent) / 100.0).toLong().coerceAtLeast(0L)
    val initialUp =
      if (baseUploadedBytes > 0L) baseUploadedBytes
      else config.initialUploadedMB * 1024L * 1024L
    val leftBytes = (torrent.totalSize - initialDl).coerceAtLeast(0L)

    updateStats(instanceId) {
      FakerStats(
        state = FakerState.STARTING,
        uploadedBytes = initialUp,
        downloadedBytes = initialDl,
        ratio = if (torrent.totalSize > 0L) initialUp.toDouble() / torrent.totalSize else 0.0,
        leftBytes = leftBytes,
        torrentCompletion = config.completionPercent,
        effectiveStopAtRatio = effectiveStopRatio,
      )
    }

    appendLog(
      LogLevel.INFO,
      instanceId,
      "[Phiên $instanceId] Bắt đầu giả lập '${torrent.name}' (${config.clientType.displayName} ${config.clientVersion})",
    )

    val job =
      scope.launch {
        var currentSeeders = 0
        var currentLeechers = 0
        var announceIntervalSec = 1800
        var lastAnnounceElapsed = -1L
        var announceCount = 0
        var trackerError: String? = null

        val firstAnnounce =
          serverClient.announceTracker(
            torrent = torrent,
            config = config,
            peerId = peerId,
            key = key,
            uploaded = initialUp,
            downloaded = initialDl,
            left = leftBytes,
            event = "started",
            proxy = currentProxy,
          )
        firstAnnounce
          .onSuccess { res ->
            currentSeeders = res.seeders
            currentLeechers = res.leechers
            announceIntervalSec = res.intervalSeconds.coerceAtLeast(60)
            announceCount = 1
            lastAnnounceElapsed = 0L
            trackerError = null
            appendLog(
              LogLevel.INFO,
              instanceId,
              "[Phiên $instanceId] Announce 'started' thành công — Seeders: $currentSeeders, Leechers: $currentLeechers",
            )
          }
          .onFailure { err ->
            trackerError = err.message
            appendLog(
              LogLevel.WARN,
              instanceId,
              "[Phiên $instanceId] Không thể announce tracker (${err.message}); tiếp tục đếm phiên cục bộ.",
            )
          }

        var sessionUp = 0L
        var sessionDl = 0L
        var currentLeft = leftBytes
        var elapsed = 0L
        var stopConditionTriggered = false
        val tickSecs = 1L

        val upHistory = mutableListOf<Double>()
        val dlHistory = mutableListOf<Double>()
        val ratioHistory = mutableListOf<Double>()
        val timestamps = mutableListOf<Long>()

        updateStats(instanceId) { prev ->
          prev.copy(
            state = FakerState.RUNNING,
            seeders = currentSeeders,
            leechers = currentLeechers,
            announceCount = announceCount,
            trackerError = trackerError,
          )
        }

        while (isActive) {
          delay(1000L)
          val latest = _statsMap.value[instanceId] ?: break
          if (latest.state == FakerState.PAUSED) {
            continue
          }
          if (latest.state == FakerState.STOPPED || latest.state == FakerState.STOPPING) {
            break
          }

          elapsed += tickSecs

          val baseUpRate =
            computeTargetRate(
              base = config.uploadRateKBs,
              target = config.targetUploadRateKBs,
              progressive = config.progressiveRatesEnabled,
              durationHours = config.progressiveDurationHours,
              elapsedSec = elapsed,
            )
          val baseDlRate =
            computeTargetRate(
              base = config.downloadRateKBs,
              target = config.targetDownloadRateKBs,
              progressive = config.progressiveRatesEnabled,
              durationHours = config.progressiveDurationHours,
              elapsedSec = elapsed,
            )

          val idleNoLeech =
            config.idleWhenNoLeechers && announceCount > 0 && currentLeechers == 0
          val idleNoSeed =
            config.idleWhenNoSeeders && announceCount > 0 && currentSeeders == 0 && currentLeft > 0L

          val actualUpRate =
            if (stopConditionTriggered || idleNoLeech) 0.0
            else randomizeRate(baseUpRate, config.randomizeRates, config.randomRangePercent)
          val actualDlRate =
            if (stopConditionTriggered || idleNoSeed || currentLeft <= 0L) 0.0
            else randomizeRate(baseDlRate, config.randomizeRates, config.randomRangePercent)

          val deltaUp = (actualUpRate * 1024.0 * tickSecs).toLong().coerceAtLeast(0L)
          val deltaDl =
            min(currentLeft, (actualDlRate * 1024.0 * tickSecs).toLong().coerceAtLeast(0L))

          sessionUp += deltaUp
          sessionDl += deltaDl
          currentLeft = (currentLeft - deltaDl).coerceAtLeast(0L)

          val totalUp = initialUp + sessionUp
          val totalDl = initialDl + sessionDl
          val sizeSafe = max(1L, torrent.totalSize)
          val totalRatio = totalUp.toDouble() / sizeSafe
          val sessionRatio = sessionUp.toDouble() / sizeSafe
          val avgUp = if (elapsed > 0L) (sessionUp / 1024.0) / elapsed else 0.0
          val avgDl = if (elapsed > 0L) (sessionDl / 1024.0) / elapsed else 0.0
          val completion =
            if (torrent.totalSize > 0L) {
              ((torrent.totalSize - currentLeft).toDouble() / torrent.totalSize * 100.0).coerceIn(
                0.0,
                100.0,
              )
            } else config.completionPercent

          // Progress calculations
          val ratioProgress =
            if (effectiveStopRatio != null && effectiveStopRatio > 0.0) {
              (sessionRatio / effectiveStopRatio * 100.0).coerceIn(0.0, 100.0)
            } else 0.0
          val targetUpBytes = (config.stopAtUploadedGB * 1024.0 * 1024.0 * 1024.0).toLong()
          val uploadProgress =
            if (config.stopAtUploadedEnabled && targetUpBytes > 0L) {
              (sessionUp.toDouble() / targetUpBytes * 100.0).coerceIn(0.0, 100.0)
            } else 0.0
          val targetDlBytes = (config.stopAtDownloadedGB * 1024.0 * 1024.0 * 1024.0).toLong()
          val downloadProgress =
            if (config.stopAtDownloadedEnabled && targetDlBytes > 0L) {
              (sessionDl.toDouble() / targetDlBytes * 100.0).coerceIn(0.0, 100.0)
            } else 0.0
          val targetSeedSecs = (config.stopAtSeedTimeHours * 3600.0).toLong()
          val seedProgress =
            if (config.stopAtSeedTimeEnabled && targetSeedSecs > 0L) {
              (elapsed.toDouble() / targetSeedSecs * 100.0).coerceIn(0.0, 100.0)
            } else 0.0

          val etaRatio =
            if (effectiveStopRatio != null && avgUp > 0.01) {
              val remBytes = ((effectiveStopRatio * sizeSafe) - sessionUp).coerceAtLeast(0.0)
              (remBytes / (avgUp * 1024.0)).toLong()
            } else null
          val etaUpload =
            if (config.stopAtUploadedEnabled && avgUp > 0.01) {
              val remBytes = (targetUpBytes - sessionUp).coerceAtLeast(0L)
              (remBytes / (avgUp * 1024.0)).toLong()
            } else null
          val etaSeed =
            if (config.stopAtSeedTimeEnabled) (targetSeedSecs - elapsed).coerceAtLeast(0L)
            else null

          if (elapsed % config.updateIntervalSeconds.coerceAtLeast(1) == 0L || upHistory.isEmpty()) {
            upHistory.add(actualUpRate)
            dlHistory.add(actualDlRate)
            ratioHistory.add(totalRatio)
            timestamps.add(System.currentTimeMillis())
            if (upHistory.size > 90) {
              upHistory.removeAt(0)
              dlHistory.removeAt(0)
              ratioHistory.removeAt(0)
              timestamps.removeAt(0)
            }
          }

          val stopMetNow =
            stopConditionTriggered ||
              (effectiveStopRatio != null && sessionRatio >= effectiveStopRatio) ||
              (config.stopAtUploadedEnabled && targetUpBytes > 0L && sessionUp >= targetUpBytes) ||
              (config.stopAtDownloadedEnabled && targetDlBytes > 0L && sessionDl >= targetDlBytes) ||
              (config.stopAtSeedTimeEnabled && targetSeedSecs > 0L && elapsed >= targetSeedSecs)
          val newlyTriggered = stopMetNow && !stopConditionTriggered
          stopConditionTriggered = stopMetNow

          if (elapsed - lastAnnounceElapsed >= announceIntervalSec) {
            lastAnnounceElapsed = elapsed
            serverClient
              .announceTracker(
                torrent = torrent,
                config = config,
                peerId = peerId,
                key = key,
                uploaded = totalUp,
                downloaded = totalDl,
                left = currentLeft,
                event = null,
                proxy = currentProxy,
              )
              .onSuccess { res ->
                currentSeeders = res.seeders
                currentLeechers = res.leechers
                announceIntervalSec = res.intervalSeconds.coerceAtLeast(60)
                announceCount++
                trackerError = null
              }
              .onFailure { trackerError = it.message }
          }

          val idlingDueToStop =
            stopConditionTriggered && config.postStopAction == PostStopAction.IDLE
          val idlingReason =
            when {
              idlingDueToStop -> "stop_condition_met"
              idleNoLeech -> "no_leechers"
              idleNoSeed -> "no_seeders"
              else -> null
            }
          val shouldStopLoop =
            stopConditionTriggered && config.postStopAction != PostStopAction.IDLE

          updateStats(instanceId) {
            FakerStats(
              state = if (shouldStopLoop) FakerState.STOPPED else FakerState.RUNNING,
              uploadedBytes = totalUp,
              downloadedBytes = totalDl,
              ratio = totalRatio,
              leftBytes = currentLeft,
              torrentCompletion = completion,
              seeders = currentSeeders,
              leechers = currentLeechers,
              isIdling = idlingDueToStop || idleNoLeech || idleNoSeed,
              idlingReason = idlingReason,
              trackerError = trackerError,
              sessionUploadedBytes = sessionUp,
              sessionDownloadedBytes = sessionDl,
              sessionRatio = sessionRatio,
              elapsedSeconds = elapsed,
              currentUploadRateKBs = if (shouldStopLoop) 0.0 else actualUpRate,
              currentDownloadRateKBs = if (shouldStopLoop) 0.0 else actualDlRate,
              averageUploadRateKBs = avgUp,
              averageDownloadRateKBs = avgDl,
              uploadProgress = uploadProgress,
              downloadProgress = downloadProgress,
              ratioProgress = ratioProgress,
              seedTimeProgress = seedProgress,
              effectiveStopAtRatio = effectiveStopRatio,
              etaRatioSeconds = etaRatio,
              etaUploadedSeconds = etaUpload,
              etaSeedTimeSeconds = etaSeed,
              announceCount = announceCount,
              uploadRateHistory = upHistory.toList(),
              downloadRateHistory = dlHistory.toList(),
              ratioHistory = ratioHistory.toList(),
              historyTimestamps = timestamps.toList(),
              stopConditionMet = stopConditionTriggered,
            )
          }

          if (elapsed % 10L == 0L) {
            onStatsPersisted?.invoke(instanceId, totalUp, totalDl)
          }

          if (newlyTriggered) {
            appendLog(
              LogLevel.INFO,
              instanceId,
              "[Phiên $instanceId] Đạt điều kiện dừng tự động — hành động: ${config.postStopAction.wireName}",
            )
            onStatsPersisted?.invoke(instanceId, totalUp, totalDl)
          }

          if (shouldStopLoop) {
            if (config.postStopAction == PostStopAction.DELETE_INSTANCE) {
              onAutoDeleteRequested?.invoke(instanceId)
            } else {
              onStoppedCallback?.invoke(instanceId)
            }
            break
          }
        }
      }
    jobs[instanceId] = job
  }

  fun pause(instanceId: String) {
    updateStats(instanceId) {
      it.copy(state = FakerState.PAUSED, currentUploadRateKBs = 0.0, currentDownloadRateKBs = 0.0)
    }
    appendLog(LogLevel.INFO, instanceId, "[Phiên $instanceId] Đã tạm dừng phiên giả lập.")
  }

  fun resume(instanceId: String) {
    updateStats(instanceId) { it.copy(state = FakerState.RUNNING) }
    appendLog(LogLevel.INFO, instanceId, "[Phiên $instanceId] Tiếp tục chạy phiên giả lập.")
  }

  suspend fun stop(instanceId: String) {
    jobs.remove(instanceId)?.cancel()
    val stats = _statsMap.value[instanceId]
    if (stats != null) {
      onStatsPersisted?.invoke(instanceId, stats.uploadedBytes, stats.downloadedBytes)
    }
    updateStats(instanceId) {
      it.copy(state = FakerState.STOPPED, currentUploadRateKBs = 0.0, currentDownloadRateKBs = 0.0)
    }
    appendLog(LogLevel.INFO, instanceId, "[Phiên $instanceId] Đã dừng phiên giả lập.")
  }

  fun shutdownForTests() {
    jobs.values.forEach { it.cancel() }
    jobs.clear()
  }

  private fun updateStats(instanceId: String, transform: (FakerStats) -> FakerStats) {
    _statsMap.update { map ->
      val current = map[instanceId] ?: FakerStats()
      map + (instanceId to transform(current))
    }
  }

  private fun computeTargetRate(
    base: Double,
    target: Double,
    progressive: Boolean,
    durationHours: Double,
    elapsedSec: Long,
  ): Double {
    if (!progressive || durationHours <= 0.0) return base.coerceAtLeast(0.0)
    val totalSec = (durationHours * 3600.0).coerceAtLeast(1.0)
    val progress = (elapsedSec / totalSec).coerceIn(0.0, 1.0)
    return (base + (target - base) * progress).coerceAtLeast(0.0)
  }

  private fun randomizeRate(rate: Double, enabled: Boolean, percent: Double): Double {
    if (!enabled || rate <= 0.0 || percent <= 0.0) return rate.coerceAtLeast(0.0)
    val variance = rate * (percent / 100.0)
    return (rate + Random.nextDouble(-variance, variance)).coerceAtLeast(0.0)
  }

  private fun buildPeerId(prefix: String): String {
    val chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    val suffixLen = (20 - prefix.length).coerceAtLeast(0)
    val suffix = (0 until suffixLen).map { chars.random() }.joinToString("")
    return prefix + suffix
  }
}
