package com.example.ui.sessions

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.domain.model.InstanceItem
import com.example.domain.model.SessionGroup
import com.example.ui.components.StatusBadge
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@Composable
fun SessionGroupCard(
  group: SessionGroup,
  expanded: Boolean,
  selectionMode: Boolean,
  selectedIds: Set<String>,
  onToggleExpanded: () -> Unit,
  onToggleSelectSession: () -> Unit,
  onSessionAction: (String) -> Unit,
  onAddEmptyTorrentToSession: () -> Unit,
  onImportTorrentToSession: () -> Unit,
  onRenameSession: () -> Unit,
  onDeleteSession: () -> Unit,
  onTorrentClick: (InstanceItem) -> Unit,
  onTorrentLongClick: (InstanceItem) -> Unit,
  onTorrentStart: (InstanceItem) -> Unit,
  onTorrentPause: (InstanceItem) -> Unit,
  onTorrentResume: (InstanceItem) -> Unit,
  onTorrentStop: (InstanceItem) -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  var menuExpanded by remember { mutableStateOf(false) }
  val allChildrenSelected =
    group.instances.isNotEmpty() && group.instances.all { selectedIds.contains(it.id) }

  Card(
    modifier = Modifier.fillMaxWidth().testTag("session_group_card_${group.id}"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = colors.surface),
    border = BorderStroke(1.dp, if (group.activeCount > 0) colors.primary.copy(alpha = 0.6f) else colors.border),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Session Header (Level 1)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (selectionMode) {
          IconButton(
            onClick = onToggleSelectSession,
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_select_${group.id}"),
          ) {
            Icon(
              imageVector =
                if (allChildrenSelected) Icons.Rounded.CheckBox
                else Icons.Rounded.CheckBoxOutlineBlank,
              contentDescription = "Chọn cả phiên ${group.name}",
              tint = if (allChildrenSelected) colors.primary else colors.textSecondary,
            )
          }
        } else {
          Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = null,
            tint = colors.primary,
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = group.name,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text =
              "${group.totalTorrents} torrent · ${group.activeCount} chạy · ${group.pausedCount} tạm dừng · ${group.stoppedCount} dừng",
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }

        StatusBadge(state = group.aggregateState, isIdling = false)

        if (!group.isRemoteGroup) {
          Box {
            IconButton(
              onClick = { menuExpanded = true },
              modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_menu_${group.id}"),
            ) {
              Icon(Icons.Rounded.MoreVert, contentDescription = "Tùy chọn phiên")
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Rounded.UploadFile, contentDescription = null) },
                text = { Text("Nhập .torrent vào phiên này") },
                onClick = {
                  menuExpanded = false
                  onImportTorrentToSession()
                },
              )
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("Thêm torrent trống để cấu hình") },
                onClick = {
                  menuExpanded = false
                  onAddEmptyTorrentToSession()
                },
              )
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = null) },
                text = { Text("Đổi tên phiên") },
                onClick = {
                  menuExpanded = false
                  onRenameSession()
                },
              )
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = colors.error) },
                text = { Text("Xóa phiên", color = colors.error) },
                onClick = {
                  menuExpanded = false
                  onDeleteSession()
                },
              )
            }
          }
        }

        IconButton(
          onClick = onToggleExpanded,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("session_toggle_${group.id}"),
        ) {
          Icon(
            imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
            contentDescription = if (expanded) "Thu gọn phiên" else "Mở rộng phiên",
          )
        }
      }

      // Session aggregate throughput summary
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            "Tổng tốc độ: ↑ ${Formatters.formatSpeedKBs(group.totalUploadRateKBs)} · ↓ ${Formatters.formatSpeedKBs(group.totalDownloadRateKBs)}",
          style = MonoMetricSmall,
          color = colors.primary,
        )
        Text(
          text =
            "↑ ${Formatters.formatBytes(group.totalUploadedBytes)}",
          style = MonoMetricSmall,
          color = colors.textSecondary,
        )
      }

      // Session-scoped controls (Start All / Pause / Resume / Stop strictly for THIS session)
      if (group.instances.isNotEmpty()) {
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          val canStartAny =
            group.instances.any {
              !it.effectiveState.isActive && it.effectiveState != FakerState.PAUSED && it.torrent != null
            }
          val canPauseAny = group.activeCount > 0
          val canResumeAny = group.pausedCount > 0
          val canStopAny = group.activeCount > 0 || group.pausedCount > 0

          OutlinedButton(
            onClick = { onSessionAction("start") },
            enabled = canStartAny,
            modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_start_all_${group.id}"),
            contentPadding = PaddingValues(horizontal = 12.dp),
          ) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(4.dp))
            Text("Chạy phiên")
          }
          if (canPauseAny) {
            OutlinedButton(
              onClick = { onSessionAction("pause") },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_pause_all_${group.id}"),
              contentPadding = PaddingValues(horizontal = 12.dp),
            ) {
              Icon(Icons.Rounded.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(4.dp))
              Text("Tạm dừng")
            }
          }
          if (canResumeAny) {
            OutlinedButton(
              onClick = { onSessionAction("resume") },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_resume_all_${group.id}"),
              contentPadding = PaddingValues(horizontal = 12.dp),
            ) {
              Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(4.dp))
              Text("Tiếp tục")
            }
          }
          if (canStopAny) {
            OutlinedButton(
              onClick = { onSessionAction("stop") },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("session_stop_all_${group.id}"),
              contentPadding = PaddingValues(horizontal = 12.dp),
            ) {
              Icon(Icons.Rounded.Stop, contentDescription = null, tint = colors.error, modifier = Modifier.size(18.dp))
              Spacer(Modifier.width(4.dp))
              Text("Dừng phiên", color = colors.error)
            }
          }
        }
      }

      // Children Torrent Instances (Level 2)
      AnimatedVisibility(visible = expanded) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          if (group.instances.isEmpty()) {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = colors.surfaceSubtle,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "Phiên chưa có torrent nào.",
                  style = MaterialTheme.typography.bodySmall,
                  color = colors.textSecondary,
                )
                OutlinedButton(
                  onClick = onImportTorrentToSession,
                  modifier = Modifier.defaultMinSize(minHeight = 48.dp),
                ) {
                  Text("Nhập .torrent")
                }
              }
            }
          } else {
            group.instances.forEach { item ->
              TorrentInstanceCard(
                item = item,
                selected = selectedIds.contains(item.id),
                selectionMode = selectionMode,
                onClick = { onTorrentClick(item) },
                onLongClick = { onTorrentLongClick(item) },
                onStart = { onTorrentStart(item) },
                onPause = { onTorrentPause(item) },
                onResume = { onTorrentResume(item) },
                onStop = { onTorrentStop(item) },
              )
            }
          }
        }
      }
    }
  }
}
