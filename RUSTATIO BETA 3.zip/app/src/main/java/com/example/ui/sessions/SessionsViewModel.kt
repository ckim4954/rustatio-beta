package com.example.ui.sessions

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppSettingsSnapshot
import com.example.data.repository.RustatioRepository
import com.example.domain.model.BuiltInPresets
import com.example.domain.model.ClientType
import com.example.domain.model.FakerState
import com.example.domain.model.ImportMode
import com.example.domain.model.InstanceItem
import com.example.domain.model.InstanceSource
import com.example.domain.model.PendingImportFile
import com.example.domain.model.Preset
import com.example.domain.model.RunMode
import com.example.domain.model.SessionGroup
import com.example.domain.model.TorrentImportOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SessionStatusFilter(val id: String, val labelVi: String) {
  ALL("all", "Tất cả"),
  RUNNING("running", "Đang chạy"),
  PAUSED("paused", "Tạm dừng"),
  STOPPED("stopped", "Đã dừng"),
}

sealed interface PendingConfirmAction {
  val title: String
  val message: String
  val confirmLabel: String
  val isDestructive: Boolean

  data class DeleteInstances(
    val ids: List<String>,
    override val title: String,
    override val message: String,
  ) : PendingConfirmAction {
    override val confirmLabel: String = "Xóa torrent"
    override val isDestructive: Boolean = true
  }

  data class DeleteSessionGroup(
    val sessionId: String,
    val sessionName: String,
    val childCount: Int,
  ) : PendingConfirmAction {
    override val title: String = "Xác nhận xóa phiên"
    override val message: String =
      if (childCount > 0) {
        "Bạn có chắc muốn xóa phiên \"$sessionName\" cùng toàn bộ $childCount torrent bên trong?"
      } else {
        "Bạn có chắc muốn xóa phiên trống \"$sessionName\"?"
      }
    override val confirmLabel: String = "Xóa phiên"
    override val isDestructive: Boolean = true
  }

  data class SessionBatchAction(
    val sessionId: String,
    val sessionName: String,
    val action: String,
    val affectedCount: Int,
  ) : PendingConfirmAction {
    override val title: String =
      when (action) {
        "stop" -> "Dừng toàn bộ phiên"
        "pause" -> "Tạm dừng phiên"
        else -> "Xác nhận thao tác phiên"
      }
    override val message: String =
      when (action) {
        "stop" -> "Dừng $affectedCount torrent đang hoạt động/tạm dừng trong phiên \"$sessionName\"?"
        "pause" -> "Tạm dừng $affectedCount torrent đang chạy trong phiên \"$sessionName\"?"
        else -> "Áp dụng cho $affectedCount torrent trong phiên \"$sessionName\"?"
      }
    override val confirmLabel: String =
      when (action) {
        "stop" -> "Dừng tất cả"
        "pause" -> "Tạm dừng"
        else -> "Xác nhận"
      }
    override val isDestructive: Boolean = action == "stop"
  }

  data class GlobalOrSelectedAction(
    val action: String,
    val targets: List<InstanceItem>,
    val scopeLabel: String,
  ) : PendingConfirmAction {
    override val title: String =
      when (action) {
        "start" -> "Bắt đầu $scopeLabel"
        "pause" -> "Tạm dừng $scopeLabel"
        "resume" -> "Tiếp tục $scopeLabel"
        "stop" -> "Dừng $scopeLabel"
        else -> "Xác nhận thao tác"
      }
    override val message: String =
      "Áp dụng thao tác lên ${targets.size} torrent ($scopeLabel). Các torrent không thuộc phạm vi sẽ được giữ nguyên."
    override val confirmLabel: String =
      when (action) {
        "start" -> "Bắt đầu"
        "pause" -> "Tạm dừng"
        "resume" -> "Tiếp tục"
        "stop" -> "Dừng tất cả"
        else -> "Xác nhận"
      }
    override val isDestructive: Boolean = action == "stop"
  }
}

data class ImportDialogState(
  val files: List<PendingImportFile>,
  val options: TorrentImportOptions,
  val tagsText: String = "",
  val uploadRateText: String = "50",
  val downloadRateText: String = "0",
  val portText: String = "6881",
  val updateIntervalText: String = "5",
  val scrapeIntervalText: String = "60",
  val customPercentText: String = "100",
  val staggerSecondsText: String = "0",
  val createNewSession: Boolean = false,
  val newSessionName: String = "",
  val validationError: String? = null,
) {
  val validCount: Int get() = files.count { it.isValidNew }
  val duplicateCount: Int get() = files.count { it.isDuplicate }
  val invalidCount: Int get() = files.count { it.error != null }
}

data class SessionsUiState(
  val isLoading: Boolean = true,
  val runMode: RunMode = RunMode.LOCAL,
  val serverOnline: Boolean = false,
  val serverError: String? = null,
  val sessionGroups: List<SessionGroup> = emptyList(),
  val filteredGroups: List<SessionGroup> = emptyList(),
  val allInstances: List<InstanceItem> = emptyList(),
  val filteredInstances: List<InstanceItem> = emptyList(),
  val expandedSessionIds: Set<String> = emptySet(),
  val totalSessionsCount: Int = 0,
  val totalCount: Int = 0,
  val runningCount: Int = 0,
  val pausedCount: Int = 0,
  val stoppedCount: Int = 0,
  val totalUploadRateKBs: Double = 0.0,
  val totalDownloadRateKBs: Double = 0.0,
  val searchQuery: String = "",
  val statusFilter: SessionStatusFilter = SessionStatusFilter.ALL,
  val tagFilter: String? = null,
  val trackerFilter: String? = null,
  val availableTags: List<String> = emptyList(),
  val availableTrackers: List<String> = emptyList(),
  val presets: List<Preset> = BuiltInPresets.all,
  val isMultiSelectExplicit: Boolean = false,
  val selectedIds: Set<String> = emptySet(),
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingConfirmAction: PendingConfirmAction? = null,
  val pendingDeleteIds: List<String> = emptyList(),
  val importDialog: ImportDialogState? = null,
  val interruptedRecoveryCount: Int = 0,
  val showNotificationPermissionBanner: Boolean = false,
) {
  val isMultiSelectActive: Boolean get() = isMultiSelectExplicit || selectedIds.isNotEmpty()
  val activeFilterCount: Int
    get() =
      (if (statusFilter != SessionStatusFilter.ALL) 1 else 0) +
        (if (tagFilter != null) 1 else 0) +
        (if (trackerFilter != null) 1 else 0)
}

private data class SessionsLocalControls(
  val searchQuery: String = "",
  val statusFilter: SessionStatusFilter = SessionStatusFilter.ALL,
  val tagFilter: String? = null,
  val trackerFilter: String? = null,
  val isMultiSelectExplicit: Boolean = false,
  val selectedIds: Set<String> = emptySet(),
  val collapsedSessionIds: Set<String> = emptySet(),
  val isBusy: Boolean = false,
  val actionMessage: String? = null,
  val errorMessage: String? = null,
  val pendingConfirmAction: PendingConfirmAction? = null,
  val importDialog: ImportDialogState? = null,
  val notificationDeniedNotice: Boolean = false,
)

class SessionsViewModel(
  private val repository: RustatioRepository,
) : ViewModel() {

  private val controls = MutableStateFlow(SessionsLocalControls())

  private val baseStream =
    combine(
      repository.sessionGroupsFlow,
      repository.settingsFlow,
      repository.serverOnline,
      repository.serverError,
      repository.customPresetsFlow,
    ) { groups, settings, online, serverErr, customPresets ->
      Triple(groups, settings, Triple(online, serverErr, BuiltInPresets.all + customPresets))
    }

  val uiState: StateFlow<SessionsUiState> =
    combine(
      baseStream,
      repository.interruptedInstances,
      controls,
    ) { (groups, settings, netAndPresets), interrupted, ctrl ->
      val (online, serverErr, allPresets) = netAndPresets
      val instances = groups.flatMap { it.instances }
      val query = ctrl.searchQuery.trim().lowercase()
      val availableTags = instances.flatMap { it.tags }.distinct().sorted()
      val availableTrackers =
        instances.mapNotNull { it.torrent?.primaryTrackerHost }.distinct().sorted()

      val hasActiveCondition =
        query.isNotEmpty() ||
          ctrl.statusFilter != SessionStatusFilter.ALL ||
          ctrl.tagFilter != null ||
          ctrl.trackerFilter != null

      val filteredGroups =
        groups.mapNotNull { group ->
          val sessionNameMatches = query.isNotEmpty() && group.name.lowercase().contains(query)
          val matchingChildren =
            group.instances.filter { item ->
              val matchesQuery =
                query.isEmpty() ||
                  sessionNameMatches ||
                  item.displayName.lowercase().contains(query) ||
                  item.tags.any { it.lowercase().contains(query) } ||
                  (item.torrent?.primaryTrackerHost?.lowercase()?.contains(query) == true) ||
                  item.config.clientType.displayName.lowercase().contains(query)

              val matchesStatus =
                when (ctrl.statusFilter) {
                  SessionStatusFilter.ALL -> true
                  SessionStatusFilter.RUNNING -> item.effectiveState.isActive
                  SessionStatusFilter.PAUSED -> item.effectiveState == FakerState.PAUSED
                  SessionStatusFilter.STOPPED ->
                    item.effectiveState == FakerState.STOPPED || item.effectiveState == FakerState.IDLE
                }

              val matchesTag =
                when (ctrl.tagFilter) {
                  null -> true
                  TAG_UNTAGGED -> item.tags.isEmpty()
                  else -> item.tags.contains(ctrl.tagFilter)
                }

              val matchesTracker =
                ctrl.trackerFilter == null || item.torrent?.primaryTrackerHost == ctrl.trackerFilter

              matchesQuery && matchesStatus && matchesTag && matchesTracker
            }

          if (!hasActiveCondition || matchingChildren.isNotEmpty() || (sessionNameMatches && ctrl.statusFilter == SessionStatusFilter.ALL && ctrl.tagFilter == null && ctrl.trackerFilter == null)) {
            group.copy(instances = matchingChildren)
          } else {
            null
          }
        }

      val filteredInstances = filteredGroups.flatMap { it.instances }
      val validIds = instances.map { it.id }.toSet()
      val validSelected = ctrl.selectedIds.intersect(validIds)
      val expandedSessionIds = groups.map { it.id }.toSet() - ctrl.collapsedSessionIds

      val legacyDeleteIds =
        (ctrl.pendingConfirmAction as? PendingConfirmAction.DeleteInstances)?.ids.orEmpty()

      SessionsUiState(
        isLoading = false,
        runMode = settings.runMode,
        serverOnline = online,
        serverError = serverErr,
        sessionGroups = groups,
        filteredGroups = filteredGroups,
        allInstances = instances,
        filteredInstances = filteredInstances,
        expandedSessionIds = expandedSessionIds,
        totalSessionsCount = groups.size,
        totalCount = instances.size,
        runningCount = instances.count { it.effectiveState.isActive },
        pausedCount = instances.count { it.effectiveState == FakerState.PAUSED },
        stoppedCount =
          instances.count {
            it.effectiveState == FakerState.STOPPED || it.effectiveState == FakerState.IDLE
          },
        totalUploadRateKBs = instances.sumOf { if (it.effectiveState.isActive) it.stats.currentUploadRateKBs else 0.0 },
        totalDownloadRateKBs = instances.sumOf { if (it.effectiveState.isActive) it.stats.currentDownloadRateKBs else 0.0 },
        searchQuery = ctrl.searchQuery,
        statusFilter = ctrl.statusFilter,
        tagFilter = ctrl.tagFilter,
        trackerFilter = ctrl.trackerFilter,
        availableTags = availableTags,
        availableTrackers = availableTrackers,
        presets = allPresets,
        isMultiSelectExplicit = ctrl.isMultiSelectExplicit,
        selectedIds = validSelected,
        isBusy = ctrl.isBusy,
        actionMessage = ctrl.actionMessage,
        errorMessage = ctrl.errorMessage,
        pendingConfirmAction = ctrl.pendingConfirmAction,
        pendingDeleteIds = legacyDeleteIds,
        importDialog = ctrl.importDialog,
        interruptedRecoveryCount = interrupted.size,
        showNotificationPermissionBanner = ctrl.notificationDeniedNotice,
      )
    }.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5_000L),
      initialValue = SessionsUiState(isLoading = true),
    )

  init {
    viewModelScope.launch {
      repository.settingsFlow.collect { settings: AppSettingsSnapshot ->
        if (settings.runMode == RunMode.SERVER && settings.serverUrl.isNotBlank()) {
          repository.refreshServerInstances()
        }
      }
    }
  }

  // ---- Filtering & Selection ----

  fun setSearchQuery(q: String) {
    controls.update { it.copy(searchQuery = q) }
  }

  fun setStatusFilter(filter: SessionStatusFilter) {
    controls.update { it.copy(statusFilter = filter) }
  }

  fun setTagFilter(tag: String?) {
    controls.update { it.copy(tagFilter = tag) }
  }

  fun setTrackerFilter(tracker: String?) {
    controls.update { it.copy(trackerFilter = tracker) }
  }

  fun clearAllFilters() {
    controls.update {
      it.copy(
        searchQuery = "",
        statusFilter = SessionStatusFilter.ALL,
        tagFilter = null,
        trackerFilter = null,
      )
    }
  }

  fun toggleSessionExpanded(sessionId: String) {
    controls.update { ctrl ->
      val next =
        if (ctrl.collapsedSessionIds.contains(sessionId)) ctrl.collapsedSessionIds - sessionId
        else ctrl.collapsedSessionIds + sessionId
      ctrl.copy(collapsedSessionIds = next)
    }
  }

  fun setMultiSelectMode(enabled: Boolean) {
    controls.update {
      it.copy(
        isMultiSelectExplicit = enabled,
        selectedIds = if (enabled) it.selectedIds else emptySet(),
      )
    }
  }

  fun toggleSelection(id: String) {
    controls.update { ctrl ->
      val next =
        if (ctrl.selectedIds.contains(id)) ctrl.selectedIds - id else ctrl.selectedIds + id
      ctrl.copy(selectedIds = next, isMultiSelectExplicit = next.isNotEmpty() || ctrl.isMultiSelectExplicit)
    }
  }

  fun toggleSessionSelection(group: SessionGroup) {
    val childIds = group.instances.map { it.id }.toSet()
    if (childIds.isEmpty()) return
    controls.update { ctrl ->
      val allSelected = childIds.all { ctrl.selectedIds.contains(it) }
      val next =
        if (allSelected) ctrl.selectedIds - childIds else ctrl.selectedIds + childIds
      ctrl.copy(selectedIds = next, isMultiSelectExplicit = true)
    }
  }

  fun selectAllVisible() {
    val visibleIds = uiState.value.filteredInstances.map { it.id }.toSet()
    controls.update { it.copy(selectedIds = visibleIds, isMultiSelectExplicit = true) }
  }

  fun clearSelection() {
    controls.update { it.copy(selectedIds = emptySet(), isMultiSelectExplicit = false) }
  }

  fun refreshServer() {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .refreshServerInstances()
        .onSuccess {
          controls.update {
            it.copy(isBusy = false, actionMessage = "Đã đồng bộ danh sách phiên từ máy chủ")
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể kết nối máy chủ")
          }
        }
    }
  }

  // ---- Import Torrent Full Workflow (Stage 2) ----

  fun onImportFilesPicked(uris: List<Uri>, preferredSessionId: String? = null) {
    if (uris.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .previewTorrentUris(uris)
        .onSuccess { previewFiles ->
          openImportDialogWithFiles(previewFiles, preferredSessionId)
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể đọc tệp .torrent")
          }
        }
    }
  }

  fun onImportFolderPicked(treeUri: Uri, preferredSessionId: String? = null) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null, actionMessage = null) }
      repository
        .previewFolderTree(treeUri, maxDepth = 0)
        .onSuccess { previewFiles ->
          if (previewFiles.isEmpty()) {
            controls.update {
              it.copy(
                isBusy = false,
                errorMessage = "Không tìm thấy tệp .torrent nào trong thư mục đã chọn.",
              )
            }
          } else {
            openImportDialogWithFiles(previewFiles, preferredSessionId)
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể quét thư mục SAF")
          }
        }
    }
  }

  private suspend fun openImportDialogWithFiles(
    previewFiles: List<PendingImportFile>,
    preferredSessionId: String?,
  ) {
    val settings = repository.settingsFlow.first()
    val allPresets = BuiltInPresets.all + repository.customPresetsFlow.first()
    val defaultPreset = allPresets.firstOrNull { it.id == settings.defaultPresetId }
    val baseConfig = defaultPreset?.config ?: com.example.domain.model.FakerConfig()
    val groups = uiState.value.sessionGroups
    val resolvedSessionId =
      preferredSessionId
        ?: groups.firstOrNull()?.id
        ?: InstanceItem.DEFAULT_SESSION_ID

    val mode =
      when {
        baseConfig.completionPercent >= 99.9 -> ImportMode.SEED
        baseConfig.completionPercent <= 0.1 -> ImportMode.LEECH
        else -> ImportMode.CUSTOM
      }

    val options =
      TorrentImportOptions(
        targetSessionId = resolvedSessionId,
        presetId = defaultPreset?.id,
        mode = mode,
        customCompletionPercent = baseConfig.completionPercent,
        clientType = baseConfig.clientType,
        clientVersion = baseConfig.clientVersion,
        port = baseConfig.port,
        vpnPortSync = baseConfig.vpnPortSync,
        uploadRateKBs = baseConfig.uploadRateKBs,
        downloadRateKBs = baseConfig.downloadRateKBs,
        updateIntervalSeconds = baseConfig.updateIntervalSeconds,
        scrapeIntervalSeconds = baseConfig.scrapeIntervalSeconds,
        baseConfig = baseConfig,
      )

    controls.update {
      it.copy(
        isBusy = false,
        importDialog =
          ImportDialogState(
            files = previewFiles,
            options = options,
            uploadRateText = formatNumber(options.uploadRateKBs),
            downloadRateText = formatNumber(options.downloadRateKBs),
            portText = options.port.toString(),
            updateIntervalText = options.updateIntervalSeconds.toString(),
            scrapeIntervalText = options.scrapeIntervalSeconds.toString(),
            customPercentText = formatNumber(options.customCompletionPercent),
            staggerSecondsText = options.staggerStartSeconds.toString(),
            createNewSession = groups.isEmpty(),
            newSessionName = if (groups.isEmpty()) InstanceItem.DEFAULT_SESSION_NAME else "",
          ),
      )
    }
  }

  fun updateImportDialog(transform: (ImportDialogState) -> ImportDialogState) {
    controls.update { ctrl ->
      val current = ctrl.importDialog ?: return@update ctrl
      ctrl.copy(importDialog = transform(current).copy(validationError = null))
    }
  }

  fun selectImportPreset(preset: Preset?) {
    controls.update { ctrl ->
      val current = ctrl.importDialog ?: return@update ctrl
      if (preset == null) {
        return@update ctrl.copy(
          importDialog = current.copy(options = current.options.copy(presetId = null))
        )
      }
      val cfg = preset.config
      val mode =
        when {
          cfg.completionPercent >= 99.9 -> ImportMode.SEED
          cfg.completionPercent <= 0.1 -> ImportMode.LEECH
          else -> ImportMode.CUSTOM
        }
      val nextOptions =
        current.options.copy(
          presetId = preset.id,
          mode = mode,
          customCompletionPercent = cfg.completionPercent,
          clientType = cfg.clientType,
          clientVersion = cfg.clientVersion,
          port = cfg.port,
          vpnPortSync = cfg.vpnPortSync,
          uploadRateKBs = cfg.uploadRateKBs,
          downloadRateKBs = cfg.downloadRateKBs,
          updateIntervalSeconds = cfg.updateIntervalSeconds,
          scrapeIntervalSeconds = cfg.scrapeIntervalSeconds,
          baseConfig = cfg,
        )
      ctrl.copy(
        importDialog =
          current.copy(
            options = nextOptions,
            uploadRateText = formatNumber(cfg.uploadRateKBs),
            downloadRateText = formatNumber(cfg.downloadRateKBs),
            portText = cfg.port.toString(),
            updateIntervalText = cfg.updateIntervalSeconds.toString(),
            scrapeIntervalText = cfg.scrapeIntervalSeconds.toString(),
            customPercentText = formatNumber(cfg.completionPercent),
            validationError = null,
          )
      )
    }
  }

  fun selectImportClient(client: ClientType) {
    controls.update { ctrl ->
      val current = ctrl.importDialog ?: return@update ctrl
      val nextOptions =
        current.options.copy(
          clientType = client,
          clientVersion = client.defaultVersion,
          port = client.defaultPort,
        )
      ctrl.copy(
        importDialog =
          current.copy(
            options = nextOptions,
            portText = client.defaultPort.toString(),
            validationError = null,
          )
      )
    }
  }

  fun dismissImportDialog() {
    controls.update { it.copy(importDialog = null) }
  }

  fun confirmImport(onAutoStarted: () -> Unit = {}) {
    val draft = controls.value.importDialog ?: return
    if (draft.validCount == 0) {
      controls.update {
        it.copy(
          importDialog =
            draft.copy(
              validationError =
                "Không có tệp .torrent hợp lệ mới để nhập (${draft.duplicateCount} trùng lặp, ${draft.invalidCount} lỗi)."
            )
        )
      }
      return
    }
    val upload = draft.uploadRateText.toDoubleOrNull()
    val download = draft.downloadRateText.toDoubleOrNull()
    val port = draft.portText.toIntOrNull()
    val updateSec = draft.updateIntervalText.toIntOrNull()
    val scrapeSec = draft.scrapeIntervalText.toIntOrNull()
    val customPct = draft.customPercentText.toDoubleOrNull() ?: 100.0
    val staggerSec = draft.staggerSecondsText.toIntOrNull() ?: 0

    val error =
      when {
        upload == null || upload < 0.0 -> "Tốc độ tải lên phải ≥ 0 KB/s."
        download == null || download < 0.0 -> "Tốc độ tải xuống phải ≥ 0 KB/s."
        port == null || port !in 1..65535 -> "Port phải nằm trong khoảng 1 – 65535."
        updateSec == null || updateSec !in 1..3600 -> "Chu kỳ cập nhật phải từ 1 – 3600 giây."
        scrapeSec == null || scrapeSec !in 10..86400 -> "Chu kỳ scrape phải từ 10 – 86400 giây."
        draft.options.mode == ImportMode.CUSTOM && customPct !in 0.0..100.0 ->
          "Mức hoàn thành tùy chỉnh phải từ 0 – 100%."
        draft.options.autoStart && staggerSec < 0 -> "Độ trễ khởi động phải ≥ 0 giây."
        draft.createNewSession && draft.newSessionName.trim().isEmpty() ->
          "Vui lòng nhập tên cho phiên mới."
        else -> null
      }
    if (error != null) {
      controls.update { it.copy(importDialog = draft.copy(validationError = error)) }
      return
    }

    val tags =
      draft.tagsText
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()

    val finalOptions =
      draft.options.copy(
        targetSessionId = if (draft.createNewSession) null else draft.options.targetSessionId,
        createNewSessionName = if (draft.createNewSession) draft.newSessionName.trim() else null,
        uploadRateKBs = upload!!,
        downloadRateKBs = download!!,
        port = port!!,
        updateIntervalSeconds = updateSec!!,
        scrapeIntervalSeconds = scrapeSec!!,
        customCompletionPercent = customPct.coerceIn(0.0, 100.0),
        tags = tags,
        staggerStartSeconds = if (draft.options.autoStart) staggerSec else 0,
      )

    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, importDialog = null, errorMessage = null) }
      repository
        .importPendingTorrents(draft.files, finalOptions, InstanceSource.MANUAL)
        .onSuccess { res ->
          val msg =
            buildString {
              append("Đã nhập ${res.importedCount} torrent vào phiên")
              if (res.autoStarted) {
                append(" và tự động chạy")
                if (res.staggerStartSeconds > 0) append(" (giãn cách ${res.staggerStartSeconds}s)")
              }
              if (res.skippedDuplicates.isNotEmpty()) {
                append(" · Bỏ qua ${res.skippedDuplicates.size} torrent trùng info_hash")
              }
              if (res.errors.isNotEmpty()) {
                append(" · ${res.errors.size} lỗi đọc tệp")
              }
            }
          controls.update { it.copy(isBusy = false, actionMessage = msg) }
          if (res.autoStarted && res.importedCount > 0) {
            onAutoStarted()
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Lỗi nhập torrent")
          }
        }
    }
  }

  // Convenience direct import helper preserved for compatibility
  fun importTorrents(uris: List<Uri>) {
    onImportFilesPicked(uris)
  }

  // ---- Two-Level Session Group Operations (Stage 3) ----

  fun createSessionGroup(
    name: String,
    alsoCreateEmptyTorrent: Boolean = false,
    onOpenCreatedTorrent: ((String) -> Unit)? = null,
  ) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      repository
        .createSessionGroup(name, alsoCreateEmptyTorrent)
        .onSuccess { (_, instanceId) ->
          controls.update {
            it.copy(
              isBusy = false,
              actionMessage = "Đã tạo phiên \"${name.trim()}\"",
            )
          }
          if (instanceId != null && onOpenCreatedTorrent != null) {
            onOpenCreatedTorrent(instanceId)
          }
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể tạo phiên mới")
          }
        }
    }
  }

  fun renameSessionGroup(sessionId: String, newName: String) {
    viewModelScope.launch {
      repository
        .renameSessionGroup(sessionId, newName)
        .onSuccess {
          controls.update { it.copy(actionMessage = "Đã đổi tên phiên thành \"${newName.trim()}\"") }
        }
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể đổi tên phiên") }
        }
    }
  }

  fun requestDeleteSessionGroup(group: SessionGroup) {
    controls.update {
      it.copy(
        pendingConfirmAction =
          PendingConfirmAction.DeleteSessionGroup(
            sessionId = group.id,
            sessionName = group.name,
            childCount = group.instances.size,
          )
      )
    }
  }

  fun requestSessionAction(group: SessionGroup, action: String) {
    val affected =
      when (action) {
        "start" ->
          group.instances.count {
            !it.effectiveState.isActive && it.effectiveState != FakerState.PAUSED && it.torrent != null
          }
        "pause" -> group.instances.count { it.effectiveState.isActive }
        "resume" -> group.instances.count { it.effectiveState == FakerState.PAUSED }
        "stop" ->
          group.instances.count {
            it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED
          }
        else -> 0
      }
    if (affected == 0) {
      controls.update {
        it.copy(errorMessage = "Không có torrent nào trong phiên \"${group.name}\" phù hợp với thao tác này.")
      }
      return
    }
    if (action == "stop") {
      controls.update {
        it.copy(
          pendingConfirmAction =
            PendingConfirmAction.SessionBatchAction(
              sessionId = group.id,
              sessionName = group.name,
              action = action,
              affectedCount = affected,
            )
        )
      }
    } else {
      executeSessionAction(group.id, group.name, action)
    }
  }

  private fun executeSessionAction(sessionId: String, sessionName: String, action: String) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      repository
        .sessionAction(sessionId, action)
        .onSuccess { count ->
          val label = actionVerb(action)
          controls.update {
            it.copy(
              isBusy = false,
              actionMessage = "Đã $label $count torrent trong phiên \"$sessionName\"",
            )
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isBusy = false, errorMessage = err.message) }
        }
    }
  }

  fun createEmptySession(sessionId: String? = null, onCreated: (String) -> Unit) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      repository
        .createEmptySession(sessionId)
        .onSuccess { id ->
          controls.update { it.copy(isBusy = false) }
          onCreated(id)
        }
        .onFailure { err ->
          controls.update {
            it.copy(isBusy = false, errorMessage = err.message ?: "Không thể tạo torrent mới")
          }
        }
    }
  }

  // ---- Individual Torrent Controls (Level 2) ----

  fun startSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .startSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể bắt đầu torrent") }
        }
    }
  }

  fun pauseSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .pauseSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể tạm dừng torrent") }
        }
    }
  }

  fun resumeSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .resumeSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể tiếp tục torrent") }
        }
    }
  }

  fun stopSession(item: InstanceItem) {
    viewModelScope.launch {
      repository
        .stopSession(item)
        .onFailure { err ->
          controls.update { it.copy(errorMessage = err.message ?: "Không thể dừng torrent") }
        }
    }
  }

  // ---- Multi-Select & Global Batch Controls (Stage 3.4) ----

  fun requestGlobalAction(action: String) {
    val scopeItems = uiState.value.filteredInstances
    val targets = filterTargetsForAction(scopeItems, action)
    if (targets.isEmpty()) {
      controls.update {
        it.copy(errorMessage = "Không có torrent nào trong danh sách hiện tại phù hợp để ${actionVerb(action)}.")
      }
      return
    }
    controls.update {
      it.copy(
        pendingConfirmAction =
          PendingConfirmAction.GlobalOrSelectedAction(
            action = action,
            targets = targets,
            scopeLabel = "toàn bộ danh sách đang hiển thị",
          )
      )
    }
  }

  fun bulkAction(action: String) {
    val selected = uiState.value.allInstances.filter { uiState.value.selectedIds.contains(it.id) }
    val targets = filterTargetsForAction(selected, action)
    if (targets.isEmpty()) {
      controls.update {
        it.copy(errorMessage = "Các torrent đã chọn không phù hợp với thao tác ${actionVerb(action)}.")
      }
      return
    }
    if (action == "stop") {
      controls.update {
        it.copy(
          pendingConfirmAction =
            PendingConfirmAction.GlobalOrSelectedAction(
              action = action,
              targets = targets,
              scopeLabel = "${targets.size} torrent đã chọn",
            )
        )
      }
    } else {
      executeBulkTargets(action, targets, clearSelect = true)
    }
  }

  fun requestDeleteSelected() {
    val ids = uiState.value.selectedIds.toList()
    if (ids.isEmpty()) return
    val message =
      if (ids.size == 1) {
        val name = uiState.value.allInstances.firstOrNull { it.id == ids.first() }?.displayName ?: ids.first()
        "Bạn có chắc muốn xóa torrent \"$name\"? Hành động này không thể hoàn tác."
      } else {
        "Bạn có chắc muốn xóa ${ids.size} torrent đã chọn? Hành động này không thể hoàn tác."
      }
    controls.update {
      it.copy(
        pendingConfirmAction =
          PendingConfirmAction.DeleteInstances(
            ids = ids,
            title = "Xác nhận xóa torrent",
            message = message,
          )
      )
    }
  }

  fun dismissPendingAction() {
    controls.update { it.copy(pendingConfirmAction = null) }
  }

  fun dismissDeleteDialog() = dismissPendingAction()

  fun confirmPendingAction() {
    val pending = controls.value.pendingConfirmAction ?: return
    controls.update { it.copy(pendingConfirmAction = null) }
    when (pending) {
      is PendingConfirmAction.DeleteInstances -> {
        viewModelScope.launch {
          controls.update { it.copy(isBusy = true) }
          repository
            .deleteSessions(pending.ids)
            .onSuccess {
              controls.update {
                it.copy(
                  isBusy = false,
                  selectedIds = emptySet(),
                  isMultiSelectExplicit = false,
                  actionMessage = "Đã xóa ${pending.ids.size} torrent",
                )
              }
            }
            .onFailure { err -> controls.update { it.copy(isBusy = false, errorMessage = err.message) } }
        }
      }
      is PendingConfirmAction.DeleteSessionGroup -> {
        viewModelScope.launch {
          controls.update { it.copy(isBusy = true) }
          repository
            .deleteSessionGroup(pending.sessionId)
            .onSuccess {
              controls.update {
                it.copy(
                  isBusy = false,
                  actionMessage = "Đã xóa phiên \"${pending.sessionName}\"",
                )
              }
            }
            .onFailure { err -> controls.update { it.copy(isBusy = false, errorMessage = err.message) } }
        }
      }
      is PendingConfirmAction.SessionBatchAction -> {
        executeSessionAction(pending.sessionId, pending.sessionName, pending.action)
      }
      is PendingConfirmAction.GlobalOrSelectedAction -> {
        executeBulkTargets(pending.action, pending.targets, clearSelect = uiState.value.selectedIds.isNotEmpty())
      }
    }
  }

  fun confirmDelete() = confirmPendingAction()

  private fun executeBulkTargets(action: String, targets: List<InstanceItem>, clearSelect: Boolean) {
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      repository
        .bulkAction(action, targets)
        .onSuccess {
          controls.update {
            it.copy(
              isBusy = false,
              selectedIds = if (clearSelect) emptySet() else it.selectedIds,
              isMultiSelectExplicit = if (clearSelect) false else it.isMultiSelectExplicit,
              actionMessage = "Đã ${actionVerb(action)} ${targets.size} torrent",
            )
          }
        }
        .onFailure { err ->
          controls.update { it.copy(isBusy = false, errorMessage = err.message) }
        }
    }
  }

  fun saveTagsForSelected(rawTagsCommaSeparated: String) {
    val tags =
      rawTagsCommaSeparated
        .split(",")
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
    val ids = uiState.value.selectedIds.toList()
    if (ids.isEmpty()) return
    viewModelScope.launch {
      controls.update { it.copy(isBusy = true, errorMessage = null) }
      var lastError: Throwable? = null
      ids.forEach { id ->
        repository.updateSessionTags(id, tags).onFailure { lastError = it }
      }
      if (lastError != null) {
        controls.update { it.copy(isBusy = false, errorMessage = lastError?.message) }
      } else {
        controls.update {
          it.copy(
            isBusy = false,
            selectedIds = emptySet(),
            isMultiSelectExplicit = false,
            actionMessage = "Đã cập nhật thẻ cho ${ids.size} torrent",
          )
        }
      }
    }
  }

  // ---- Recovery & Permission State ----

  fun recoverInterrupted() {
    viewModelScope.launch {
      repository.recoverInterruptedInstances()
      controls.update { it.copy(actionMessage = "Đã khôi phục các torrent đang chạy trước đó") }
    }
  }

  fun dismissInterrupted() {
    viewModelScope.launch {
      repository.dismissInterruptedRecovery()
    }
  }

  fun onNotificationPermissionResult(granted: Boolean) {
    controls.update { it.copy(notificationDeniedNotice = !granted) }
  }

  fun dismissMessages() {
    controls.update {
      it.copy(actionMessage = null, errorMessage = null, notificationDeniedNotice = false)
    }
  }

  private fun filterTargetsForAction(items: List<InstanceItem>, action: String): List<InstanceItem> =
    when (action) {
      "start" -> items.filter { !it.effectiveState.isActive && it.effectiveState != FakerState.PAUSED && it.torrent != null }
      "pause" -> items.filter { it.effectiveState.isActive }
      "resume" -> items.filter { it.effectiveState == FakerState.PAUSED }
      "stop" -> items.filter { it.effectiveState.isActive || it.effectiveState == FakerState.PAUSED }
      else -> emptyList()
    }

  private fun actionVerb(action: String): String =
    when (action) {
      "start" -> "bắt đầu"
      "pause" -> "tạm dừng"
      "resume" -> "tiếp tục"
      "stop" -> "dừng"
      else -> "cập nhật"
    }

  private fun formatNumber(value: Double): String {
    val asLong = value.toLong()
    return if (value == asLong.toDouble()) asLong.toString() else value.toString()
  }

  companion object {
    const val TAG_UNTAGGED = "__untagged__"

    fun factory(repository: RustatioRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
          SessionsViewModel(repository) as T
      }
  }
}
