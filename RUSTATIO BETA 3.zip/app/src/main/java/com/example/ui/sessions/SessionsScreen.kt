package com.example.ui.sessions

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.model.RunMode
import com.example.domain.model.SessionGroup
import com.example.ui.components.BannerType
import com.example.ui.components.RustatioBanner
import com.example.ui.components.RustatioConfirmDialog
import com.example.ui.components.RustatioEmptyState
import com.example.ui.components.RustatioLoadingSkeleton
import com.example.ui.theme.RustatioThemeTokens

@Composable
fun SessionsScreen(
  viewModel: SessionsViewModel,
  onOpenSessionDetail: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val colors = RustatioThemeTokens.colors
  val context = LocalContext.current

  var showAddSheet by remember { mutableStateOf(false) }
  var showImportSourceSheet by remember { mutableStateOf(false) }
  var showCreateSessionDialog by remember { mutableStateOf(false) }
  var renameTargetGroup by remember { mutableStateOf<SessionGroup?>(null) }
  var showFilterSheet by remember { mutableStateOf(false) }
  var showTagDialog by remember { mutableStateOf(false) }
  var pendingImportSessionId by remember { mutableStateOf<String?>(null) }

  val torrentPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
      val target = pendingImportSessionId
      pendingImportSessionId = null
      if (uris.isNotEmpty()) viewModel.onImportFilesPicked(uris, target)
    }

  val folderPicker =
    rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { treeUri ->
      val target = pendingImportSessionId
      pendingImportSessionId = null
      if (treeUri != null) viewModel.onImportFolderPicked(treeUri, target)
    }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      viewModel.onNotificationPermissionResult(granted)
    }

  fun requestNotificationPermissionIfNeeded() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = colors.background,
    contentWindowInsets = WindowInsets(0),
    topBar = {
      SessionsTopBar(
        state = state,
        onClearSelection = { viewModel.clearSelection() },
        onSelectAll = { viewModel.selectAllVisible() },
        onBulkStart = {
          requestNotificationPermissionIfNeeded()
          viewModel.bulkAction("start")
        },
        onBulkPause = { viewModel.bulkAction("pause") },
        onBulkStop = { viewModel.bulkAction("stop") },
        onBulkTag = { showTagDialog = true },
        onBulkDelete = { viewModel.requestDeleteSelected() },
        onRefreshServer = { viewModel.refreshServer() },
        onOpenFilters = { showFilterSheet = true },
      )
    },
    floatingActionButton = {
      if (!state.isMultiSelectActive) {
        ExtendedFloatingActionButton(
          onClick = { showAddSheet = true },
          containerColor = colors.primary,
          contentColor = Color.White,
          icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
          text = { Text("Thêm phiên") },
          modifier = Modifier.testTag("sessions_add_fab"),
        )
      }
    },
  ) { innerPadding ->
    BoxWithConstraints(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
      val isTablet = maxWidth >= 600.dp

      Column(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        if (state.runMode == RunMode.SERVER && !state.serverOnline) {
          RustatioBanner(
            type = BannerType.OFFLINE,
            message =
              state.serverError?.let { "Không kết nối được Rustatio Server ($it). Đang hiển thị phiên cục bộ." }
                ?: "Chưa kết nối máy chủ — đang hiển thị dữ liệu cục bộ.",
            actionLabel = "Thử lại",
            onAction = { viewModel.refreshServer() },
          )
        }

        if (state.interruptedRecoveryCount > 0) {
          SessionsRecoveryBanner(
            count = state.interruptedRecoveryCount,
            onDismiss = { viewModel.dismissInterrupted() },
            onRestore = {
              requestNotificationPermissionIfNeeded()
              viewModel.recoverInterrupted()
            },
          )
        }

        if (state.showNotificationPermissionBanner) {
          RustatioBanner(
            type = BannerType.INFO,
            message =
              "Quyền thông báo đang tắt — giả lập vẫn chạy bình thường nhưng thông báo điều khiển nhanh sẽ không hiển thị.",
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        state.actionMessage?.let { msg ->
          RustatioBanner(
            type = BannerType.SUCCESS,
            message = msg,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        state.errorMessage?.let { err ->
          RustatioBanner(
            type = BannerType.ERROR,
            message = err,
            actionLabel = "Đóng",
            onAction = { viewModel.dismissMessages() },
          )
        }

        SessionsPrimaryActionRow(
          onImportTorrentClick = {
            pendingImportSessionId = null
            showImportSourceSheet = true
          },
          onAddSessionClick = { showCreateSessionDialog = true },
        )

        SessionsSummaryPillRow(
          state = state,
          onSelectFilter = viewModel::setStatusFilter,
        )

        if (state.totalCount > 0) {
          SessionsMultiSelectAndGlobalBar(
            isMultiSelectActive = state.isMultiSelectActive,
            onToggleMultiSelect = { viewModel.setMultiSelectMode(!state.isMultiSelectActive) },
            onGlobalAction = { action ->
              if (action == "start" || action == "resume") requestNotificationPermissionIfNeeded()
              viewModel.requestGlobalAction(action)
            },
          )
        }

        OutlinedTextField(
          value = state.searchQuery,
          onValueChange = viewModel::setSearchQuery,
          modifier = Modifier.fillMaxWidth().testTag("sessions_search_input"),
          placeholder = { Text("Tìm phiên, torrent, tag, tracker…") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (state.searchQuery.isNotEmpty()) {
              IconButton(onClick = { viewModel.setSearchQuery("") }) {
                Icon(Icons.Rounded.Close, contentDescription = "Xóa từ khóa")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
        )

        if (state.activeFilterCount > 0) {
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            if (state.tagFilter != null) {
              FilterChip(
                selected = true,
                onClick = { viewModel.setTagFilter(null) },
                label = {
                  Text(
                    if (state.tagFilter == SessionsViewModel.TAG_UNTAGGED) "Thẻ: Chưa gắn thẻ"
                    else "Thẻ: ${state.tagFilter}"
                  )
                },
                trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Bỏ lọc thẻ") },
              )
            }
            if (state.trackerFilter != null) {
              FilterChip(
                selected = true,
                onClick = { viewModel.setTrackerFilter(null) },
                label = { Text("Tracker: ${state.trackerFilter}") },
                trailingIcon = { Icon(Icons.Rounded.Close, contentDescription = "Bỏ lọc tracker") },
              )
            }
            TextButton(
              onClick = { viewModel.clearAllFilters() },
              modifier = Modifier.defaultMinSize(minHeight = 48.dp),
            ) {
              Text("Xóa tất cả bộ lọc")
            }
          }
        }

        val renderGroupCard: @Composable (SessionGroup) -> Unit = { group ->
          SessionGroupCard(
            group = group,
            expanded = state.expandedSessionIds.contains(group.id),
            selectionMode = state.isMultiSelectActive,
            selectedIds = state.selectedIds,
            onToggleExpanded = { viewModel.toggleSessionExpanded(group.id) },
            onToggleSelectSession = { viewModel.toggleSessionSelection(group) },
            onSessionAction = { act ->
              if (act == "start" || act == "resume") requestNotificationPermissionIfNeeded()
              viewModel.requestSessionAction(group, act)
            },
            onAddEmptyTorrentToSession = {
              viewModel.createEmptySession(group.id, onCreated = onOpenSessionDetail)
            },
            onImportTorrentToSession = {
              pendingImportSessionId = group.id
              showImportSourceSheet = true
            },
            onRenameSession = { renameTargetGroup = group },
            onDeleteSession = { viewModel.requestDeleteSessionGroup(group) },
            onTorrentClick = { item ->
              if (state.isMultiSelectActive) viewModel.toggleSelection(item.id)
              else onOpenSessionDetail(item.id)
            },
            onTorrentLongClick = { item -> viewModel.toggleSelection(item.id) },
            onTorrentStart = { item ->
              requestNotificationPermissionIfNeeded()
              viewModel.startSession(item)
            },
            onTorrentPause = { item -> viewModel.pauseSession(item) },
            onTorrentResume = { item ->
              requestNotificationPermissionIfNeeded()
              viewModel.resumeSession(item)
            },
            onTorrentStop = { item -> viewModel.stopSession(item) },
          )
        }

        when {
          state.isLoading -> RustatioLoadingSkeleton(cardCount = 3)
          state.sessionGroups.isEmpty() -> {
            RustatioEmptyState(
              icon = Icons.Rounded.UploadFile,
              title = "Chưa có phiên nào",
              description =
                "Nhấn \"Nhập Torrent\" để chọn tệp .torrent hoặc thư mục từ thiết bị, hoặc \"Thêm phiên\" để tạo nhóm phiên mới.",
              primaryActionLabel = "Nhập tệp .torrent",
              onPrimaryAction = {
                pendingImportSessionId = null
                torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*"))
              },
              actionTestTag = "sessions_empty_import_button",
            )
          }
          state.filteredGroups.isEmpty() -> {
            RustatioEmptyState(
              icon = Icons.Rounded.Search,
              title = "Không tìm thấy phiên phù hợp",
              description = "Thử thay đổi từ khóa tìm kiếm hoặc bỏ bớt điều kiện lọc hiện tại.",
              primaryActionLabel = "Đặt lại bộ lọc",
              onPrimaryAction = { viewModel.clearAllFilters() },
              actionTestTag = "sessions_empty_reset_filter",
            )
          }
          isTablet -> {
            LazyVerticalGrid(
              columns = GridCells.Fixed(2),
              verticalArrangement = Arrangement.spacedBy(12.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(bottom = 96.dp),
              modifier = Modifier.fillMaxSize().testTag("sessions_list"),
            ) {
              items(state.filteredGroups, key = { it.id }) { renderGroupCard(it) }
              item(span = { GridItemSpan(2) }) { Spacer(Modifier.height(4.dp)) }
            }
          }
          else -> {
            LazyColumn(
              verticalArrangement = Arrangement.spacedBy(12.dp),
              contentPadding = PaddingValues(bottom = 96.dp),
              modifier = Modifier.fillMaxSize().testTag("sessions_list"),
            ) {
              items(state.filteredGroups, key = { it.id }) { renderGroupCard(it) }
            }
          }
        }
      }
    }
  }

  ImportSourcePickerSheet(
    visible = showImportSourceSheet,
    onPickFiles = { torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*")) },
    onPickFolder = { folderPicker.launch(null) },
    onDismiss = { showImportSourceSheet = false },
  )

  AddSessionActionSheet(
    visible = showAddSheet,
    onPickFiles = {
      pendingImportSessionId = null
      torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*"))
    },
    onPickFolder = {
      pendingImportSessionId = null
      folderPicker.launch(null)
    },
    onCreateSessionGroup = { showCreateSessionDialog = true },
    onCreateEmptyTorrent = { viewModel.createEmptySession(onCreated = onOpenSessionDetail) },
    onDismiss = { showAddSheet = false },
  )

  CreateSessionDialog(
    visible = showCreateSessionDialog,
    onConfirm = { name, alsoEmpty ->
      showCreateSessionDialog = false
      viewModel.createSessionGroup(
        name = name,
        alsoCreateEmptyTorrent = alsoEmpty,
        onOpenCreatedTorrent = onOpenSessionDetail,
      )
    },
    onDismiss = { showCreateSessionDialog = false },
  )

  RenameSessionDialog(
    sessionName = renameTargetGroup?.name,
    onConfirm = { newName ->
      val target = renameTargetGroup
      renameTargetGroup = null
      if (target != null) viewModel.renameSessionGroup(target.id, newName)
    },
    onDismiss = { renameTargetGroup = null },
  )

  SessionsFilterSheet(
    visible = showFilterSheet,
    state = state,
    onStatusFilter = viewModel::setStatusFilter,
    onTagFilter = viewModel::setTagFilter,
    onTrackerFilter = viewModel::setTrackerFilter,
    onReset = viewModel::clearAllFilters,
    onDismiss = { showFilterSheet = false },
  )

  BulkTagDialog(
    visible = showTagDialog,
    selectedCount = state.selectedIds.size,
    onSave = { viewModel.saveTagsForSelected(it) },
    onDismiss = { showTagDialog = false },
  )

  state.importDialog?.let { importDraft ->
    TorrentImportSheet(
      dialogState = importDraft,
      runMode = state.runMode,
      serverOnline = state.serverOnline,
      sessionGroups = state.sessionGroups,
      presets = state.presets,
      onUpdate = viewModel::updateImportDialog,
      onSelectPreset = viewModel::selectImportPreset,
      onSelectClient = viewModel::selectImportClient,
      onPickMoreFiles = { torrentPicker.launch(arrayOf("application/x-bittorrent", "*/*")) },
      onPickMoreFolder = { folderPicker.launch(null) },
      onDismiss = { viewModel.dismissImportDialog() },
      onConfirm = {
        viewModel.confirmImport(onAutoStarted = { requestNotificationPermissionIfNeeded() })
      },
    )
  }

  val pending = state.pendingConfirmAction
  RustatioConfirmDialog(
    visible = pending != null,
    title = pending?.title.orEmpty(),
    message = pending?.message.orEmpty(),
    confirmLabel = pending?.confirmLabel ?: "Xác nhận",
    isDestructive = pending?.isDestructive == true,
    onConfirm = { viewModel.confirmPendingAction() },
    onDismiss = { viewModel.dismissPendingAction() },
  )
}
