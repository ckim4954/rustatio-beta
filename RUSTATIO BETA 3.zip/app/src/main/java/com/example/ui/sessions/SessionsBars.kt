package com.example.ui.sessions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Label
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FilterList
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.Formatters
import com.example.domain.model.RunMode
import com.example.ui.theme.MonoMetricLarge
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SessionsTopBar(
  state: SessionsUiState,
  onClearSelection: () -> Unit,
  onSelectAll: () -> Unit,
  onBulkStart: () -> Unit,
  onBulkPause: () -> Unit,
  onBulkStop: () -> Unit,
  onBulkTag: () -> Unit,
  onBulkDelete: () -> Unit,
  onRefreshServer: () -> Unit,
  onOpenFilters: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  if (state.isMultiSelectActive) {
    TopAppBar(
      colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.surfaceElevated),
      navigationIcon = {
        IconButton(
          onClick = onClearSelection,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_clear_button"),
        ) {
          Icon(Icons.Rounded.Close, contentDescription = "Bỏ chọn")
        }
      },
      title = {
        Text(
          text = "Đã chọn ${state.selectedIds.size} torrent",
          style = MaterialTheme.typography.titleMedium,
        )
      },
      actions = {
        IconButton(
          onClick = onSelectAll,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_select_all_button"),
        ) {
          Icon(Icons.Rounded.SelectAll, contentDescription = "Chọn tất cả")
        }
        IconButton(
          onClick = onBulkStart,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_start_button"),
        ) {
          Icon(Icons.Rounded.PlayArrow, contentDescription = "Bắt đầu", tint = colors.upload)
        }
        IconButton(
          onClick = onBulkPause,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_pause_button"),
        ) {
          Icon(Icons.Rounded.Pause, contentDescription = "Tạm dừng", tint = colors.warning)
        }
        IconButton(
          onClick = onBulkStop,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_stop_button"),
        ) {
          Icon(Icons.Rounded.Stop, contentDescription = "Dừng", tint = colors.error)
        }
        IconButton(
          onClick = onBulkTag,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_tag_button"),
        ) {
          Icon(Icons.AutoMirrored.Rounded.Label, contentDescription = "Gắn thẻ")
        }
        IconButton(
          onClick = onBulkDelete,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("bulk_delete_button"),
        ) {
          Icon(Icons.Rounded.Delete, contentDescription = "Xóa", tint = colors.error)
        }
      },
    )
  } else {
    TopAppBar(
      colors = TopAppBarDefaults.topAppBarColors(containerColor = colors.background),
      title = {
        Column {
          Text(
            text = "Phiên",
            style = MaterialTheme.typography.headlineMedium,
            color = colors.textPrimary,
          )
          Text(
            text =
              if (state.runMode == RunMode.SERVER) {
                if (state.serverOnline) "Rustatio Server · Đã kết nối"
                else "Rustatio Server · Ngoại tuyến"
              } else {
                "${state.totalSessionsCount} phiên · ${state.totalCount} torrent · ↑ ${Formatters.formatSpeedKBs(state.totalUploadRateKBs)}"
              },
            style = MaterialTheme.typography.bodySmall,
            color =
              if (state.runMode == RunMode.SERVER && !state.serverOnline) colors.warning
              else colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      },
      actions = {
        if (state.runMode == RunMode.SERVER) {
          IconButton(
            onClick = onRefreshServer,
            modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("sessions_refresh_button"),
          ) {
            Icon(Icons.Rounded.Refresh, contentDescription = "Làm mới máy chủ")
          }
        }
        IconButton(
          onClick = onOpenFilters,
          modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("sessions_filter_button"),
        ) {
          BadgedBox(
            badge = {
              if (state.activeFilterCount > 0) {
                Badge { Text(state.activeFilterCount.toString()) }
              }
            }
          ) {
            Icon(Icons.Rounded.FilterList, contentDescription = "Bộ lọc phiên")
          }
        }
      },
    )
  }
}

@Composable
fun SessionsRecoveryBanner(
  count: Int,
  onDismiss: () -> Unit,
  onRestore: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    modifier = Modifier.fillMaxWidth().testTag("sessions_recovery_banner"),
    shape = RoundedCornerShape(14.dp),
    color = colors.download.copy(alpha = 0.12f),
    border = BorderStroke(1.dp, colors.download.copy(alpha = 0.4f)),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Text(
        text = "Phát hiện $count torrent từng chạy khi ứng dụng bị hệ thống đóng. Bạn có muốn khôi phục?",
        style = MaterialTheme.typography.bodyMedium,
        color = colors.textPrimary,
      )
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
      ) {
        TextButton(
          onClick = onDismiss,
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("recovery_dismiss_btn"),
        ) {
          Text("Bỏ qua")
        }
        Spacer(Modifier.width(8.dp))
        Button(
          onClick = onRestore,
          modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("recovery_restore_btn"),
        ) {
          Text("Khôi phục chạy")
        }
      }
    }
  }
}

@Composable
fun SessionsPrimaryActionRow(
  onImportTorrentClick: () -> Unit,
  onAddSessionClick: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Button(
      onClick = onImportTorrentClick,
      modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("sessions_import_torrent_btn"),
    ) {
      Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(Modifier.width(6.dp))
      Text("Nhập Torrent", maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    OutlinedButton(
      onClick = onAddSessionClick,
      modifier = Modifier.weight(1f).defaultMinSize(minHeight = 48.dp).testTag("sessions_add_session_btn"),
    ) {
      Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(Modifier.width(6.dp))
      Text("Thêm phiên", maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
  }
}

@Composable
fun SessionsSummaryPillRow(
  state: SessionsUiState,
  onSelectFilter: (SessionStatusFilter) -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  Row(
    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    SummaryPillCard(
      label = "Tổng torrent",
      count = state.totalCount,
      selected = state.statusFilter == SessionStatusFilter.ALL,
      accent = colors.primary,
      onClick = { onSelectFilter(SessionStatusFilter.ALL) },
      testTag = "summary_all",
    )
    SummaryPillCard(
      label = "Đang chạy",
      count = state.runningCount,
      selected = state.statusFilter == SessionStatusFilter.RUNNING,
      accent = colors.upload,
      onClick = { onSelectFilter(SessionStatusFilter.RUNNING) },
      testTag = "summary_running",
    )
    SummaryPillCard(
      label = "Tạm dừng",
      count = state.pausedCount,
      selected = state.statusFilter == SessionStatusFilter.PAUSED,
      accent = colors.warning,
      onClick = { onSelectFilter(SessionStatusFilter.PAUSED) },
      testTag = "summary_paused",
    )
    SummaryPillCard(
      label = "Đã dừng",
      count = state.stoppedCount,
      selected = state.statusFilter == SessionStatusFilter.STOPPED,
      accent = colors.textSecondary,
      onClick = { onSelectFilter(SessionStatusFilter.STOPPED) },
      testTag = "summary_stopped",
    )
  }
}

@Composable
fun SessionsMultiSelectAndGlobalBar(
  isMultiSelectActive: Boolean,
  onToggleMultiSelect: () -> Unit,
  onGlobalAction: (String) -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  var showGlobalMenu by remember { mutableStateOf(false) }

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    OutlinedButton(
      onClick = onToggleMultiSelect,
      modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("sessions_multiselect_toggle"),
    ) {
      Icon(Icons.Rounded.CheckBox, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(Modifier.width(6.dp))
      Text(if (isMultiSelectActive) "Thoát chọn" else "Chọn nhiều")
    }
    Box(modifier = Modifier.weight(1f)) {
      OutlinedButton(
        onClick = { showGlobalMenu = true },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp).testTag("sessions_global_controls_btn"),
      ) {
        Text("Điều khiển danh sách", maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
      }
      DropdownMenu(expanded = showGlobalMenu, onDismissRequest = { showGlobalMenu = false }) {
        DropdownMenuItem(
          leadingIcon = { Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = colors.upload) },
          text = { Text("Bắt đầu tất cả") },
          onClick = {
            showGlobalMenu = false
            onGlobalAction("start")
          },
        )
        DropdownMenuItem(
          leadingIcon = { Icon(Icons.Rounded.Pause, contentDescription = null, tint = colors.warning) },
          text = { Text("Tạm dừng tất cả") },
          onClick = {
            showGlobalMenu = false
            onGlobalAction("pause")
          },
        )
        DropdownMenuItem(
          leadingIcon = { Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = colors.primary) },
          text = { Text("Tiếp tục tất cả") },
          onClick = {
            showGlobalMenu = false
            onGlobalAction("resume")
          },
        )
        DropdownMenuItem(
          leadingIcon = { Icon(Icons.Rounded.Stop, contentDescription = null, tint = colors.error) },
          text = { Text("Dừng tất cả", color = colors.error) },
          onClick = {
            showGlobalMenu = false
            onGlobalAction("stop")
          },
        )
      }
    }
  }
}

@Composable
private fun SummaryPillCard(
  label: String,
  count: Int,
  selected: Boolean,
  accent: Color,
  onClick: () -> Unit,
  testTag: String,
) {
  val colors = RustatioThemeTokens.colors
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(14.dp),
    color = if (selected) accent.copy(alpha = 0.16f) else colors.surface,
    border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) accent else colors.border),
    modifier = Modifier.defaultMinSize(minWidth = 88.dp, minHeight = 48.dp).testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = if (selected) accent else colors.textSecondary,
      )
      Text(
        text = count.toString(),
        style = MonoMetricLarge,
        color = colors.textPrimary,
      )
    }
  }
}
