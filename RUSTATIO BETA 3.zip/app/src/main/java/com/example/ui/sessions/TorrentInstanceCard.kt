package com.example.ui.sessions

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckBox
import androidx.compose.material.icons.rounded.CheckBoxOutlineBlank
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.model.FakerState
import com.example.domain.model.Formatters
import com.example.domain.model.InstanceItem
import com.example.ui.components.StatusBadge
import com.example.ui.theme.MonoMetricMedium
import com.example.ui.theme.MonoMetricSmall
import com.example.ui.theme.RustatioThemeTokens

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun TorrentInstanceCard(
  item: InstanceItem,
  selected: Boolean,
  selectionMode: Boolean,
  onClick: () -> Unit,
  onLongClick: () -> Unit,
  onStart: () -> Unit,
  onPause: () -> Unit,
  onResume: () -> Unit,
  onStop: () -> Unit,
) {
  val colors = RustatioThemeTokens.colors
  val torrent = item.torrent
  val stats = item.stats

  val targetProgress =
    when {
      item.config.stopAtRatioEnabled && stats.ratioProgress > 0.0 -> (stats.ratioProgress / 100.0).toFloat()
      item.config.stopAtUploadedEnabled && stats.uploadProgress > 0.0 -> (stats.uploadProgress / 100.0).toFloat()
      item.config.stopAtDownloadedEnabled && stats.downloadProgress > 0.0 -> (stats.downloadProgress / 100.0).toFloat()
      item.config.stopAtSeedTimeEnabled && stats.seedTimeProgress > 0.0 -> (stats.seedTimeProgress / 100.0).toFloat()
      else -> (stats.torrentCompletion / 100.0).toFloat()
    }.coerceIn(0f, 1f)

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)
        .testTag("session_card_${item.id}"),
    shape = RoundedCornerShape(14.dp),
    color = if (selected) colors.primaryContainer.copy(alpha = 0.55f) else colors.surfaceSubtle,
    border =
      BorderStroke(
        width = if (selected) 1.5.dp else 1.dp,
        color = if (selected) colors.primary else colors.border.copy(alpha = 0.8f),
      ),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        if (selectionMode) {
          Icon(
            imageVector =
              if (selected) Icons.Rounded.CheckBox else Icons.Rounded.CheckBoxOutlineBlank,
            contentDescription = if (selected) "Đã chọn" else "Chưa chọn",
            tint = if (selected) colors.primary else colors.textSecondary,
            modifier = Modifier.padding(top = 2.dp),
          )
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = item.displayName,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = colors.textPrimary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(Modifier.height(2.dp))
          Text(
            text =
              buildString {
                append(item.config.clientType.displayName)
                append(" ")
                append(item.config.clientVersion)
                append(" · Cổng ")
                append(item.config.port)
                if (torrent != null) {
                  append(" · ")
                  append(Formatters.formatBytes(torrent.totalSize))
                }
              },
            style = MaterialTheme.typography.bodySmall,
            color = colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
        StatusBadge(state = item.effectiveState, isIdling = stats.isIdling)
      }

      if (item.tags.isNotEmpty() || torrent != null) {
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          if (torrent != null) {
            Surface(shape = RoundedCornerShape(8.dp), color = colors.surfaceElevated) {
              Text(
                text = torrent.primaryTrackerHost,
                style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
          item.tags.take(3).forEach { tag ->
            Surface(shape = RoundedCornerShape(8.dp), color = colors.primaryContainer) {
              Text(
                text = "#$tag",
                style = MaterialTheme.typography.labelSmall,
                color = colors.primary,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text("Tải lên", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
          Text(
            text = Formatters.formatBytes(stats.uploadedBytes),
            style = MonoMetricMedium,
            color = colors.upload,
          )
          Text(
            text = Formatters.formatSpeedKBs(stats.currentUploadRateKBs),
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
        Column(modifier = Modifier.weight(1f)) {
          Text("Tải xuống", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
          Text(
            text = Formatters.formatBytes(stats.downloadedBytes),
            style = MonoMetricMedium,
            color = colors.download,
          )
          Text(
            text = Formatters.formatSpeedKBs(stats.currentDownloadRateKBs),
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
        Column(modifier = Modifier.weight(0.75f), horizontalAlignment = Alignment.End) {
          Text("Tỷ lệ", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
          Text(
            text = Formatters.formatRatio(stats.ratio),
            style = MonoMetricMedium,
            color = colors.ratio,
          )
          Text(
            text = "${stats.seeders}S / ${stats.leechers}L",
            style = MonoMetricSmall,
            color = colors.textSecondary,
          )
        }
      }

      LinearProgressIndicator(
        progress = { targetProgress },
        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(4.dp)),
        color = if (item.effectiveState == FakerState.RUNNING) colors.upload else colors.primary,
        trackColor = colors.surfaceElevated,
      )

      HorizontalDivider(color = colors.border.copy(alpha = 0.5f))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text =
            if (stats.trackerError != null) "Tracker: ${stats.trackerError}"
            else item.statusMessage,
          style = MaterialTheme.typography.bodySmall,
          color = if (stats.trackerError != null) colors.warning else colors.textSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f).padding(end = 8.dp),
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          when (item.effectiveState) {
            FakerState.RUNNING, FakerState.STARTING -> {
              OutlinedButton(
                onClick = onPause,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("card_pause_${item.id}"),
                contentPadding = PaddingValues(horizontal = 12.dp),
              ) {
                Icon(Icons.Rounded.Pause, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Tạm dừng")
              }
              IconButton(
                onClick = onStop,
                modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("card_stop_${item.id}"),
              ) {
                Icon(Icons.Rounded.Stop, contentDescription = "Dừng", tint = colors.error)
              }
            }
            FakerState.PAUSED -> {
              Button(
                onClick = onResume,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("card_resume_${item.id}"),
                contentPadding = PaddingValues(horizontal = 12.dp),
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Tiếp tục")
              }
              IconButton(
                onClick = onStop,
                modifier = Modifier.defaultMinSize(48.dp, 48.dp).testTag("card_stop_${item.id}"),
              ) {
                Icon(Icons.Rounded.Stop, contentDescription = "Dừng", tint = colors.error)
              }
            }
            else -> {
              Button(
                onClick = onStart,
                enabled = torrent != null,
                modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("card_start_${item.id}"),
                contentPadding = PaddingValues(horizontal = 14.dp),
              ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Bắt đầu")
              }
            }
          }
        }
      }
    }
  }
}
