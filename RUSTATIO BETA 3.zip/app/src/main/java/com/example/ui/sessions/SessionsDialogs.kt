package com.example.ui.sessions

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportSourcePickerSheet(
  visible: Boolean,
  onPickFiles: () -> Unit,
  onPickFolder: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text("Nhập Torrent", style = MaterialTheme.typography.titleLarge)
      Text(
        "Chọn một hoặc nhiều tệp .torrent, hoặc quét cả thư mục qua Storage Access Framework.",
        style = MaterialTheme.typography.bodySmall,
      )
      Button(
        onClick = {
          onDismiss()
          onPickFiles()
        },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("import_source_files"),
      ) {
        Icon(Icons.Rounded.UploadFile, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Chọn một hoặc nhiều tệp .torrent")
      }
      OutlinedButton(
        onClick = {
          onDismiss()
          onPickFolder()
        },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("import_source_folder"),
      ) {
        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Chọn thư mục chứa .torrent (Android SAF)")
      }
      Spacer(Modifier.height(16.dp))
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSessionActionSheet(
  visible: Boolean,
  onPickFiles: () -> Unit,
  onPickFolder: () -> Unit,
  onCreateSessionGroup: () -> Unit,
  onCreateEmptyTorrent: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text("Thêm phiên hoặc nhập Torrent", style = MaterialTheme.typography.titleLarge)
      Button(
        onClick = {
          onDismiss()
          onPickFiles()
        },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("add_import_torrent"),
      ) {
        Icon(Icons.Rounded.UploadFile, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Nhập tệp .torrent (một hoặc nhiều)")
      }
      OutlinedButton(
        onClick = {
          onDismiss()
          onPickFolder()
        },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("add_import_folder"),
      ) {
        Icon(Icons.Rounded.FolderOpen, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Nhập từ thư mục .torrent (SAF)")
      }
      OutlinedButton(
        onClick = {
          onDismiss()
          onCreateSessionGroup()
        },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("add_create_session_group"),
      ) {
        Icon(Icons.Rounded.CreateNewFolder, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Tạo nhóm Phiên mới")
      }
      OutlinedButton(
        onClick = {
          onDismiss()
          onCreateEmptyTorrent()
        },
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 52.dp).testTag("add_create_empty"),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Tạo phiên trống để cấu hình")
      }
      Spacer(Modifier.height(16.dp))
    }
  }
}

@Composable
fun CreateSessionDialog(
  visible: Boolean,
  onConfirm: (name: String, alsoEmptyTorrent: Boolean) -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  var nameInput by remember { mutableStateOf("") }
  var createEmptyTorrent by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Tạo phiên mới") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          "Một Phiên dùng để nhóm và điều khiển chung nhiều torrent độc lập.",
          style = MaterialTheme.typography.bodySmall,
        )
        OutlinedTextField(
          value = nameInput,
          onValueChange = { nameInput = it },
          label = { Text("Tên phiên *") },
          placeholder = { Text("Ví dụ: Phiên Seed Đêm") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("create_session_name_input"),
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Checkbox(
            checked = createEmptyTorrent,
            onCheckedChange = { createEmptyTorrent = it },
          )
          Text(
            "Tạo kèm 1 torrent trống để cấu hình ngay",
            style = MaterialTheme.typography.bodySmall,
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onConfirm(nameInput.trim().ifBlank { "Phiên mới" }, createEmptyTorrent)
        },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp).testTag("create_session_confirm_btn"),
      ) {
        Text("Tạo phiên")
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier.defaultMinSize(minHeight = 48.dp),
      ) {
        Text("Hủy")
      }
    },
  )
}

@Composable
fun RenameSessionDialog(
  sessionName: String?,
  onConfirm: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  if (sessionName == null) return
  var nameInput by remember(sessionName) { mutableStateOf(sessionName) }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Đổi tên phiên") },
    text = {
      OutlinedTextField(
        value = nameInput,
        onValueChange = { nameInput = it },
        label = { Text("Tên phiên mới *") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
      )
    },
    confirmButton = {
      Button(
        onClick = { if (nameInput.isNotBlank()) onConfirm(nameInput.trim()) },
        enabled = nameInput.isNotBlank(),
        modifier = Modifier.defaultMinSize(minHeight = 48.dp),
      ) {
        Text("Lưu")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.defaultMinSize(minHeight = 48.dp)) {
        Text("Hủy")
      }
    },
  )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SessionsFilterSheet(
  visible: Boolean,
  state: SessionsUiState,
  onStatusFilter: (SessionStatusFilter) -> Unit,
  onTagFilter: (String?) -> Unit,
  onTrackerFilter: (String?) -> Unit,
  onReset: () -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("Bộ lọc phiên & torrent", style = MaterialTheme.typography.titleLarge)
        TextButton(
          onClick = {
            onReset()
            onDismiss()
          }
        ) {
          Text("Đặt lại")
        }
      }
      Text("Trạng thái", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        SessionStatusFilter.entries.forEach { f ->
          FilterChip(
            selected = state.statusFilter == f,
            onClick = { onStatusFilter(f) },
            label = { Text(f.labelVi) },
          )
        }
      }
      Text("Thẻ (Tag)", style = MaterialTheme.typography.titleSmall)
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
          selected = state.tagFilter == null,
          onClick = { onTagFilter(null) },
          label = { Text("Tất cả") },
        )
        FilterChip(
          selected = state.tagFilter == SessionsViewModel.TAG_UNTAGGED,
          onClick = { onTagFilter(SessionsViewModel.TAG_UNTAGGED) },
          label = { Text("Chưa gắn thẻ") },
        )
        state.availableTags.forEach { tag ->
          FilterChip(
            selected = state.tagFilter == tag,
            onClick = { onTagFilter(tag) },
            label = { Text(tag) },
          )
        }
      }
      if (state.availableTrackers.isNotEmpty()) {
        Text("Tracker", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = state.trackerFilter == null,
            onClick = { onTrackerFilter(null) },
            label = { Text("Tất cả") },
          )
          state.availableTrackers.forEach { host ->
            FilterChip(
              selected = state.trackerFilter == host,
              onClick = { onTrackerFilter(host) },
              label = { Text(host, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            )
          }
        }
      }
      Button(
        onClick = onDismiss,
        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 48.dp),
      ) {
        Text("Áp dụng")
      }
      Spacer(Modifier.height(12.dp))
    }
  }
}

@Composable
fun BulkTagDialog(
  visible: Boolean,
  selectedCount: Int,
  onSave: (String) -> Unit,
  onDismiss: () -> Unit,
) {
  if (!visible) return
  var tagInput by remember { mutableStateOf("") }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Gắn thẻ cho $selectedCount torrent") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          "Nhập danh sách thẻ cách nhau bằng dấu phẩy. Để trống nếu muốn xóa hết thẻ.",
          style = MaterialTheme.typography.bodySmall,
        )
        OutlinedTextField(
          value = tagInput,
          onValueChange = { tagInput = it },
          placeholder = { Text("Ví dụ: tracker-chinh, seedbox, ưu tiên") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(tagInput)
          onDismiss()
        },
        modifier = Modifier.defaultMinSize(minHeight = 48.dp),
      ) {
        Text("Lưu thẻ")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss, modifier = Modifier.defaultMinSize(minHeight = 48.dp)) {
        Text("Hủy")
      }
    },
  )
}
